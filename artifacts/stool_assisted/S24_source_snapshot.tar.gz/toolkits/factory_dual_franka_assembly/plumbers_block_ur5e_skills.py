from __future__ import annotations

import copy
import math
import os
import json
from collections import OrderedDict
from typing import Any

import numpy as np

from toolkits.factory_dual_franka_assembly.planner_primitives import (
    compose_pose,
    euler_xyz_to_quat,
    normalize_quat,
    pose_error,
    quat_multiply,
    quat_rotate,
)

def _quat_from_axes(x_axis: np.ndarray, y_axis: np.ndarray, z_axis: np.ndarray) -> np.ndarray:
    matrix = np.column_stack((x_axis, y_axis, z_axis))
    trace = float(matrix[0, 0] + matrix[1, 1] + matrix[2, 2])
    if trace > 0.0:
        scale = math.sqrt(trace + 1.0) * 2.0
        quaternion = [
            0.25 * scale,
            (matrix[2, 1] - matrix[1, 2]) / scale,
            (matrix[0, 2] - matrix[2, 0]) / scale,
            (matrix[1, 0] - matrix[0, 1]) / scale,
        ]
    elif matrix[0, 0] > matrix[1, 1] and matrix[0, 0] > matrix[2, 2]:
        scale = math.sqrt(1.0 + matrix[0, 0] - matrix[1, 1] - matrix[2, 2]) * 2.0
        quaternion = [
            (matrix[2, 1] - matrix[1, 2]) / scale,
            0.25 * scale,
            (matrix[0, 1] + matrix[1, 0]) / scale,
            (matrix[0, 2] + matrix[2, 0]) / scale,
        ]
    elif matrix[1, 1] > matrix[2, 2]:
        scale = math.sqrt(1.0 + matrix[1, 1] - matrix[0, 0] - matrix[2, 2]) * 2.0
        quaternion = [
            (matrix[0, 2] - matrix[2, 0]) / scale,
            (matrix[0, 1] + matrix[1, 0]) / scale,
            0.25 * scale,
            (matrix[1, 2] + matrix[2, 1]) / scale,
        ]
    else:
        scale = math.sqrt(1.0 + matrix[2, 2] - matrix[0, 0] - matrix[1, 1]) * 2.0
        quaternion = [
            (matrix[1, 0] - matrix[0, 1]) / scale,
            (matrix[0, 2] + matrix[2, 0]) / scale,
            (matrix[1, 2] + matrix[2, 1]) / scale,
            0.25 * scale,
        ]
    return normalize_quat(quaternion)


def _limit_finger_tilt(direction: np.ndarray, max_tilt_rad: float) -> np.ndarray:
    """Lean from straight down toward `direction`, and stop at `max_tilt_rad`."""

    direction = np.asarray(direction, dtype=float)
    norm = float(np.linalg.norm(direction))
    if norm < 1e-6 or max_tilt_rad <= 0.0:
        return np.array([0.0, 0.0, -1.0], dtype=float)
    direction = direction / norm
    if float(direction[2]) > 0.0:
        direction = -direction
    vertical = np.array([0.0, 0.0, -1.0], dtype=float)
    cosine = float(np.clip(np.dot(direction, vertical), -1.0, 1.0))
    angle = math.acos(cosine)
    if angle <= max_tilt_rad or angle < 1e-4:
        return direction
    horizontal = direction - vertical * cosine
    horizontal_norm = float(np.linalg.norm(horizontal))
    if horizontal_norm < 1e-6:
        return vertical
    horizontal = horizontal / horizontal_norm
    return vertical * math.cos(max_tilt_rad) + horizontal * math.sin(max_tilt_rad)


def _vertical_pad_pose(
    position,
    orientation,
    pad_distance: float,
    reach: float | None = None,
    finger_direction=None,
):
    """Keep the pinch and closing axis, and aim the fingers along `finger_direction`.

    With no direction, the fingers point straight down. The authored approach
    leans along the beam and meets the fixture slot end-on (v76–v78). A caller
    can instead pass the plate's long axis so the pad lies on the face.
    """

    orientation = normalize_quat(orientation)
    finger = np.asarray(quat_rotate(orientation, [0.0, 0.0, 1.0]), dtype=float)
    closing = np.asarray(quat_rotate(orientation, [0.0, 1.0, 0.0]), dtype=float)
    if finger_direction is None:
        down = np.array([0.0, 0.0, -1.0 if float(finger[2]) <= 0.0 else 1.0], dtype=float)
    else:
        down = np.asarray(finger_direction, dtype=float)
        down_norm = float(np.linalg.norm(down))
        if down_norm < 1e-6:
            down = np.array([0.0, 0.0, -1.0], dtype=float)
        else:
            down = down / down_norm
        if float(down[2]) > 0.0:
            down = -down
    pinch = np.asarray(position, dtype=float) + finger * float(pad_distance)
    closing = closing - down * float(np.dot(closing, down))
    closing_norm = float(np.linalg.norm(closing))
    if closing_norm < 1e-6:
        return np.asarray(position, dtype=float), orientation
    closing = closing / closing_norm
    lateral = np.cross(closing, down)
    lateral_norm = float(np.linalg.norm(lateral))
    if lateral_norm < 1e-6:
        return np.asarray(position, dtype=float), orientation
    lateral = lateral / lateral_norm
    closing = np.cross(down, lateral)
    new_orientation = _quat_from_axes(lateral, closing, down)
    if reach is None:
        reach = pad_distance
    new_position = pinch - down * float(reach)
    return new_position, new_orientation


_ARM_JOINT_CONTROLLER = 'arm_joint_controller'
_GRIPPER_CONTROLLER = 'gripper_controller'
_ARM_IK_CONTROLLER = 'arm_ik_controller'
_UR5E_ARM_JOINT_NAMES = (
    'shoulder_pan_joint',
    'shoulder_lift_joint',
    'elbow_joint',
    'wrist_1_joint',
    'wrist_2_joint',
    'wrist_3_joint',
)
_FRANKA_ARM_JOINT_NAMES = tuple(f'panda_joint{index}' for index in range(1, 8))
_SUPPORTED_ARM_JOINT_NAMES = (_FRANKA_ARM_JOINT_NAMES, _UR5E_ARM_JOINT_NAMES)
_CARTESIAN_SERVO_SKILLS = frozenset(
    {
        'ur5e_move_above_part',
        'ur5e_descend_to_grasp',
        'ur5e_retreat_vertical',
        'ur5e_move_part_to_staging',
        'ur5e_move_part_to_table_hover',
        'ur5e_hold_part_end',
    }
)


class UR5eAssemblyAtomicSkillAdapter:
    """Scripted atomic skills for continuous, bounded UR5e assembly motion.

    Each skill computes a Cartesian target, solves IK with the existing Lula solver,
    then sends the result through the joint-position controller.  Completion is
    reported through task.mark_local_skill_complete so recipes can chain the
    five atoms explicitly.
    """

    def __init__(self, spec: dict[str, Any]):
        del spec
        self.spec: dict[str, Any] = {}
        self._last_targets: dict[tuple[Any, ...], dict[str, Any]] = {}
        self._prealign_state: dict[tuple[Any, ...], dict[str, Any]] = {}
        self._phase_locks: dict[tuple[Any, ...], dict[str, np.ndarray]] = {}
        self._close_gate_state: dict[tuple[Any, ...], dict[str, Any]] = {}
        self._preshape_state: dict[tuple[Any, ...], dict[str, Any]] = {}
        self._grasp_slip_state: dict[tuple[Any, ...], dict[str, Any]] = {}
        self._completion_state: dict[tuple[Any, ...], dict[str, Any]] = {}
        self._ik_failure_state: dict[tuple[Any, ...], int] = {}
        self._ik_stall_recovery_state: dict[tuple[Any, ...], dict[str, int]] = {}
        self._locked_transport_ik_targets: dict[tuple[Any, ...], np.ndarray] = {}
        self._pickup_terminal_ik_seeds: dict[tuple[int, str, str], np.ndarray] = {}
        self._continuous_transport_ik_fallbacks: set[tuple[Any, ...]] = set()
        self._last_arm_command_q: dict[str, np.ndarray] = {}
        self._arm_measurement_status: dict[str, dict] = {}
        self._cartesian_command_positions: dict[tuple[Any, ...], np.ndarray] = {}
        self._cartesian_command_orientations: dict[tuple[Any, ...], np.ndarray] = {}
        self._insertion_axial_anchors: dict[tuple[Any, ...], float] = {}
        self._insertion_lateral_alignment_active: dict[tuple[Any, ...], bool] = {}
        self._insertion_lateral_alignment_stable_steps: dict[tuple[Any, ...], int] = {}
        self._insertion_lateral_orientation_anchors: dict[tuple[Any, ...], np.ndarray] = {}
        self._insertion_lateral_clearance_required: dict[tuple[Any, ...], bool] = {}
        self._insertion_lateral_clearance_anchors: dict[tuple[Any, ...], float] = {}
        self._target_object_settle_state: dict[tuple[Any, ...], dict[str, Any]] = {}
        self._physically_relaxed_insertion_objects: set[tuple[int, str]] = set()
        self._completed_insertion_compliance_transitions: dict[tuple[int, str], dict[str, Any]] = {}
        self._insertion_compliance_transition_state: dict[tuple[int, str], dict[str, Any]] = {}
        self._compliant_motion_recovery_state: dict[tuple[int, str], dict[str, Any]] = {}

    def act(  # noqa: C901
        self,
        *,
        task,
        robot_name: str,
        phase_spec: dict,
        skill_spec: dict,
        tracked_robots: dict,
        tracked_objects: dict,
        checkpoint_path: str | None = None,
    ) -> dict | None:
        del checkpoint_path
        spec = {**self.spec, **dict(skill_spec)}
        skill_name = str(spec.get('name', ''))
        phase_key = (
            id(task),
            getattr(task, 'phase_index', None),
            getattr(task, 'phase_entry_step', None),
            robot_name,
            skill_name,
        )
        if spec.get('beam_assisted') and spec.get('beam_assisted_absolute_object_servo'):
            contexts = getattr(task, '_beam_assisted_command_contexts', None)
            if contexts is None:
                contexts = task._beam_assisted_command_contexts = {}
            contexts[robot_name] = {'adapter': self, 'spec': spec, 'phase_key': phase_key,
                'phase_index': getattr(task, 'phase_index', None),
                'phase_entry_step': getattr(task, 'phase_entry_step', None),
                'tracked_robots': tracked_robots, 'tracked_objects': tracked_objects}

        if spec.get('continuous_physics') and self._current_arm_q(task, robot_name) is None:
            return self._failure_or_hold(
                task, robot_name, spec, 'current_joint_state_unavailable',
                diagnostics=self._arm_measurement_status.get(robot_name, {}),
            )

        if (spec.get('trace_pregrasp') and os.environ.get('BEAM_CONTACT_TRACE_PATH')
                and int(task.step_counter) % 8 == 0):
            object_name = self._object_name_from_spec(spec)
            metrics = task._gripper_contact_metrics(object_name, robot_name,
                attach_spec={**spec, 'measure_force_contact': True})
            task._write_physical_contact_trace(object_name, metrics, spec, {},
                                                validation_stage='pregrasp')

        if spec.get('beam_table_seat'):
            return self._beam_table_seat_action(phase_key=phase_key, task=task, robot_name=robot_name,
                spec=spec, tracked_robots=tracked_robots, tracked_objects=tracked_objects)

        if spec.get('hold_previous_grasp_command'):
            return self._hold_previous_grasp_command(task=task, robot_name=robot_name,
                spec=spec, tracked_robots=tracked_robots)

        if skill_name in {'ur5e_preshape_gripper', 'preshape_gripper'}:
            return self._preshape_gripper_action(
                phase_key=phase_key,
                task=task,
                robot_name=robot_name,
                skill_name=skill_name,
                spec=spec,
                tracked_objects=tracked_objects,
            )

        if skill_name in {'ur5e_close_gripper', 'close_gripper'}:
            action = self._hold_joint_action(task=task, robot_name=robot_name)
            close_started_step = 0
            # A plan created later in this act call is absent from the arm
            # command already constructed by the pose gate.
            gate_pending = self._close_gate_state.get(phase_key, {}).get('force_recenter_pending')
            if bool(spec.get('require_close_pose_gate', False)) and not (
                spec.get('beam_assisted_visual_pinch') and
                self._close_gate_state.get(phase_key, {}).get('assisted_visual_close_started')):
                gate_ready, gate_action, gate_detail = self._close_pose_gate_action(
                    phase_key=phase_key,
                    task=task,
                    robot_name=robot_name,
                    spec=spec,
                    tracked_robots=tracked_robots,
                    tracked_objects=tracked_objects,
                )
                if not gate_ready:
                    gate_state = self._close_gate_state.get(phase_key, {})
                    if gate_state.get('close_arm_frozen') or (
                        spec.get('close_force_regulation') and gate_state.get('contact_control_active')
                    ):
                        return self._failure_or_hold(task, robot_name, spec, 'contact_pose_gate_lost', diagnostics=gate_detail)
                    timeout_steps = spec.get('close_pose_gate_timeout_steps')
                    phase_step_counter = int(getattr(task, 'phase_step_counter', 0))
                    stable_progress = int(gate_detail.get('ready_steps', 0))
                    required_stable_steps = max(int(gate_detail.get('required_ready_steps', 1)), 1)
                    timeout_grace_active = bool(
                        stable_progress > 0
                        and timeout_steps is not None
                        and phase_step_counter < int(timeout_steps) + required_stable_steps
                    )
                    if (
                        timeout_steps is not None
                        and phase_step_counter >= int(timeout_steps)
                        and not timeout_grace_active
                    ):
                        return self._failure_or_hold(
                            task,
                            robot_name,
                            spec,
                            'close_pose_gate_timeout',
                            diagnostics=gate_detail,
                        )
                    return gate_action
                state = self._close_gate_state.setdefault(phase_key, {})
                close_started_step = int(state.get('close_started_step', getattr(task, 'phase_step_counter', 0)))
                hold_q = state.get('hold_q')
                action = OrderedDict()
                if hold_q is not None:
                    action[_ARM_JOINT_CONTROLLER] = [np.asarray(hold_q, dtype=float).tolist()]

            if spec.get('beam_assisted_visual_pinch'):
                from .beam_assisted_visual_grasp import close_action
                self._close_gate_state.setdefault(phase_key, {})['assisted_visual_close_started'] = True
                try:
                    action, ready, detail = close_action(task, self, robot_name,
                                                        spec['object'], action)
                except Exception as exc:
                    return self._failure_or_hold(task, robot_name, spec,
                        'assisted_visible_pinch',
                        diagnostics={'error': f'{type(exc).__name__}: {exc}'})
                if ready:
                    self._mark_complete(task=task, robot_name=robot_name,
                                        skill_name=skill_name, detail=detail)
                return action

            hold_steps = max(int(spec.get('hold_steps', spec.get('close_steps', 36))), 0)
            close_elapsed_steps = max(int(getattr(task, 'phase_step_counter', 0)) - int(close_started_step), 0)
            ramp_steps = max(int(spec.get('close_ramp_steps', hold_steps)), 1)
            preclose_openness = float(spec.get('preclose_openness', spec.get('open_openness', 1.0)))
            closed_openness = float(spec.get('closed_openness', spec.get('close_openness', 0.0)))
            ramp_ratio = min(max(float(close_elapsed_steps) / float(ramp_steps), 0.0), 1.0)
            gripper_openness = preclose_openness + ramp_ratio * (closed_openness - preclose_openness)
            action[_GRIPPER_CONTROLLER] = [gripper_openness]
            if bool(spec.get('close_until_contact', False)):
                state = self._close_gate_state.setdefault(phase_key, {})
                close_ready, close_detail = self._close_until_contact_ready(
                    state=state,
                    task=task,
                    robot_name=robot_name,
                    spec=spec,
                    tracked_objects=tracked_objects,
                    close_elapsed_steps=close_elapsed_steps,
                    gripper_openness=gripper_openness,
                )
                if spec.get('close_force_recenter_track_weak_side'):
                    # The task counter is guarded by Beam's real physics tick.
                    # Contact observations expose dt, not a native clock token.
                    state['force_recenter_observation_step'] = int(task.step_counter)
                close_detail['recenter'] = self._update_close_recenter_offset(
                    state=state,
                    close_detail=close_detail,
                    spec=spec,
                    close_ready=close_ready,
                )
                if close_detail['recenter'].get('reason') == 'recenter_motion_timeout':
                    return self._failure_or_hold(task, robot_name, spec, 'close_recenter_motion_timeout', diagnostics=close_detail)
                if spec.get('close_force_regulation'):
                    trace_path = os.environ.get('BEAM_CLOSE_CONTROL_TRACE_PATH')
                    if trace_path:
                        with open(trace_path, 'a', encoding='utf-8') as handle:
                            handle.write(json.dumps({
                                'step': int(task.step_counter), 'phase': task.phase, 'robot': robot_name,
                                'close_elapsed_steps': close_elapsed_steps, 'ready': close_ready,
                                'stable_steps': close_detail.get('stable_steps'),
                                'required_stable_steps': close_detail.get('required_stable_steps'),
                                'gripper_q': close_detail.get('gripper_joint_position'),
                                'control': close_detail.get('control'), 'recenter': close_detail['recenter'],
                                'motion_detail': close_detail.get('motion_detail'),
                                'timing': 'observation at step; command for next physics interval',
                            }) + '\n')
                    if close_detail.get('control_error'):
                        return self._failure_or_hold(task, robot_name, spec, 'contact_control_state_unavailable', diagnostics=close_detail)
                self._debug_close_step(
                    task=task,
                    robot_name=robot_name,
                    skill_name=skill_name,
                    close_elapsed_steps=close_elapsed_steps,
                    gripper_openness=gripper_openness,
                    close_ready=close_ready,
                    close_detail=close_detail,
                )
                hold_openness = state.get('hold_gripper_openness')
                if hold_openness is not None:
                    action[_GRIPPER_CONTROLLER] = [float(hold_openness)]
                if close_ready:
                    if spec.get('continuous_physics') and (
                        spec.get('beam_coordinated') or state.get('hold_command_pose') is not None
                    ):
                        cached_pose = state.get('hold_command_pose')
                        cache_metadata = {}
                        if spec.get('beam_coordinated'):
                            # Joint limiting/freezing can change the requested
                            # pose. Retain FK of the arm target in this action.
                            cached_q = self._coerce_arm_q(
                                (action.get(_ARM_JOINT_CONTROLLER) or [None])[0],
                                bound_revolute=False,
                            )
                            cached_pose = None if cached_q is None else self._grasp_command_fk_pose(
                                task=task, robot_name=robot_name, spec=spec, command_q=cached_q,
                            )
                            try:
                                position = np.asarray(cached_pose['position'], dtype=float)
                                orientation = np.asarray(cached_pose['orientation'], dtype=float)
                                pose_valid = bool(
                                    position.shape == (3,) and orientation.shape == (4,)
                                    and np.all(np.isfinite(position)) and np.all(np.isfinite(orientation))
                                    and np.linalg.norm(orientation) > 1e-9
                                )
                            except (TypeError, KeyError, ValueError):
                                pose_valid = False
                            if not pose_valid:
                                return self._failure_or_hold(
                                    task, robot_name, spec, 'close_grasp_command_cache_unavailable',
                                    diagnostics=close_detail,
                                )
                            cache_metadata = {
                                'step': int(task.step_counter), 'pose_source': 'published_joint_fk',
                            }
                            close_detail.update(
                                grasp_command_cache_step=cache_metadata['step'],
                                grasp_command_cache_pose_source=cache_metadata['pose_source'],
                            )
                        else:
                            cached_q = np.asarray(state['hold_q']).copy()
                        cache = getattr(task, '_ur5e_contact_hold_commands', None)
                        if cache is None:
                            cache = {}
                            task._ur5e_contact_hold_commands = cache
                        cache[robot_name] = {
                            'object': self._object_name_from_spec(spec),
                            'arm_q': cached_q.copy(),
                            'pose': {k: np.asarray(v).copy() for k, v in cached_pose.items()},
                            'gripper_openness': float(hold_openness),
                            **cache_metadata,
                        }
                    if hold_openness is None:
                        self._remember_gripper_hold_openness(
                            task=task,
                            robot_name=robot_name,
                            openness=gripper_openness,
                        )
                    self._mark_complete(
                        task=task,
                        robot_name=robot_name,
                        skill_name=skill_name,
                        detail=close_detail,
                    )
                elif self._close_object_motion_abort(
                    close_detail=close_detail,
                    spec=spec,
                    close_elapsed_steps=close_elapsed_steps,
                ):
                    return self._failure_or_hold(
                        task,
                        robot_name,
                        spec,
                        'close_object_knocked',
                        diagnostics=close_detail,
                    )
                else:
                    timeout_steps = spec.get('close_until_contact_timeout_steps')
                    if timeout_steps is not None and close_elapsed_steps >= int(timeout_steps):
                        return self._failure_or_hold(
                            task,
                            robot_name,
                            spec,
                            'close_until_contact_timeout',
                            diagnostics=close_detail,
                        )
                pending = state.get('force_recenter_pending')
                if (pending is gate_pending and pending is not None
                        and pending.get('lifecycle') == 'planned'):
                    if not self._record_recenter_final_action(
                        state=state, pending=pending, action=action,
                        task=task, robot_name=robot_name, spec=spec,
                    ):
                        return self._failure_or_hold(
                            task, robot_name, spec, 'recenter_final_action_unavailable',
                            diagnostics=close_detail,
                        )
                return action
            if close_elapsed_steps >= hold_steps:
                if bool(spec.get('require_grasp_contact', False)):
                    grasp_ready, grasp_detail = self._grasp_contact_ready(
                        task=task,
                        robot_name=robot_name,
                        spec=spec,
                    )
                    if not grasp_ready:
                        return self._failure_or_hold(
                            task,
                            robot_name,
                            spec,
                            'grasp_contact_not_ready',
                            diagnostics=grasp_detail,
                        )
                self._mark_complete(
                    task=task,
                    robot_name=robot_name,
                    skill_name=skill_name,
                    detail={
                        'closed': True,
                        'hold_steps': hold_steps,
                        'close_elapsed_steps': close_elapsed_steps,
                    },
                )
                self._remember_gripper_hold_openness(
                    task=task,
                    robot_name=robot_name,
                    openness=gripper_openness,
                )
            return action

        if skill_name in {'move_arm_to_joint_positions', 'ur5e_move_arm_to_joint_positions'}:
            return self._move_arm_to_joint_positions_action(
                phase_key=phase_key,
                task=task,
                robot_name=robot_name,
                skill_name=skill_name,
                spec=spec,
            )

        target_pose = self._target_pose(
            phase_key=phase_key,
            task=task,
            robot_name=robot_name,
            spec=spec,
            tracked_robots=tracked_robots,
            tracked_objects=tracked_objects,
        )
        if target_pose is None:
            return self._failure_or_hold(task, robot_name, spec, 'target_pose_unavailable')
        if spec.get('no_descent_during_clearance'):
            target_pose = self._raise_clearance_target(task=task, robot_name=robot_name,
                phase_key=phase_key, spec=spec, target_pose=target_pose)
            if target_pose is None:
                return self._failure_or_hold(task, robot_name, spec, 'clearance_target_unavailable')
        target_pose = self._locked_target_pose(phase_key=phase_key, target_pose=target_pose, spec=spec)

        if spec.get('inherit_grasp_drive_target'):
            return self._grasp_drive_motion(
                phase_key=phase_key, task=task, robot_name=robot_name, spec=spec,
                target_pose=target_pose, tracked_robots=tracked_robots,
                tracked_objects=tracked_objects,
            )

        routed_prealign=(spec.get('fabrica_empty_joint_route') or {}).get('replace_prealign') is True
        if routed_prealign:
            route_action=self._stool_empty_joint_route_action(
                phase_key=phase_key,task=task,robot_name=robot_name,skill_name=skill_name,
                spec=spec,target_pose=target_pose)
            if route_action is not None:
                return route_action
        prealign_action = (None if routed_prealign else self._prealign_action(
            phase_key=phase_key,
            task=task,
            robot_name=robot_name,
            target_pose=target_pose,
            spec=spec,
        ))
        if prealign_action is not None:
            return prealign_action

        raw_current_pose = self._current_robot_pose(task=task, robot_name=robot_name, tracked_robots=tracked_robots)
        current_pose = self._current_tcp_pose(current_pose=raw_current_pose, spec=spec)
        slip_failure = self._object_tcp_slip_failure(
            phase_key=phase_key,
            task=task,
            robot_name=robot_name,
            spec=spec,
            tracked_objects=tracked_objects,
            current_pose=current_pose,
        )
        if slip_failure is not None:
            return self._failure_or_hold(
                task,
                robot_name,
                spec,
                'object_tcp_slip',
                diagnostics=slip_failure,
            )
        self._debug_transport_step(
            task=task,
            robot_name=robot_name,
            skill_name=skill_name,
            spec=spec,
            target_pose=target_pose,
            current_pose=current_pose,
            tracked_objects=tracked_objects,
        )
        compliance_transition_hold = self._maybe_relax_insertion_attachment(
            task=task,
            spec=spec,
            tracked_objects=tracked_objects,
        )
        object_name = self._object_name_from_spec(spec)
        compliance_transition_key = None if object_name is None else (id(task), object_name)
        if compliance_transition_key in self._completed_insertion_compliance_transitions:
            capture_detail = self._completed_insertion_compliance_transitions.pop(compliance_transition_key)
            self._mark_complete(
                task=task,
                robot_name=robot_name,
                skill_name=skill_name,
                detail={
                    'completion_reason': 'stable_physical_insertion_capture',
                    'object': object_name,
                    'phase': getattr(task, 'phase', None),
                    **capture_detail,
                },
            )
            self._request_insertion_capture_transition(
                task=task,
                robot_name=robot_name,
                skill_name=skill_name,
                spec=spec,
                capture_detail=capture_detail,
            )
            return self._held_transport_action(
                task=task,
                robot_name=robot_name,
                spec=spec,
            )
        if compliance_transition_hold:
            return self._held_transport_action(
                task=task,
                robot_name=robot_name,
                spec=spec,
            )
        recovery_allows_settle = self._compliant_recovery_allows_target_settle(
            task=task,
            spec=spec,
            tracked_objects=tracked_objects,
        )
        if not recovery_allows_settle and self._compliant_motion_requires_hold(
            phase_key=phase_key,
            task=task,
            spec=spec,
            tracked_objects=tracked_objects,
        ):
            return self._held_transport_action(
                task=task,
                robot_name=robot_name,
                spec=spec,
            )
        if spec.get('fabrica_object_se3_transport'):
            return self._stool_clearance_joint_action(
                phase_key=phase_key, task=task, robot_name=robot_name, skill_name=skill_name,
                spec=spec, tracked_objects=tracked_objects, current_pose=current_pose,
                target_pose=target_pose, transport=True)
        if self._target_object_settle_ready(
            phase_key=phase_key,
            task=task,
            spec=spec,
            target_pose=target_pose,
            current_pose=current_pose,
            tracked_objects=tracked_objects,
        ):
            current_q = self._current_arm_q(task, robot_name)
            if spec.get('beam_coordinated') and spec.get('requires_held_object'):
                # Settling keeps the published preload and the loaded grasp's
                # force/measurement protections while the completion gate runs.
                action = self._hold_previous_grasp_command(
                    task=task, robot_name=robot_name, spec=spec,
                    tracked_robots=tracked_robots, target_pose=target_pose,
                )
                if action.get('__local_skill_failure__'):
                    return action
                hold_target_q = np.asarray(action[_ARM_JOINT_CONTROLLER][0], dtype=float)
            elif spec.get('beam_assisted_transition_settle'):
                # Retain the target that really reached the native backend,
                # rather than an earlier pre-clamp adapter command.
                hold_target_q = self._assisted_transition_hold_target(task, robot_name, current_q)
                from .beam_assisted_servo import object_pose_from_tcp
                _, stamp, _, native_object, relative, servo_state = self._assisted_object_servo_context(
                    phase_key=phase_key, task=task, robot_name=robot_name, spec=spec,
                    tracked_robots=tracked_robots, tracked_objects=tracked_objects)
                tcp = self._grasp_command_fk_pose(task=task, robot_name=robot_name,
                                                 spec=spec, command_q=current_q)
                if tcp is None:
                    raise ValueError('assisted transition hold lacks measured-joint FK')
                self._assisted_phase_handoff(task=task, robot_name=robot_name, spec=spec,
                    stamp=stamp, state=servo_state, current_object=native_object,
                    measured_model_object=object_pose_from_tcp(tcp, relative[0], relative[1]),
                    relative=relative, actual_q=current_q)
                action = OrderedDict([(_ARM_JOINT_CONTROLLER, [hold_target_q.tolist()]),
                    (_GRIPPER_CONTROLLER, [self._gripper_command_value(
                        task=task, robot_name=robot_name,
                        command=spec.get('gripper_command', 'contact_hold'))])])
            else:
                action = self._hold_joint_action(task=task, robot_name=robot_name)
                gripper_command = spec.get('gripper_command')
                if gripper_command is None:
                    gripper_command = (
                        'close' if skill_name in {'ur5e_move_part_to_staging', 'ur5e_hold_part_end'} else 'open'
                    )
                action[_GRIPPER_CONTROLLER] = [
                    self._gripper_command_value(
                        task=task,
                        robot_name=robot_name,
                        command=gripper_command,
                    )
                ]
                hold_target_q = current_q
            ik_target_pose = self._ik_target_pose(target_pose=target_pose, spec=spec)
            self._maybe_mark_complete(
                phase_key=phase_key,
                task=task,
                robot_name=robot_name,
                skill_name=skill_name,
                spec=spec,
                target_pose=target_pose,
                ik_target_pose=ik_target_pose,
                current_pose=current_pose,
                tracked_objects=tracked_objects,
                current_q=current_q,
                target_q=hold_target_q,
            )
            return action
        if recovery_allows_settle:
            return self._held_transport_action(
                task=task,
                robot_name=robot_name,
                spec=spec,
            )
        cartesian_servo = bool(spec.get('cartesian_servo', skill_name in _CARTESIAN_SERVO_SKILLS))
        lock_transport_ik_target = self._use_locked_transport_ik_target(spec)
        lock_pickup_ik_target = self._use_locked_pickup_ik_target(
            skill_name=skill_name,
            spec=spec,
            current_pose=current_pose,
            target_pose=target_pose,
            already_locked=phase_key in self._locked_transport_ik_targets,
        )
        lock_cartesian_ik_target = lock_transport_ik_target or lock_pickup_ik_target
        if lock_pickup_ik_target and phase_key not in self._locked_transport_ik_targets:
            object_name = self._object_name_from_spec(spec)
            if object_name is not None:
                terminal_seed = self._pickup_terminal_ik_seeds.get(
                    (id(task), robot_name, object_name)
                )
                terminal_seed = self._coerce_arm_q(
                    terminal_seed,
                    bound_revolute=False,
                )
                if terminal_seed is not None:
                    self._locked_transport_ik_targets[phase_key] = terminal_seed.copy()
                    print(
                        '[assembly-ik-target-lock] '
                        f"step={getattr(task, 'step_counter', None)} "
                        f"phase={getattr(task, 'phase', None)} robot={robot_name} "
                        'source=pickup_terminal_seed',
                        flush=True,
                    )
        if spec.get('fabrica_empty_joint_route'):
            route_action = self._stool_empty_joint_route_action(
                phase_key=phase_key, task=task, robot_name=robot_name, skill_name=skill_name,
                spec=spec, target_pose=target_pose)
            if route_action is not None:
                return route_action
        if spec.get('fabrica_object_se3_clearance'):
            return self._stool_clearance_joint_action(
                phase_key=phase_key, task=task, robot_name=robot_name, skill_name=skill_name,
                spec=spec, tracked_objects=tracked_objects, current_pose=current_pose,
                target_pose=target_pose)

        command_target_pose = target_pose
        if cartesian_servo and current_pose is not None and not lock_cartesian_ik_target:
            orientation_first_pose = self._orientation_first_servo_pose(
                skill_name=skill_name,
                spec=spec,
                current_pose=current_pose,
                target_pose=target_pose,
                phase_step_counter=int(getattr(task, 'phase_step_counter', 0)),
            )
            if orientation_first_pose is not None:
                command_target_pose = orientation_first_pose
            else:
                command_target_pose = self._target_object_servo_pose(
                    phase_key=phase_key,
                    task=task,
                    robot_name=robot_name,
                    spec=spec,
                    tracked_robots=tracked_robots,
                    tracked_objects=tracked_objects,
                    current_pose=current_pose,
                    target_pose=target_pose,
                )

        ik_target_pose = self._ik_target_pose(target_pose=command_target_pose, spec=spec)
        use_arm_ik_controller = bool(spec.get('use_arm_ik_controller', False))
        # Raw Cartesian IK can choose a different UR5e branch between frames.  Keep it
        # opt-in and otherwise route through the joint-limited IK path below.
        if use_arm_ik_controller and bool(spec.get('allow_direct_arm_ik_controller', False)):
            current_q = self._current_arm_q(task, robot_name)
            action = OrderedDict()
            action[_ARM_IK_CONTROLLER] = [
                np.asarray(ik_target_pose['position'], dtype=float).tolist(),
                np.asarray(ik_target_pose['orientation'], dtype=float).tolist(),
            ]
            gripper_command = spec.get('gripper_command')
            if gripper_command is None:
                gripper_command = (
                    'close' if skill_name in {'ur5e_move_part_to_staging', 'ur5e_hold_part_end'} else 'open'
                )
            action[_GRIPPER_CONTROLLER] = [
                self._gripper_command_value(task=task, robot_name=robot_name, command=gripper_command)
            ]
            self._debug_joint_step(
                task=task,
                robot_name=robot_name,
                skill_name=skill_name,
                spec=spec,
                current_pose=current_pose,
                target_pose=target_pose,
                command_target_pose=command_target_pose,
                ik_target_pose=ik_target_pose,
                current_q=current_q,
                reference_q=current_q,
                target_q=None,
                command_q=None,
            )
            self._last_targets[phase_key] = {
                'position': target_pose['position'].copy(),
                'orientation': target_pose['orientation'].copy(),
            }
            self._remember_cartesian_command_position(
                phase_key=phase_key,
                command_target_pose=command_target_pose,
            )
            self._remember_cartesian_command_orientation(
                phase_key=phase_key,
                command_target_pose=command_target_pose,
            )
            self._maybe_mark_complete(
                phase_key=phase_key,
                task=task,
                robot_name=robot_name,
                skill_name=skill_name,
                spec=spec,
                target_pose=target_pose,
                ik_target_pose=ik_target_pose,
                current_pose=current_pose,
                tracked_objects=tracked_objects,
                current_q=current_q,
                target_q=None,
            )
            return action

        current_q = self._current_arm_q(task, robot_name)
        reference_q = self._command_reference_q(task=task, robot_name=robot_name, current_q=current_q, spec=spec)
        # Once an exact free-space endpoint has been rejected, the Cartesian
        # continuation may need Lula's global seed set for a nearby waypoint.
        # Keep the normal warm-start contract for all other phases, but do not
        # repeatedly ask a known-failed local-only solve to cross that boundary.
        ik_solve_spec = spec
        if lock_cartesian_ik_target:
            ik_result = self._locked_transport_ik_target(
                phase_key=phase_key,
                task=task,
                robot_name=robot_name,
                target_pose=ik_target_pose,
                reference_q=reference_q,
                spec=spec,
            )
            if phase_key in self._continuous_transport_ik_fallbacks:
                lock_transport_ik_target = False
                lock_pickup_ik_target = False
                lock_cartesian_ik_target = False
                ik_solve_spec = {
                    **spec,
                    'require_warm_start_ik': False,
                    'warm_start_ik_only': False,
                }
                if cartesian_servo and current_pose is not None:
                    command_target_pose = self._target_object_servo_pose(
                        phase_key=phase_key,
                        task=task,
                        robot_name=robot_name,
                        spec=spec,
                        tracked_robots=tracked_robots,
                        tracked_objects=tracked_objects,
                        current_pose=current_pose,
                        target_pose=target_pose,
                    )
                ik_target_pose = self._ik_target_pose(target_pose=command_target_pose, spec=spec)
                ik_result = self._solve_ik(
                    task=task,
                    robot_name=robot_name,
                    target_pose=ik_target_pose,
                    warm_start=reference_q,
                    spec=ik_solve_spec,
                )
                warm_start_stalled = self._ik_solution_stalled(
                    ik_result=ik_result,
                    measured_q=current_q,
                    warm_start_q=reference_q,
                    current_pose=current_pose,
                    command_target_pose=command_target_pose,
                    spec=spec,
                )
            else:
                warm_start_stalled = False
        else:
            ik_result = self._solve_ik(
                task=task,
                robot_name=robot_name,
                target_pose=ik_target_pose,
                warm_start=reference_q,
                spec=ik_solve_spec,
            )
            warm_start_stalled = self._ik_solution_stalled(
                ik_result=ik_result,
                measured_q=current_q,
                warm_start_q=reference_q,
                current_pose=current_pose,
                command_target_pose=command_target_pose,
                spec=ik_solve_spec,
            )
        if warm_start_stalled:
            # Lula may declare a locally warm-started solve successful while it
            # returns the seed unchanged. Treat that as no solution for a
            # non-trivial Cartesian command and retry its global search.
            stall_state = self._ik_stall_recovery_state.setdefault(phase_key, {})
            stalled_steps = int(stall_state.get('stalled_steps', 0)) + 1
            stall_state['stalled_steps'] = stalled_steps
            reseed_after_steps = max(int(spec.get('ik_stall_reseed_after_steps', 3)), 1)
            retry_interval_steps = max(int(spec.get('ik_stall_reseed_retry_interval_steps', 60)), 1)
            current_step = int(getattr(task, 'step_counter', 0))
            last_reseed_step = int(stall_state.get('last_reseed_step', -retry_interval_steps))
            should_reseed = (
                stalled_steps >= reseed_after_steps
                and current_step - last_reseed_step >= retry_interval_steps
            )
            if should_reseed:
                stall_state['last_reseed_step'] = current_step
                global_result = self._solve_ik(
                    task=task,
                    robot_name=robot_name,
                    target_pose=ik_target_pose,
                    warm_start=None,
                    spec={
                        **ik_solve_spec,
                        'use_command_warm_start': False,
                        'require_warm_start_ik': False,
                        'warm_start_ik_only': False,
                    },
                )
                if not self._ik_solution_stalled(
                    ik_result=global_result,
                    measured_q=current_q,
                    warm_start_q=None,
                    current_pose=current_pose,
                    command_target_pose=command_target_pose,
                    spec=ik_solve_spec,
                ):
                    ik_result = global_result
                    stall_state['stalled_steps'] = 0
                    print(
                        '[assembly-ik-recovery] '
                        f"event=global_reseed step={current_step} "
                        f"phase={getattr(task, 'phase', None)} robot={robot_name} ",
                        flush=True,
                    )
                else:
                    # Do not keep issuing a zero-motion command for an
                    # unreachable target.  The established backtracking and
                    # bounded failure path below can now recover or fail fast.
                    ik_result = None
                    print(
                        '[assembly-ik-recovery] '
                        f"event=stalled_no_global_solution step={current_step} "
                        f"phase={getattr(task, 'phase', None)} robot={robot_name} "
                        f"stalled_steps={stalled_steps}",
                        flush=True,
                    )
            elif stalled_steps >= reseed_after_steps:
                # A prior global solve already rejected this target.  Route
                # this step through backtracking/failure rather than timing
                # out hundreds of identical Cartesian servo commands.
                ik_result = None
        else:
            self._ik_stall_recovery_state.pop(phase_key, None)
        retried_with_measured_state = False
        measured_q = self._coerce_arm_q(current_q)
        if (
            ik_result is None
            and bool(spec.get('ik_retry_with_measured_state', True))
            and measured_q is not None
            and (
                reference_q is None
                or reference_q.shape != measured_q.shape
                or float(np.max(np.abs(reference_q - measured_q))) > 1e-6
            )
        ):
            retried_with_measured_state = True
            ik_result = self._solve_ik(
                task=task,
                robot_name=robot_name,
                target_pose=ik_target_pose,
                warm_start=measured_q,
                spec=ik_solve_spec,
            )
            if self._ik_solution_stalled(
                ik_result=ik_result,
                measured_q=measured_q,
                warm_start_q=measured_q,
                current_pose=current_pose,
                command_target_pose=command_target_pose,
                spec=spec,
            ):
                ik_result = None
        ik_backtrack_ratio = None
        if ik_result is None and cartesian_servo and current_pose is not None:
            for raw_ratio in spec.get('ik_backtrack_ratios', (0.5, 0.25, 0.125)):
                try:
                    ratio = float(raw_ratio)
                except (TypeError, ValueError):
                    continue
                if not 0.0 < ratio < 1.0:
                    continue
                candidate_command_pose = self._cartesian_pose_fraction(
                    current_pose=current_pose,
                    target_pose=command_target_pose,
                    ratio=ratio,
                )
                candidate_ik_pose = self._ik_target_pose(
                    target_pose=candidate_command_pose,
                    spec=spec,
                )
                candidate_result = self._solve_ik(
                    task=task,
                    robot_name=robot_name,
                    target_pose=candidate_ik_pose,
                    warm_start=reference_q,
                    spec=ik_solve_spec,
                )
                candidate_warm_start = reference_q
                if (
                    candidate_result is None
                    and bool(spec.get('ik_retry_with_measured_state', True))
                    and measured_q is not None
                    and (
                        reference_q is None
                        or reference_q.shape != measured_q.shape
                        or float(np.max(np.abs(reference_q - measured_q))) > 1e-6
                    )
                ):
                    retried_with_measured_state = True
                    candidate_result = self._solve_ik(
                        task=task,
                        robot_name=robot_name,
                        target_pose=candidate_ik_pose,
                        warm_start=measured_q,
                        spec=ik_solve_spec,
                    )
                    candidate_warm_start = measured_q
                if candidate_result is None:
                    continue
                if self._ik_solution_stalled(
                    ik_result=candidate_result,
                    measured_q=measured_q,
                    warm_start_q=candidate_warm_start,
                    current_pose=current_pose,
                    command_target_pose=candidate_command_pose,
                    spec=ik_solve_spec,
                ):
                    continue
                ik_result = candidate_result
                command_target_pose = candidate_command_pose
                ik_target_pose = candidate_ik_pose
                ik_backtrack_ratio = ratio
                break
        if ik_result is None:
            self._debug_motion_blocked(
                task=task,
                robot_name=robot_name,
                skill_name=skill_name,
                reason='ik_failed',
                spec=spec,
                target_pose=target_pose,
                ik_target_pose=ik_target_pose,
                reference_q=reference_q,
            )
            failure_streak = int(self._ik_failure_state.get(phase_key, 0)) + 1
            self._ik_failure_state[phase_key] = failure_streak
            tolerance_steps = max(
                int(spec.get('ik_failure_tolerance_steps', 48 if cartesian_servo else 0)),
                0,
            )
            if failure_streak <= tolerance_steps:
                action = self._hold_joint_action(task=task, robot_name=robot_name)
                gripper_command = spec.get('gripper_command')
                if gripper_command is None:
                    gripper_command = (
                        'close' if skill_name in {'ur5e_move_part_to_staging', 'ur5e_hold_part_end'} else 'open'
                    )
                action[_GRIPPER_CONTROLLER] = [
                    self._gripper_command_value(
                        task=task,
                        robot_name=robot_name,
                        command=gripper_command,
                    )
                ]
                return action
            return self._failure_or_hold(
                task,
                robot_name,
                spec,
                'ik_failed',
                diagnostics={
                    'consecutive_failures': failure_streak,
                    'tolerance_steps': tolerance_steps,
                    'retried_with_measured_state': retried_with_measured_state,
                    'last_backtrack_ratio': ik_backtrack_ratio,
                },
            )
        branch_reference_q = self._ik_branch_reference_q(
            phase_key=phase_key,
            reference_q=reference_q,
            spec=spec,
        )
        # Lula may return the same revolute-joint pose on opposite sides of the
        # +/-pi representation boundary.  Normalize against the last accepted
        # IK endpoint for this phase before deciding whether the branch jumped.
        target_normalization_q = (
            branch_reference_q if branch_reference_q is not None else reference_q
        )
        target_q = self._joint_target_near_reference(
            target_q=ik_result,
            reference_q=target_normalization_q,
            spec=spec,
            preferred_abs_limit=spec.get('preferred_joint_abs_limit', 3.05),
            hard_preferred_abs_limit=bool(spec.get('hard_preferred_joint_abs_limit', True)),
        )
        if reference_q is None:
            return self._failure_or_hold(
                task,
                robot_name,
                spec,
                'current_joint_state_unavailable',
                diagnostics={
                    'target_position': target_pose['position'].tolist(),
                    'target_orientation': target_pose['orientation'].tolist(),
                },
            )
        # Locked free-space endpoints may intentionally use another redundancy
        # branch; fine Cartesian servo must stay on the local branch.
        guard_branch_jump = bool(
            spec.get('guard_ik_branch_jump', cartesian_servo)
            and not lock_cartesian_ik_target
        )
        branch_jump = bool(
            guard_branch_jump
            and branch_reference_q is not None
            and self._ik_branch_jump_detected(
                reference_q=branch_reference_q,
                target_q=target_q,
                spec=spec,
            )
        )
        branch_recovery_mode = None
        if branch_jump and cartesian_servo and current_pose is not None:
            recovery = self._recover_ik_branch_jump(
                task=task,
                robot_name=robot_name,
                skill_name=skill_name,
                spec=spec,
                current_pose=current_pose,
                command_target_pose=command_target_pose,
                reference_q=reference_q,
                branch_reference_q=branch_reference_q,
                measured_q=measured_q,
            )
            if recovery is not None:
                ik_result = recovery['ik_result']
                target_q = recovery['target_q']
                command_target_pose = recovery['command_target_pose']
                ik_target_pose = recovery['ik_target_pose']
                branch_recovery_mode = recovery['mode']
                branch_jump = False
        if branch_jump:
            self._debug_motion_blocked(
                task=task,
                robot_name=robot_name,
                skill_name=skill_name,
                reason='ik_branch_jump_guard',
                spec=spec,
                target_pose=target_pose,
                ik_target_pose=ik_target_pose,
                reference_q=reference_q,
                target_q=target_q,
            )
            failure_streak = int(self._ik_failure_state.get(phase_key, 0)) + 1
            self._ik_failure_state[phase_key] = failure_streak
            tolerance_steps = max(int(spec.get('ik_branch_jump_tolerance_steps', 48)), 0)
            diagnostics = {
                'target_position': target_pose['position'].tolist(),
                'target_orientation': target_pose['orientation'].tolist(),
                'reference_q': reference_q.tolist(),
                'target_q': target_q.tolist(),
                'consecutive_failures': failure_streak,
                'tolerance_steps': tolerance_steps,
            }
            if failure_streak > tolerance_steps:
                return self._failure_or_hold(
                    task,
                    robot_name,
                    spec,
                    'ik_branch_jump_guard',
                    diagnostics=diagnostics,
                )
            return self._failure_or_hold(
                task,
                robot_name,
                {**spec, 'require_success': False},
                'ik_branch_jump_guard',
                diagnostics=diagnostics,
            )
        self._ik_failure_state.pop(phase_key, None)
        joint_step_limits = self._command_joint_step_limits(
            spec=spec,
            joint_count=reference_q.shape[0],
        )
        if lock_cartesian_ik_target and spec.get('locked_transport_max_joint_step') is not None:
            joint_step_limits = spec['locked_transport_max_joint_step']
        if joint_step_limits is None:
            joint_step_limits = float(spec.get('max_joint_step', 0.035))
        command_q = self._limited_joint_target(
            current_q=reference_q,
            target_q=target_q,
            max_joint_step=joint_step_limits,
        )
        command_q = self._continuous_command_q(
            task=task,
            robot_name=robot_name,
            command_q=command_q,
            spec=spec,
        )
        measured_limit_spec = spec
        if lock_cartesian_ik_target:
            locked_tracking_error = spec.get('locked_transport_max_command_tracking_error')
            if locked_tracking_error is not None:
                measured_limit_spec = {
                    **spec,
                    'max_command_tracking_error': locked_tracking_error,
                    'max_wrist_command_tracking_error': locked_tracking_error,
                }
        command_q = self._limit_command_to_measured_state(
            current_q=current_q,
            command_q=command_q,
            spec=measured_limit_spec,
        )
        self._debug_joint_step(
            task=task,
            robot_name=robot_name,
            skill_name=skill_name,
            spec=spec,
            current_pose=current_pose,
            target_pose=target_pose,
            command_target_pose=command_target_pose,
            ik_target_pose=ik_target_pose,
            current_q=current_q,
            reference_q=reference_q,
            target_q=target_q,
            command_q=command_q,
        )

        self._last_targets[phase_key] = {
            'position': target_pose['position'].copy(),
            'orientation': target_pose['orientation'].copy(),
            'target_q': target_q.copy(),
        }
        self._remember_cartesian_command_position(
            phase_key=phase_key,
            command_target_pose=command_target_pose,
        )
        self._remember_cartesian_command_orientation(
            phase_key=phase_key,
            command_target_pose=command_target_pose,
        )
        if branch_recovery_mode is not None:
            self._last_targets[phase_key]['ik_branch_recovery_mode'] = branch_recovery_mode

        action = OrderedDict()
        if use_arm_ik_controller:
            action[_ARM_IK_CONTROLLER] = [
                np.asarray(ik_target_pose['position'], dtype=float).tolist(),
                np.asarray(ik_target_pose['orientation'], dtype=float).tolist(),
            ]
        action[_ARM_JOINT_CONTROLLER] = [command_q.tolist()]
        self._remember_arm_command(task, robot_name, command_q)
        gripper_command = spec.get('gripper_command')
        if gripper_command is None:
            gripper_command = 'close' if skill_name in {'ur5e_move_part_to_staging', 'ur5e_hold_part_end'} else 'open'
        action[_GRIPPER_CONTROLLER] = [
            self._gripper_command_value(task=task, robot_name=robot_name, command=gripper_command)
        ]

        if spec.get('track_published_grasp_command'):
            if not self._record_published_grasp_command(task=task, robot_name=robot_name, spec=spec,
                    command_q=command_q, gripper_openness=action[_GRIPPER_CONTROLLER][0]):
                return self._failure_or_hold(task, robot_name, spec, 'grasp_command_cache_unavailable')
            if spec.get('beam_coordinated'):
                action = self._regulated_insertion_action(task=task, robot_name=robot_name,
                    spec=spec, command_q=command_q, fallback_action=action)
                if action.get('__local_skill_failure__'):
                    return action

        self._maybe_mark_complete(
            phase_key=phase_key,
            task=task,
            robot_name=robot_name,
            skill_name=skill_name,
            spec=spec,
            target_pose=target_pose,
            ik_target_pose=ik_target_pose,
            current_pose=current_pose,
            tracked_objects=tracked_objects,
            current_q=current_q,
            target_q=target_q,
        )
        return action

    @staticmethod
    def _raise_clearance_target(*, task, robot_name, phase_key, spec, target_pose):
        """Raise the free-space waypoint and its TCP by the same amount, once.

        Only the clearance target moves. The seating/assembled target and all
        physical bodies remain unchanged. Completion still checks object pose.
        """
        saved = getattr(task, '_ur5e_contact_hold_commands', {}).get(robot_name)
        target_name = spec.get('target_object_target')
        target = getattr(task, 'target_poses', {}).get(target_name)
        if saved is None or target is None:
            return None
        cache = getattr(task, '_beam_raised_clearance_targets', None)
        if cache is None:
            cache = task._beam_raised_clearance_targets = set()
        result = {k: np.asarray(v).copy() for k, v in target_pose.items()}
        if phase_key not in cache:
            dz = max(0., float(saved['pose']['position'][2] - result['position'][2]))
            position = np.asarray(target['position'], dtype=float).copy()
            position[2] += dz
            target['position'] = position
            result['position'][2] += dz
            cache.add(phase_key)
        return result

    def _regulated_insertion_action(self, *, task, robot_name, spec, command_q, fallback_action):
        if not spec.get('requires_held_object'):
            return fallback_action
        name = self._object_name_from_spec(spec)
        attachment = task._attachment_for(name, robot_name)
        saved = getattr(task, '_ur5e_contact_hold_commands', {}).get(robot_name)
        if (attachment is None or saved is None or saved.get('object') != name
                or not task._physical_hold_valid(name, attachment, validation_stage='pre_insertion_action')):
            return self._failure_or_hold(task, robot_name, spec, 'insertion_grasp_invalid')
        return self._publish_loaded_action(task=task, robot_name=robot_name, spec=spec,
                                            saved=saved, command_q=command_q)

    def _maybe_mark_complete(
        self,
        *,
        phase_key=None,
        task,
        robot_name: str,
        skill_name: str,
        spec: dict,
        target_pose: dict,
        ik_target_pose: dict,
        current_pose: dict | None,
        tracked_objects: dict,
        current_q,
        target_q,
    ) -> None:
        if spec.get('beam_table_seat'):
            # Seating completion is based on sustained table load, not each
            # small Cartesian increment being within a TCP tolerance.
            return
        position_tolerance = float(spec.get('position_tolerance', 0.025))
        relaxed_position_tolerance = spec.get('relaxed_position_tolerance')
        relaxed_after_steps = spec.get('relaxed_position_tolerance_after_steps')
        relaxed_tolerance_active = bool(
            relaxed_position_tolerance is not None
            and relaxed_after_steps is not None
            and int(getattr(task, 'phase_step_counter', 0)) >= int(relaxed_after_steps)
        )
        effective_position_tolerance = position_tolerance
        if relaxed_tolerance_active:
            effective_position_tolerance = max(
                position_tolerance,
                float(relaxed_position_tolerance),
            )
        orientation_tolerance = spec.get('orientation_tolerance')
        orientation_tolerance = None if orientation_tolerance is None else float(orientation_tolerance)
        object_name = self._object_name_from_spec(spec)
        compliant_linear_allowance, compliant_angular_allowance, attachment_mode = self._compliant_attachment_allowance(
            object_name=object_name,
            tracked_objects=tracked_objects,
        )
        effective_position_tolerance += compliant_linear_allowance
        if orientation_tolerance is not None:
            orientation_tolerance += compliant_angular_allowance
        force_complete_after_steps = spec.get('force_complete_after_steps')
        complete = False
        completion_detail = {
            'target_position': target_pose['position'].tolist(),
            'target_orientation': target_pose['orientation'].tolist(),
            'ik_target_position': ik_target_pose['position'].tolist(),
            'ik_target_orientation': ik_target_pose['orientation'].tolist(),
            'attachment_mode': attachment_mode,
            'compliant_linear_allowance': compliant_linear_allowance,
            'compliant_angular_allowance': compliant_angular_allowance,
        }
        tcp_offset = self._tcp_offset(spec)
        if tcp_offset is not None:
            completion_detail['grasp_tcp_offset'] = tcp_offset.tolist()
            completion_detail['grasp_tcp_offset_frame'] = self._tcp_offset_frame(spec)
        if current_pose is not None:
            position_error, orientation_error = pose_error(
                current_position=current_pose['position'],
                current_orientation=current_pose['orientation'],
                target_position=target_pose['position'],
                target_orientation=target_pose['orientation'],
            )
            completion_detail.update(
                {
                    'position_error': position_error,
                    'orientation_error': orientation_error,
                    'position_tolerance': effective_position_tolerance,
                    'primary_position_tolerance': position_tolerance,
                    'relaxed_position_tolerance': relaxed_position_tolerance,
                    'relaxed_position_tolerance_after_steps': relaxed_after_steps,
                    'relaxed_position_tolerance_active': relaxed_tolerance_active,
                    'orientation_tolerance': orientation_tolerance,
                }
            )
            complete = position_error <= effective_position_tolerance and (
                orientation_tolerance is None or orientation_error is None or orientation_error <= orientation_tolerance
            )
            if attachment_mode == 'compliant_joint' and bool(spec.get('require_target_object_pose_convergence', False)):
                complete = True
                completion_detail['tcp_pose_required_for_completion'] = False

        if bool(spec.get('require_target_object_pose_convergence', False)):
            object_pose = None
            target_object_pose = None
            if object_name is not None:
                object_pose = self._object_pose(
                    task=task,
                    object_name=object_name,
                    tracked_objects=tracked_objects,
                )
                target_object_pose = self._target_object_pose(task=task, spec=spec)

            object_position_tolerance = float(
                spec.get('target_object_position_tolerance', effective_position_tolerance)
            )
            primary_object_position_tolerance = object_position_tolerance
            relaxed_object_position_tolerance = spec.get('relaxed_target_object_position_tolerance')
            if relaxed_tolerance_active and relaxed_object_position_tolerance is not None:
                object_position_tolerance = max(
                    object_position_tolerance,
                    float(relaxed_object_position_tolerance),
                )
            object_orientation_tolerance = spec.get(
                'target_object_orientation_tolerance',
                orientation_tolerance,
            )
            object_orientation_tolerance = (
                None if object_orientation_tolerance is None else float(object_orientation_tolerance)
            )
            object_pose_complete = False
            object_position_error = None
            object_orientation_error = None
            object_axial_position_error = None
            object_axial_position_tolerance = spec.get('target_object_axial_position_tolerance')
            object_axial_position_tolerance = (
                None
                if object_axial_position_tolerance is None
                else float(object_axial_position_tolerance)
            )
            object_lateral_position_error = None
            object_lateral_position_tolerance = spec.get('target_object_lateral_position_tolerance')
            object_convergence_axis = spec.get('target_object_convergence_axis')
            lateral_alignment_complete = True
            if (
                phase_key is not None
                and object_convergence_axis is not None
                and object_lateral_position_tolerance is not None
            ):
                lateral_alignment_complete = not bool(self._insertion_lateral_alignment_active.get(phase_key, False))
            if object_pose is not None and target_object_pose is not None:
                object_position_delta = np.asarray(object_pose['position'], dtype=float) - np.asarray(
                    target_object_pose['position'], dtype=float
                )
                target_object_orientation = target_object_pose.get('orientation')
                if target_object_orientation is None:
                    object_position_error = float(np.linalg.norm(object_position_delta))
                else:
                    object_position_error, object_orientation_error = pose_error(
                        current_position=object_pose['position'],
                        current_orientation=object_pose['orientation'],
                        target_position=target_object_pose['position'],
                        target_orientation=target_object_orientation,
                    )
                lateral_complete = True
                if object_convergence_axis is not None:
                    convergence_axis = np.asarray(object_convergence_axis, dtype=float)
                    axis_norm = float(np.linalg.norm(convergence_axis))
                    if convergence_axis.shape != (3,) or not np.isfinite(axis_norm) or axis_norm <= 1e-9:
                        raise ValueError('target_object_convergence_axis must be a finite non-zero 3D vector.')
                    convergence_axis = convergence_axis / axis_norm
                    signed_axial_error = float(np.dot(object_position_delta, convergence_axis))
                    lateral_error = object_position_delta - signed_axial_error * convergence_axis
                    object_axial_position_error = abs(signed_axial_error)
                    object_lateral_position_error = float(np.linalg.norm(lateral_error))
                    if object_lateral_position_tolerance is not None:
                        lateral_complete = bool(
                            object_lateral_position_error <= float(object_lateral_position_tolerance)
                        )
                axial_complete = bool(
                    object_axial_position_tolerance is None
                    or object_axial_position_error is None
                    or object_axial_position_error <= object_axial_position_tolerance
                )
                position_complete = (
                    object_position_error <= object_position_tolerance
                    if object_axial_position_tolerance is None
                    else axial_complete
                )
                object_pose_complete = bool(
                    position_complete
                    and lateral_complete
                    and (
                        object_orientation_tolerance is None
                        or object_orientation_error is None
                        or object_orientation_error <= object_orientation_tolerance
                    )
                )
            completion_detail.update(
                {
                    'target_object_pose_required': True,
                    'target_object_name': object_name,
                    'target_object_position': (
                        None
                        if target_object_pose is None
                        else np.asarray(target_object_pose['position'], dtype=float).tolist()
                    ),
                    'target_object_orientation': (
                        None
                        if target_object_pose is None or target_object_pose.get('orientation') is None
                        else np.asarray(target_object_pose['orientation'], dtype=float).tolist()
                    ),
                    'object_position_error': object_position_error,
                    'object_orientation_error': object_orientation_error,
                    'target_object_convergence_axis': object_convergence_axis,
                    'object_axial_position_error': object_axial_position_error,
                    'target_object_axial_position_tolerance': object_axial_position_tolerance,
                    'object_lateral_position_error': object_lateral_position_error,
                    'target_object_lateral_alignment_complete': (lateral_alignment_complete),
                    'target_object_lateral_position_tolerance': (
                        None if object_lateral_position_tolerance is None else float(object_lateral_position_tolerance)
                    ),
                    'target_object_position_tolerance': object_position_tolerance,
                    'primary_target_object_position_tolerance': primary_object_position_tolerance,
                    'relaxed_target_object_position_tolerance': relaxed_object_position_tolerance,
                    'target_object_orientation_tolerance': object_orientation_tolerance,
                    'target_object_pose_complete': object_pose_complete,
                }
            )
            if bool(spec.get('target_object_capture_requires_tcp', True)):
                complete = bool(complete and object_pose_complete)
            else:
                # For a strict hover, the held object's measured pose is the
                # physical goal. A fixed/compliant grasp can leave the nominal
                # TCP offset from the generated target while the object is
                # already correctly aligned for the following insertion.
                complete = bool(object_pose_complete)

        if bool(spec.get('require_target_object_static', False)):
            object_name = self._object_name_from_spec(spec)
            motion_detail = self._object_motion_detail(
                task=task,
                object_name=object_name,
                tracked_objects=tracked_objects,
            )
            max_linear_speed = float(spec.get('target_object_max_linear_speed', 0.03))
            max_angular_speed = float(spec.get('target_object_max_angular_speed', 2.0))
            configured_stable_steps = max(
                int(spec.get('target_object_stable_steps', 8)),
                1,
            )
            velocity_motion_ready = bool(
                motion_detail.get('valid')
                and motion_detail.get('linear_speed') is not None
                and motion_detail.get('angular_speed') is not None
                and float(motion_detail['linear_speed']) <= max_linear_speed
                and float(motion_detail['angular_speed']) <= max_angular_speed
            )
            pose_stable_override_used = bool(
                spec.get('target_object_allow_pose_stable_override', True)
                and motion_detail.get('is_static') is True
                and motion_detail.get('pose_stable_override') is True
                and motion_detail.get('linear_speed') is not None
                and motion_detail.get('angular_speed') is not None
                and float(motion_detail['linear_speed'])
                <= float(
                    spec.get(
                        'target_object_pose_stable_override_max_linear_speed',
                        max(
                            2.0 * max_linear_speed,
                            float(
                                spec.get(
                                    'compliant_servo_settle_max_linear_speed',
                                    max_linear_speed,
                                )
                            ),
                        ),
                    )
                )
                and float(motion_detail['angular_speed'])
                <= float(
                    spec.get(
                        'target_object_pose_stable_override_max_angular_speed',
                        spec.get(
                            'compliant_servo_settle_max_angular_speed',
                            max_angular_speed,
                        ),
                    )
                )
            )
            pose_history_velocity_override_used = self._pose_history_velocity_override_ready(
                spec=spec,
                motion_detail=motion_detail,
            )
            motion_ready = bool(velocity_motion_ready or pose_stable_override_used)
            motion_ready = bool(motion_ready or pose_history_velocity_override_used)
            entry_capture_max_steps = max(
                int(spec.get('target_object_entry_capture_max_steps', 0)),
                0,
            )
            entry_capture_active = bool(
                entry_capture_max_steps > 0
                and int(getattr(task, 'phase_step_counter', 0)) <= entry_capture_max_steps
                and complete
                and velocity_motion_ready
            )
            required_stable_steps = 1 if entry_capture_active else configured_stable_steps
            if phase_key is None:
                phase_key = (
                    id(task),
                    getattr(task, 'phase_index', None),
                    getattr(task, 'phase_entry_step', None),
                    robot_name,
                    skill_name,
                )
            state = self._completion_state.setdefault(phase_key, {})
            if complete and motion_ready:
                state['target_object_stable_steps'] = int(state.get('target_object_stable_steps', 0)) + 1
            else:
                state['target_object_stable_steps'] = 0
            stable_steps = int(state['target_object_stable_steps'])
            completion_detail.update(
                {
                    'target_object_static_required': True,
                    'target_object_motion_detail': motion_detail,
                    'target_object_motion_ready': motion_ready,
                    'target_object_velocity_motion_ready': velocity_motion_ready,
                    'target_object_pose_stable_override_used': (pose_stable_override_used),
                    'target_object_pose_history_velocity_override_used': (pose_history_velocity_override_used),
                    'target_object_max_linear_speed': max_linear_speed,
                    'target_object_max_angular_speed': max_angular_speed,
                    'target_object_stable_steps': stable_steps,
                    'configured_target_object_stable_steps': (configured_stable_steps),
                    'required_target_object_stable_steps': required_stable_steps,
                    'target_object_entry_capture_max_steps': (entry_capture_max_steps),
                    'target_object_entry_capture_active': entry_capture_active,
                }
            )
            complete = bool(complete and motion_ready and stable_steps >= required_stable_steps)

        joint_position_tolerance = spec.get('joint_position_tolerance')
        if joint_position_tolerance is not None and current_q is not None and target_q is not None:
            joint_error = float(np.max(np.abs(np.asarray(target_q, dtype=float) - np.asarray(current_q, dtype=float))))
            completion_detail.update(
                {
                    'joint_error': joint_error,
                    'joint_position_tolerance': float(joint_position_tolerance),
                }
            )
            complete = bool(complete and joint_error <= float(joint_position_tolerance))

        if force_complete_after_steps is not None and int(getattr(task, 'phase_step_counter', 0)) >= int(
            force_complete_after_steps
        ):
            complete = True
            completion_detail['force_complete'] = True

        if spec.get('beam_assisted_staged_clearance'):
            _, _, _, _, _, servo_state = self._assisted_object_servo_context(
                phase_key=phase_key, task=task, robot_name=robot_name, spec=spec,
                tracked_robots={}, tracked_objects=tracked_objects)
            stage = servo_state.get('clearance_path', {}).get('stage')
            completion_detail['assisted_clearance_stage'] = stage
            complete = bool(complete and stage == 'lower')

        if spec.get('beam_assisted_absolute_object_servo') and spec.get('beam_assisted_descent_admission'):
            from .beam_assisted_servo import descent_admission
            _, stamp, native, actual_object, _, servo_state = self._assisted_object_servo_context(
                phase_key=phase_key, task=task, robot_name=robot_name, spec=spec,
                tracked_robots={}, tracked_objects=tracked_objects)
            ready, detail = descent_admission(servo_state.setdefault('admission', {}), stamp,
                actual_object, self._target_object_pose(task=task, spec=spec),
                spec.get('target_object_convergence_axis', [0., 0., -1.]),
                spec['beam_assisted_descent_admission'], native)
            servo_state.update(descent_ready=ready, admission_detail=detail, stamp=dict(stamp))
            completion_detail['assisted_descent_admission'] = detail
            complete = bool(complete and ready)

        if spec.get('beam_assisted_transition_settle'):
            from .beam_assisted_servo import settled_transition_ready
            _, stamp, native, _, _, servo_state = self._assisted_object_servo_context(
                phase_key=phase_key, task=task, robot_name=robot_name, spec=spec,
                tracked_robots={}, tracked_objects=tracked_objects)
            ready, settle_detail = settled_transition_ready(
                servo_state.setdefault('transition_settle', {}), stamp, native, complete,
                spec['beam_assisted_transition_settle'])
            completion_detail['assisted_transition_settle'] = settle_detail
            complete = bool(complete and ready)
            task._assisted_event('transition_settle', robot=robot_name, object=object_name,
                                 **settle_detail)

        if complete:
            self._mark_complete(
                task=task,
                robot_name=robot_name,
                skill_name=skill_name,
                detail=completion_detail,
            )

    @staticmethod
    def _debug_grasp_enabled() -> bool:
        return os.environ.get('UR5E_DEBUG_GRASP', '0').strip().lower() in {'1', 'true', 'yes'}

    @classmethod
    def _debug_close_enabled(cls) -> bool:
        return cls._debug_grasp_enabled() or os.environ.get('UR5E_DEBUG_CLOSE', '0').strip().lower() in {
            '1',
            'true',
            'yes',
        }

    def _debug_close_step(
        self,
        *,
        task,
        robot_name: str,
        skill_name: str,
        close_elapsed_steps: int,
        gripper_openness: float,
        close_ready: bool,
        close_detail: dict[str, Any],
    ) -> None:
        if not self._debug_close_enabled():
            return
        should_print = (
            int(close_elapsed_steps) <= 5
            or int(close_elapsed_steps) % 12 == 0
            or bool(close_ready)
            or bool(close_detail.get('detected_clamp'))
            or not bool(close_detail.get('motion_ready', True))
        )
        if not should_print:
            return
        motion_detail = close_detail.get('motion_detail') or {}
        recenter_detail = close_detail.get('recenter') or {}
        contact_detail = close_detail.get('contact_detail') or {}
        contact_metrics = contact_detail.get('contact_metrics') if isinstance(contact_detail, dict) else {}
        left_gap = None
        right_gap = None
        if isinstance(contact_metrics, dict):
            left_finger = contact_metrics.get('left_finger') or {}
            right_finger = contact_metrics.get('right_finger') or {}
            left_gap = left_finger.get('surface_gap')
            right_gap = right_finger.get('surface_gap')
            left_local = (left_finger.get('local_contact') or {}).get('local_point')
            right_local = (right_finger.get('local_contact') or {}).get('local_point')
        else:
            left_local = None
            right_local = None
        print(
            '[ur5e-grasp-debug] '
            f"step={getattr(task, 'step_counter', None)} "
            f"phase_step={getattr(task, 'phase_step_counter', None)} "
            f'robot={robot_name} skill={skill_name} close_elapsed={int(close_elapsed_steps)} '
            f'cmd_open={float(gripper_openness):.4f} '
            f"q={close_detail.get('gripper_joint_position')} "
            f"target_q={close_detail.get('target_gripper_joint_position')} "
            f"ready={bool(close_ready)} reason={close_detail.get('completion_reason')} "
            f"detected_clamp={close_detail.get('detected_clamp')} "
            f"contact_ready={close_detail.get('contact_ready')} stable={close_detail.get('stable_steps')}/"
            f"{close_detail.get('required_stable_steps')} "
            f"motion_ready={close_detail.get('motion_ready')} motion_stable="
            f"{close_detail.get('motion_stable_steps')}/{close_detail.get('required_motion_stable_steps')} "
            f"lin={motion_detail.get('linear_speed')} ang={motion_detail.get('angular_speed')} "
            f"is_static={motion_detail.get('is_static')} pose_static={motion_detail.get('pose_stable_override')} "
            f"hold_open={close_detail.get('hold_gripper_openness')} "
            f"strict={contact_detail.get('strict_contact_ready')} "
            f"pinch_axis={contact_metrics.get('pinch_axis') if isinstance(contact_metrics, dict) else None} "
            f"recenter_side={recenter_detail.get('single_finger_side')} "
            f"recenter_updated={recenter_detail.get('updated')} "
            f"recenter_offset={recenter_detail.get('offset_world')} "
            f'left_gap={left_gap} right_gap={right_gap} '
            f'left_local={left_local} right_local={right_local}',
            flush=True,
        )

    def _debug_close_gate_step(
        self,
        *,
        task,
        robot_name: str,
        detail: dict[str, Any],
    ) -> None:
        if not self._debug_close_enabled():
            return
        phase_step = int(getattr(task, 'phase_step_counter', 0))
        every = max(int(os.environ.get('UR5E_DEBUG_CLOSE_GATE_EVERY', '30')), 1)
        if phase_step > 5 and phase_step % every != 0 and not bool(detail.get('gate_ready')):
            return
        print(
            '[ur5e-close-gate-debug] '
            f"step={getattr(task, 'step_counter', None)} phase={getattr(task, 'phase', None)} "
            f'phase_step={phase_step} robot={robot_name} reason={detail.get("reason")} '
            f'gate_ready={detail.get("gate_ready")} ready_steps={detail.get("ready_steps")}/'
            f'{detail.get("required_ready_steps")} '
            f'position_error={detail.get("position_error")}/{detail.get("position_tolerance")} '
            f'orientation_error={detail.get("orientation_error")}/{detail.get("orientation_tolerance")} '
            f'joint_error={detail.get("joint_error")}/{detail.get("joint_position_tolerance")} '
            f'target={detail.get("target_position")} current={detail.get("current_position")} '
            f'reference_q={detail.get("reference_q")} target_q={detail.get("target_q")}',
            flush=True,
        )

    def _debug_transport_step(
        self,
        *,
        task,
        robot_name: str,
        skill_name: str,
        spec: dict,
        target_pose: dict,
        current_pose: dict | None,
        tracked_objects: dict,
    ) -> None:
        if not self._debug_grasp_enabled():
            return
        if not (
            spec.get('target_object_position') is not None
            or spec.get('target_object_target') is not None
            or spec.get('target_object') is not None
            or spec.get('object_target') is not None
            or skill_name in {'ur5e_move_part_to_table_hover', 'ur5e_move_part_to_staging', 'ur5e_hold_part_end'}
        ):
            return
        phase_step = int(getattr(task, 'phase_step_counter', 0))
        every = max(int(os.environ.get('UR5E_DEBUG_TRANSPORT_EVERY', '15')), 1)
        if phase_step > 5 and phase_step % every != 0:
            return

        object_name = self._object_name_from_spec(spec)
        object_pose = None
        if object_name:
            object_pose = self._object_pose(
                task=task,
                object_name=object_name,
                tracked_objects=tracked_objects,
            )
        target_object_position = self._target_object_position(task=task, spec=spec)
        object_error = None
        object_axial_error = None
        object_lateral_error = None
        relative_world = None
        if object_pose is not None and target_object_position is not None:
            object_delta = np.asarray(object_pose['position'], dtype=float) - np.asarray(
                target_object_position, dtype=float
            )
            object_error = float(np.linalg.norm(object_delta))
            convergence_axis = spec.get('target_object_convergence_axis')
            if convergence_axis is not None:
                convergence_axis = np.asarray(convergence_axis, dtype=float)
                axis_norm = float(np.linalg.norm(convergence_axis))
                if convergence_axis.shape == (3,) and np.isfinite(axis_norm) and axis_norm > 1e-9:
                    convergence_axis = convergence_axis / axis_norm
                    signed_axial_error = float(np.dot(object_delta, convergence_axis))
                    object_axial_error = abs(signed_axial_error)
                    object_lateral_error = float(np.linalg.norm(object_delta - signed_axial_error * convergence_axis))
        if object_pose is not None and current_pose is not None:
            relative_world = np.asarray(object_pose['position'], dtype=float) - np.asarray(
                current_pose['position'], dtype=float
            )

        tcp_error = None
        if current_pose is not None:
            tcp_error = float(
                np.linalg.norm(
                    np.asarray(current_pose['position'], dtype=float) - np.asarray(target_pose['position'], dtype=float)
                )
            )
        motion_detail = self._object_motion_detail(
            task=task,
            object_name=object_name,
            tracked_objects=tracked_objects,
        )
        print(
            '[ur5e-transport-debug] '
            f"step={getattr(task, 'step_counter', None)} phase={getattr(task, 'phase', None)} "
            f'phase_step={phase_step} robot={robot_name} skill={skill_name} '
            f'target_object_position={None if target_object_position is None else np.asarray(target_object_position, dtype=float).tolist()} '
            f"object_position={None if object_pose is None else np.asarray(object_pose['position'], dtype=float).tolist()} "
            f'object_error={object_error} '
            f'object_axial_error={object_axial_error} '
            f'object_lateral_error={object_lateral_error} '
            f"target_tcp={np.asarray(target_pose['position'], dtype=float).tolist()} "
            f"current_tcp={None if current_pose is None else np.asarray(current_pose['position'], dtype=float).tolist()} "
            f'tcp_error={tcp_error} '
            f'relative_world={None if relative_world is None else relative_world.tolist()} '
            f'gripper_q={self._current_gripper_q(task=task, robot_name=robot_name)} '
            f'hold_open={self._last_gripper_hold_openness(task=task, robot_name=robot_name)} '
            f"lin={motion_detail.get('linear_speed')} ang={motion_detail.get('angular_speed')} "
            f"is_static={motion_detail.get('is_static')} pose_static={motion_detail.get('pose_stable_override')}",
            flush=True,
        )

    def _debug_motion_blocked(
        self,
        *,
        task,
        robot_name: str,
        skill_name: str,
        reason: str,
        spec: dict,
        target_pose: dict,
        ik_target_pose: dict,
        reference_q=None,
        target_q=None,
    ) -> None:
        if not self._debug_grasp_enabled():
            return
        phase_step = int(getattr(task, 'phase_step_counter', 0))
        every = max(int(os.environ.get('UR5E_DEBUG_TRANSPORT_EVERY', '15')), 1)
        if phase_step > 5 and phase_step % every != 0:
            return
        print(
            '[ur5e-motion-blocked] '
            f"step={getattr(task, 'step_counter', None)} phase={getattr(task, 'phase', None)} "
            f'phase_step={phase_step} robot={robot_name} skill={skill_name} reason={reason} '
            f"target_tcp={np.asarray(target_pose['position'], dtype=float).tolist()} "
            f"ik_target={np.asarray(ik_target_pose['position'], dtype=float).tolist()} "
            f'reference_q={None if reference_q is None else np.asarray(reference_q, dtype=float).tolist()} '
            f'target_q={None if target_q is None else np.asarray(target_q, dtype=float).tolist()} '
            f"max_joint_step={spec.get('max_joint_step')} "
            f"guard_ik_branch_jump={spec.get('guard_ik_branch_jump', spec.get('cartesian_servo', False))}",
            flush=True,
        )

    def _debug_joint_step(
        self,
        *,
        task,
        robot_name: str,
        skill_name: str,
        spec: dict,
        current_pose: dict | None,
        target_pose: dict,
        command_target_pose: dict,
        ik_target_pose: dict,
        current_q,
        reference_q,
        target_q,
        command_q,
    ) -> None:
        trace_path = os.environ.get('BEAM_MOTION_TRACE_PATH')
        if trace_path and (spec.get('requires_held_object') or spec.get('trace_pregrasp')):
            def array(value):
                return None if value is None else np.asarray(value, dtype=float).tolist()
            def pose(value):
                return None if value is None else {key: array(value[key]) for key in ('position', 'orientation')}
            with open(trace_path, 'a', encoding='utf-8') as handle:
                handle.write(json.dumps({
                    'step': int(task.step_counter), 'phase': task.phase, 'robot': robot_name,
                    'current_pose': pose(current_pose), 'target_pose': pose(target_pose),
                    'command_target_pose': pose(command_target_pose), 'ik_target_pose': pose(ik_target_pose),
                    'current_q': array(current_q), 'reference_q': array(reference_q),
                    'target_q': array(target_q), 'command_q': array(command_q),
                    'timing': 'observation at step; command for next physics interval',
                }) + '\n')
        if not self._debug_grasp_enabled():
            return
        if not (
            bool(spec.get('cartesian_servo', False))
            or spec.get('target_object_position') is not None
            or spec.get('target_object_target') is not None
            or skill_name in {'ur5e_move_part_to_table_hover', 'ur5e_move_part_to_staging', 'ur5e_hold_part_end'}
        ):
            return
        phase_step = int(getattr(task, 'phase_step_counter', 0))
        every = max(int(os.environ.get('UR5E_DEBUG_TRANSPORT_EVERY', '15')), 1)
        if phase_step > 5 and phase_step % every != 0:
            return

        current_q = self._coerce_arm_q(current_q)
        reference_q = self._coerce_arm_q(reference_q)
        target_q = self._coerce_arm_q(target_q)
        command_q = self._coerce_arm_q(command_q)

        def _max_abs_delta(a, b):
            if a is None or b is None:
                return None
            if a.shape != b.shape:
                return None
            return float(np.max(np.abs(np.asarray(a, dtype=float) - np.asarray(b, dtype=float))))

        tcp_error = None
        tcp_orientation_error = None
        command_tcp_step = None
        command_orientation_step = None
        if current_pose is not None:
            tcp_error, tcp_orientation_error = pose_error(
                current_pose['position'],
                current_pose['orientation'],
                target_pose['position'],
                target_pose['orientation'],
            )
            command_tcp_step, command_orientation_step = pose_error(
                current_pose['position'],
                current_pose['orientation'],
                command_target_pose['position'],
                command_target_pose['orientation'],
            )
        ik_position_tolerance, ik_orientation_tolerance = self._ik_solver_tolerances(spec)
        arm_dynamics = self._current_arm_dynamics(task=task, robot_name=robot_name)
        pose_frame_diagnostic = None
        get_pose_frame_diagnostic = getattr(task, '_get_robot_pose_frame_diagnostic', None)
        if callable(get_pose_frame_diagnostic):
            try:
                pose_frame_diagnostic = get_pose_frame_diagnostic(robot_name)
            except Exception as exc:
                pose_frame_diagnostic = {'error': repr(exc)}
        if isinstance(pose_frame_diagnostic, dict):
            pose_frame_diagnostic = {
                key: value.tolist() if isinstance(value, np.ndarray) else value
                for key, value in pose_frame_diagnostic.items()
            }
        print(
            '[ur5e-joint-debug] '
            f"step={getattr(task, 'step_counter', None)} phase={getattr(task, 'phase', None)} "
            f'phase_step={phase_step} robot={robot_name} skill={skill_name} '
            f"ik_reference_mode={spec.get('ik_reference_mode', spec.get('reference_mode'))} "
            f"use_command_warm_start={spec.get('use_command_warm_start', True)} "
            f'tcp_error={tcp_error} tcp_orientation_error={tcp_orientation_error} '
            f'command_tcp_step={command_tcp_step} command_orientation_step={command_orientation_step} '
            f'ik_position_tolerance={ik_position_tolerance} '
            f'ik_orientation_tolerance={ik_orientation_tolerance} '
            f"target_tcp={np.asarray(target_pose['position'], dtype=float).tolist()} "
            f"command_tcp={np.asarray(command_target_pose['position'], dtype=float).tolist()} "
            f"ik_tcp={np.asarray(ik_target_pose['position'], dtype=float).tolist()} "
            f'current_q={None if current_q is None else current_q.tolist()} '
            f'reference_q={None if reference_q is None else reference_q.tolist()} '
            f'target_q={None if target_q is None else target_q.tolist()} '
            f'command_q={None if command_q is None else command_q.tolist()} '
            f'ref_to_target_max={_max_abs_delta(reference_q, target_q)} '
            f'ref_to_cmd_max={_max_abs_delta(reference_q, command_q)} '
            f'current_to_cmd_max={_max_abs_delta(current_q, command_q)} '
            f'current_to_ref_max={_max_abs_delta(current_q, reference_q)} '
            f'pose_frame_diagnostic={pose_frame_diagnostic} '
            f"joint_velocity={arm_dynamics.get('joint_velocity')} "
            f"measured_effort={arm_dynamics.get('measured_effort')} "
            f"applied_effort={arm_dynamics.get('applied_effort')} "
            f"stiffness={arm_dynamics.get('stiffness')} "
            f"damping={arm_dynamics.get('damping')} "
            f"max_force={arm_dynamics.get('max_force')}",
            flush=True,
        )

    @staticmethod
    def _cartesian_pose_fraction(*, current_pose: dict, target_pose: dict, ratio: float) -> dict:
        current_position = np.asarray(current_pose['position'], dtype=float)
        target_position = np.asarray(target_pose['position'], dtype=float)
        position_distance = float(np.linalg.norm(target_position - current_position))
        current_orientation = normalize_quat(current_pose['orientation'])
        target_orientation = normalize_quat(target_pose['orientation'])
        orientation_dot = float(np.dot(current_orientation, target_orientation))
        orientation_angle = float(2.0 * math.acos(np.clip(abs(orientation_dot), 0.0, 1.0)))
        return UR5eAssemblyAtomicSkillAdapter._cartesian_servo_target_pose(
            current_pose=current_pose,
            target_pose=target_pose,
            max_position_step=position_distance * float(ratio),
            max_orientation_step=orientation_angle * float(ratio),
        )

    def _recover_ik_branch_jump(
        self,
        *,
        task,
        robot_name: str,
        skill_name: str,
        spec: dict,
        current_pose: dict,
        command_target_pose: dict,
        reference_q: np.ndarray,
        branch_reference_q: np.ndarray,
        measured_q: np.ndarray | None,
    ) -> dict | None:
        candidates: list[tuple[str, dict]] = []
        for raw_ratio in spec.get(
            'ik_branch_backtrack_ratios',
            spec.get('ik_backtrack_ratios', (0.5, 0.25, 0.125)),
        ):
            try:
                ratio = float(raw_ratio)
            except (TypeError, ValueError):
                continue
            if not 0.0 < ratio < 1.0:
                continue
            candidates.append(
                (
                    f'cartesian_backtrack_{ratio:g}',
                    self._cartesian_pose_fraction(
                        current_pose=current_pose,
                        target_pose=command_target_pose,
                        ratio=ratio,
                    ),
                )
            )

        translation_only = bool(
            spec.get(
                'ik_branch_translation_only_recovery',
                skill_name == 'ur5e_move_above_part',
            )
        )
        translation_distance = float(
            np.linalg.norm(
                np.asarray(command_target_pose['position'], dtype=float)
                - np.asarray(current_pose['position'], dtype=float)
            )
        )
        minimum_translation = max(
            float(spec.get('ik_branch_translation_only_min_step', 1e-5)),
            0.0,
        )
        if translation_only and translation_distance > minimum_translation:
            candidates.append(
                (
                    'translation_only',
                    {
                        'position': np.asarray(command_target_pose['position'], dtype=float),
                        'orientation': normalize_quat(current_pose['orientation']),
                    },
                )
            )

        warm_starts = [('command', reference_q)]
        measured_q = self._coerce_arm_q(measured_q)
        if (
            measured_q is not None
            and measured_q.shape == reference_q.shape
            and float(np.max(np.abs(measured_q - reference_q))) > 1e-6
        ):
            warm_starts.append(('measured', measured_q))

        for mode, candidate_command_pose in candidates:
            candidate_ik_pose = self._ik_target_pose(
                target_pose=candidate_command_pose,
                spec=spec,
            )
            for warm_start_name, warm_start in warm_starts:
                candidate_result = self._solve_ik(
                    task=task,
                    robot_name=robot_name,
                    target_pose=candidate_ik_pose,
                    warm_start=warm_start,
                    spec=spec,
                )
                if candidate_result is None:
                    continue
                candidate_q = self._joint_target_near_reference(
                    target_q=candidate_result,
                    reference_q=branch_reference_q,
                    spec=spec,
                    preferred_abs_limit=spec.get('preferred_joint_abs_limit', 3.05),
                    hard_preferred_abs_limit=bool(spec.get('hard_preferred_joint_abs_limit', True)),
                )
                if self._ik_branch_jump_detected(
                    reference_q=branch_reference_q,
                    target_q=candidate_q,
                    spec=spec,
                ):
                    continue
                return {
                    'ik_result': np.asarray(candidate_result, dtype=float),
                    'target_q': candidate_q,
                    'command_target_pose': candidate_command_pose,
                    'ik_target_pose': candidate_ik_pose,
                    'mode': f'{mode}_{warm_start_name}_warm_start',
                }
        return None

    @staticmethod
    def _orientation_first_servo_pose(
        *,
        skill_name: str,
        spec: dict,
        current_pose: dict,
        target_pose: dict,
        phase_step_counter: int = 0,
    ) -> dict | None:
        orientation_tolerance = spec.get('orientation_tolerance')
        enabled = bool(spec.get('orientation_first_before_translation', False))
        if not enabled:
            return None
        max_steps = max(int(spec.get('orientation_first_max_steps', 48)), 0)
        if int(phase_step_counter) >= max_steps:
            return None
        _, orientation_error = pose_error(
            current_position=current_pose['position'],
            current_orientation=current_pose['orientation'],
            target_position=target_pose['position'],
            target_orientation=target_pose['orientation'],
        )
        default_threshold = 0.035 if orientation_tolerance is None else max(float(orientation_tolerance) * 0.8, 0.035)
        threshold = max(float(spec.get('orientation_first_tolerance', default_threshold)), 0.0)
        if orientation_error is None or float(orientation_error) <= threshold:
            return None
        alignment_target = {
            'position': np.asarray(current_pose['position'], dtype=float),
            'orientation': np.asarray(target_pose['orientation'], dtype=float),
        }
        return UR5eAssemblyAtomicSkillAdapter._cartesian_servo_target_pose(
            current_pose=current_pose,
            target_pose=alignment_target,
            max_position_step=0.0,
            max_orientation_step=float(spec.get('cartesian_orientation_step', 0.01)),
        )

    @staticmethod
    def _cartesian_servo_target_pose(
        *,
        current_pose: dict,
        target_pose: dict,
        max_position_step: float,
        max_orientation_step: float,
    ) -> dict:
        current_position = np.asarray(current_pose['position'], dtype=float)
        target_position = np.asarray(target_pose['position'], dtype=float)
        delta = target_position - current_position
        distance = float(np.linalg.norm(delta))
        if max_position_step > 0.0 and distance > max_position_step:
            command_position = current_position + delta * (max_position_step / distance)
        else:
            command_position = target_position

        current_orientation = normalize_quat(current_pose['orientation'])
        target_orientation = normalize_quat(target_pose['orientation'])
        dot = float(np.dot(current_orientation, target_orientation))
        if dot < 0.0:
            target_orientation = -target_orientation
            dot = -dot
        dot = float(np.clip(dot, -1.0, 1.0))
        orientation_angle = float(2.0 * math.acos(dot))
        if max_orientation_step > 0.0 and orientation_angle > max_orientation_step:
            ratio = max_orientation_step / orientation_angle
            if dot > 0.9995:
                command_orientation = normalize_quat((1.0 - ratio) * current_orientation + ratio * target_orientation)
            else:
                half_angle = math.acos(dot)
                sin_half_angle = math.sin(half_angle)
                if abs(sin_half_angle) < 1e-8:
                    command_orientation = current_orientation
                else:
                    command_orientation = normalize_quat(
                        (math.sin((1.0 - ratio) * half_angle) / sin_half_angle) * current_orientation
                        + (math.sin(ratio * half_angle) / sin_half_angle) * target_orientation
                    )
        else:
            command_orientation = target_orientation
        return {
            'position': command_position,
            'orientation': command_orientation,
        }

    def _assisted_object_servo_context(self, *, phase_key, task, robot_name, spec,
                                       tracked_robots, tracked_objects):
        name = self._object_name_from_spec(spec)
        attachment = tracked_objects.get(name, {}).get('attachment') or {}
        if attachment.get('mode') != 'fixed_joint' or attachment.get('robot_name') != robot_name:
            raise ValueError('absolute assisted object servo requires its live fixed grasp')
        stamp = task._beam_physics_stamp()
        if stamp.get('valid') is not True:
            raise ValueError('absolute assisted object servo lacks native physical time')
        motion_options = {}
        if any((spec.get(key) or {}).get('motion_metric') == 'native_com_pose_difference'
               for key in ('beam_assisted_transition_settle', 'beam_assisted_descent_admission')):
            motion_options['include_center_of_mass'] = True
        native = task._assisted_native_body_motion(name, stamp['epoch'], **motion_options)
        if not native.get('motion_valid') or not native.get('physics_handle_valid'):
            raise ValueError('absolute assisted object servo lacks a live native body')
        object_pose = {key: np.asarray(native[key], float) for key in ('position', 'orientation')}
        relative = self._object_tcp_relative_pose(phase_key=phase_key, task=task,
            robot_name=robot_name, object_name=name, spec=spec,
            tracked_robots=tracked_robots, tracked_objects=tracked_objects, object_pose=object_pose)
        if relative is None:
            raise ValueError('absolute assisted object servo lacks its captured grasp transform')
        # Grasp identity is authoritative attachment/view lifecycle data.
        # Derived control-frame floats vary at roundoff level across ticks.
        identity = (attachment.get('joint_path'), attachment.get('attach_step'),
                    stamp['epoch'], native.get('body_path'), native.get('motion_view_id'))
        states = getattr(task, '_beam_assisted_object_servo_states', None)
        if states is None:
            states = task._beam_assisted_object_servo_states = {}
        state = states.setdefault((robot_name, phase_key), {})
        if state.get('identity') != identity:
            if (spec.get('beam_assisted_lift_command_rotation_hold')
                    and 'identity' in state):
                raise ValueError('loaded lift captured grasp identity changed within its phase')
            state.clear()
            state['identity'] = identity
        return name, stamp, native, object_pose, relative, state

    def _assisted_lift_hold_publication(self, *, task, robot_name, spec, stamp, state, actual_q):
        """Read the fresh final drive target; never substitute measured hold."""
        publication = getattr(task, '_assisted_published_q_stamps', {}).get(robot_name)
        previous = np.asarray(getattr(task, '_assisted_published_q', {}).get(robot_name), float)
        if (stamp.get('valid') is not True or not isinstance(publication, dict)
                or publication.get('epoch') != stamp.get('epoch')
                or type(stamp.get('index')) is not int
                or type(publication.get('index')) is not int
                or stamp['index']-publication['index'] not in (0, 1)
                or previous.shape != (6,) or not np.all(np.isfinite(previous))
                or np.max(np.abs(previous-np.asarray(actual_q, float))) > .12+1e-12):
            raise ValueError('loaded lift lacks a fresh final published target')
        previous_tcp = self._grasp_command_fk_pose(task=task, robot_name=robot_name,
            spec=spec, command_q=previous)
        if previous_tcp is None:
            raise ValueError('loaded lift lacks final publication FK')
        if 'lift_command_orientation' not in state:
            state['lift_command_orientation'] = normalize_quat(previous_tcp['orientation']).copy()
        return previous.copy(), previous_tcp

    def _assisted_check_model_residual(self, *, task, robot_name, spec, stamp, state,
                                       current_object, model_object, actual_q, relative):
        """Keep the original guard and retain its exact exceptional input."""
        from .beam_assisted_servo import validate_model_native_residual
        position_limit = float(spec.get('beam_assisted_fk_native_position_limit_m', .0001))
        angle_limit = float(spec.get('beam_assisted_fk_native_orientation_limit_rad', .0015))
        if spec.get('beam_assisted_lift_command_rotation_hold'):
            dp, da = pose_error(current_object['position'], current_object['orientation'],
                                model_object['position'], model_object['orientation'])
            if dp > position_limit or da > angle_limit:
                task._assisted_event('object_model_residual_rejected', robot=robot_name,
                    physics_stamp=dict(stamp), clearance_stage=state.get('clearance_path', {}).get('stage'),
                    native_object_pose=current_object, measured_model_object_pose=model_object,
                    actual_q=actual_q,
                    previous_final_q=getattr(task, '_assisted_published_q', {}).get(robot_name),
                    phase_cached_final_q=state.get('published_q'),
                    captured_object_in_tcp_position=relative[0],
                    captured_object_in_tcp_orientation=relative[1],
                    position_residual_m=dp, orientation_residual_rad=da,
                    position_limit_m=position_limit, orientation_limit_rad=angle_limit,
                    captured_grasp_reference_changed=False)
        return validate_model_native_residual(current_object, model_object, position_limit, angle_limit)

    def _assisted_phase_handoff(self, *, task, robot_name, spec, stamp, state,
                                current_object, measured_model_object, relative, actual_q):
        """Carry final publication through a native-clock-bounded mode change."""
        ticks = spec.get('beam_assisted_phase_handoff_ticks')
        full = (float(spec.get('cartesian_position_step', .001)),
                float(spec.get('cartesian_orientation_step', .004)), .02)
        if ticks is None:
            return full
        if type(ticks) is not int or ticks < 2:
            raise ValueError('assisted phase handoff needs multiple native ticks')
        if 'phase_handoff_start' not in state:
            publication = getattr(task, '_assisted_published_q_stamps', {}).get(robot_name)
            previous = np.asarray(getattr(task, '_assisted_published_q', {}).get(robot_name), float)
            if (stamp.get('valid') is not True or not isinstance(publication, dict)
                    or publication.get('epoch') != stamp.get('epoch')
                    or type(stamp.get('index')) is not int
                    or type(publication.get('index')) is not int
                    or stamp['index']-publication['index'] not in (0, 1)
                    or previous.shape != (6,) or not np.all(np.isfinite(previous))
                    or np.max(np.abs(previous-np.asarray(actual_q, float))) > .12+1e-12):
                raise ValueError('assisted phase handoff lacks a fresh final published target')
            from .beam_assisted_servo import anchored_object_prediction, object_pose_from_tcp
            previous_tcp = self._grasp_command_fk_pose(task=task, robot_name=robot_name,
                                                     spec=spec, command_q=previous)
            if previous_tcp is None:
                raise ValueError('assisted phase handoff lacks publication FK')
            previous_model = object_pose_from_tcp(previous_tcp, relative[0], relative[1])
            seed = anchored_object_prediction(current_object, measured_model_object, previous_model)
            state.update(phase_handoff_start=dict(stamp), object_command=seed,
                         phase_handoff_seed_q=previous.copy())
            task._assisted_event('phase_handoff_seed', robot=robot_name,
                previous_final_q=previous, current_q=actual_q, object_seed=seed,
                native_warm_ticks=ticks, captured_grasp_reference_changed=False)
        start = state['phase_handoff_start']
        age = stamp['index']-start['index']
        if stamp['epoch'] != start['epoch'] or age < 0:
            raise ValueError('assisted phase handoff clock changed')
        ratio = min(1., age/ticks)
        steps = tuple(min(top, low)+(top-min(top, low))*ratio
                      for low, top in zip((.0002, .0005, .004), full))
        if spec.get('beam_assisted_descent_admission') is not None:
            # The original final guard must be able to unwind an incoming
            # downward lead while admission is cold. Do not narrow its joint
            # backtracking radius merely to preserve an unsafe old target.
            steps = steps[:2] + (.02,)
        state.update(phase_handoff_age=age, phase_handoff_joint_step=steps[2])
        return steps

    def _assisted_alignment_reference(self, *, task, spec, state, stamp,
                                      current_object, model_object, target_object,
                                      descent_ready):
        """Hold a world plane and compensate bounded persistent tracking bias.

        Only controller references change. Admission, final-q guards and the
        captured grasp still use the unmodified native pose and original goal.
        """
        settings = spec.get('beam_assisted_alignment_hold')
        if settings is None:
            return current_object, target_object, model_object
        contract = spec.get('beam_assisted_descent_admission')
        if not isinstance(settings, dict) or not isinstance(contract, dict):
            raise ValueError('assisted alignment hold lacks its admission contract')
        keys = ('maximum_lateral_compensation_m', 'maximum_integral_step_m',
                'integral_gain_per_native_tick', 'cold_actual_axial_limit_m')
        limits = [float(settings[k]) for k in keys]
        if not all(math.isfinite(v) and v > 0 for v in limits):
            raise ValueError('invalid assisted alignment hold limits')
        cap, step, gain, axial_limit = limits
        tolerance = float(contract['lateral_tolerance_m'])
        if cap > .8*tolerance+1e-12 or step > cap or gain > 1.:
            raise ValueError('assisted alignment compensation exceeds its corridor')
        axis = np.asarray(spec.get('target_object_convergence_axis', [0., 0., -1.]), float)
        if axis.shape != (3,) or not np.all(np.isfinite(axis)) or np.linalg.norm(axis) < 1e-12:
            raise ValueError('invalid assisted alignment hold axis')
        axis = axis/np.linalg.norm(axis)
        current = np.asarray(current_object['position'], float)
        goal = np.asarray(target_object['position'], float)
        if (current.shape != (3,) or goal.shape != (3,)
                or not np.all(np.isfinite([current, goal]))
                or stamp.get('valid') is not True
                or type(stamp.get('epoch')) is not int or type(stamp.get('index')) is not int):
            raise ValueError('assisted alignment reference lacks a native sample')
        alignment = state.setdefault('alignment_reference', {})
        clock = (stamp['epoch'], stamp['index'])
        previous = alignment.get('clock')
        if previous is not None:
            if clock[0] != previous[0] or clock[1] < previous[1]:
                raise ValueError('assisted alignment reference clock changed')
            if clock == previous and np.max(abs(current-alignment['position'])) > 1e-12:
                raise ValueError('assisted alignment reference changed at the same native tick')
            if np.max(abs(axis-alignment['axis'])) > 1e-12:
                raise ValueError('assisted alignment reference axis changed')
        bias = np.asarray(alignment.get('lateral_bias', np.zeros(3)), float).copy()
        error = goal-current
        lateral = error-np.dot(error, axis)*axis
        if previous is not None and clock != previous and .5*tolerance < np.linalg.norm(lateral) <= 4*tolerance:
            increment = gain*lateral
            increment *= min(1., step/max(float(np.linalg.norm(increment)), 1e-15))
            bias += increment
            bias -= np.dot(bias, axis)*axis
            bias *= min(1., cap/max(float(np.linalg.norm(bias)), 1e-15))
        coordinate = float(np.dot(current, axis))
        anchor = alignment.get('cold_axis_anchor')
        displacement = 0.
        if descent_ready:
            anchor = None
        else:
            anchor = coordinate if anchor is None else min(float(anchor), coordinate)
            displacement = coordinate-anchor
            if displacement > axial_limit+1e-12:
                task._assisted_event('cold_actual_height_violation',
                    actual_axial_displacement_m=displacement, limit_m=axial_limit,
                    world_axis_reference=anchor, current_object_pose=current_object)
                raise ValueError('actual cold insertion drift exceeds its fixed world-height envelope')
        alignment.update(clock=clock, position=current.copy(), axis=axis.copy(),
                         lateral_bias=bias, cold_axis_anchor=anchor)
        target = {**target_object, 'position': goal+bias}
        if anchor is None:
            reference, model_reference = current_object, model_object
        else:
            shift = (anchor-coordinate)*axis
            reference = {**current_object, 'position': current+shift}
            model_reference = {**model_object,
                'position': np.asarray(model_object['position'], float)+shift}
        if int(task.step_counter) % 8 == 0:
            task._assisted_event('alignment_reference', lateral_bias_m=bias,
                original_target_object_pose=target_object, descent_ready=descent_ready,
                cold_world_axis_reference=anchor, actual_cold_axial_displacement_m=displacement,
                cold_actual_axial_limit_m=axial_limit, captured_grasp_reference_changed=False)
        return reference, target, model_reference

    def _assisted_absolute_object_servo_pose(self, *, phase_key, task, robot_name, spec,
                                            tracked_robots, tracked_objects,
                                            object_pose, target_object_pose):
        from .beam_assisted_servo import (
            absolute_object_servo, descent_admission, object_pose_from_tcp,
            staged_clearance_target,
        )
        name, stamp, native, object_pose, relative, state = self._assisted_object_servo_context(
            phase_key=phase_key, task=task, robot_name=robot_name, spec=spec,
            tracked_robots=tracked_robots, tracked_objects=tracked_objects)
        contract = spec.get('beam_assisted_descent_admission')
        axis = spec.get('target_object_convergence_axis', [0., 0., -1.])
        ready, detail = True, None
        if contract is not None:
            ready, detail = descent_admission(state.setdefault('admission', {}), stamp,
                object_pose, target_object_pose, axis, contract, native)
            # Completion must not bypass a still-cold measured alignment gate.
            self._insertion_lateral_alignment_active[phase_key] = not ready
        actual_q = self._current_arm_q(task, robot_name)
        model_tcp = self._grasp_command_fk_pose(task=task, robot_name=robot_name,
                                                spec=spec, command_q=actual_q)
        if model_tcp is None:
            raise ValueError('assisted object servo lacks measured-joint model FK')
        model_object = object_pose_from_tcp(model_tcp, relative[0], relative[1])
        baseline_position, baseline_angle = self._assisted_check_model_residual(
            task=task, robot_name=robot_name, spec=spec, stamp=stamp, state=state,
            current_object=object_pose, model_object=model_object, actual_q=actual_q, relative=relative)
        position_step, orientation_step, _ = self._assisted_phase_handoff(
            task=task, robot_name=robot_name, spec=spec, stamp=stamp, state=state,
            current_object=object_pose, measured_model_object=model_object,
            relative=relative, actual_q=actual_q)
        servo_object, servo_target, servo_model = self._assisted_alignment_reference(
            task=task, spec=spec, state=state, stamp=stamp,
            current_object=object_pose, model_object=model_object,
            target_object=target_object_pose, descent_ready=ready)
        if spec.get('beam_assisted_staged_clearance'):
            servo_target = staged_clearance_target(state, stamp, object_pose,
                target_object_pose, spec['beam_assisted_staged_clearance'])
        incremental = bool(spec.get('beam_assisted_incremental_clearance'))
        if incremental:
            from .beam_assisted_servo import incremental_clearance_command, object_pose_from_tcp
            stage = state.get('clearance_path', {}).get('stage')
            previous_q, previous_tcp = self._assisted_lift_hold_publication(
                task=task, robot_name=robot_name, spec=spec, stamp=stamp, state=state, actual_q=actual_q)
            if 'incremental_drive_reference' not in state:
                from .planner_primitives import quat_conjugate as _entry_conjugate,quat_multiply as _entry_multiply,normalize_quat as _entry_normalize
                initial_model=object_pose_from_tcp(previous_tcp,*relative)
                state['incremental_drive_reference']=dict(
                    position=np.asarray(initial_model['position'])-np.asarray(object_pose['position']),
                    orientation=_entry_normalize(_entry_multiply(initial_model['orientation'],_entry_conjugate(np.asarray(object_pose['orientation'])))))
                task._assisted_event('incremental_drive_reference',robot=robot_name,
                    retained_entry_bias=state['incremental_drive_reference'],
                    previous_final_model_pose=initial_model,native_entry_pose=object_pose,
                    captured_grasp_reference_changed=False)
            old_request = state.get('incremental_request')
            same_tick = bool(old_request and old_request['stamp'] == stamp)
            if same_tick and (not np.array_equal(old_request['actual_q'], actual_q)
                    or not np.array_equal(old_request['native_position'], object_pose['position'])
                    or not np.array_equal(old_request['native_orientation'], object_pose['orientation'])):
                raise ValueError('incremental clearance observations changed within a native tick')
            if same_tick and np.array_equal(old_request['previous_q'], previous_q):
                command, requested_model, increment_detail = (
                    old_request['tcp'], old_request['model'], old_request['detail'])
            else:
                accepted_repeat = bool(same_tick and state.get('incremental_accepted_stamp') == stamp
                    and np.array_equal(state.get('published_q'), previous_q))
                if same_tick and not accepted_repeat:
                    raise ValueError('unowned final publication changed within incremental tick')
                command, requested_model, increment_detail = incremental_clearance_command(
                    object_pose, model_object, previous_tcp, relative, servo_target, stage,
                    position_step, orientation_step,
                    position_lookahead=float(spec.get('target_object_servo_position_command_lookahead', .003)),
                    orientation_lookahead=float(spec.get('cartesian_orientation_command_lookahead', .02)),
                    hold=bool(accepted_repeat or state.get('phase_handoff_age') == 0),
                    drive_reference=state['incremental_drive_reference'])
            state['incremental_request'] = dict(stamp=dict(stamp), previous_q=previous_q.copy(),
                actual_q=actual_q.copy(), native_position=np.asarray(object_pose['position']).copy(),
                native_orientation=np.asarray(object_pose['orientation']).copy(),
                tcp=command, model=requested_model, detail=increment_detail,
                previous_model=object_pose_from_tcp(previous_tcp, *relative))
            object_command = increment_detail['predicted_native_pose']
        else:
            command, object_command = absolute_object_servo(
            servo_object, servo_target, relative[0], relative[1],
            position_step, orientation_step,
            previous_object_command=state.get('object_command'),
            position_lookahead=float(spec.get('target_object_servo_position_command_lookahead', .003)),
            orientation_lookahead=float(spec.get('cartesian_orientation_command_lookahead', .02)),
            convergence_axis=axis if contract is not None else None,
            allow_axial_motion=ready, measured_fk_object_pose=servo_model)
        hold_lift = bool(not incremental and spec.get('beam_assisted_lift_command_rotation_hold')
                         and state.get('clearance_path', {}).get('stage') == 'lift')
        state['lift_command_hold_active'] = hold_lift
        state['lift_command_zero_motion'] = False
        if hold_lift:
            _, previous_tcp = self._assisted_lift_hold_publication(
                task=task, robot_name=robot_name, spec=spec, stamp=stamp, state=state, actual_q=actual_q)
            dp, da = pose_error(servo_object['position'], servo_object['orientation'],
                                servo_target['position'], servo_target['orientation'])
            state['lift_command_zero_motion'] = dp <= 1e-12 and da <= 1e-12
            if state['lift_command_zero_motion']:
                command = {k: np.asarray(previous_tcp[k], float).copy() for k in ('position', 'orientation')}
            else:
                # Retain the model-object translation, but invert the SAME
                # frozen grasp with the loaded drive rotation. Replacing only
                # the quaternion would move the long grasp's lever arm.
                model_position = (np.asarray(command['position'], float)
                                  + quat_rotate(command['orientation'], relative[0]))
                orientation = state['lift_command_orientation'].copy()
                command = {'position': model_position-quat_rotate(orientation, relative[0]),
                           'orientation': orientation}
        state.update(requested_object_command=object_command, descent_ready=ready,
                     admission_detail=detail, stamp=dict(stamp))
        if int(task.step_counter) % 8 == 0:
            task._assisted_event('absolute_object_servo', robot=robot_name, object=name,
                current_object_pose=object_pose, command_object_pose=object_command,
                command_tcp_pose=command, descent_admission=detail,
                fk_native_position_residual_m=baseline_position,
                fk_native_orientation_residual_rad=baseline_angle,
                clearance_stage=state.get('clearance_path', {}).get('stage'))
        return command

    def _assisted_verify_published_held_command(self, *, task, robot_name, context,
                                               command_q, current_q, previous_q=None):
        """Validate the final explicit joints, including the outer native clamp."""
        from .beam_assisted_servo import (
            anchored_object_prediction, object_pose_from_tcp, published_object_command_safe,
        )
        spec, phase_key = context['spec'], context['phase_key']
        if (context['phase_index'] != getattr(task, 'phase_index', None)
                or context['phase_entry_step'] != getattr(task, 'phase_entry_step', None)):
            raise ValueError('stale assisted object command context')
        name, stamp, native, current_object, relative, state = self._assisted_object_servo_context(
            phase_key=phase_key, task=task, robot_name=robot_name, spec=spec,
            tracked_robots=context['tracked_robots'], tracked_objects=context['tracked_objects'])
        target = self._target_object_pose(task=task, spec=spec)
        contract = spec.get('beam_assisted_descent_admission')
        ready = bool(state.get('descent_ready') and state.get('stamp') == stamp)
        actual = np.asarray(current_q, float)
        requested = np.asarray(command_q, float)
        if actual.shape != (6,) or requested.shape != (6,) or not np.all(np.isfinite([actual, requested])):
            raise ValueError('assisted final object command requires six native joints')
        actual_tcp = self._grasp_command_fk_pose(task=task, robot_name=robot_name,
                                                 spec=spec, command_q=actual)
        if actual_tcp is None:
            raise ValueError('assisted final object command lacks measured-joint FK')
        actual_fk_object = object_pose_from_tcp(actual_tcp, relative[0], relative[1])
        baseline_position, baseline_angle = self._assisted_check_model_residual(
            task=task, robot_name=robot_name, spec=spec, stamp=stamp, state=state,
            current_object=current_object, model_object=actual_fk_object, actual_q=actual, relative=relative)
        joint_cap = min(.02, float(state.get('phase_handoff_joint_step', .02)))
        incremental = bool(spec.get('beam_assisted_incremental_clearance'))
        increment_request = state.get('incremental_request') if incremental else None
        if incremental:
            fresh_previous, _ = self._assisted_lift_hold_publication(
                task=task, robot_name=robot_name, spec=spec, stamp=stamp, state=state, actual_q=actual)
            if (increment_request is None or increment_request['stamp'] != stamp
                    or previous_q is None or not np.array_equal(previous_q, fresh_previous)
                    or not np.array_equal(increment_request['previous_q'], fresh_previous)):
                raise ValueError('incremental clearance lacks its current final publication')
        hold_lift = bool(spec.get('beam_assisted_lift_command_rotation_hold')
                         and state.get('lift_command_hold_active') and not incremental)
        if hold_lift:
            if state.get('stamp') != stamp or state.get('clearance_path', {}).get('stage') != 'lift':
                raise ValueError('loaded lift lacks a current stage reference')
            fresh_previous, previous_tcp = self._assisted_lift_hold_publication(
                task=task, robot_name=robot_name, spec=spec, stamp=stamp, state=state, actual_q=actual)
            if previous_q is None or not np.array_equal(np.asarray(previous_q, float), fresh_previous):
                raise ValueError('loaded lift final publication changed before its guard')
            if state.get('lift_command_zero_motion'):
                requested = fresh_previous.copy()
        if spec.get('beam_assisted_phase_handoff_ticks') is not None:
            if previous_q is None or 'phase_handoff_age' not in state:
                raise ValueError('assisted final handoff lacks its current entry state')
            if state['phase_handoff_age'] == 0:
                requested = np.asarray(previous_q, float).copy()
        last_detail = None
        for ratio in (1., .5, .25, .125, .0625, 0.):
            # A measured-state backtrack releases the existing loaded drive
            # bias. Only this explicit lift mode backtracks from publication.
            origin = np.asarray(previous_q, float) if (hold_lift or incremental) else actual
            candidate = origin + ratio*(requested-origin)
            if previous_q is not None:
                # Re-check after the safety backtrack as well: moving toward
                # measured hold must not bypass the last-publication step cap.
                candidate = np.asarray(previous_q, float) + np.clip(
                    candidate-np.asarray(previous_q, float), -joint_cap, joint_cap)
                candidate = np.clip(candidate, actual-.12, actual+.12)
            tcp = self._grasp_command_fk_pose(task=task, robot_name=robot_name,
                                               spec=spec, command_q=candidate)
            if tcp is None:
                raise ValueError('assisted final object command lacks calibrated FK')
            lift_detail = None
            incremental_detail = None
            if incremental:
                from .beam_assisted_servo import interpolate_object_pose
                from .planner_primitives import quat_conjugate
                intended = interpolate_object_pose(increment_request['previous_model'],
                                                   increment_request['model'], ratio)
                desired_tcp_q = normalize_quat(quat_multiply(intended['orientation'],
                                                    quat_conjugate(relative[1])))
                desired_tcp = dict(position=intended['position']-quat_rotate(desired_tcp_q, relative[0]),
                                   orientation=desired_tcp_q)
                # Numerical publication consistency, not a changed physical
                # budget. Refine the complete intended pose after outer clamps.
                dp, da = pose_error(tcp['position'], tcp['orientation'],
                                    desired_tcp['position'], desired_tcp['orientation'])
                refined = False
                if ratio == 0.:
                    candidate = fresh_previous.copy()
                    tcp = self._grasp_command_fk_pose(task=task, robot_name=robot_name,
                                                     spec=spec, command_q=candidate)
                elif dp > 1e-6 or da > 1e-6:
                    refined_q = self._local_grasp_ik(task=task, robot_name=robot_name,
                        target_pose=desired_tcp, reference_q=fresh_previous, joint_radius=joint_cap,
                        spec={**spec, 'ik_position_tolerance': min(float(spec.get('ik_position_tolerance', .00005)), 1e-6),
                              'ik_orientation_tolerance': min(float(spec.get('ik_orientation_tolerance', .0005)), 1e-6)})
                    if refined_q is None:
                        continue
                    candidate = np.asarray(refined_q, float)
                    if (candidate.shape != (6,) or not np.all(np.isfinite(candidate))
                            or np.max(abs(candidate-fresh_previous)) > joint_cap+1e-12
                            or np.max(abs(candidate-actual)) > .12+1e-12):
                        continue
                    tcp = self._grasp_command_fk_pose(task=task, robot_name=robot_name,
                                                     spec=spec, command_q=candidate)
                    refined = True
                dp, da = pose_error(tcp['position'], tcp['orientation'],
                                    desired_tcp['position'], desired_tcp['orientation'])
                if dp > 1e-6 or da > 1e-6:
                    continue
                incremental_detail = dict(stage=increment_request['detail']['stage'],
                    position_consistency_m=dp, orientation_consistency_rad=da,
                    refined=refined, hold_fallback=bool(ratio == 0.),
                    previous_final_q=fresh_previous, intended_model=intended)
            if hold_lift:
                _, rotation_error = pose_error(tcp['position'], tcp['orientation'],
                    tcp['position'], state['lift_command_orientation'])
                refined = False
                # This is numerical command consistency, not a relaxed
                # physical success/model threshold. Refine inside the ORIGINAL
                # publication joint box after outer clamps have run.
                if rotation_error > 1e-6 and ratio != 0.:
                    refined_q = self._local_grasp_ik(task=task, robot_name=robot_name,
                        target_pose={'position': tcp['position'],
                                     'orientation': state['lift_command_orientation']},
                        reference_q=fresh_previous,
                        spec={**spec, 'ik_orientation_tolerance': min(
                            float(spec.get('ik_orientation_tolerance', .0005)), 1e-6)},
                        joint_radius=joint_cap)
                    if refined_q is None:
                        continue
                    candidate = np.asarray(refined_q, float)
                    if (candidate.shape != (6,) or not np.all(np.isfinite(candidate))
                            or np.max(abs(candidate-fresh_previous)) > joint_cap+1e-12
                            or np.max(abs(candidate-actual)) > .12+1e-12):
                        continue
                    tcp = self._grasp_command_fk_pose(task=task, robot_name=robot_name,
                                                    spec=spec, command_q=candidate)
                    if tcp is None:
                        raise ValueError('loaded lift refined command lacks FK')
                    _, rotation_error = pose_error(tcp['position'], tcp['orientation'],
                        tcp['position'], state['lift_command_orientation'])
                    refined = True
                if rotation_error > 1e-6:
                    continue
                lift_detail = dict(orientation_error_rad=rotation_error, refined=refined,
                    hold_fallback=bool(ratio == 0. and not np.array_equal(requested, fresh_previous)),
                    zero_motion=bool(state.get('lift_command_zero_motion')),
                    translation_step_m=float(np.linalg.norm(np.asarray(tcp['position'])
                                                           - np.asarray(previous_tcp['position']))))
            predicted = object_pose_from_tcp(tcp, relative[0], relative[1])
            if incremental:
                native_candidate = anchored_object_prediction(current_object, actual_fk_object, predicted)
                lead_p, lead_a = pose_error(current_object['position'], current_object['orientation'],
                                           native_candidate['position'], native_candidate['orientation'])
                if (lead_p > float(spec.get('target_object_servo_position_command_lookahead', .003))+1e-12
                        or lead_a > float(spec.get('cartesian_orientation_command_lookahead', .02))+1e-12):
                    continue
            allowed, detail = True, {}
            if contract is not None:
                # Sweep the complete bounded joint increment. This cheap FK
                # check supplements, rather than replaces, the CAD certificate.
                for fraction in (.25, .5, .75, 1.):
                    sample_tcp = (tcp if fraction == 1. else self._grasp_command_fk_pose(
                        task=task, robot_name=robot_name, spec=spec,
                        command_q=actual+fraction*(candidate-actual)))
                    if sample_tcp is None:
                        raise ValueError('assisted final object sweep lacks FK')
                    sample_model = object_pose_from_tcp(sample_tcp, relative[0], relative[1])
                    sample = anchored_object_prediction(current_object, actual_fk_object, sample_model)
                    allowed, detail = published_object_command_safe(current_object, sample, target,
                        spec.get('target_object_convergence_axis', [0., 0., -1.]), contract, ready)
                    if not allowed:
                        break
                detail['checked_joint_fraction'] = fraction
            if allowed and spec.get('beam_assisted_production_cad_guard'):
                guard = getattr(task, '_assisted_production_cad_guard', None)
                if not callable(guard):
                    raise ValueError('loaded free motion lacks its production CAD guard')
                allowed, cad_detail = guard(robot_name=robot_name, object_name=name,
                    command_q=candidate, current_q=actual, relative=relative,
                    physics_stamp=stamp)
                detail['production_cad'] = cad_detail
            last_detail = dict(detail, accepted_ratio=ratio, object=name,
                fk_native_position_residual_m=baseline_position,
                fk_native_orientation_residual_rad=baseline_angle)
            if lift_detail is not None:
                last_detail['lift_command_rotation_hold'] = lift_detail
            if allowed:
                # Only the FK of the target that will actually be published
                # becomes the next object-space lead. Never cache rejected IK.
                state['object_command'] = anchored_object_prediction(current_object, actual_fk_object, predicted)
                state['published_model_object_pose'] = predicted
                state['published_q'] = candidate.copy()
                if incremental_detail is not None:
                    state['incremental_accepted_stamp'] = dict(stamp)
                    task._assisted_event('incremental_clearance_command', robot=robot_name,
                        physics_stamp=dict(stamp), accepted_ratio=ratio,
                        published_q=candidate, **incremental_detail)
                if lift_detail is not None:
                    task._assisted_event('lift_command_rotation_hold', robot=robot_name,
                        physics_stamp=dict(stamp), accepted_ratio=ratio,
                        previous_final_q=fresh_previous, published_q=candidate,
                        **lift_detail)
                return candidate, last_detail
        raise ValueError('no safe assisted explicit-joint command, including measured hold: '
                         + repr(last_detail))

    def _target_object_servo_pose(  # noqa: C901
        self,
        *,
        phase_key,
        task,
        robot_name: str,
        spec: dict,
        tracked_robots: dict,
        tracked_objects: dict,
        current_pose: dict,
        target_pose: dict,
    ) -> dict:
        max_position_step = float(spec.get('cartesian_position_step', 0.01))
        max_orientation_step = float(spec.get('cartesian_orientation_step', 0.01))
        default_object_servo = any(
            spec.get(name) is not None
            for name in ('target_object_position', 'target_object_target', 'target_object', 'object_target')
        )
        if spec.get('fabrica_native_lateral_hold'):
            return self._stool_native_lateral_hold_pose(
                phase_key=phase_key, task=task, robot_name=robot_name, spec=spec,
                current_pose=current_pose, target_pose=target_pose,
            )
        if not bool(spec.get('servo_target_object_pose', default_object_servo)):
            return self._cartesian_command_servo_target_pose(
                phase_key=phase_key,
                current_pose=current_pose,
                target_pose=target_pose,
                max_position_step=max_position_step,
                max_orientation_step=max_orientation_step,
                spec=spec,
            )

        object_name = self._object_name_from_spec(spec)
        object_pose = (
            None
            if object_name is None
            else self._object_pose(
                task=task,
                object_name=object_name,
                tracked_objects=tracked_objects,
            )
        )
        target_object_pose = self._target_object_pose(task=task, spec=spec)
        if object_pose is None or target_object_pose is None:
            return self._cartesian_command_servo_target_pose(
                phase_key=phase_key,
                current_pose=current_pose,
                target_pose=target_pose,
                max_position_step=max_position_step,
                max_orientation_step=max_orientation_step,
                spec=spec,
            )

        current_object_position = np.asarray(object_pose['position'], dtype=float)
        target_object_position = np.asarray(target_object_pose['position'], dtype=float)
        if (spec.get('beam_assisted') and spec.get('requires_held_object')
                and spec.get('beam_assisted_absolute_object_servo')):
            return self._assisted_absolute_object_servo_pose(
                phase_key=phase_key, task=task, robot_name=robot_name, spec=spec,
                tracked_robots=tracked_robots, tracked_objects=tracked_objects,
                object_pose=object_pose, target_object_pose=target_object_pose)
        object_delta = target_object_position - current_object_position
        _, _, attachment_mode = self._compliant_attachment_allowance(
            object_name=object_name,
            tracked_objects=tracked_objects,
        )
        if attachment_mode == 'compliant_joint':
            motion_detail = self._object_motion_detail(
                task=task,
                object_name=object_name,
                tracked_objects=tracked_objects,
            )
            compliant_step_scale = self._compliant_servo_step_scale(
                spec=spec,
                motion_detail=motion_detail,
            )
            compliant_max_position_step = float(spec.get('compliant_servo_max_position_step', 0.0005))
            compliant_max_orientation_step = float(spec.get('compliant_servo_max_orientation_step', 0.002))
            if (
                not np.isfinite(compliant_max_position_step)
                or compliant_max_position_step <= 0.0
                or not np.isfinite(compliant_max_orientation_step)
                or compliant_max_orientation_step <= 0.0
            ):
                raise ValueError('Compliant-servo Cartesian step limits must be finite and positive.')
            max_position_step = (
                min(
                    max_position_step,
                    compliant_max_position_step,
                )
                * compliant_step_scale
            )
            max_orientation_step = (
                min(
                    max_orientation_step,
                    compliant_max_orientation_step,
                )
                * compliant_step_scale
            )
        orientation_step = self._cartesian_command_servo_target_pose(
            phase_key=phase_key,
            current_pose=current_pose,
            target_pose=target_pose,
            max_position_step=0.0,
            max_orientation_step=max_orientation_step,
            spec=spec,
        )
        compliant_tcp_orientation = None
        target_object_orientation = target_object_pose.get('orientation')
        if (
            attachment_mode == 'compliant_joint'
            and bool(spec.get('compliant_servo_track_object_orientation', False))
            and target_object_orientation is not None
            and object_pose.get('orientation') is not None
        ):
            orientation_deadband = float(
                spec.get(
                    'compliant_servo_orientation_correction_deadband',
                    0.005,
                )
            )
            object_orientation_tolerance = spec.get('target_object_orientation_tolerance')
            if object_orientation_tolerance is not None:
                object_orientation_tolerance = float(object_orientation_tolerance)
                activation_ratio = float(
                    spec.get(
                        'compliant_servo_orientation_tolerance_activation_ratio',
                        0.5,
                    )
                )
                if not np.isfinite(activation_ratio) or activation_ratio <= 0.0 or activation_ratio > 1.0:
                    raise ValueError('Compliant-servo orientation activation ratio must be ' 'finite and in (0, 1].')
                orientation_deadband = max(
                    orientation_deadband,
                    activation_ratio * object_orientation_tolerance,
                )
            if not np.isfinite(orientation_deadband) or orientation_deadband < 0.0 or orientation_deadband > math.pi:
                raise ValueError('Compliant-servo orientation correction deadband must be finite ' 'and in [0, pi].')
            _, object_orientation_error = pose_error(
                current_object_position,
                object_pose['orientation'],
                current_object_position,
                target_object_orientation,
            )
            compliant_tcp_orientation = normalize_quat(orientation_step['orientation'])
            object_orientation_correction = quat_multiply(
                normalize_quat(target_object_orientation),
                self._quat_conjugate(object_pose['orientation']),
            )
            if object_orientation_error is not None and object_orientation_error > orientation_deadband:
                compliant_tcp_orientation = normalize_quat(
                    quat_multiply(
                        object_orientation_correction,
                        current_pose['orientation'],
                    )
                )
                compliant_tcp_orientation = self._cartesian_servo_target_pose(
                    current_pose=current_pose,
                    target_pose={
                        'position': np.asarray(current_pose['position'], dtype=float),
                        'orientation': compliant_tcp_orientation,
                    },
                    max_position_step=0.0,
                    max_orientation_step=max_orientation_step,
                )['orientation']
        convergence_axis = spec.get('target_object_convergence_axis')
        lateral_tolerance = spec.get('target_object_lateral_position_tolerance')
        axial_delta = None
        if convergence_axis is not None and lateral_tolerance is not None:
            convergence_axis = np.asarray(convergence_axis, dtype=float)
            axis_norm = float(np.linalg.norm(convergence_axis))
            if convergence_axis.shape != (3,) or not np.isfinite(axis_norm) or axis_norm <= 1e-9:
                raise ValueError('target_object_convergence_axis must be a finite non-zero 3D vector.')
            convergence_axis = convergence_axis / axis_norm
            lateral_tolerance = float(lateral_tolerance)
            if not np.isfinite(lateral_tolerance) or lateral_tolerance < 0.0:
                raise ValueError('target_object_lateral_position_tolerance must be finite and non-negative.')
            alignment_enter_tolerance = float(
                spec.get(
                    'target_object_lateral_alignment_enter_tolerance',
                    lateral_tolerance,
                )
            )
            alignment_exit_tolerance = float(
                spec.get(
                    'target_object_lateral_alignment_exit_tolerance',
                    alignment_enter_tolerance,
                )
            )
            if (
                not np.isfinite(alignment_enter_tolerance)
                or alignment_enter_tolerance < 0.0
                or not np.isfinite(alignment_exit_tolerance)
                or alignment_exit_tolerance < alignment_enter_tolerance
            ):
                raise ValueError(
                    'target-object lateral alignment tolerances must be finite, '
                    'non-negative, and ordered enter <= exit.'
                )
            lateral_alignment_step = float(
                spec.get(
                    'target_object_lateral_alignment_cartesian_position_step',
                    max_position_step,
                )
            )
            if not np.isfinite(lateral_alignment_step) or lateral_alignment_step <= 0.0:
                raise ValueError(
                    'target_object_lateral_alignment_cartesian_position_step must be ' 'finite and positive.'
                )
            if attachment_mode == 'compliant_joint':
                compliant_max_lateral_step = float(spec.get('compliant_servo_max_lateral_step', 0.0005))
                if not np.isfinite(compliant_max_lateral_step) or compliant_max_lateral_step <= 0.0:
                    raise ValueError('compliant_servo_max_lateral_step must be finite and positive.')
                lateral_alignment_step = (
                    min(
                        lateral_alignment_step,
                        compliant_max_lateral_step,
                    )
                    * compliant_step_scale
                )
            axial_delta = float(np.dot(object_delta, convergence_axis))
            lateral_delta = object_delta - axial_delta * convergence_axis
            lateral_error = float(np.linalg.norm(lateral_delta))
            axial_recovery_step = None
            axial_recovery_deadband = 0.0
            axial_clearance = 0.0
            clearance_required = False
            clearance_ready = True
            if attachment_mode == 'compliant_joint':
                axial_recovery_step = spec.get('target_object_axial_recovery_cartesian_position_step')
                if axial_recovery_step is not None:
                    axial_recovery_step = float(axial_recovery_step)
                    axial_recovery_deadband = float(spec.get('target_object_axial_recovery_deadband', 0.0))
                    axial_clearance = float(
                        spec.get(
                            'target_object_lateral_alignment_axial_clearance',
                            0.0,
                        )
                    )
                    max_alignment_retraction = spec.get('compliant_servo_max_alignment_retraction')
                    if max_alignment_retraction is not None:
                        max_alignment_retraction = float(max_alignment_retraction)
                        insertion_path_depth = float(spec.get('target_object_insertion_path_depth', 0.0))
                        if (
                            not np.isfinite(max_alignment_retraction)
                            or max_alignment_retraction <= 0.0
                            or not np.isfinite(insertion_path_depth)
                            or insertion_path_depth < 0.0
                        ):
                            raise ValueError(
                                'Compliant alignment retraction must be finite and '
                                'positive, and insertion path depth must be finite '
                                'and non-negative.'
                            )
                    if (
                        not np.isfinite(axial_recovery_step)
                        or axial_recovery_step <= 0.0
                        or not np.isfinite(axial_recovery_deadband)
                        or axial_recovery_deadband < 0.0
                        or not np.isfinite(axial_clearance)
                        or axial_clearance < 0.0
                    ):
                        raise ValueError(
                            'target-object axial recovery step must be finite and '
                            'positive, and its deadband and lateral-alignment axial '
                            'clearance must be finite and non-negative.'
                        )
                    clearance_required = bool(
                        self._insertion_lateral_clearance_required.get(
                            phase_key,
                            False,
                        )
                        or (axial_clearance > 0.0 and lateral_error > alignment_exit_tolerance)
                    )
                    if clearance_required and max_alignment_retraction is not None:
                        axial_clearance = self._insertion_lateral_clearance_anchors.setdefault(
                            phase_key,
                            min(
                                axial_clearance,
                                axial_delta + max_alignment_retraction,
                            ),
                        )
                    elif not clearance_required:
                        self._insertion_lateral_clearance_anchors.pop(
                            phase_key,
                            None,
                        )
                    clearance_ready = bool(
                        not clearance_required or axial_delta >= axial_clearance - axial_recovery_deadband
                    )
            previous_alignment_active = self._insertion_lateral_alignment_active.get(
                phase_key,
                True,
            )
            alignment_active = previous_alignment_active
            required_alignment_stable_steps = max(
                int(spec.get('target_object_lateral_alignment_stable_steps', 1)),
                1,
            )
            if alignment_active:
                if lateral_error <= alignment_enter_tolerance and clearance_ready:
                    alignment_stable_steps = (
                        int(
                            self._insertion_lateral_alignment_stable_steps.get(
                                phase_key,
                                0,
                            )
                        )
                        + 1
                    )
                    self._insertion_lateral_alignment_stable_steps[phase_key] = alignment_stable_steps
                    alignment_active = alignment_stable_steps < required_alignment_stable_steps
                else:
                    self._insertion_lateral_alignment_stable_steps[phase_key] = 0
            else:
                alignment_active = lateral_error > alignment_exit_tolerance
                if alignment_active:
                    self._insertion_lateral_alignment_stable_steps[phase_key] = 0
            self._insertion_lateral_alignment_active[phase_key] = alignment_active
            if alignment_active != previous_alignment_active:
                self._cartesian_command_positions.pop(phase_key, None)
            if alignment_active and clearance_required:
                self._insertion_lateral_clearance_required[phase_key] = True
            else:
                self._insertion_lateral_clearance_required.pop(phase_key, None)
                self._insertion_lateral_clearance_anchors.pop(phase_key, None)
            if alignment_active:
                if attachment_mode == 'compliant_joint':
                    gate_object_position = current_object_position + lateral_delta
                    if lateral_error > lateral_alignment_step:
                        command_object_position = current_object_position + lateral_delta * (
                            lateral_alignment_step / lateral_error
                        )
                    else:
                        command_object_position = current_object_position + lateral_delta
                    if axial_recovery_step is not None:
                        required_recovery = axial_clearance - axial_delta if clearance_required else -axial_delta
                        if required_recovery > axial_recovery_deadband:
                            gate_object_position = gate_object_position - required_recovery * convergence_axis
                            recovery_distance = min(
                                required_recovery,
                                axial_recovery_step * compliant_step_scale,
                            )
                            command_object_position = command_object_position - recovery_distance * convergence_axis
                    if bool(
                        spec.get(
                            'compliant_servo_hold_orientation_during_lateral_alignment',
                            True,
                        )
                    ):
                        orientation_anchor = self._insertion_lateral_orientation_anchors.setdefault(
                            phase_key,
                            normalize_quat(current_pose['orientation']),
                        )
                        command_orientation = self._cartesian_servo_target_pose(
                            current_pose=current_pose,
                            target_pose={
                                'position': np.asarray(
                                    current_pose['position'],
                                    dtype=float,
                                ),
                                'orientation': orientation_anchor,
                            },
                            max_position_step=0.0,
                            max_orientation_step=max_orientation_step,
                        )['orientation']
                    else:
                        command_orientation = (
                            compliant_tcp_orientation
                            if compliant_tcp_orientation is not None
                            else normalize_quat(orientation_step['orientation'])
                        )
                    relative_world = current_object_position - np.asarray(
                        current_pose['position'],
                        dtype=float,
                    )
                    relative_position = quat_rotate(
                        self._quat_conjugate(current_pose['orientation']),
                        relative_world,
                    )
                    if relative_position.shape == (3,) and np.all(np.isfinite(relative_position)):
                        position_servo_orientation = command_orientation
                        if bool(
                            spec.get(
                                'target_object_use_measured_orientation_for_position_servo',
                                True,
                            )
                        ):
                            position_servo_orientation = normalize_quat(current_pose['orientation'])
                        one_step_tcp_position = command_object_position - quat_rotate(
                            position_servo_orientation,
                            relative_position,
                        )
                        gate_tcp_position = gate_object_position - quat_rotate(
                            position_servo_orientation,
                            relative_position,
                        )
                        one_step_tcp_position = self._accumulated_cartesian_command_position(
                            phase_key=phase_key,
                            current_position=np.asarray(current_pose['position'], dtype=float),
                            one_step_position=one_step_tcp_position,
                            gate_position=gate_tcp_position,
                            enabled=bool(
                                spec.get(
                                    'compliant_servo_position_command_warm_start',
                                    True,
                                )
                            ),
                            allow_gate_overdrive=bool(
                                spec.get(
                                    'compliant_servo_position_command_gate_overdrive',
                                    True,
                                )
                            ),
                            accumulation_step=float(
                                spec.get(
                                    'compliant_servo_position_command_accumulation_step',
                                    0.0001,
                                )
                            ),
                            lookahead=float(
                                spec.get(
                                    'compliant_servo_position_command_lookahead',
                                    0.004,
                                )
                            ),
                        )
                        return {
                            'position': one_step_tcp_position,
                            'orientation': command_orientation,
                        }
                # Shift the stable final TCP target back to the current insertion depth.
                # Rebuilding this target from the live, loaded object/TCP transform can
                # reverse the lateral correction when the grasp has a large lever arm.
                current_axial_position = float(np.dot(current_object_position, convergence_axis))
                axial_anchor = self._insertion_axial_anchors.setdefault(
                    phase_key,
                    current_axial_position,
                )
                target_axial_position = float(np.dot(target_object_position, convergence_axis))
                gate_target_pose = {
                    'position': np.asarray(target_pose['position'], dtype=float)
                    + (axial_anchor - target_axial_position) * convergence_axis,
                    'orientation': normalize_quat(target_pose['orientation']),
                }
                command_pose = self._cartesian_command_servo_target_pose(
                    phase_key=phase_key,
                    current_pose=current_pose,
                    target_pose=gate_target_pose,
                    max_position_step=lateral_alignment_step,
                    max_orientation_step=max_orientation_step,
                    spec=spec,
                )
                command_pose['position'] = self._accumulated_cartesian_command_position(
                    phase_key=phase_key,
                    current_position=np.asarray(current_pose['position'], dtype=float),
                    one_step_position=np.asarray(command_pose['position'], dtype=float),
                    gate_position=np.asarray(gate_target_pose['position'], dtype=float),
                    enabled=bool(
                        spec.get(
                            'target_object_servo_position_command_warm_start',
                            False,
                        )
                    ),
                    lookahead=float(
                        spec.get(
                            'target_object_servo_position_command_lookahead',
                            0.004,
                        )
                    ),
                    allow_gate_overdrive=bool(
                        spec.get(
                            'target_object_servo_position_command_gate_overdrive',
                            True,
                        )
                    ),
                    accumulation_step=float(
                        spec.get(
                            'target_object_servo_position_command_accumulation_step',
                            0.0001,
                        )
                    ),
                )
                return command_pose
            else:
                self._insertion_axial_anchors.pop(phase_key, None)
                self._insertion_lateral_alignment_stable_steps.pop(phase_key, None)
                self._insertion_lateral_orientation_anchors.pop(phase_key, None)
                self._insertion_lateral_clearance_anchors.pop(phase_key, None)
        effective_position_step = max_position_step
        if axial_delta is not None and spec.get('target_object_axial_recovery_cartesian_position_step') is not None:
            axial_recovery_step = float(spec['target_object_axial_recovery_cartesian_position_step'])
            axial_recovery_deadband = float(spec.get('target_object_axial_recovery_deadband', 0.0))
            if (
                not np.isfinite(axial_recovery_step)
                or axial_recovery_step <= 0.0
                or not np.isfinite(axial_recovery_deadband)
                or axial_recovery_deadband < 0.0
            ):
                raise ValueError(
                    'target-object axial recovery step must be finite and positive, '
                    'and its deadband must be finite and non-negative.'
                )
            if axial_delta < -axial_recovery_deadband:
                effective_position_step = max(
                    effective_position_step,
                    axial_recovery_step,
                )
        object_distance = float(np.linalg.norm(object_delta))
        if attachment_mode == 'compliant_joint' and axial_delta is not None:
            axial_step = float(
                np.clip(
                    axial_delta,
                    -effective_position_step,
                    effective_position_step,
                )
            )
            if lateral_error > lateral_alignment_step:
                lateral_step = lateral_delta * (lateral_alignment_step / lateral_error)
            else:
                lateral_step = lateral_delta
            command_object_position = current_object_position + axial_step * convergence_axis + lateral_step
        elif effective_position_step > 0.0 and object_distance > effective_position_step:
            command_object_position = current_object_position + object_delta * (
                effective_position_step / object_distance
            )
        else:
            command_object_position = current_object_position + object_delta
        command_orientation = (
            compliant_tcp_orientation
            if compliant_tcp_orientation is not None
            else normalize_quat(orientation_step['orientation'])
        )
        position_servo_orientation = command_orientation
        if bool(
            spec.get(
                'target_object_use_measured_orientation_for_position_servo',
                attachment_mode == 'compliant_joint',
            )
        ):
            position_servo_orientation = normalize_quat(current_pose['orientation'])
        relative_world = current_object_position - np.asarray(current_pose['position'], dtype=float)
        relative_position = quat_rotate(
            self._quat_conjugate(current_pose['orientation']),
            relative_world,
        )
        if relative_position.shape != (3,) or not np.all(np.isfinite(relative_position)):
            return self._cartesian_command_servo_target_pose(
                phase_key=phase_key,
                current_pose=current_pose,
                target_pose=target_pose,
                max_position_step=max_position_step,
                max_orientation_step=max_orientation_step,
                spec=spec,
            )
        one_step_tcp_position = command_object_position - quat_rotate(
            position_servo_orientation,
            relative_position,
        )
        gate_tcp_position = target_object_position - quat_rotate(
            position_servo_orientation,
            relative_position,
        )
        one_step_tcp_position = self._accumulated_cartesian_command_position(
            phase_key=phase_key,
            current_position=np.asarray(current_pose['position'], dtype=float),
            one_step_position=one_step_tcp_position,
            gate_position=gate_tcp_position,
            enabled=bool(
                spec.get(
                    'target_object_servo_position_command_warm_start',
                    False,
                )
            ),
            lookahead=float(
                spec.get(
                    'target_object_servo_position_command_lookahead',
                    0.004,
                )
            ),
            allow_gate_overdrive=bool(
                spec.get(
                    'target_object_servo_position_command_gate_overdrive',
                    True,
                )
            ),
            accumulation_step=float(
                spec.get(
                    'target_object_servo_position_command_accumulation_step',
                    0.0001,
                )
            ),
        )
        return {
            'position': one_step_tcp_position,
            'orientation': command_orientation,
        }

    @staticmethod
    def _compliant_servo_step_scale(
        *,
        spec: dict,
        motion_detail: dict[str, Any],
    ) -> float:
        if not bool(spec.get('compliant_servo_velocity_rate_limit', True)):
            return 1.0
        minimum_scale = float(spec.get('compliant_servo_minimum_step_scale', 0.2))
        if not np.isfinite(minimum_scale) or not 0.0 < minimum_scale <= 1.0:
            raise ValueError('compliant_servo_minimum_step_scale must be finite and in (0, 1].')
        if not motion_detail.get('valid'):
            return 1.0
        pause_linear_speed = float(spec.get('compliant_servo_pause_linear_speed', 0.15))
        pause_angular_speed = float(spec.get('compliant_servo_pause_angular_speed', 5.0))
        if (
            not np.isfinite(pause_linear_speed)
            or pause_linear_speed <= 0.0
            or not np.isfinite(pause_angular_speed)
            or pause_angular_speed <= 0.0
        ):
            raise ValueError('Compliant-servo pause speeds must be finite and positive.')
        speed_ratio = max(
            float(motion_detail['linear_speed']) / pause_linear_speed,
            float(motion_detail['angular_speed']) / pause_angular_speed,
        )
        return float(np.clip(1.0 - speed_ratio, minimum_scale, 1.0))

    def _target_object_settle_ready(
        self,
        *,
        phase_key: tuple[Any, ...] | None = None,
        task,
        spec: dict,
        target_pose: dict,
        current_pose: dict | None,
        tracked_objects: dict,
    ) -> bool:
        detail = self._target_object_settle_capture_detail(
            task=task,
            spec=spec,
            target_pose=target_pose,
            current_pose=current_pose,
            tracked_objects=tracked_objects,
        )
        if phase_key is None or not bool(detail['configured']):
            return bool(detail['capture_ready'])

        if spec.get('beam_assisted_transition_settle'):
            # The completion gate counts physical samples. A fixed number of
            # policy calls must not resume motion while the load is settling.
            return bool(detail['capture_ready'])

        hold_steps = int(spec.get('target_object_settle_hold_steps', 48))
        retry_servo_steps = int(spec.get('target_object_settle_retry_servo_steps', 8))
        if hold_steps <= 0 or retry_servo_steps < 0:
            raise ValueError(
                'target-object settle hold steps must be positive and retry servo ' 'steps must be non-negative.'
            )
        state = self._target_object_settle_state.setdefault(phase_key, {})
        if (spec.get('beam_assisted_absolute_object_servo')
                and spec.get('beam_assisted_descent_admission')
                and not detail.get('assisted_descent_admission', {}).get('ready')):
            # A lost corridor must resume alignment now, not retain a 48-call
            # settle hold whose looser legacy capture remains true.
            state.update(hold_active=False, remaining_steps=0, retry_servo_steps=0)
            return False
        event = 'idle'
        hold_active = False
        if bool(state.get('hold_active', False)):
            hold_active = True
            remaining_steps = max(int(state.get('remaining_steps', 1)) - 1, 0)
            state['remaining_steps'] = remaining_steps
            event = 'hold'
            if remaining_steps == 0:
                state['hold_active'] = False
                state['retry_servo_steps'] = retry_servo_steps
                self._cartesian_command_positions.pop(phase_key, None)
                self._cartesian_command_orientations.pop(phase_key, None)
                event = 'hold_complete'
        elif int(state.get('retry_servo_steps', 0)) > 0:
            state['retry_servo_steps'] = int(state['retry_servo_steps']) - 1
            event = 'retry_servo'
        elif bool(detail['capture_ready']):
            hold_active = True
            state['remaining_steps'] = hold_steps - 1
            state['hold_active'] = bool(state['remaining_steps'] > 0)
            if not state['hold_active']:
                state['retry_servo_steps'] = retry_servo_steps
            self._cartesian_command_positions.pop(phase_key, None)
            self._cartesian_command_orientations.pop(phase_key, None)
            self._insertion_lateral_alignment_active[phase_key] = False
            self._insertion_lateral_alignment_stable_steps.pop(phase_key, None)
            self._insertion_axial_anchors.pop(phase_key, None)
            self._insertion_lateral_orientation_anchors.pop(phase_key, None)
            self._insertion_lateral_clearance_required.pop(phase_key, None)
            self._insertion_lateral_clearance_anchors.pop(phase_key, None)
            state['capture_count'] = int(state.get('capture_count', 0)) + 1
            event = 'capture'

        self._debug_target_object_settle(
            task=task,
            detail=detail,
            state=state,
            event=event,
            hold_active=hold_active,
            tracked_objects=tracked_objects,
        )
        return hold_active

    def _maybe_relax_insertion_attachment(
        self,
        *,
        task,
        spec: dict,
        tracked_objects: dict,
    ) -> bool:
        """Return whether motion should hold while switching to compliance."""

        final_target_name = spec.get('target_object_final_target')
        position_tolerance = spec.get('relax_fixed_attachment_within_final_position_tolerance')
        if final_target_name is None or position_tolerance is None:
            return False
        object_name = self._object_name_from_spec(spec)
        if object_name is None:
            return False
        relaxation_key = (id(task), object_name)
        attachment_for = getattr(task, '_attachment_for', None)
        attachment = (attachment_for(object_name, spec.get('robot')) if callable(attachment_for)
                      else getattr(task, '_attachments', {}).get(object_name))
        if isinstance(attachment, dict) and attachment.get('mode') == 'pure_physical_grasp':
            # There is no fixed joint to convert. Continue through the ordinary
            # insertion servo, completion gates and loaded-force protection.
            self._insertion_compliance_transition_state.pop(relaxation_key, None)
            self._completed_insertion_compliance_transitions.pop(relaxation_key, None)
            return False
        locked_linear_world_direction = None
        compliance_mode = 'isotropic'
        minimum_gravity_alignment = float(spec.get('relax_fixed_attachment_minimum_gravity_alignment', 0.0))
        if not np.isfinite(minimum_gravity_alignment) or not 0.0 <= minimum_gravity_alignment <= 1.0:
            raise ValueError('relax_fixed_attachment_minimum_gravity_alignment must be ' 'finite and in [0, 1].')
        if minimum_gravity_alignment > 0.0:
            convergence_axis = np.asarray(
                spec.get('target_object_convergence_axis'),
                dtype=float,
            )
            gravity_direction = np.asarray(
                spec.get('relax_fixed_attachment_gravity_direction', [0.0, 0.0, -1.0]),
                dtype=float,
            )
            convergence_norm = float(np.linalg.norm(convergence_axis))
            gravity_norm = float(np.linalg.norm(gravity_direction))
            if (
                convergence_axis.shape != (3,)
                or gravity_direction.shape != (3,)
                or not np.isfinite(convergence_norm)
                or not np.isfinite(gravity_norm)
                or convergence_norm <= 1e-9
                or gravity_norm <= 1e-9
            ):
                raise ValueError(
                    'Gravity-gated insertion compliance requires finite non-zero ' 'convergence and gravity directions.'
                )
            gravity_alignment = abs(
                float(
                    np.dot(
                        convergence_axis / convergence_norm,
                        gravity_direction / gravity_norm,
                    )
                )
            )
            if gravity_alignment < minimum_gravity_alignment:
                locked_linear_world_direction = (gravity_direction / gravity_norm).tolist()
                compliance_mode = 'gravity_locked'
        if relaxation_key in self._physically_relaxed_insertion_objects:
            return False
        relax_after_steps = int(spec.get('relax_fixed_attachment_after_steps', 0))
        if relax_after_steps < 0:
            raise ValueError('relax_fixed_attachment_after_steps must be non-negative.')
        if int(getattr(task, 'phase_step_counter', 0)) < relax_after_steps:
            self._insertion_compliance_transition_state.pop(relaxation_key, None)
            return False

        object_pose = self._object_pose(
            task=task,
            object_name=object_name,
            tracked_objects=tracked_objects,
        )
        target_poses = getattr(task, 'target_poses', {})
        final_target_pose = target_poses.get(str(final_target_name))
        if object_pose is None or final_target_pose is None:
            return False
        position_error, final_orientation_error = pose_error(
            object_pose['position'],
            object_pose['orientation'],
            final_target_pose['position'],
            final_target_pose['orientation'],
        )
        position_tolerance = float(position_tolerance)
        orientation_tolerance = float(spec.get('relax_fixed_attachment_final_orientation_tolerance', 0.15))
        orientation_error = final_orientation_error
        waypoint_position_error = None
        waypoint_position_tolerance = None
        waypoint_axial_position_error = None
        waypoint_axial_position_tolerance = None
        waypoint_lateral_position_error = None
        waypoint_lateral_position_tolerance = None
        waypoint_proximity_ready = True
        if bool(spec.get('relax_fixed_attachment_require_waypoint_proximity', False)):
            waypoint_pose = self._target_object_pose(task=task, spec=spec)
            if waypoint_pose is None:
                self._insertion_compliance_transition_state.pop(relaxation_key, None)
                return False
            waypoint_position_error, orientation_error = pose_error(
                object_pose['position'],
                object_pose['orientation'],
                waypoint_pose['position'],
                waypoint_pose.get('orientation'),
            )
            waypoint_position_tolerance = float(spec.get('relax_fixed_attachment_waypoint_position_tolerance', 0.010))
            if not np.isfinite(waypoint_position_tolerance) or waypoint_position_tolerance <= 0.0:
                raise ValueError('relax_fixed_attachment_waypoint_position_tolerance must be ' 'finite and positive.')
            split_axial_tolerance = spec.get('relax_fixed_attachment_waypoint_axial_position_tolerance')
            split_lateral_tolerance = spec.get('relax_fixed_attachment_waypoint_lateral_position_tolerance')
            strict_waypoint_proximity_ready = bool(waypoint_position_error <= waypoint_position_tolerance)
            if split_axial_tolerance is not None or split_lateral_tolerance is not None:
                if split_axial_tolerance is None or split_lateral_tolerance is None:
                    raise ValueError('Waypoint axial and lateral capture tolerances must be ' 'configured together.')
                convergence_axis = np.asarray(
                    spec.get('target_object_convergence_axis'),
                    dtype=float,
                )
                axis_norm = float(np.linalg.norm(convergence_axis))
                waypoint_axial_position_tolerance = float(split_axial_tolerance)
                waypoint_lateral_position_tolerance = float(split_lateral_tolerance)
                if (
                    convergence_axis.shape != (3,)
                    or not np.isfinite(axis_norm)
                    or axis_norm <= 1e-9
                    or not np.isfinite(waypoint_axial_position_tolerance)
                    or waypoint_axial_position_tolerance <= 0.0
                    or not np.isfinite(waypoint_lateral_position_tolerance)
                    or waypoint_lateral_position_tolerance <= 0.0
                ):
                    raise ValueError(
                        'Waypoint split capture requires a finite non-zero convergence '
                        'axis and finite positive axial/lateral tolerances.'
                    )
                convergence_axis = convergence_axis / axis_norm
                waypoint_delta = np.asarray(
                    waypoint_pose['position'],
                    dtype=float,
                ) - np.asarray(object_pose['position'], dtype=float)
                signed_axial_error = float(np.dot(waypoint_delta, convergence_axis))
                waypoint_axial_position_error = abs(signed_axial_error)
                waypoint_lateral_position_error = float(
                    np.linalg.norm(waypoint_delta - signed_axial_error * convergence_axis)
                )
                geometric_capture_after_steps = int(
                    spec.get(
                        'relax_fixed_attachment_geometric_capture_after_steps',
                        0,
                    )
                )
                if geometric_capture_after_steps < 0:
                    raise ValueError('Geometric waypoint capture delay must be non-negative.')
                split_waypoint_proximity_ready = bool(
                    waypoint_axial_position_error <= waypoint_axial_position_tolerance
                    and waypoint_lateral_position_error <= waypoint_lateral_position_tolerance
                )
                waypoint_proximity_ready = bool(
                    split_waypoint_proximity_ready
                    and (
                        strict_waypoint_proximity_ready
                        or int(getattr(task, 'phase_step_counter', 0)) >= geometric_capture_after_steps
                    )
                )
            else:
                waypoint_proximity_ready = strict_waypoint_proximity_ready
        if (
            position_error > position_tolerance
            or not waypoint_proximity_ready
            or orientation_error is None
            or orientation_error > orientation_tolerance
        ):
            self._insertion_compliance_transition_state.pop(relaxation_key, None)
            return False

        motion_detail = self._object_motion_detail(
            task=task,
            object_name=object_name,
            tracked_objects=tracked_objects,
        )
        max_linear_speed = float(
            spec.get(
                'relax_fixed_attachment_max_linear_speed',
                spec.get('target_object_max_linear_speed', 0.03),
            )
        )
        max_angular_speed = float(
            spec.get(
                'relax_fixed_attachment_max_angular_speed',
                spec.get('target_object_max_angular_speed', 2.0),
            )
        )
        transition_state = self._insertion_compliance_transition_state.setdefault(
            relaxation_key,
            {'stable_steps': 0},
        )
        velocity_ready = bool(
            motion_detail.get('valid')
            and motion_detail.get('linear_speed') is not None
            and motion_detail.get('angular_speed') is not None
            and float(motion_detail['linear_speed']) <= max_linear_speed
            and float(motion_detail['angular_speed']) <= max_angular_speed
        )
        pose_stable_ready = bool(
            spec.get('relax_fixed_attachment_allow_pose_stable_override', True)
            and motion_detail.get('is_static') is True
            and motion_detail.get('pose_stable_override') is True
            and motion_detail.get('linear_speed') is not None
            and motion_detail.get('angular_speed') is not None
            and float(motion_detail['linear_speed']) <= float(spec.get('compliant_servo_pause_linear_speed', 0.15))
            and float(motion_detail['angular_speed']) <= float(spec.get('compliant_servo_pause_angular_speed', 5.0))
        )
        pose_history_velocity_override_ready = self._pose_history_velocity_override_ready(
            spec=spec,
            motion_detail=motion_detail,
        )
        # A hard grasp joint can become dynamically overconstrained exactly at
        # tight contact, so waiting for low velocity can deadlock compliance
        # capture. Selected insertion geometries may complete from a valid pose
        # gate even while moving, while retaining the fixed joint until the
        # following release-and-lock phase secures the object.
        dynamic_capture_ready = bool(spec.get('relax_fixed_attachment_allow_dynamic_capture', False))
        motion_ready = bool(
            dynamic_capture_ready
            or velocity_ready
            or pose_stable_ready
            or pose_history_velocity_override_ready
        )
        if motion_ready:
            transition_state['stable_steps'] = int(transition_state.get('stable_steps', 0)) + 1
        else:
            transition_state['stable_steps'] = 0
        required_stable_steps = max(
            int(
                spec.get(
                    'relax_fixed_attachment_dynamic_capture_stable_steps',
                    1,
                )
                if dynamic_capture_ready
                else spec.get('relax_fixed_attachment_stable_steps', 8)
            ),
            1,
        )
        if int(transition_state['stable_steps']) < required_stable_steps:
            return True

        capture_detail = {
            'final_target': str(final_target_name),
            'position_error': float(position_error),
            'position_tolerance': float(position_tolerance),
            'orientation_error': float(orientation_error),
            'waypoint_position_error': (
                None if waypoint_position_error is None else float(waypoint_position_error)
            ),
            'waypoint_axial_position_error': (
                None if waypoint_axial_position_error is None else float(waypoint_axial_position_error)
            ),
            'waypoint_lateral_position_error': (
                None if waypoint_lateral_position_error is None else float(waypoint_lateral_position_error)
            ),
        }

        keep_fixed_until_lock = bool(spec.get('keep_fixed_attachment_until_release_lock', False))
        if dynamic_capture_ready or keep_fixed_until_lock:
            # Keep the grasp joint authoritative until the requested
            # release-and-lock phase. That transition is consumed in the same
            # task update, so pre-locking here only duplicates the release
            # phase's pose gate and can strand a valid contact capture when
            # live USD and policy observations differ by one physics sample.
            capture_mode = 'fixed_joint_dynamic' if dynamic_capture_ready else 'fixed_joint_stable'
            self._completed_insertion_compliance_transitions[relaxation_key] = {
                **capture_detail,
                'capture_mode': capture_mode,
            }
            self._insertion_compliance_transition_state.pop(relaxation_key, None)
            print(
                '[ur5e-insertion-compliance] '
                f"step={getattr(task, 'step_counter', None)} "
                f"phase={getattr(task, 'phase', None)} object={object_name} "
                f'final_target={final_target_name} '
                f'position_error={position_error} position_tolerance={position_tolerance} '
                f'waypoint_position_error={waypoint_position_error} '
                f'waypoint_axial_position_error={waypoint_axial_position_error} '
                f'waypoint_lateral_position_error={waypoint_lateral_position_error} '
                f'orientation_error={orientation_error} '
                f'mode={capture_mode}_capture',
                flush=True,
            )
            return False

        relax_fn = getattr(task, 'relax_fixed_attachment_to_physical_hold', None)
        if not callable(relax_fn) or not bool(
            relax_fn(
                object_name,
                locked_linear_world_direction=locked_linear_world_direction,
            )
        ):
            return True

        self._physically_relaxed_insertion_objects.add(relaxation_key)
        self._completed_insertion_compliance_transitions[relaxation_key] = {
            **capture_detail,
            'capture_mode': 'compliant_joint',
        }
        self._insertion_compliance_transition_state.pop(relaxation_key, None)
        print(
            '[ur5e-insertion-compliance] '
            f"step={getattr(task, 'step_counter', None)} "
            f"phase={getattr(task, 'phase', None)} object={object_name} "
            f'final_target={final_target_name} '
            f'position_error={position_error} position_tolerance={position_tolerance} '
            f'waypoint_position_error={waypoint_position_error} '
            f'waypoint_position_tolerance={waypoint_position_tolerance} '
            f'waypoint_axial_position_error={waypoint_axial_position_error} '
            f'waypoint_axial_position_tolerance={waypoint_axial_position_tolerance} '
            f'waypoint_lateral_position_error={waypoint_lateral_position_error} '
            f'waypoint_lateral_position_tolerance={waypoint_lateral_position_tolerance} '
            f'orientation_error={orientation_error} '
            f'orientation_tolerance={orientation_tolerance} '
            f'stable_steps={required_stable_steps} mode={compliance_mode}_compliant_joint ',
            f'locked_linear_world_direction={locked_linear_world_direction}',
            flush=True,
        )
        # The fixed grasp has already met the pose and motion gates for the
        # required consecutive steps. Let this same stable sample complete the
        # waypoint; waiting one compliant-joint frame can introduce contact
        # oscillation and turn a valid insertion into a timeout.
        return False

    def _compliant_motion_requires_hold(
        self,
        *,
        phase_key: tuple[Any, ...] | None = None,
        task,
        spec: dict,
        tracked_objects: dict,
    ) -> bool:
        object_name = self._object_name_from_spec(spec)
        if object_name is None:
            return False
        _, _, attachment_mode = self._compliant_attachment_allowance(
            object_name=object_name,
            tracked_objects=tracked_objects,
        )
        recovery_key = (id(task), object_name)
        if attachment_mode != 'compliant_joint':
            self._compliant_motion_recovery_state.pop(recovery_key, None)
            return False

        motion_detail = self._object_motion_detail(
            task=task,
            object_name=object_name,
            tracked_objects=tracked_objects,
        )
        if not motion_detail.get('valid'):
            return False
        linear_speed = float(motion_detail['linear_speed'])
        angular_speed = float(motion_detail['angular_speed'])
        pause_linear_speed = float(spec.get('compliant_servo_pause_linear_speed', 0.15))
        pause_angular_speed = float(spec.get('compliant_servo_pause_angular_speed', 5.0))
        resume_linear_speed = float(
            spec.get(
                'compliant_servo_resume_linear_speed',
                spec.get('target_object_max_linear_speed', 0.03),
            )
        )
        resume_angular_speed = float(
            spec.get(
                'compliant_servo_resume_angular_speed',
                spec.get('target_object_max_angular_speed', 2.0),
            )
        )
        required_stable_steps = max(
            int(spec.get('compliant_servo_resume_stable_steps', 8)),
            1,
        )
        state = self._compliant_motion_recovery_state.setdefault(
            recovery_key,
            {'active': False, 'stable_steps': 0},
        )
        pose_stable_ready = bool(
            spec.get('compliant_servo_allow_pose_stable_resume', True)
            and motion_detail.get('is_static') is True
            and motion_detail.get('pose_stable_override') is True
            and linear_speed <= resume_linear_speed
            and angular_speed <= resume_angular_speed
        )
        pose_history_velocity_override_ready = self._pose_history_velocity_override_ready(
            spec=spec,
            motion_detail=motion_detail,
        )
        if not bool(state.get('active', False)):
            if (
                (linear_speed <= pause_linear_speed and angular_speed <= pause_angular_speed)
                or pose_stable_ready
                or pose_history_velocity_override_ready
            ):
                return False
            state['active'] = True
            state['stable_steps'] = 0
            state['settle_stable_steps'] = 0
            if phase_key is not None:
                self._cartesian_command_positions.pop(phase_key, None)
                self._cartesian_command_orientations.pop(phase_key, None)
            print(
                '[ur5e-compliant-recovery] '
                f"event=enter step={getattr(task, 'step_counter', None)} "
                f"phase={getattr(task, 'phase', None)} object={object_name} "
                f'linear_speed={linear_speed} angular_speed={angular_speed}',
                flush=True,
            )
            return True

        velocity_ready = bool(linear_speed <= resume_linear_speed and angular_speed <= resume_angular_speed)
        motion_ready = bool(velocity_ready or pose_stable_ready or pose_history_velocity_override_ready)
        if motion_ready:
            state['stable_steps'] = int(state.get('stable_steps', 0)) + 1
        else:
            state['stable_steps'] = 0
        if int(state['stable_steps']) < required_stable_steps:
            return True

        self._compliant_motion_recovery_state.pop(recovery_key, None)
        print(
            '[ur5e-compliant-recovery] '
            f"event=resume step={getattr(task, 'step_counter', None)} "
            f"phase={getattr(task, 'phase', None)} object={object_name} "
            f'linear_speed={linear_speed} angular_speed={angular_speed} '
            f'stable_steps={required_stable_steps}',
            flush=True,
        )
        return False

    def _compliant_recovery_allows_target_settle(
        self,
        *,
        task,
        spec: dict,
        tracked_objects: dict,
    ) -> bool:
        object_name = self._object_name_from_spec(spec)
        if object_name is None:
            return False
        state = self._compliant_motion_recovery_state.get((id(task), object_name))
        if state is None or not bool(state.get('active', False)):
            return False
        motion_detail = self._object_motion_detail(
            task=task,
            object_name=object_name,
            tracked_objects=tracked_objects,
        )
        max_linear_speed = float(
            spec.get(
                'compliant_servo_settle_max_linear_speed',
                spec.get('relax_fixed_attachment_max_linear_speed', 0.10),
            )
        )
        max_angular_speed = float(
            spec.get(
                'compliant_servo_settle_max_angular_speed',
                spec.get('target_object_max_angular_speed', 2.0),
            )
        )
        settle_ready = bool(
            motion_detail.get('valid')
            and motion_detail.get('pose_stable_override') is True
            and motion_detail.get('linear_speed') is not None
            and motion_detail.get('angular_speed') is not None
            and float(motion_detail['linear_speed']) <= max_linear_speed
            and float(motion_detail['angular_speed']) <= max_angular_speed
        )
        settle_ready = bool(
            settle_ready
            or self._pose_history_velocity_override_ready(
                spec=spec,
                motion_detail=motion_detail,
            )
        )
        if settle_ready:
            state['settle_stable_steps'] = int(state.get('settle_stable_steps', 0)) + 1
        else:
            state['settle_stable_steps'] = 0
            state['settle_ready_logged'] = False
        required_steps = max(
            int(spec.get('compliant_servo_settle_stable_steps', 24)),
            1,
        )
        ready = int(state['settle_stable_steps']) >= required_steps
        maximum_target_settle_steps = max(
            int(
                spec.get(
                    'compliant_recovery_target_settle_max_steps',
                    spec.get('target_object_settle_hold_steps', 48),
                )
            ),
            1,
        )
        if ready:
            state['target_settle_steps'] = int(state.get('target_settle_steps', 0)) + 1
        else:
            state['target_settle_steps'] = 0
        if ready and not bool(state.get('settle_ready_logged', False)):
            state['settle_ready_logged'] = True
            print(
                '[ur5e-compliant-recovery] '
                f"event=settle_ready step={getattr(task, 'step_counter', None)} "
                f"phase={getattr(task, 'phase', None)} object={object_name} "
                f"linear_speed={motion_detail.get('linear_speed')} "
                f"angular_speed={motion_detail.get('angular_speed')} "
                f'stable_steps={required_steps}',
                flush=True,
            )
        if ready and int(state['target_settle_steps']) > maximum_target_settle_steps:
            self._compliant_motion_recovery_state.pop(
                (id(task), object_name),
                None,
            )
            print(
                '[ur5e-compliant-recovery] '
                f"event=retry_servo step={getattr(task, 'step_counter', None)} "
                f"phase={getattr(task, 'phase', None)} object={object_name} "
                f'target_settle_steps={maximum_target_settle_steps}',
                flush=True,
            )
            return False
        return ready

    def _beam_table_seat_action(self, *, phase_key, task, robot_name, spec,
                                tracked_robots, tracked_objects):
        from toolkits.factory_dual_franka_assembly.beam_seating_control import seating_decision
        sample = task._beam_table_observation()
        saved = getattr(task, '_ur5e_contact_hold_commands', {}).get(robot_name)
        if saved is None:
            return self._failure_or_hold(task, robot_name, spec, 'seat_grasp_unavailable')
        state = saved.setdefault('beam_seat', {})
        if state.get('phase_key') != phase_key:
            state.clear(); state['phase_key'] = phase_key
        command_z = float(saved['pose']['position'][2])
        decision = seating_decision(state, sample, command_z, float(task._contact_physics_dt()), spec)
        trace = os.environ.get('BEAM_MOTION_TRACE_PATH')
        if trace:
            with open(os.path.join(os.path.dirname(trace), 'seat_control_trace.jsonl'), 'a') as handle:
                handle.write(json.dumps({'step':int(task.step_counter), 'phase':task.phase,
                    'command_z':command_z, 'decision':decision, 'observation':sample})+'\n')
        if decision['failure']:
            return self._failure_or_hold(task, robot_name, spec, decision['failure'],
                                         diagnostics={'decision':decision, **sample})
        # This bounded diagnostic freezes existing drive targets, never bodies.
        # Production seating and all physical success/safety gates stay active.
        from toolkits.factory_dual_franka_assembly.beam_loaded_target_hold import (
            capture_loaded_native_targets, loaded_target_hold_decision)
        hold_state = state.setdefault('loaded_target_hold', {})
        hold = loaded_target_hold_decision(
            hold_state, sample, os.environ.get('BEAM_LOADED_TARGET_HOLD_SECONDS', '0'))
        if hold['mode'] == 'capture':
            open_q, closed_q = self._gripper_open_closed_q(task=task, robot_name=robot_name)
            captured = capture_loaded_native_targets(
                task.robots[robot_name], saved, open_q, closed_q,
                float(getattr(task.robots[robot_name].config, 'gripper_close_openness', .08)))
            hold_state['captured'] = captured
            if not captured['valid']:
                hold_state['failure'] = 'native_capture_' + captured['reason']
                hold = dict(hold, mode='failure', reason=hold_state['failure'])
        if trace and hold['mode'] != 'disabled':
            with open(os.path.join(os.path.dirname(trace), 'loaded_target_hold_trace.jsonl'), 'a') as handle:
                handle.write(json.dumps({'step': int(task.step_counter), 'phase': task.phase,
                    'robot': robot_name, 'hold': hold, 'captured': hold_state.get('captured'),
                    'seating_decision': decision, 'observation': sample}) + '\n')
        if hold['mode'] == 'failure':
            return self._failure_or_hold(task, robot_name, spec, 'loaded_target_hold_' + hold['reason'],
                                         diagnostics={'hold': hold})
        if hold['mode'] in ('capture', 'holding'):
            captured = hold_state.get('captured') or {}
            if not captured.get('valid'):
                return self._failure_or_hold(task, robot_name, spec, 'loaded_target_hold_capture_missing')
            return self._hold_previous_grasp_command(task=task, robot_name=robot_name,
                spec=spec, tracked_robots=tracked_robots, diagnostic_hold=captured)
        if decision['delta_z'] == 0:
            return self._hold_previous_grasp_command(task=task, robot_name=robot_name,
                                                    spec=spec, tracked_robots=tracked_robots)
        target = {k: np.asarray(v, dtype=float).copy() for k, v in saved['pose'].items()}
        target['position'][2] += decision['delta_z']
        # Completion belongs to the measured table-load gate, never a TCP gate.
        action = self._grasp_drive_motion(phase_key=phase_key, task=task, robot_name=robot_name,
            spec=spec, target_pose=target, tracked_robots=tracked_robots, tracked_objects=tracked_objects)
        return action

    def _grasp_drive_motion(self, *, phase_key, task, robot_name, spec, target_pose,
                            tracked_robots, tracked_objects):
        """Advance a loaded drive without rebasing its preload onto measured FK.

        A lagging robot pauses command advancement; it never pulls the existing
        reference back to measured FK. Physical hold and joint tracking limits
        remain prerequisites, and the cache only records commands actually sent.
        """
        object_name = self._object_name_from_spec(spec)
        saved = getattr(task, '_ur5e_contact_hold_commands', {}).get(robot_name)
        attachment = (task._attachment_for(object_name, robot_name) if hasattr(task, '_attachment_for')
                      else getattr(task, '_attachments', {}).get(object_name))
        if (saved is None or saved.get('object') != object_name or attachment is None
                or attachment.get('robot_name') != robot_name):
            return self._failure_or_hold(task, robot_name, spec, 'grasp_command_unavailable')
        if not task._physical_hold_valid(object_name, attachment, validation_stage='pre_action'):
            return self._failure_or_hold(task, robot_name, spec, 'held_object_not_grasped')
        current_pose = self._current_tcp_pose(current_pose=self._current_robot_pose(
            task=task, robot_name=robot_name, tracked_robots=tracked_robots), spec=spec)
        current_q = self._current_arm_q(task, robot_name)
        if current_pose is None or current_q is None:
            return self._failure_or_hold(task, robot_name, spec, 'current_joint_state_unavailable')
        reference_q = np.asarray(saved['arm_q'], dtype=float)
        limited_reference = self._limit_command_to_measured_state(
            current_q=current_q, command_q=reference_q, spec=spec)
        if not np.allclose(limited_reference, reference_q, rtol=0, atol=1e-10):
            return self._failure_or_hold(task, robot_name, spec, 'grasp_command_tracking_limit',
                diagnostics={'current_q': current_q.tolist(), 'reference_q': reference_q.tolist(),
                    'limited_reference_q': limited_reference.tolist(), 'current_pose': {
                        k: np.asarray(v).tolist() for k, v in current_pose.items()},
                    'cached_command_step': saved.get('step'),
                    'max_command_tracking_error': spec.get('max_command_tracking_error', .18),
                    'max_wrist_command_tracking_error': spec.get('max_wrist_command_tracking_error', .12)})
        if spec.get('grasp_drive_smooth_transport'):
            return self._smooth_grasp_drive_motion(phase_key=phase_key, task=task, robot_name=robot_name,
                spec=spec, target_pose=target_pose, tracked_objects=tracked_objects,
                saved=saved, current_pose=current_pose, current_q=current_q)
        joint_lookahead = spec.get('grasp_drive_joint_lookahead')
        if joint_lookahead is not None and np.max(np.abs(reference_q - current_q)) > float(joint_lookahead):
            self._debug_grasp_drive_guard(task, robot_name, 'joint_tracking_pause', spec,
                                          current_pose, saved['pose'], current_q, reference_q)
            return self._hold_previous_grasp_command(task=task, robot_name=robot_name, spec=spec,
                tracked_robots=tracked_robots, target_pose=target_pose)
        lookahead = float(spec.get('grasp_drive_position_lookahead', 0.001))
        command_pose = self._cartesian_servo_target_pose(
            current_pose=saved['pose'], target_pose=target_pose,
            max_position_step=min(float(spec.get('cartesian_position_step', 0.0002)), lookahead / 4),
            max_orientation_step=float(spec.get('cartesian_orientation_step', 0.004)),
        )
        # Pause, rather than radially clamping to measured FK: that clamp itself
        # would introduce lateral and orientation changes at the handoff.
        position_lead, orientation_lead = pose_error(
            current_position=current_pose['position'], current_orientation=current_pose['orientation'],
            target_position=command_pose['position'], target_orientation=command_pose['orientation'])
        orientation_lookahead = spec.get('grasp_drive_orientation_lookahead')
        if (position_lead > lookahead or
                (orientation_lookahead is not None and orientation_lead > float(orientation_lookahead))):
            self._debug_grasp_drive_guard(task, robot_name, 'pose_tracking_pause', spec,
                                          current_pose, command_pose, current_q, reference_q)
            return self._hold_previous_grasp_command(
                task=task, robot_name=robot_name, spec=spec, tracked_robots=tracked_robots,
                target_pose=target_pose)
        ik_pose = self._ik_target_pose(target_pose=command_pose, spec=spec)
        result = self._solve_ik(task=task, robot_name=robot_name, target_pose=ik_pose,
                                warm_start=reference_q, spec=spec)
        limits = self._command_joint_step_limits(spec=spec, joint_count=len(reference_q))
        if limits is None:
            limits = float(spec.get('max_joint_step', 0.035))

        def nearby(candidate):
            if candidate is None:
                return None
            q = self._unwrap_to_reference(target_q=candidate, reference_q=reference_q,
                preferred_abs_limit=spec.get('preferred_joint_abs_limit', 3.05),
                hard_preferred_abs_limit=bool(spec.get('hard_preferred_joint_abs_limit', True)))
            if (not np.all(np.isfinite(q))
                    or self._ik_branch_jump_detected(reference_q=reference_q, target_q=q, spec=spec)
                    or np.any(np.abs(q - reference_q) > np.asarray(limits) + 1e-10)):
                return None
            return q

        target_q = nearby(result)
        if target_q is None:
            full_command_pose = command_pose
            # Lula may restart on another branch as an orientation residual
            # reaches its convergence boundary. Refine the previous command
            # locally; neither measured joints nor simulator state are written.
            for ratio in (1.0, 0.5, 0.25, 0.125):
                candidate_pose = self._cartesian_pose_fraction(
                    current_pose=saved['pose'], target_pose=full_command_pose, ratio=ratio)
                candidate_ik_pose = self._ik_target_pose(target_pose=candidate_pose, spec=spec)
                refined = self._local_grasp_ik(task=task, robot_name=robot_name,
                    target_pose=candidate_ik_pose, reference_q=reference_q, spec=spec,
                    joint_radius=float(np.min(np.asarray(limits))))
                target_q = nearby(refined)
                if target_q is not None:
                    command_pose, ik_pose = candidate_pose, candidate_ik_pose
                    break
            if target_q is None:
                return self._failure_or_hold(task, robot_name, spec, 'grasp_local_ik_failed')
        if joint_lookahead is not None and np.max(np.abs(target_q - current_q)) > float(joint_lookahead):
            self._debug_grasp_drive_guard(task, robot_name, 'candidate_joint_tracking_pause', spec,
                                          current_pose, command_pose, current_q, target_q)
            return self._hold_previous_grasp_command(task=task, robot_name=robot_name, spec=spec,
                tracked_robots=tracked_robots, target_pose=target_pose)
        command_q = self._limited_joint_target(current_q=reference_q, target_q=target_q,
            max_joint_step=limits)
        command_q = self._continuous_command_q(task=task, robot_name=robot_name,
                                               command_q=command_q, spec=spec)
        command_q = self._limit_command_to_measured_state(current_q=current_q,
                                                         command_q=command_q, spec=spec)
        if not np.allclose(command_q, target_q, rtol=0, atol=1e-10):
            # Do not associate a partial joint command with the full Cartesian
            # target: the next step would then start from an unsent pose.
            return self._failure_or_hold(task, robot_name, spec, 'grasp_drive_joint_step_limit')
        self._debug_joint_step(task=task, robot_name=robot_name, skill_name=spec['name'], spec=spec,
            current_pose=current_pose, target_pose=target_pose, command_target_pose=command_pose,
            ik_target_pose=ik_pose, current_q=current_q, reference_q=reference_q,
            target_q=target_q, command_q=command_q)
        self._remember_arm_command(task, robot_name, command_q)
        saved['arm_q'] = command_q.copy()
        saved['pose'] = {key: np.asarray(command_pose[key]).copy() for key in ('position', 'orientation')}
        saved['step'] = int(getattr(task, 'step_counter', 0))
        saved['pose_source'] = 'accepted_ik_target'
        self._last_targets[phase_key] = {**saved['pose'], 'target_q': target_q.copy()}
        self._maybe_mark_complete(phase_key=phase_key, task=task, robot_name=robot_name,
            skill_name=spec['name'], spec=spec, target_pose=target_pose, ik_target_pose=ik_pose,
            current_pose=current_pose, tracked_objects=tracked_objects, current_q=current_q,
            target_q=target_q)
        return self._publish_loaded_action(task=task, robot_name=robot_name, spec=spec,
                                           saved=saved, command_q=command_q)

    @staticmethod
    def _debug_grasp_drive_guard(task, robot_name, reason, spec, current_pose, candidate_pose,
                                 current_q, candidate_q):
        trace = os.environ.get('BEAM_MOTION_TRACE_PATH')
        if not trace or spec.get('grasp_drive_joint_lookahead') is None:
            return
        position_lead, orientation_lead = pose_error(
            current_position=current_pose['position'], current_orientation=current_pose['orientation'],
            target_position=candidate_pose['position'], target_orientation=candidate_pose['orientation'])
        detail = {'step': int(task.step_counter), 'phase': task.phase, 'robot': robot_name,
            'reason': reason, 'position_lead': position_lead, 'orientation_lead': orientation_lead,
            'joint_lead': float(np.max(np.abs(np.asarray(candidate_q)-current_q)))}
        with open(os.path.join(os.path.dirname(trace), 'drive_guard_trace.jsonl'), 'a', encoding='utf-8') as handle:
            handle.write(json.dumps(detail)+'\n')

    @staticmethod
    def _grasp_tracking_scale(*, position_lead, orientation_lead, joint_lead, spec):
        utilization = max(position_lead / float(spec['grasp_drive_position_lookahead']),
                          orientation_lead / float(spec['grasp_drive_orientation_lookahead']),
                          joint_lead / float(spec['grasp_drive_joint_lookahead']))
        start, stop = float(spec['grasp_drive_slowdown_start']), float(spec['grasp_drive_slowdown_stop'])
        if not 0 <= start < stop < 1:
            raise ValueError('Invalid loaded transport slowdown interval')
        x = float(np.clip((stop-utilization)/(stop-start), 0., 1.))
        return x*x*(3.-2.*x), utilization

    @staticmethod
    def _rate_limited_grasp_command(*, reference_q, target_q, previous_velocity, dt, speed, acceleration):
        if not all(np.isfinite(x) and x > 0 for x in (dt, speed, acceleration)):
            raise ValueError('Loaded transport timestep and rates must be finite and positive')
        desired_velocity = np.clip((np.asarray(target_q)-reference_q)/dt, -speed, speed)
        velocity = np.clip(desired_velocity, previous_velocity-acceleration*dt,
                           previous_velocity+acceleration*dt)
        return reference_q + velocity*dt, velocity

    def _smooth_grasp_drive_motion(self, *, phase_key, task, robot_name, spec, target_pose,
                                   tracked_objects, saved, current_pose, current_q):
        """Retain command preload while continuously governing loaded motion.

        Limit the velocity of the *published* joints, then cache their FK rather
        than the unexecuted IK target. All physical and tracking gates remain.
        """
        reference_q = np.asarray(saved['arm_q'], dtype=float)
        dt = float(task._contact_physics_dt())
        if not np.isfinite(dt) or dt <= 0:
            return self._failure_or_hold(task, robot_name, spec, 'grasp_invalid_control_dt')
        previous_velocity = (np.asarray(saved['velocity_q']) if saved.get('smooth_step') == task.step_counter-1
                             else np.zeros_like(reference_q))
        position_lead, orientation_lead = pose_error(
            current_position=current_pose['position'], current_orientation=current_pose['orientation'],
            target_position=saved['pose']['position'], target_orientation=saved['pose']['orientation'])
        scale, utilization = self._grasp_tracking_scale(position_lead=position_lead,
            orientation_lead=orientation_lead, joint_lead=float(np.max(np.abs(reference_q-current_q))), spec=spec)
        distance, angle = pose_error(current_position=saved['pose']['position'],
            current_orientation=saved['pose']['orientation'], target_position=target_pose['position'],
            target_orientation=target_pose['orientation'])
        at_goal = distance <= 0.00001 and angle <= 0.0015
        # A shared interpolation fraction couples translation and rotation.
        # The minimum horizon also slows approach to the final pose.
        horizon = max(distance/float(spec['grasp_drive_linear_speed']),
                      angle/float(spec['grasp_drive_angular_speed']), 0.08)
        ratio = 0. if at_goal else min(1., dt/horizon)*scale
        desired_pose = self._cartesian_pose_fraction(current_pose=saved['pose'],
                                                    target_pose=target_pose, ratio=ratio)
        ik_pose = self._ik_target_pose(target_pose=desired_pose, spec=spec)
        limits = self._command_joint_step_limits(spec=spec, joint_count=len(reference_q))
        if limits is None:
            limits = float(spec.get('max_joint_step', 0.008))

        def nearby(q):
            if q is None:
                return None
            q = self._unwrap_to_reference(target_q=q, reference_q=reference_q,
                preferred_abs_limit=spec.get('preferred_joint_abs_limit', 3.05),
                hard_preferred_abs_limit=bool(spec.get('hard_preferred_joint_abs_limit', True)))
            if (not np.all(np.isfinite(q)) or self._ik_branch_jump_detected(
                    reference_q=reference_q, target_q=q, spec=spec)
                    or np.any(np.abs(q-reference_q) > np.asarray(limits)+1e-10)):
                return None
            return q

        target_q = reference_q.copy() if ratio == 0 else nearby(self._solve_ik(
            task=task, robot_name=robot_name, target_pose=ik_pose, warm_start=reference_q, spec=spec))
        if target_q is None:
            for fraction in (1., .5, .25, .125):
                candidate = self._cartesian_pose_fraction(current_pose=saved['pose'],
                    target_pose=desired_pose, ratio=fraction)
                target_q = nearby(self._local_grasp_ik(task=task, robot_name=robot_name,
                    target_pose=self._ik_target_pose(target_pose=candidate, spec=spec),
                    reference_q=reference_q, spec=spec, joint_radius=float(np.min(np.asarray(limits)))))
                if target_q is not None:
                    break
        if target_q is None:
            return self._failure_or_hold(task, robot_name, spec, 'grasp_local_ik_failed')
        command_q, velocity = self._rate_limited_grasp_command(reference_q=reference_q,
            target_q=target_q, previous_velocity=previous_velocity, dt=dt,
            speed=float(spec['grasp_drive_joint_speed']), acceleration=float(spec['grasp_drive_joint_acceleration']))
        command_pose = self._grasp_command_fk_pose(task=task, robot_name=robot_name, spec=spec, command_q=command_q)
        if command_pose is None:
            return self._failure_or_hold(task, robot_name, spec, 'grasp_command_cache_unavailable')
        p_lead, r_lead = pose_error(current_position=current_pose['position'],
            current_orientation=current_pose['orientation'], target_position=command_pose['position'],
            target_orientation=command_pose['orientation'])
        joint_lead = float(np.max(np.abs(command_q-current_q)))
        limited = self._limit_command_to_measured_state(current_q=current_q,
            command_q=self._continuous_command_q(task=task, robot_name=robot_name, command_q=command_q, spec=spec),
            spec=spec)
        safe = (p_lead <= float(spec['grasp_drive_position_lookahead'])
                and r_lead <= float(spec['grasp_drive_orientation_lookahead'])
                and joint_lead <= float(spec['grasp_drive_joint_lookahead'])
                and np.all(np.abs(command_q-reference_q) <= np.asarray(limits)+1e-10)
                and np.allclose(limited, command_q, rtol=0, atol=1e-10))
        trace = os.environ.get('BEAM_MOTION_TRACE_PATH')
        if trace:
            detail = {'step': int(task.step_counter), 'phase': task.phase, 'robot': robot_name,
                'dt': dt, 'tracking_scale': scale, 'tracking_utilization': utilization,
                'path_fraction': ratio, 'at_goal': at_goal, 'published': bool(safe),
                'joint_velocity': velocity.tolist(), 'joint_acceleration': ((velocity-previous_velocity)/dt).tolist(),
                'position_lead': p_lead, 'orientation_lead': r_lead, 'joint_lead': joint_lead}
            with open(os.path.join(os.path.dirname(trace), 'smooth_drive_trace.jsonl'), 'a', encoding='utf-8') as f:
                f.write(json.dumps(detail)+'\n')
        if not safe:
            # Do not hide an infeasible braking/tracking combination by silently
            # clipping the final command or relaxing the physical gate.
            return self._failure_or_hold(task, robot_name, spec, 'grasp_smooth_tracking_boundary')
        self._debug_joint_step(task=task, robot_name=robot_name, skill_name=spec['name'], spec=spec,
            current_pose=current_pose, target_pose=target_pose, command_target_pose=command_pose,
            ik_target_pose=ik_pose, current_q=current_q, reference_q=reference_q,
            target_q=target_q, command_q=command_q)
        self._remember_arm_command(task, robot_name, command_q)
        saved.update(arm_q=command_q.copy(), pose=command_pose, velocity_q=velocity.copy(),
            smooth_step=int(task.step_counter), step=int(task.step_counter), pose_source='published_joint_fk')
        self._last_targets[phase_key] = {**command_pose, 'target_q': target_q.copy()}
        # Finish at rest, so handing off to a hold cannot drop a moving command
        # to zero velocity. The original object/static completion checks remain.
        if np.max(np.abs(velocity)) <= 0.005:
            # A stopped command can already satisfy the physical phase gates
            # even when its tiny remaining IK request falls in the deadband.
            self._maybe_mark_complete(phase_key=phase_key, task=task, robot_name=robot_name,
                skill_name=spec['name'], spec=spec, target_pose=target_pose, ik_target_pose=ik_pose,
                current_pose=current_pose, tracked_objects=tracked_objects, current_q=current_q,
                target_q=target_q)
        return self._publish_loaded_action(task=task, robot_name=robot_name, spec=spec,
                                           saved=saved, command_q=command_q)

    def _record_published_grasp_command(self, *, task, robot_name, spec, command_q, gripper_openness):
        """Bridge the legacy insertion servo to later relative holds using FK.

        Joint limiting may have changed the IK solution, so its requested pose
        is not a valid cache entry. This is a read-only model calculation.
        """
        saved = getattr(task, '_ur5e_contact_hold_commands', {}).get(robot_name)
        if saved is None or saved.get('object') != self._object_name_from_spec(spec):
            return False
        pose = self._grasp_command_fk_pose(task=task, robot_name=robot_name, spec=spec, command_q=command_q)
        if pose is None:
            return False
        saved.update(arm_q=np.asarray(command_q).copy(), pose=pose,
            gripper_openness=float(gripper_openness), step=int(getattr(task, 'step_counter', 0)),
            pose_source='published_joint_fk')
        return True

    def _grasp_command_fk_pose(self, *, task, robot_name, spec, command_q):
        try:
            controller = task.robots[robot_name].controllers[_ARM_IK_CONTROLLER]
            wrapper = controller._kinematics_solver
            position, rotation = wrapper.get_kinematics_solver().compute_forward_kinematics(
                wrapper.get_end_effector_frame(), np.asarray(command_q))
            orientation = _quat_from_axes(rotation[:, 0], rotation[:, 1], rotation[:, 2])
            pose = self._current_tcp_pose(current_pose={
                'position': np.asarray(position) * controller._robot_scale,
                'orientation': orientation}, spec=spec)
            if not all(np.all(np.isfinite(pose[k])) for k in ('position', 'orientation')):
                return None
        except Exception:
            return None
        return pose

    def _local_grasp_ik(self, *, task, robot_name, target_pose, reference_q, spec, joint_radius):
        controller = task.robots[robot_name].controllers[_ARM_IK_CONTROLLER]
        wrapper = controller._kinematics_solver
        raw = wrapper.get_kinematics_solver()
        frame = wrapper.get_end_effector_frame()
        target_position = np.asarray(target_pose['position']) / controller._robot_scale
        target_orientation = np.asarray(target_pose['orientation'])
        result = self._bounded_local_pose_ik(
            forward=lambda q: raw.compute_forward_kinematics(frame, q), reference_q=reference_q,
            target_position=target_position, target_orientation=target_orientation,
            position_tolerance=float(spec['ik_position_tolerance']),
            orientation_tolerance=float(spec['ik_orientation_tolerance']), joint_radius=joint_radius)
        self._debug_loaded_ik(task=task, robot_name=robot_name, raw_solver=raw, frame=frame,
            warm_start=reference_q, result=result, success=result is not None,
            target_position=target_position, target_orientation=target_orientation, spec=spec,
            path='bounded_local_fk_refinement')
        return result

    @staticmethod
    def _bounded_local_pose_ik(*, forward, reference_q, target_position, target_orientation,
                               position_tolerance, orientation_tolerance, joint_radius):
        """Finite-difference local IK, constrained to a small joint-space box."""
        def rotation_error(target, current):
            conjugate = np.asarray(current).copy()
            conjugate[1:] *= -1
            delta = normalize_quat(quat_multiply(target, conjugate))
            if delta[0] < 0:
                delta = -delta
            sine = float(np.linalg.norm(delta[1:]))
            return (2.0 * delta[1:] if sine < 1e-12 else
                    delta[1:] * (2.0 * math.atan2(sine, delta[0]) / sine))

        def pose(q):
            position, rotation = forward(q)
            return np.asarray(position), _quat_from_axes(rotation[:, 0], rotation[:, 1], rotation[:, 2])

        reference = np.asarray(reference_q, dtype=float)
        q = reference.copy()
        epsilon = 1e-5
        weights = np.array([1., 1., 1., .1, .1, .1])
        for _ in range(24):
            position, orientation = pose(q)
            translation = np.asarray(target_position) - position
            rotation = rotation_error(target_orientation, orientation)
            if (np.linalg.norm(translation) <= position_tolerance
                    and np.linalg.norm(rotation) <= orientation_tolerance):
                return q
            error = np.r_[translation, rotation] * weights
            jacobian = np.empty((6, len(q)))
            for j in range(len(q)):
                perturbed = q.copy()
                perturbed[j] += epsilon
                p, r = pose(perturbed)
                jacobian[:, j] = np.r_[p - position, rotation_error(r, orientation)] / epsilon * weights
            delta = jacobian.T @ np.linalg.solve(jacobian @ jacobian.T + np.eye(6) * 1e-10, error)
            if not np.all(np.isfinite(delta)):
                return None
            magnitude = float(np.max(np.abs(delta)))
            if magnitude > .002:
                delta *= .002 / magnitude
            candidate = np.clip(q + delta, reference - joint_radius, reference + joint_radius)
            if np.max(np.abs(candidate - q)) < 1e-12:
                return None
            q = candidate
        return None

    def _hold_previous_grasp_command(self, *, task, robot_name, spec, tracked_robots, target_pose=None,
                                     diagnostic_hold=None):
        object_name = self._object_name_from_spec(spec)
        saved = getattr(task, '_ur5e_contact_hold_commands', {}).get(robot_name)
        attachment = (task._attachment_for(object_name, robot_name) if hasattr(task, '_attachment_for')
                      else getattr(task, '_attachments', {}).get(object_name))
        if (saved is None or saved.get('object') != object_name or attachment is None
                or attachment.get('robot_name') != robot_name):
            return self._failure_or_hold(task, robot_name, spec, 'grasp_command_unavailable')
        if not task._physical_hold_valid(object_name, attachment, validation_stage='pre_action_hold'):
            return self._failure_or_hold(task, robot_name, spec, 'held_object_not_grasped')
        current_q = self._current_arm_q(task, robot_name)
        command_q = np.asarray(saved['arm_q']).copy()
        if diagnostic_hold is not None:
            if (not diagnostic_hold.get('valid') or not np.allclose(command_q,
                    diagnostic_hold.get('arm_q'), rtol=0, atol=1e-6)):
                return self._failure_or_hold(task, robot_name, spec, 'loaded_target_hold_target_changed')
            command_q = np.asarray(diagnostic_hold['arm_q'], dtype=float).copy()
        limited_command = self._limit_command_to_measured_state(
            current_q=current_q, command_q=command_q, spec=spec)
        if current_q is None or not np.allclose(limited_command, command_q, rtol=0, atol=1e-10):
            return self._failure_or_hold(task, robot_name, spec, 'grasp_command_tracking_limit',
                diagnostics={'current_q': None if current_q is None else current_q.tolist(),
                    'reference_q': command_q.tolist(), 'limited_reference_q': limited_command.tolist(),
                    'cached_command_step': saved.get('step'),
                    'max_command_tracking_error': spec.get('max_command_tracking_error', .18),
                    'max_wrist_command_tracking_error': spec.get('max_wrist_command_tracking_error', .12)})
        current_pose = self._current_tcp_pose(current_pose=self._current_robot_pose(
            task=task, robot_name=robot_name, tracked_robots=tracked_robots), spec=spec)
        pose = saved['pose']
        self._debug_joint_step(task=task, robot_name=robot_name, skill_name=spec['name'], spec=spec,
            current_pose=current_pose, target_pose=pose if target_pose is None else target_pose, command_target_pose=pose,
            ik_target_pose=self._ik_target_pose(target_pose=pose, spec=spec), current_q=current_q,
            reference_q=command_q, target_q=command_q, command_q=command_q)
        self._remember_arm_command(task, robot_name, command_q)
        return self._publish_loaded_action(task=task, robot_name=robot_name, spec=spec,
                                           saved=saved, command_q=command_q, diagnostic_hold=diagnostic_hold)

    def _publish_loaded_action(self, *, task, robot_name, spec, saved, command_q,
                               diagnostic_hold=None):
        attachment = (task._attachment_for(saved['object'], robot_name) if hasattr(task, '_attachment_for')
                      else getattr(task, '_attachments', {}).get(saved['object'])) or {}
        attach_spec = attachment.get('attach_spec') or {}
        if attach_spec.get('hold_force_regulation'):
            metrics = task._gripper_contact_metrics(saved['object'], robot_name, attach_spec=attach_spec)
            threshold = float(attach_spec.get('contact_force_threshold', .1))
            if not all(metrics.get(s, {}).get('force_probe_valid') and
                       np.isfinite(float(metrics[s].get('force', float('nan')))) and
                       float(metrics[s].get('force', 0.0)) >= threshold
                       for s in ('left_finger', 'right_finger')):
                return self._failure_or_hold(task, robot_name, spec, 'loaded_force_contact_missing')
            measured = self._current_gripper_q(task=task, robot_name=robot_name)
            open_q, closed_q = self._gripper_open_closed_q(task=task, robot_name=robot_name)
            if measured is None or open_q is None or closed_q is None:
                return self._failure_or_hold(task, robot_name, spec, 'loaded_force_state_unavailable')
            previous = abs(closed_q - open_q) * (1.0 - saved['gripper_openness'])
            state = saved.setdefault('loaded_force_state', {
                'contact_control_active': True, 'contact_capture_closure': previous,
                'contact_command_closure': previous})
            # Consume real relief samples even while diagnostic targets are
            # fixed, so expiry does not introduce an artificial clock gap/band reset.
            control_spec, relief = attach_spec, None
            if state.get('step') != int(task.step_counter):
                phase_spec = (task.get_current_phase_spec() if hasattr(task, 'get_current_phase_spec') else {})
                force_band = None
                band_kind = 'turn'
                if getattr(task, 'phase', None) == 'assemble_00_part_3_assembly_clearance':
                    force_band = (phase_spec.get('local_skill') or {}).get('beam_turn_peak_force_band_N')
                elif getattr(task, 'phase', None) in {
                        'assemble_00_part_3_lift', 'assemble_00_part_3_post_lift_restore_gravity',
                        'assemble_00_part_3_pickup_clearance'}:
                    force_band = (phase_spec.get('local_skill') or {}).get('beam_carry_peak_force_band_N')
                    band_kind = 'carry'
                if (saved['object'] == 'fabrica_beam_3'
                        and force_band is not None):
                    try:
                        low, high = map(float, force_band)
                        if not (np.isfinite(low) and np.isfinite(high)
                                and 4.0 <= low < high <= 24.0
                                and high < float(attach_spec.get('close_force_limit', 40.0))):
                            raise ValueError('Invalid loaded force band')
                    except (TypeError, ValueError):
                        return self._failure_or_hold(task, robot_name, spec,
                                                     f'loaded_{band_kind}_force_band_invalid')
                    # Preserve the captured grasp, accumulated seek budget and
                    # original hard limits. This band regulates the larger force,
                    # never declares bilateral contact or a successful hold.
                    control_spec = dict(attach_spec, close_force_low=low, close_force_high=high)
                config = phase_spec.get('beam_table_contact_force_relief')
                if saved['object'] == 'fabrica_beam_6' and config:
                    from toolkits.factory_dual_franka_assembly.beam_contact_relief import contact_relief_spec
                    control_spec, relief = contact_relief_spec(
                        saved.setdefault('beam_contact_relief', {}), task._beam_table_observation(),
                        attach_spec, config)
            if diagnostic_hold is not None:
                if (not diagnostic_hold.get('valid') or not np.allclose(command_q,
                        diagnostic_hold.get('arm_q'), rtol=0, atol=1e-6)):
                    return self._failure_or_hold(task, robot_name, spec, 'loaded_target_hold_target_changed')
                forces = [float(metrics[s]['force']) for s in ('left_finger', 'right_finger')]
                force_limit = float(attach_spec.get('close_force_limit', 40.))
                if max(forces) > force_limit:
                    return self._failure_or_hold(task, robot_name, spec, 'loaded_gripper_force_limit')
                openness = float(diagnostic_hold['gripper_openness'])
                # Keep the regulation cache at the published target, so expiry
                # resumes a rate-limited update without a hidden accumulated seek.
                state['contact_command_closure'] = abs(closed_q - open_q) * (1. - openness)
                state['hold_gripper_openness'] = openness
                state['step'] = int(task.step_counter)
                state['last_control'] = {'mode': 'diagnostic_native_target_hold',
                    'force_within_limit': True, 'forces': forces, 'force_limit': force_limit,
                    'command_q': diagnostic_hold['gripper_q'], 'command_openness': openness,
                    'table_contact_relief': relief}
                saved['gripper_openness'] = openness
                self._remember_gripper_hold_openness(task=task, robot_name=robot_name, openness=openness)
                return OrderedDict([(_ARM_JOINT_CONTROLLER, [diagnostic_hold['arm_q']]),
                                    (_GRIPPER_CONTROLLER, [openness])])
            if state.get('step') != int(task.step_counter):
                control = self._contact_close_control(state=state, spec=control_spec, metrics=metrics,
                    gripper_q=measured, open_q=open_q, closed_q=closed_q,
                    requested_openness=saved['gripper_openness'], min_openness=float(getattr(
                        task.robots[robot_name].config, 'gripper_close_openness', .08)))
                state['step'] = int(task.step_counter)
                state['last_control'] = control
                trace = os.environ.get('BEAM_HOLD_TRACE_PATH')
                if trace:
                    path = os.path.join(os.path.dirname(trace), 'loaded_force_trace.jsonl')
                    with open(path, 'a', encoding='utf-8') as handle:
                        handle.write(json.dumps({'step': int(task.step_counter), 'phase': task.phase,
                            'robot': robot_name, 'gripper_q': measured, 'previous_command_closure': previous,
                            'control': control, 'table_contact_relief': relief}) + '\n')
                if not control['force_within_limit']:
                    return self._failure_or_hold(task, robot_name, spec, 'loaded_gripper_force_limit')
                saved['gripper_openness'] = control['command_openness']
                self._remember_gripper_hold_openness(task=task, robot_name=robot_name,
                                                     openness=saved['gripper_openness'])
            if not state['last_control']['force_within_limit']:
                return self._failure_or_hold(task, robot_name, spec, 'loaded_gripper_force_limit')
        elif diagnostic_hold is not None:
            return self._failure_or_hold(task, robot_name, spec, 'loaded_target_hold_regulation_unavailable')
        return OrderedDict([(_ARM_JOINT_CONTROLLER, [np.asarray(command_q).tolist()]),
                            (_GRIPPER_CONTROLLER, [saved['gripper_openness']])])

    @staticmethod
    def _assisted_transition_hold_target(task, robot_name, current_q):
        stamp = task._beam_physics_stamp()
        published = getattr(task, '_assisted_published_q_stamps', {}).get(robot_name)
        q = np.asarray(getattr(task, '_assisted_published_q', {}).get(robot_name), float)
        actual = np.asarray(current_q, float)
        if (stamp.get('valid') is not True or not isinstance(published, dict)
                or published.get('epoch') != stamp.get('epoch')
                or type(stamp.get('index')) is not int or type(published.get('index')) is not int
                or stamp['index']-published['index'] not in (0, 1)
                or q.shape != (6,) or actual.shape != (6,)
                or not np.all(np.isfinite([q, actual])) or np.max(np.abs(q-actual)) > .12+1e-12):
            raise ValueError('assisted transition hold lacks a fresh final published target')
        return q.copy()

    def _held_transport_action(self, *, task, robot_name: str, spec: dict) -> OrderedDict:
        action = self._hold_joint_action(task=task, robot_name=robot_name)
        gripper_command = spec.get('gripper_command', 'contact_hold')
        action[_GRIPPER_CONTROLLER] = [
            self._gripper_command_value(
                task=task,
                robot_name=robot_name,
                command=gripper_command,
            )
        ]
        return action

    def _target_object_settle_capture_detail(
        self,
        *,
        task,
        spec: dict,
        target_pose: dict,
        current_pose: dict | None,
        tracked_objects: dict,
    ) -> dict[str, Any]:
        detail: dict[str, Any] = {
            'configured': bool(
                spec.get('beam_assisted_transition_settle')
                or (spec.get('hold_for_target_object_settle', False)
                    and spec.get('require_target_object_static', False))
            ),
            'capture_ready': False,
            'tcp_position_ready': False,
            'tcp_orientation_ready': False,
            'object_position_ready': False,
            'object_orientation_ready': False,
            'lateral_ready': False,
        }
        if not detail['configured'] or current_pose is None:
            return detail
        object_name = self._object_name_from_spec(spec)
        if object_name is None:
            return detail
        object_pose = self._object_pose(
            task=task,
            object_name=object_name,
            tracked_objects=tracked_objects,
        )
        target_object_pose = self._target_object_pose(task=task, spec=spec)
        if object_pose is None or target_object_pose is None:
            return detail
        relaxed_active = bool(
            spec.get('relaxed_position_tolerance') is not None
            and spec.get('relaxed_position_tolerance_after_steps') is not None
            and int(getattr(task, 'phase_step_counter', 0)) >= int(spec['relaxed_position_tolerance_after_steps'])
        )
        tcp_tolerance = float(spec.get('position_tolerance', 0.025))
        object_tolerance = float(spec.get('target_object_position_tolerance', tcp_tolerance))
        if relaxed_active:
            tcp_tolerance = max(
                tcp_tolerance,
                float(spec['relaxed_position_tolerance']),
            )
            if spec.get('relaxed_target_object_position_tolerance') is not None:
                object_tolerance = max(
                    object_tolerance,
                    float(spec['relaxed_target_object_position_tolerance']),
                )

        compliant_linear_allowance, compliant_angular_tolerance, attachment_mode = self._compliant_attachment_allowance(
            object_name=object_name,
            tracked_objects=tracked_objects,
        )
        tcp_tolerance += compliant_linear_allowance

        tcp_position_error, tcp_orientation_error = pose_error(
            current_pose['position'],
            current_pose['orientation'],
            target_pose['position'],
            target_pose['orientation'],
        )
        orientation_tolerance = spec.get('orientation_tolerance')
        if orientation_tolerance is not None:
            orientation_tolerance = float(orientation_tolerance) + compliant_angular_tolerance
        compliant_object_gated = bool(
            attachment_mode == 'compliant_joint' and spec.get('require_target_object_pose_convergence', False)
        )
        requires_tcp_for_capture = bool(spec.get('target_object_capture_requires_tcp', True))
        tcp_position_ready = bool(
            not requires_tcp_for_capture
            or compliant_object_gated
            or tcp_position_error <= tcp_tolerance
        )
        tcp_orientation_ready = bool(
            not requires_tcp_for_capture
            or compliant_object_gated
            or orientation_tolerance is None
            or tcp_orientation_error is None
            or tcp_orientation_error <= float(orientation_tolerance)
        )

        target_object_orientation = target_object_pose.get('orientation')
        if target_object_orientation is None:
            object_position_error = float(
                np.linalg.norm(
                    np.asarray(object_pose['position'], dtype=float)
                    - np.asarray(target_object_pose['position'], dtype=float)
                )
            )
            object_orientation_error = None
        else:
            object_position_error, object_orientation_error = pose_error(
                object_pose['position'],
                object_pose['orientation'],
                target_object_pose['position'],
                target_object_orientation,
            )
        object_orientation_tolerance = spec.get(
            'target_object_orientation_tolerance',
            orientation_tolerance,
        )
        object_position_ready = bool(object_position_error <= object_tolerance)
        object_orientation_ready = bool(
            object_orientation_tolerance is None
            or object_orientation_error is None
            or object_orientation_error <= float(object_orientation_tolerance)
        )

        convergence_axis = spec.get('target_object_convergence_axis')
        lateral_tolerance = spec.get('target_object_lateral_position_tolerance')
        lateral_error = None
        lateral_ready = True
        if convergence_axis is not None and lateral_tolerance is not None:
            convergence_axis = np.asarray(convergence_axis, dtype=float)
            axis_norm = float(np.linalg.norm(convergence_axis))
            if convergence_axis.shape != (3,) or not np.isfinite(axis_norm) or axis_norm <= 1e-9:
                lateral_ready = False
            else:
                convergence_axis = convergence_axis / axis_norm
                object_delta = np.asarray(object_pose['position'], dtype=float) - np.asarray(
                    target_object_pose['position'],
                    dtype=float,
                )
                axial_delta = float(np.dot(object_delta, convergence_axis))
                lateral_error = float(np.linalg.norm(object_delta - axial_delta * convergence_axis))
                lateral_ready = bool(lateral_error <= float(lateral_tolerance))

        detail.update(
            {
                'object_name': object_name,
                'attachment_mode': attachment_mode,
                'tcp_pose_required_for_capture': not compliant_object_gated,
                'target_object_capture_requires_tcp': requires_tcp_for_capture,
                'relaxed_active': relaxed_active,
                'tcp_position_error': tcp_position_error,
                'tcp_position_tolerance': tcp_tolerance,
                'tcp_orientation_error': tcp_orientation_error,
                'tcp_orientation_tolerance': orientation_tolerance,
                'tcp_position_ready': tcp_position_ready,
                'tcp_orientation_ready': tcp_orientation_ready,
                'object_position_error': object_position_error,
                'object_position_tolerance': object_tolerance,
                'object_orientation_error': object_orientation_error,
                'object_orientation_tolerance': object_orientation_tolerance,
                'object_position_ready': object_position_ready,
                'object_orientation_ready': object_orientation_ready,
                'lateral_error': lateral_error,
                'lateral_tolerance': lateral_tolerance,
                'lateral_ready': lateral_ready,
            }
        )
        detail['capture_ready'] = bool(
            tcp_position_ready
            and tcp_orientation_ready
            and object_position_ready
            and object_orientation_ready
            and lateral_ready
        )
        if spec.get('beam_assisted_absolute_object_servo') and spec.get('beam_assisted_descent_admission'):
            from .beam_assisted_servo import descent_admission
            robot_name = spec.get('robot')
            context = getattr(task, '_beam_assisted_command_contexts', {}).get(robot_name)
            if (context is None or context['phase_index'] != getattr(task, 'phase_index', None)
                    or context['phase_entry_step'] != getattr(task, 'phase_entry_step', None)):
                raise ValueError('assisted capture lacks a current servo context')
            _, stamp, native, actual_object, _, state = self._assisted_object_servo_context(
                phase_key=context['phase_key'], task=task, robot_name=robot_name, spec=spec,
                tracked_robots=context['tracked_robots'], tracked_objects=tracked_objects)
            ready, admission = descent_admission(state.setdefault('admission', {}), stamp,
                actual_object, target_object_pose,
                spec.get('target_object_convergence_axis', [0., 0., -1.]),
                spec['beam_assisted_descent_admission'], native)
            state.update(descent_ready=ready, admission_detail=admission, stamp=dict(stamp))
            detail['assisted_descent_admission'] = admission
            detail['capture_ready'] = bool(detail['capture_ready'] and ready)
        return detail

    @staticmethod
    def _compliant_attachment_allowance(
        *,
        object_name: str | None,
        tracked_objects: dict,
    ) -> tuple[float, float, str | None]:
        if object_name is None:
            return 0.0, 0.0, None
        tracked_object = tracked_objects.get(str(object_name), {})
        attachment_state = tracked_object.get('attachment') or {}
        attachment_mode = attachment_state.get('mode')
        if attachment_mode != 'compliant_joint':
            return 0.0, 0.0, attachment_mode
        attach_spec = attachment_state.get('attach_spec') or {}
        linear_limit = max(
            float(attach_spec.get('compliant_hold_linear_limit', 0.006)),
            0.0,
        )
        angular_limit_degrees = max(
            float(
                attach_spec.get(
                    'compliant_hold_angular_limit_degrees',
                    6.0,
                )
            ),
            0.0,
        )
        return (
            math.sqrt(3.0) * linear_limit,
            math.radians(angular_limit_degrees),
            attachment_mode,
        )

    def _debug_target_object_settle(
        self,
        *,
        task,
        detail: dict[str, Any],
        state: dict[str, Any],
        event: str,
        hold_active: bool,
        tracked_objects: dict,
    ) -> None:
        if not self._debug_grasp_enabled() or not bool(detail.get('configured')):
            return
        phase_step = int(getattr(task, 'phase_step_counter', 0))
        every = max(int(os.environ.get('UR5E_DEBUG_TRANSPORT_EVERY', '15')), 1)
        if phase_step > 5 and phase_step % every != 0 and event not in {'capture', 'hold_complete'}:
            return
        motion_detail = self._object_motion_detail(
            task=task,
            object_name=detail.get('object_name'),
            tracked_objects=tracked_objects,
        )
        print(
            '[ur5e-settle-debug] '
            f"step={getattr(task, 'step_counter', None)} "
            f"phase={getattr(task, 'phase', None)} phase_step={phase_step} "
            f"event={event} capture_ready={detail.get('capture_ready')} "
            f"hold_active={hold_active} hold_remaining={state.get('remaining_steps', 0)} "
            f"retry_servo_remaining={state.get('retry_servo_steps', 0)} "
            f"capture_count={state.get('capture_count', 0)} "
            f"tcp_pos={detail.get('tcp_position_error')}/{detail.get('tcp_position_tolerance')} "
            f"tcp_pos_ready={detail.get('tcp_position_ready')} "
            f"tcp_rot={detail.get('tcp_orientation_error')}/{detail.get('tcp_orientation_tolerance')} "
            f"tcp_rot_ready={detail.get('tcp_orientation_ready')} "
            f"object_pos={detail.get('object_position_error')}/{detail.get('object_position_tolerance')} "
            f"object_pos_ready={detail.get('object_position_ready')} "
            f"object_rot={detail.get('object_orientation_error')}/{detail.get('object_orientation_tolerance')} "
            f"object_rot_ready={detail.get('object_orientation_ready')} "
            f"lateral={detail.get('lateral_error')}/{detail.get('lateral_tolerance')} "
            f"lateral_ready={detail.get('lateral_ready')} "
            f"lin={motion_detail.get('linear_speed')} ang={motion_detail.get('angular_speed')} "
            f"relaxed={detail.get('relaxed_active')}",
            flush=True,
        )

    def _stool_empty_joint_route_action(self, *, phase_key, task, robot_name,
                                        skill_name, spec, target_pose):
        """Run declared empty-arm waypoints through the original joint atom.

        Original target locking and prealign have already run in act. Internal
        waypoint completion never marks the original skill. Final actual SDK
        full FK seeds the original Cartesian continuation, which retains its
        original goal/completion predicates and still passes the uniform guard.
        """
        pairs={'assemble_00_part_3_move_above':'fabrica_stool_circular_3',
               'assemble_01_part_7_move_above':'fabrica_stool_circular_7',
               'assemble_02_part_6_move_above':'fabrica_stool_circular_6',
               'assemble_04_part_5_move_above':'fabrica_stool_circular_5',
               'assemble_06_part_0_move_above':'fabrica_stool_circular_0'}
        contract=task._assisted_task_contract();request=spec.get('fabrica_empty_joint_route') or {}
        replace_prealign=request.get('replace_prealign')
        if (contract.get('adapter')!='stool_circular_ur5e_v1'
                or (contract.get('base_support') or {}).get('schema')!='stool_continuous_base_support_v3'
                or robot_name!='franka_left' or task.phase not in pairs
                or spec.get('object')!=pairs[task.phase] or skill_name!='ur5e_move_above_part'
                or spec.get('requires_held_object') or self._tcp_offset(spec) is not None
                or spec.get('prealign_steps')!=240 or spec.get('prealign_until_converged')
                or type(replace_prealign) is not bool
                or (replace_prealign and task.phase!='assemble_01_part_7_move_above')
                or (not replace_prealign and int(task.phase_step_counter)<240) or spec.get('gripper_command')!='open'
                or any(a.get('robot_name')==robot_name for a in getattr(task,'_attachments',{}).values())):
            raise ValueError('Stool empty route is outside exact post-prealign empty left pickup scope')
        keys={'schema','phase','object','terminal_joint_positions','waypoints','source_receipt_sha256','replace_prealign'}
        if (set(request)!=keys or request.get('schema')!='stool_empty_joint_route_v1'
                or request.get('phase')!=task.phase or request.get('object')!=pairs[task.phase]
                or not isinstance(request.get('source_receipt_sha256'),str)
                or len(request['source_receipt_sha256'])!=64
                or any(c not in '0123456789abcdef' for c in request['source_receipt_sha256'])
                or not isinstance(request.get('waypoints'),list)):
            raise ValueError('Stool empty route lacks an exact source-bound route declaration')
        terminal=np.asarray(request['terminal_joint_positions'],float)
        if terminal.shape!=(6,) or not np.all(np.isfinite(terminal)):
            raise ValueError('Stool empty route endpoint must be complete finite joint data')
        points=request['waypoints']
        for point in points:
            value=np.asarray(point,float)
            if value.shape!=(6,) or not np.all(np.isfinite(value)):
                raise ValueError('Stool empty route waypoint must retain six finite joint coordinates')
        if (contract.get('left_empty_joint_routes') or {}).get(task.phase)!=request:
            raise ValueError('Stool empty route does not match its compiled source-bound task declaration')
        role=task._assisted_base_support_role()
        if role is None or role.get('stage')!='hold':
            raise ValueError('Stool empty route requires continuing right base support')
        stamp=task._beam_physics_stamp();sdk=task._assisted_stool_final_sdk_command(robot_name)
        prior_state=self._completion_state.get(phase_key,{}).get('stool_empty_joint_route')
        expected_sdk_phase=task.phase
        if replace_prealign and not prior_state:
            canonical=contract['base_support']['canonical_phase_names']
            index=canonical.index(task.phase)
            if index<=0:raise ValueError('Stool replaced prealign lacks its original preceding phase')
            expected_sdk_phase=canonical[index-1]
        elif (replace_prealign and prior_state and stamp==prior_state.get('stamp')
                and sdk['receipt']==prior_state.get('reference_receipt')):
            expected_sdk_phase=prior_state['reference_receipt'].get('phase')
        current_q=np.asarray(self._current_arm_q(task,robot_name),float)
        if (stamp.get('valid') is not True or type(stamp.get('epoch')) is not int
                or type(stamp.get('index')) is not int or current_q.shape!=(6,)
                or not np.all(np.isfinite(current_q)) or sdk['gripper_openness']!=1.
                or sdk['receipt'].get('phase')!=expected_sdk_phase):
            raise ValueError('Stool empty route lacks its same-phase actual SDK reference')
        state=self._completion_state.setdefault(phase_key,{}).setdefault('stool_empty_joint_route',{})
        goal={k:np.asarray(target_pose[k],float).copy() for k in ('position','orientation')}
        if any(v.shape!=shape or not np.all(np.isfinite(v)) for v,shape in ((goal['position'],(3,)),(goal['orientation'],(4,)))):
            raise ValueError('Stool empty route original locked goal is invalid')
        if not state:
            state.update(request=copy.deepcopy(request),original_goal=goal,entry_q=sdk['arm_q'].copy(),
                articulation_id=sdk['articulation_id'],index=0,done=False,waypoint_complete=False)
            class RouteJointController(UR5eAssemblyAtomicSkillAdapter):
                @staticmethod
                def _mark_complete(*,task,robot_name,skill_name,detail):
                    state['waypoint_complete']=copy.deepcopy(detail)
            state['controller']=RouteJointController({})
        elif (state['request']!=request or state['articulation_id']!=sdk['articulation_id']
                or any(not np.array_equal(state['original_goal'][k],goal[k]) for k in goal)):
            raise ValueError('Stool empty route goal/runtime/source identity changed')
        if state['done']:
            return None
        if state.get('stamp') is not None:
            if stamp['epoch']!=state['stamp']['epoch'] or stamp['index']<state['stamp']['index']:
                raise ValueError('Stool empty route native clock reordered')
            if stamp['index']==state['stamp']['index']:
                same_reference=sdk['receipt']==state['reference_receipt']
                own_publication=(sdk['receipt'].get('physics_stamp')==state['stamp']
                    and sdk['receipt'].get('expected_sdk_batch_sequence')==state['expected_sdk_sequence'])
                if stamp!=state['stamp'] or not np.array_equal(current_q,state['current_q']) or not(same_reference or own_publication):
                    raise ValueError('Stool empty route duplicate native tick changed its observations/SDK ownership')
                return copy.deepcopy(state['action'])
            if (sdk['receipt'].get('physics_stamp')!=state['stamp']
                    or sdk['receipt'].get('expected_sdk_batch_sequence')!=state['expected_sdk_sequence']):
                raise ValueError('Stool empty route previous publication lacks its actual SDK acknowledgment')
        if state['done']:
            return None
        if state['waypoint_complete']:
            state['index']+=1;state['waypoint_complete']=False
        if state['index']>len(points):
            fk=self._grasp_command_fk_pose(task=task,robot_name=robot_name,spec=spec,command_q=sdk['arm_q'])
            if fk is None:raise ValueError('Stool empty route handoff lacks complete final SDK FK')
            self._remember_cartesian_command_position(phase_key=phase_key,command_target_pose=fk)
            self._remember_cartesian_command_orientation(phase_key=phase_key,command_target_pose=fk)
            self._remember_arm_command(task,robot_name,sdk['arm_q'])
            state['done']=True
            task._assisted_event('stool_empty_route_handoff',robot=robot_name,object=spec['object'],physics_stamp=stamp,
                actual_final_SDK=sdk,full_FK_tcp_pose=fk,original_locked_goal=state['original_goal'],original_completion_unmodified=True)
            return None
        index=state['index']
        target=np.asarray(points[index],float).copy() if index<len(points) else terminal.copy()
        joint=state['controller'];joint._current_arm_q=self._current_arm_q
        joint._gripper_command_value=self._gripper_command_value
        joint._remember_arm_command(task,robot_name,sdk['arm_q'])
        joint_spec={**spec,'name':'ur5e_move_arm_to_joint_positions','joint_positions':target.tolist(),
            'beam_assisted_native_joint_target':True,'unwrap_revolute_joints':False,
            'joint_position_tolerance':.025,'joint_target_stable_steps':8,
            'max_joint_step':contract['max_joint_step_rad'],'max_command_joint_step':contract['max_joint_step_rad'],
            'max_command_tracking_error':contract['max_tracking_error_rad'],'gripper_command':'open'}
        action=joint._move_arm_to_joint_positions_action(phase_key=phase_key+('route',index),task=task,
            robot_name=robot_name,skill_name='ur5e_move_arm_to_joint_positions',spec=joint_spec)
        if task._beam_physics_stamp()!=stamp:raise ValueError('Stool empty route clock changed during command construction')
        state.update(stamp=copy.deepcopy(stamp),current_q=current_q.copy(),reference_receipt=copy.deepcopy(sdk['receipt']),
            expected_sdk_sequence=sdk['receipt']['expected_sdk_batch_sequence']+1,action=copy.deepcopy(action))
        task._assisted_event('stool_empty_route_command',robot=robot_name,object=spec['object'],physics_stamp=stamp,
            route_index=index,entry_final_sdk_q=state['entry_q'],terminal_reference_q=terminal,route_target_q=target,
            reference_actual_final_SDK=sdk,provisional_action=action,source_receipt_sha256=request['source_receipt_sha256'],
            original_locked_goal=state['original_goal'],original_completion_unmodified=True,
            command_scope='original native joint primitive; provisional before the same complete guard and actual SDK')
        return action

    def _stool_loaded_route_goal(self, *, task, robot_name, spec, state, stamp,
                                 native_pose, current_model, previous_model, previous_tcp,
                                 current_pose, relative_p, relative_q, original_goal,
                                 precision, rprecision, settings):
        """Select a fixed native object waypoint, leaving the SE3 controller intact.

        Waypoint q6 values are planning parameters. Their actual control-frame
        FK and the original captured relation define model poses. One fixed
        entry-native/final-SDK-model anchor maps them to native object goals.
        Advancement proves accepted command fidelity, never native contact or
        phase completion; every motion still uses the original SE3 envelopes.
        """
        from .beam_assisted_servo import object_pose_from_tcp,anchored_object_prediction,model_command_for_native_pose
        pairs={'assemble_00_part_3_assembly_clearance':'fabrica_stool_circular_3',
               'assemble_01_part_7_assembly_clearance':'fabrica_stool_circular_7',
               'assemble_02_part_6_assembly_clearance':'fabrica_stool_circular_6',
               'assemble_03_part_4_assembly_clearance':'fabrica_stool_circular_4',
               'assemble_04_part_5_assembly_clearance':'fabrica_stool_circular_5'}
        contract=task._assisted_task_contract();request=spec['fabrica_loaded_object_route']
        if (robot_name!='franka_left' or task.phase not in pairs or spec.get('object')!=pairs[task.phase]
                or not spec.get('fabrica_object_se3_clearance') or not spec.get('requires_held_object')
                or (contract.get('base_support') or {}).get('schema')!='stool_continuous_base_support_v3'
                or (contract.get('left_loaded_object_routes') or {}).get(task.phase)!=request
                or set(request)!={'schema','phase','object','waypoint_joint_positions','source_receipt_sha256'}
                or request.get('schema')!='stool_loaded_object_route_v1' or request.get('phase')!=task.phase
                or request.get('object')!=pairs[task.phase] or not isinstance(request.get('waypoint_joint_positions'),list)
                or not request['waypoint_joint_positions'] or not isinstance(request.get('source_receipt_sha256'),str)
                or len(request['source_receipt_sha256'])!=64
                or any(c not in '0123456789abcdef' for c in request['source_receipt_sha256'])):
            raise ValueError('Stool loaded route is outside its source-bound original held-clearance pair')
        role=task._assisted_base_support_role()
        if role is None or role.get('stage')!='hold':raise ValueError('Stool loaded route requires continuing right base support')
        route=state.get('loaded_route')
        if route is None:
            native_goals=[];model_goals=[]
            for value in request['waypoint_joint_positions']:
                q=np.asarray(value,float)
                if q.shape!=(6,) or not np.all(np.isfinite(q)):raise ValueError('Stool loaded route waypoint is not finite full6q')
                tcp=self._grasp_command_fk_pose(task=task,robot_name=robot_name,spec=spec,command_q=q)
                if tcp is None:raise ValueError('Stool loaded route waypoint lacks actual control FK')
                model=object_pose_from_tcp(tcp,relative_p,relative_q)
                native=anchored_object_prediction(native_pose,previous_model,model)
                for pose in (model,native):
                    if (np.asarray(pose['position']).shape!=(3,) or np.asarray(pose['orientation']).shape!=(4,)
                            or not all(np.all(np.isfinite(v)) for v in pose.values())):
                        raise ValueError('Stool loaded route waypoint pose is invalid')
                model_goals.append(copy.deepcopy(model));native_goals.append(copy.deepcopy(native))
            route=dict(request=copy.deepcopy(request),index=0,entry_stamp=copy.deepcopy(stamp),
                entry_native_pose=copy.deepcopy(native_pose),entry_final_sdk_model_pose=copy.deepcopy(previous_model),
                waypoint_model_poses=model_goals,waypoint_native_poses=native_goals)
            state['loaded_route']=route
        if route['request']!=request:raise ValueError('Stool loaded route declaration changed after entry')
        predicted=anchored_object_prediction(native_pose,current_model,previous_model)
        lead_p,lead_r=pose_error(native_pose['position'],native_pose['orientation'],predicted['position'],predicted['orientation'])
        tcp_lead=float(np.linalg.norm(np.asarray(previous_tcp['position'])-current_pose['position']))
        inside=bool(lead_p<=settings['position_lookahead_m']+1e-12 and lead_r<=settings['orientation_lookahead_rad']+1e-12
                    and tcp_lead<=settings['position_lookahead_m']+1e-12)
        accepted=[];error=None
        while route['index']<len(route['waypoint_native_poses']):
            active=route['waypoint_native_poses'][route['index']]
            mapped=model_command_for_native_pose(native_pose,current_model,active)
            dp,dr=pose_error(previous_model['position'],previous_model['orientation'],mapped['position'],mapped['orientation'])
            error=dict(position_m=dp,orientation_rad=dr)
            if not inside or dp>precision or dr>rprecision:break
            accepted.append(route['index']);route['index']+=1
        pending=route['index']<len(route['waypoint_native_poses'])
        active=copy.deepcopy(route['waypoint_native_poses'][route['index']] if pending else original_goal)
        return active,pending,dict(index=route['index'],waypoint_count=len(route['waypoint_native_poses']),
            newly_accepted_command_waypoints=accepted,accepted_full_FK_error=error,command_inside_original_envelopes=inside,
            entry_physics_stamp=route['entry_stamp'],entry_native_object_pose=route['entry_native_pose'],
            entry_final_sdk_model_object_pose=route['entry_final_sdk_model_pose'],
            source_receipt_sha256=request['source_receipt_sha256'],qualification='accepted final SDK command fidelity only; native fit/guard/original completion remain independent')

    def _stool_clearance_joint_action(self, *, phase_key, task, robot_name, skill_name,
                                      spec, tracked_objects, current_pose, target_pose, transport=False):
        """Advance one complete object SE3 from the actual final SDK drive pose.

        The original captured relation and native state are read-only. Every
        new object-p/R increment shares one backtrack fraction; its inverse
        uses that SAME rotation for all three TCP position coordinates.
        """
        from .beam_assisted_servo import (object_pose_from_tcp, model_command_for_native_pose,
            anchored_object_prediction, interpolate_object_pose)
        contract = task._assisted_task_contract()
        settings = spec.get('fabrica_object_se3_transport' if transport else 'fabrica_object_se3_clearance') or {}
        STOOL_SE3_CLEARANCE_OBJECTS = {
            'assemble_00_part_3_pickup_clearance': 'fabrica_stool_circular_3',
            'assemble_00_part_3_assembly_clearance': 'fabrica_stool_circular_3',
            'assemble_01_part_7_pickup_clearance': 'fabrica_stool_circular_7',
            'assemble_01_part_7_assembly_clearance': 'fabrica_stool_circular_7',
            'assemble_02_part_6_pickup_clearance': 'fabrica_stool_circular_6',
            'assemble_02_part_6_assembly_clearance': 'fabrica_stool_circular_6',
            'assemble_03_part_4_pickup_clearance': 'fabrica_stool_circular_4',
            'assemble_03_part_4_assembly_clearance': 'fabrica_stool_circular_4',
            'assemble_04_part_5_pickup_clearance': 'fabrica_stool_circular_5',
            'assemble_04_part_5_assembly_clearance': 'fabrica_stool_circular_5',
            'assemble_05_part_1_pickup_clearance': 'fabrica_stool_circular_1',
            'assemble_05_part_1_assembly_clearance': 'fabrica_stool_circular_1',
            'assemble_06_part_0_pickup_clearance': 'fabrica_stool_circular_0',
            'assemble_06_part_0_assembly_clearance': 'fabrica_stool_circular_0',
            'assemble_07_part_8_pickup_clearance': 'fabrica_stool_circular_8',
            'assemble_07_part_8_assembly_clearance': 'fabrica_stool_circular_8',
        }
        STOOL_SE3_TRANSPORT_OBJECTS = {'assemble_02_part_6_transport_hover': 'fabrica_stool_circular_6', 'assemble_03_part_4_transport_hover': 'fabrica_stool_circular_4', 'assemble_04_part_5_transport_hover': 'fabrica_stool_circular_5', 'assemble_05_part_1_transport_hover': 'fabrica_stool_circular_1', 'assemble_06_part_0_transport_hover': 'fabrica_stool_circular_0', 'assemble_07_part_8_transport_hover': 'fabrica_stool_circular_8'}
        selected_pairs = STOOL_SE3_TRANSPORT_OBJECTS if transport else STOOL_SE3_CLEARANCE_OBJECTS
        if (contract.get('adapter') != 'stool_circular_ur5e_v1' or task.phase not in selected_pairs
                or skill_name != 'ur5e_move_part_to_staging'
                or spec.get('object') != selected_pairs[task.phase]
                or not spec.get('requires_held_object') or self._tcp_offset(spec) is not None
                or spec.get('beam_assisted_absolute_object_servo')
                or (transport and spec.get('fabrica_object_se3_clearance'))
                or (not transport and spec.get('fabrica_object_se3_transport'))):
            raise ValueError('Stool SE3 clearance requires its exact original phase/object pair')
        pstep = float(contract['install_position_step_m'])
        rstep = float(contract['install_orientation_step_rad'])
        precision = max(min(pstep * .05, 5e-4), 1e-5)
        expected = {'schema': 'stool_object_se3_transport_v1' if transport else 'stool_object_se3_clearance_v1', 'position_step_m': pstep,
            'orientation_step_rad': rstep, 'position_lookahead_m': .003,
            'orientation_lookahead_rad': 3. * rstep, 'position_precision_m': precision,
            'original_ik_orientation_tolerance_rad': .002,
            'numeric_source': 'original Stool insertion p/R steps; unchanged3mm generic TCP budget; three original insertion orientation samples; timeout inverse orientation-lead ratio'}
        if transport:
            expected['numeric_source'] = 'original Stool insertion p/R steps; unchanged3mm generic TCP budget; three original insertion orientation samples; original transport timeout retained'
            if (spec.get('hold_for_target_object_settle') is not True
                    or spec.get('require_target_object_static') is not True
                    or spec.get('target_object_settle_hold_steps') != 48
                    or spec.get('target_object_settle_retry_servo_steps') != 8
                    or spec.get('beam_assisted_transition_settle')):
                raise ValueError('Stool SE3 transport original static/settle contract changed')
        if (settings != expected or spec.get('cartesian_position_step') != pstep
                or spec.get('cartesian_orientation_step') != rstep
                or spec.get('ik_position_tolerance') != precision):
            raise ValueError('Stool SE3 clearance command contract changed')
        stamp = task._beam_physics_stamp()
        if (stamp.get('valid') is not True or type(stamp.get('epoch')) is not int
                or type(stamp.get('index')) is not int):
            raise ValueError('Stool SE3 clearance lacks a native clock')
        name = spec['object'];robot = task.robots[robot_name]
        attachment = getattr(task, '_attachments', {}).get(name) or {}
        if (attachment.get('mode') != 'fixed_joint' or attachment.get('robot_name') != robot_name
                or not attachment.get('joint_path') or attachment.get('attach_step') is None):
            raise ValueError('Stool SE3 clearance lacks its original fixed grasp')
        capture_p = np.asarray(attachment.get('position'), float).copy()
        capture_q = np.asarray(attachment.get('orientation'), float).copy()
        if (capture_p.shape != (3,) or capture_q.shape != (4,)
                or not np.all(np.isfinite(capture_p)) or not np.all(np.isfinite(capture_q))
                or np.linalg.norm(capture_q) == 0.):
            raise ValueError('Stool SE3 clearance capture is invalid')
        native = task._assisted_native_body_motion(name, stamp['epoch'])
        if (native.get('motion_valid') is not True or native.get('physics_handle_valid') is not True
                or not native.get('body_path') or native.get('motion_view_id') is None):
            raise ValueError('Stool SE3 clearance native object identity is invalid')
        native_pose = {k: np.asarray(native[k], float).copy() for k in ('position', 'orientation')}
        goal = self._target_object_pose(task=task, spec=spec)
        if goal is None:
            raise ValueError('Stool SE3 clearance lacks its original object goal')
        goal = {k: np.asarray(goal[k], float).copy() for k in ('position', 'orientation')}
        current_pose = {k: np.asarray(current_pose[k], float).copy() for k in ('position', 'orientation')}
        for pose in (native_pose, goal, current_pose):
            if (pose['position'].shape != (3,) or pose['orientation'].shape != (4,)
                    or not all(np.all(np.isfinite(v)) for v in pose.values())
                    or np.linalg.norm(pose['orientation']) == 0.):
                raise ValueError('Stool SE3 clearance pose is invalid')
        current_q = np.asarray(self._current_arm_q(task, robot_name), float)
        previous_q = np.asarray(getattr(task, '_assisted_published_q', {}).get(robot_name), float)
        receipt = getattr(task, '_fabrica_final_gripper_commands', {}).get(robot_name) or {}
        published_stamp = receipt.get('physics_stamp') or {}
        if (published_stamp.get('valid') is not True or published_stamp.get('epoch') != stamp['epoch']
                or type(published_stamp.get('index')) is not int
                or stamp['index'] - published_stamp['index'] not in (0, 1)
                or type(receipt.get('expected_sdk_batch_sequence')) is not int
                or receipt['expected_sdk_batch_sequence'] != getattr(robot, '_action_batch_sequence', None)
                or 'arm_joint_controller' not in getattr(robot, 'last_action_controller_names', ())
                or any(q.shape != (6,) or not np.all(np.isfinite(q)) for q in (current_q, previous_q))):
            raise ValueError('Stool SE3 clearance lacks a fresh completed final SDK joint command')
        identity = (stamp['epoch'], attachment['joint_path'], attachment['attach_step'],
                    native['body_path'], native['motion_view_id'])
        state = self._completion_state.setdefault(phase_key, {}).setdefault('stool_transport_se3' if transport else 'stool_clearance_se3', {})
        entry = not state
        if state:
            if (state['identity'] != identity or not np.array_equal(state['capture_p'], capture_p)
                    or not np.array_equal(state['capture_q'], capture_q)):
                raise ValueError('Stool SE3 clearance grasp/body identity changed')
            if any(not np.array_equal(state['goal'][k], goal[k]) for k in goal):
                raise ValueError('Stool SE3 clearance original phase goal changed')
            if stamp['index'] < state['stamp']['index']:
                raise ValueError('Stool SE3 clearance native clock moved backwards')
            if stamp['index'] == state['stamp']['index']:
                if (stamp != state['stamp'] or not np.array_equal(current_q, state['current_q'])
                        or any(not np.array_equal(native_pose[k], state['native_pose'][k])
                               or not np.array_equal(current_pose[k], state['current_pose'][k]) for k in native_pose)):
                    raise ValueError('Stool SE3 clearance observations changed within one native tick')
                reference_owner = (published_stamp == state['reference_receipt_stamp']
                    and receipt['expected_sdk_batch_sequence'] == state['reference_receipt_sequence'])
                own_publication = (published_stamp == state['stamp']
                    and receipt['expected_sdk_batch_sequence'] == state['expected_sdk_sequence'])
                if not (reference_owner or own_publication):
                    raise ValueError('Stool SE3 clearance duplicate clock SDK ownership changed')
                return copy.deepcopy(state['action'])
            if (published_stamp != state['stamp']
                    or receipt['expected_sdk_batch_sequence'] != state['expected_sdk_sequence']):
                raise ValueError('Stool SE3 clearance previous command SDK ownership changed')
        convert = getattr(task, '_physical_relative_pose_to_control_frame', None)
        if not callable(convert):
            raise ValueError('Stool SE3 clearance lacks original capture conversion')
        try:
            relative_p, relative_q = convert(robot_name, capture_p.copy(), capture_q.copy())
            relative_p, relative_q = np.asarray(relative_p, float), np.asarray(relative_q, float)
            if (relative_p.shape != (3,) or relative_q.shape != (4,)
                    or not np.all(np.isfinite(relative_p)) or not np.all(np.isfinite(relative_q))
                    or np.linalg.norm(relative_q) == 0.):
                raise ValueError('invalid converted capture')
        except Exception as exc:
            raise ValueError('Stool SE3 clearance capture conversion failed') from exc
        lever = float(np.linalg.norm(relative_p))
        rprecision = min(settings['original_ik_orientation_tolerance_rad'],
                         precision / max(lever, np.finfo(float).eps))
        solve_spec = {**spec, 'ik_position_tolerance': precision,
                      'ik_orientation_tolerance': rprecision}
        # Configure only the kinematic solver frame; this does not write native
        # articulation/body state and matches the existing bounded IK outlet.
        controller = robot.controllers[_ARM_IK_CONTROLLER]
        wrapper = controller._kinematics_solver
        base_pose = controller.get_ik_base_world_pose()
        wrapper.set_robot_base_pose(robot_position=np.asarray(base_pose[0]) / controller._robot_scale,
                                    robot_orientation=base_pose[1])
        previous_tcp = self._grasp_command_fk_pose(task=task, robot_name=robot_name,
                                                  spec=spec, command_q=previous_q)
        if previous_tcp is None:
            raise ValueError('Stool SE3 clearance lacks final SDK full FK')
        current_model = object_pose_from_tcp(current_pose, relative_p, relative_q)
        previous_model = object_pose_from_tcp(previous_tcp, relative_p, relative_q)
        active_motion_goal=goal;route_pending=False;route_detail=None
        if spec.get('fabrica_loaded_object_route'):
            active_motion_goal,route_pending,route_detail=self._stool_loaded_route_goal(
                task=task,robot_name=robot_name,spec=spec,state=state,stamp=stamp,
                native_pose=native_pose,current_model=current_model,previous_model=previous_model,
                previous_tcp=previous_tcp,current_pose=current_pose,relative_p=relative_p,relative_q=relative_q,
                original_goal=goal,precision=precision,rprecision=rprecision,settings=settings)
        drive_goal = model_command_for_native_pose(native_pose, current_model, active_motion_goal)
        remaining_p, remaining_r = pose_error(previous_model['position'], previous_model['orientation'],
            drive_goal['position'], drive_goal['orientation'])
        # Use one fraction of this complete goal path; later envelope/IK
        # backtracking scales that same P/R progress without changing its ratio.
        goal_fraction = min(1., pstep / remaining_p if remaining_p > 0. else 1.,
                            rstep / remaining_r if remaining_r > 0. else 1.)
        proposed_model = interpolate_object_pose(previous_model, drive_goal, goal_fraction)
        def inverse(model_pose):
            q = normalize_quat(quat_multiply(model_pose['orientation'], self._quat_conjugate(relative_q)))
            return {'position': np.asarray(model_pose['position']) - quat_rotate(q, relative_p), 'orientation': q}
        def envelope(tcp_pose, model_pose):
            predicted = anchored_object_prediction(native_pose, current_model, model_pose)
            dp, da = pose_error(native_pose['position'], native_pose['orientation'],
                                predicted['position'], predicted['orientation'])
            tcp_lead = float(np.linalg.norm(np.asarray(tcp_pose['position']) - current_pose['position']))
            return bool(dp <= settings['position_lookahead_m'] + 1e-12
                and da <= settings['orientation_lookahead_rad'] + 1e-12
                and tcp_lead <= settings['position_lookahead_m'] + 1e-12), dict(
                    predicted_native_object_pose=predicted, object_position_lead_m=dp,
                    object_orientation_lead_rad=da, TCP_position_lead_m=tcp_lead)
        # Duplicate native calls returned from the exact cache above. The
        # original settle state machine therefore advances once per new native tick.
        settle_hold = bool(transport and self._target_object_settle_ready(
            phase_key=phase_key, task=task, spec=spec, target_pose=target_pose,
            current_pose=current_pose, tracked_objects=tracked_objects))
        old_inside, old_lead = envelope(previous_tcp, previous_model)
        chosen_q = previous_q.copy();chosen_tcp = copy.deepcopy(previous_tcp)
        requested_tcp = copy.deepcopy(previous_tcp);chosen_model = previous_model
        ratio_used = 0.;hold_reason = 'phase_entry_complete_final_sdk_hold' if entry else 'incoming_complete_drive_outside_envelope'
        numerical_error = {'position_m': 0., 'orientation_rad': 0.}
        lead_detail = old_lead
        joint_limits = np.asarray(self._command_joint_step_limits(spec=spec, joint_count=6), float)
        radius = min(float(np.min(joint_limits)), float(contract['max_joint_step_rad']))
        if not np.isfinite(radius) or radius <= 0.:
            raise ValueError('Stool SE3 clearance lacks its original positive joint budget')
        if settle_hold:
            hold_reason = 'original_target_object_settle_complete_final_sdk_hold'
        if not entry and old_inside and not settle_hold:
            hold_reason = 'no_complete_pose_IK_candidate'
            for ratio in (1., .5, .25, .125, .0625):
                model = interpolate_object_pose(previous_model, proposed_model, ratio)
                request = inverse(model)
                inside, detail = envelope(request, model)
                if not inside:
                    continue
                q = self._local_grasp_ik(task=task, robot_name=robot_name, target_pose=request,
                    reference_q=previous_q, spec=solve_spec, joint_radius=radius)
                if q is None:
                    continue
                q = np.asarray(q, float)
                if q.shape != (6,) or not np.all(np.isfinite(q)):
                    continue
                q = self._continuous_command_q(task=task, robot_name=robot_name, command_q=q, spec=spec)
                q = self._limit_command_to_measured_state(current_q=current_q, command_q=q, spec=spec)
                if np.max(np.abs(q - previous_q)) > radius + 1e-12:
                    continue
                actual_tcp = self._grasp_command_fk_pose(task=task, robot_name=robot_name, spec=spec, command_q=q)
                if actual_tcp is None:
                    continue
                dp, da = pose_error(actual_tcp['position'], actual_tcp['orientation'], request['position'], request['orientation'])
                if dp > precision or da > rprecision:
                    continue
                actual_model = object_pose_from_tcp(actual_tcp, relative_p, relative_q)
                move_p, move_r = pose_error(previous_model['position'], previous_model['orientation'],
                    actual_model['position'], actual_model['orientation'])
                inside, detail = envelope(actual_tcp, actual_model)
                if not inside or move_p > pstep + 1e-12 or move_r > rstep + 1e-12:
                    continue
                chosen_q, chosen_tcp, chosen_model = q.copy(), actual_tcp, actual_model
                requested_tcp = request;ratio_used = ratio;hold_reason = None
                numerical_error = {'position_m': dp, 'orientation_rad': da};lead_detail = detail
                break
        if task._beam_physics_stamp() != stamp:
            raise ValueError('Stool SE3 clearance native clock changed during construction')
        action = OrderedDict([(_ARM_JOINT_CONTROLLER, [chosen_q.tolist()]),
            (_GRIPPER_CONTROLLER, [self._gripper_command_value(task=task, robot_name=robot_name,
                                                            command=spec.get('gripper_command', 'contact_hold'))])])
        state.update(identity=identity, capture_p=capture_p.copy(), capture_q=capture_q.copy(),
            goal=copy.deepcopy(goal), stamp=dict(stamp), current_q=current_q.copy(),
            native_pose=copy.deepcopy(native_pose), current_pose=copy.deepcopy(current_pose),
            expected_sdk_sequence=robot._action_batch_sequence + 1,
            reference_receipt_stamp=copy.deepcopy(published_stamp),
            reference_receipt_sequence=receipt['expected_sdk_batch_sequence'], action=copy.deepcopy(action))
        self._last_targets[phase_key] = {'position': np.asarray(target_pose['position']).copy(),
            'orientation': np.asarray(target_pose['orientation']).copy(), 'target_q': chosen_q.copy()}
        self._remember_cartesian_command_position(phase_key=phase_key, command_target_pose=chosen_tcp)
        self._remember_cartesian_command_orientation(phase_key=phase_key, command_target_pose=chosen_tcp)
        self._remember_arm_command(task, robot_name, chosen_q)
        self._debug_joint_step(task=task, robot_name=robot_name, skill_name=skill_name, spec=spec,
            current_pose=current_pose, target_pose=target_pose, command_target_pose=requested_tcp,
            ik_target_pose=self._ik_target_pose(target_pose=requested_tcp, spec=spec),
            current_q=current_q, reference_q=previous_q, target_q=chosen_q, command_q=chosen_q)
        if not route_pending:
            self._maybe_mark_complete(phase_key=phase_key, task=task, robot_name=robot_name,
                skill_name=skill_name, spec=spec, target_pose=target_pose,
                ik_target_pose=self._ik_target_pose(target_pose=requested_tcp, spec=spec),
                current_pose=current_pose, tracked_objects=tracked_objects, current_q=current_q, target_q=chosen_q)
        task._assisted_event('stool_transport_se3_command' if transport else 'stool_clearance_se3_command', robot=robot_name, object=name,
            physics_stamp=dict(stamp), previous_final_sdk_q=previous_q, previous_final_sdk_receipt=receipt,
            previous_final_tcp_pose=previous_tcp, previous_final_model_object_pose=previous_model,
            native_object_pose=native_pose, measured_model_object_pose=current_model,
            original_native_object_goal=goal, active_motion_native_object_goal=active_motion_goal,
            loaded_route_pending=route_pending,loaded_route=route_detail,mapped_model_object_goal=drive_goal,
            requested_tcp_pose=requested_tcp, provisional_command_q=chosen_q,
            provisional_full_FK_tcp_pose=chosen_tcp, provisional_model_object_pose=chosen_model,
            shared_SE3_fraction=ratio_used, complete_hold_reason=hold_reason, incoming_lead=old_lead,
            outgoing_lead=lead_detail, captured_control_lever_m=lever,
            numerical_position_tolerance_m=precision, numerical_orientation_tolerance_rad=rprecision,
            numerical_tolerance_source='original Stool insertion numerical p precision / original converted capture lever, bounded by original clearance IK R tolerance',
            numerical_full_FK_error=numerical_error, original_capture_changed=False,
            command_scope='provisional before uniform full guard and SDK; next fresh receipt is progress authority')
        return action

    def _stool_native_lateral_hold_pose(self, *, phase_key, task, robot_name,
                                         spec, current_pose, target_pose):
        """Invert an absolute native object-XY goal; keep the original hand Z/R.

        Only XY is an absolute object reference. The complete accepted hand Z
        and original phase orientation planner remain intact. Native/model bias
        is mapped once through the original captured EEF relation; neither that
        capture nor the physical wrist3/object fixed grasp is rewritten.
        """
        from .beam_assisted_servo import object_pose_from_tcp, model_command_for_native_pose
        contract = task._assisted_task_contract()
        offset = np.asarray(spec.get('offset'), float)
        if (contract.get('adapter') != 'stool_circular_ur5e_v1'
                or spec.get('name') != 'ur5e_retreat_vertical'
                or not spec.get('requires_held_object')
                or spec.get('offset_frame') != 'world' or offset.shape != (3,)
                or not np.all(np.isfinite(offset)) or np.any(offset[:2] != 0.) or offset[2] <= 0.
                or spec.get('beam_assisted_absolute_object_servo') or self._tcp_offset(spec) is not None):
            raise ValueError('stool native lateral hold requires its unoffset held world+Z retreat')
        name = self._object_name_from_spec(spec)
        hold = spec['fabrica_native_lateral_hold']
        bound = float(hold['max_lateral_step_m'])
        bias_lifts = {
            'fabrica_stool_circular_3': 'assemble_00_part_3_lift',
            'fabrica_stool_circular_7': 'assemble_01_part_7_lift',
            'fabrica_stool_circular_6': 'assemble_02_part_6_lift',
            'fabrica_stool_circular_4': 'assemble_03_part_4_lift',
            'fabrica_stool_circular_5': 'assemble_04_part_5_lift',
            'fabrica_stool_circular_1': 'assemble_05_part_1_lift',
            'fabrica_stool_circular_0': 'assemble_06_part_0_lift',
            'fabrica_stool_circular_8': 'assemble_07_part_8_lift',
        }
        bias_enabled = name in bias_lifts
        if bias_enabled and getattr(task, 'phase', None) != bias_lifts[name]:
            raise ValueError('Stool XY bias requires its exact original lift phase/object pair')
        bias_settings = hold.get('reference_bias')
        expected_schema = 'stool_native_object_xy_bias_v1' if bias_enabled else 'stool_native_object_xy_hold_v2'
        if bias_enabled:
            contact_ticks = contract.get('contact_stable_physics_steps')
            if type(contact_ticks) is not int or contact_ticks <= 0:
                raise ValueError('stool XY reference bias lacks its original native window')
            expected_bias = {'max_total_m': bound / 2., 'gain_per_native_tick': 1. / contact_ticks,
                'max_step_m': bound, 'numeric_source': 'half original Stool insertion position step cap; original contact stable native ticks reciprocal gain; original insertion step increment'}
            ik_position_tolerance, ik_orientation_tolerance = self._ik_solver_tolerances(spec)
            expected_ik_tolerance = max(min(bound * .05, 5e-4), 1e-5)
            if (bias_settings != expected_bias or spec.get('ik_position_tolerance') != expected_ik_tolerance
                    or ik_position_tolerance != expected_ik_tolerance
                    or ik_orientation_tolerance is None or not np.isfinite(ik_orientation_tolerance)
                    or ik_orientation_tolerance <= 0.):
                raise ValueError('stool XY bias lacks task-derived bounds and numerical IK fidelity')
        elif bias_settings is not None:
            raise ValueError('stool XY bias is restricted to its exact nonbase lift pairs')
        step = float(spec['cartesian_position_step'])
        # The original general Cartesian accumulator uses this measured-FK
        # TCP lead sphere. Only newly added increments may consume its budget.
        lookahead = .003
        if (hold.get('schema') != expected_schema
                or not np.isfinite(bound) or bound <= 0.
                or bound != contract['install_position_step_m']
                or not np.isfinite(step) or step <= 0.):
            raise ValueError('stool native lateral hold lacks its task-derived bound')
        stamp = task._beam_physics_stamp()
        if (stamp.get('valid') is not True or type(stamp.get('epoch')) is not int
                or type(stamp.get('index')) is not int):
            raise ValueError('stool native lateral hold lacks a native clock')
        attached = getattr(task, '_attachments', {}).get(name) or {}
        if (attached.get('mode') != 'fixed_joint' or attached.get('robot_name') != robot_name
                or not attached.get('joint_path') or attached.get('attach_step') is None):
            raise ValueError('stool native lateral hold lacks its captured fixed grasp')
        capture_p = np.asarray(attached.get('position'), float).copy()
        capture_q = np.asarray(attached.get('orientation'), float).copy()
        if (capture_p.shape != (3,) or capture_q.shape != (4,)
                or not np.all(np.isfinite(capture_p)) or not np.all(np.isfinite(capture_q))
                or not np.isfinite(np.linalg.norm(capture_q)) or np.linalg.norm(capture_q) == 0.):
            raise ValueError('stool object XY lacks a finite original EEF capture')
        native = task._assisted_native_body_motion(name, stamp['epoch'])
        hand = task._get_robot_hand_rigid_body(robot_name)
        hand_path = str(task.robots[robot_name].config.prim_path) + '/wrist_3_link'
        if hand is None or str(hand.unwrap().prim_path) != hand_path:
            raise ValueError('stool native lateral hold lacks the native wrist_3_link')
        hand_position, hand_orientation = hand.get_pose()
        position = np.asarray(native.get('position'), float)
        orientation = np.asarray(native.get('orientation'), float)
        hand_position = np.asarray(hand_position, float)
        hand_orientation = np.asarray(hand_orientation, float)
        if (native.get('motion_valid') is not True or native.get('physics_handle_valid') is not True
                or not native.get('body_path') or native.get('motion_view_id') is None
                or position.shape != (3,) or orientation.shape != (4,)
                or hand_position.shape != (3,) or hand_orientation.shape != (4,)
                or not all(np.all(np.isfinite(v)) for v in
                           (position, orientation, hand_position, hand_orientation))
                or task._beam_physics_stamp() != stamp):
            raise ValueError('stool native lateral hold has an invalid or stale native sample')
        identity = (stamp['epoch'], attached['joint_path'], attached['attach_step'],
                    native['body_path'], native['motion_view_id'], str(hand.unwrap().prim_path))
        state = self._completion_state.setdefault(phase_key, {}).setdefault('stool_native_xy_hold', {})
        if state and state['identity'] != identity:
            raise ValueError('stool native lateral hold grasp/body identity changed')
        if state and (not np.array_equal(capture_p, state['eef_capture_position'])
                      or not np.array_equal(capture_q, state['eef_capture_orientation'])):
            raise ValueError('stool object XY original EEF capture changed within its phase')
        if not state:
            state.update(identity=identity, entry_object_position=position.copy(),
                         entry_hand_position=hand_position.copy(), entry_hand_orientation=hand_orientation.copy(),
                         eef_capture_position=capture_p.copy(), eef_capture_orientation=capture_q.copy())
        receipt = getattr(task, '_fabrica_final_gripper_commands', {}).get(robot_name) or {}
        published_stamp = receipt.get('physics_stamp') or {}
        robot = task.robots[robot_name]
        previous_q = np.asarray(getattr(task, '_assisted_published_q', {}).get(robot_name), float)
        if (published_stamp.get('valid') is not True
                or published_stamp.get('epoch') != stamp['epoch']
                or type(published_stamp.get('index')) is not int
                or stamp['index'] - published_stamp['index'] not in (0, 1)
                or type(receipt.get('expected_sdk_batch_sequence')) is not int
                or receipt['expected_sdk_batch_sequence'] != getattr(robot, '_action_batch_sequence', None)
                or 'arm_joint_controller' not in getattr(robot, 'last_action_controller_names', ())
                or previous_q.shape != (6,) or not np.all(np.isfinite(previous_q))):
            raise ValueError('stool native lateral hold lacks an exact final SDK arm publication')
        if 'stamp' in state:
            if stamp['index'] < state['stamp']['index']:
                raise ValueError('stool native lateral hold clock moved backwards')
            if stamp['index'] == state['stamp']['index']:
                if (stamp != state['stamp'] or not np.array_equal(position, state['native_position'])
                        or not np.array_equal(orientation, state['native_orientation'])
                        or not np.array_equal(hand_position, state['native_hand_position'])
                        or not np.array_equal(hand_orientation, state['native_hand_orientation'])):
                    raise ValueError('stool native lateral hold sample changed within one tick')
                return {k: v.copy() for k, v in state['request'].items()}
        accepted = self._grasp_command_fk_pose(task=task, robot_name=robot_name, spec=spec, command_q=previous_q)
        if accepted is None:
            raise ValueError('stool native lateral hold lacks final SDK FK')
        base = np.asarray(accepted['position'], float).copy()
        measured = np.asarray(current_pose['position'], float)
        goal = np.asarray(target_pose['position'], float)
        if any(v.shape != (3,) or not np.all(np.isfinite(v)) for v in (base, measured, goal)):
            raise ValueError('stool native lateral hold has invalid Cartesian inputs')
        orientation_step = float(spec.get('cartesian_orientation_step', .01))
        original_orientation_command = self._cartesian_servo_target_pose(
            current_pose=current_pose, target_pose=target_pose,
            max_position_step=0., max_orientation_step=orientation_step)
        convert = getattr(task, '_physical_relative_pose_to_control_frame', None)
        if not callable(convert):
            raise ValueError('stool object XY lacks its physical EEF/control-frame conversion')
        try:
            relative_p, relative_q = convert(robot_name, capture_p.copy(), capture_q.copy())
            relative_p, relative_q = np.asarray(relative_p, float), np.asarray(relative_q, float)
            if (relative_p.shape != (3,) or relative_q.shape != (4,)
                    or not np.all(np.isfinite(relative_p)) or not np.all(np.isfinite(relative_q))
                    or not np.isfinite(np.linalg.norm(relative_q)) or np.linalg.norm(relative_q) == 0.):
                raise ValueError('invalid converted relative pose')
        except Exception as exc:
            raise ValueError('stool object XY physical/control conversion failed') from exc
        native_pose = {'position': position, 'orientation': orientation}
        model_object = object_pose_from_tcp(current_pose, relative_p, relative_q)
        reference_bias = np.zeros(2)
        bias_detail = None
        if bias_enabled:
            reference_bias = np.asarray(state.get('issued_reference_bias_xy', np.zeros(2)), float).copy()
            pending = state.get('reference_bias_pending')
            may_accumulate = pending is None
            bias_detail = dict(pending_present=pending is not None, committed_previous=False,
                commit_scope='final SDK full-FK command fidelity only; native object correction unproven',
                ik_position_tolerance_m=ik_position_tolerance,
                ik_orientation_tolerance_rad=ik_orientation_tolerance,
                tolerance_source='original generic IK formula evaluated at original Stool insertion step',
                pending_full_position_error_m=None, pending_desired_xy_error_m=None,
                pending_orientation_error_rad=None, pending_xy_unclipped=None)
            if pending is not None:
                if (pending['issue_stamp'] != published_stamp
                        or pending['expected_sdk_batch_sequence'] != receipt['expected_sdk_batch_sequence']):
                    raise ValueError('stool XY reference bias pending SDK ownership changed')
                dp, da = pose_error(base, accepted['orientation'],
                                    pending['request']['position'], pending['request']['orientation'])
                xy_error = float(np.linalg.norm(base[:2] - pending['desired_tcp_xy']))
                may_accumulate = bool(pending['xy_unclipped'] and dp <= ik_position_tolerance
                    and xy_error <= ik_position_tolerance and da <= ik_orientation_tolerance)
                bias_detail.update(pending_full_position_error_m=dp,
                    pending_desired_xy_error_m=xy_error, pending_orientation_error_rad=da,
                    pending_xy_unclipped=pending['xy_unclipped'], committed_previous=may_accumulate)
                if may_accumulate:
                    state['committed_reference_bias_xy'] = reference_bias.copy()
            if may_accumulate:
                bias_increment = bias_settings['gain_per_native_tick'] * (state['entry_object_position'][:2] - position[:2])
                increment_norm = float(np.linalg.norm(bias_increment))
                if increment_norm > bias_settings['max_step_m']:
                    bias_increment *= bias_settings['max_step_m'] / increment_norm
                reference_bias += bias_increment
                bias_norm = float(np.linalg.norm(reference_bias))
                if bias_norm > bias_settings['max_total_m']:
                    reference_bias *= bias_settings['max_total_m'] / bias_norm
            bias_detail.update(issued_reference_bias_xy=reference_bias.copy(),
                committed_reference_bias_xy=np.asarray(state.get('committed_reference_bias_xy', np.zeros(2))).copy(),
                may_accumulate=may_accumulate, max_total_m=bias_settings['max_total_m'])
        desired_native = {'position': position.copy(), 'orientation': orientation.copy()}
        desired_native['position'][:2] = state['entry_object_position'][:2] + reference_bias
        desired_model = model_command_for_native_pose(native_pose, model_object, desired_native)
        desired_tcp_xy = (desired_model['position']
            - quat_rotate(original_orientation_command['orientation'], relative_p))[:2]
        error = state['entry_object_position'][:2] - position[:2]
        correction = desired_tcp_xy - base[:2]
        size = float(np.linalg.norm(correction))
        if size > bound:
            correction *= bound / size
        increment = np.zeros(3)
        lead = base - measured
        if np.linalg.norm(lead) < lookahead:
            # Preserve the complete old XYZ even when no new budget remains.
            # Reserve feasible XY first; the distant Z goal cannot dilute it.
            aa = float(np.dot(correction, correction))
            bb = float(np.dot(lead[:2], correction))
            cc = float(np.dot(lead, lead) - lookahead**2)
            ratio = min(1., max(0., (-bb + math.sqrt(max(0., bb*bb-aa*cc))) / aa)) if aa else 0.
            increment[:2] = ratio * correction
            xy_lead = lead[:2] + increment[:2]
            z_budget = max(0., math.sqrt(max(0., lookahead**2 - float(xy_lead @ xy_lead))) - lead[2])
            increment[2] = min(step, max(0., goal[2]-base[2]), z_budget)
        request = {'position': base + increment,
                   'orientation': original_orientation_command['orientation'].copy()}
        if bias_enabled:
            # Structural admission proves the original XY increment/lead
            # construction did not truncate this desired biased reference.
            xy_unclipped = bool(size == 0. or (size <= bound
                and np.linalg.norm(lead) < lookahead and ratio == 1.))
            state['issued_reference_bias_xy'] = reference_bias.copy()
            state['reference_bias_pending'] = dict(issue_stamp=dict(stamp),
                expected_sdk_batch_sequence=robot._action_batch_sequence + 1,
                desired_tcp_xy=desired_tcp_xy.copy(), xy_unclipped=xy_unclipped,
                request={k: v.copy() for k, v in request.items()})
            bias_detail['current_xy_unclipped'] = xy_unclipped
        if task._beam_physics_stamp() != stamp:
            raise ValueError('stool native lateral hold clock changed during command construction')
        state.update(stamp=dict(stamp), native_position=position.copy(), native_orientation=orientation.copy(),
                     native_hand_position=hand_position.copy(), native_hand_orientation=hand_orientation.copy(),
                     request={k: v.copy() for k, v in request.items()})
        task._assisted_event('stool_native_lateral_hold', robot=robot_name, object=name,
            physics_stamp=dict(stamp), entry_native_object_position=state['entry_object_position'],
            entry_native_hand_position=state['entry_hand_position'], native_object_position=position,
            native_hand_position=hand_position, final_sdk_q=previous_q, final_sdk_receipt=receipt,
            previous_final_pose=accepted, measured_fk_tcp_pose=current_pose,
            lateral_error_m=error, requested_lateral_correction_m=correction,
            added_increment_m=increment, max_lateral_step_m=bound,
            original_cartesian_position_step_m=step, measured_fk_lookahead_m=lookahead,
            command_pose=request, captured_grasp_reference_changed=False,
            orientation_source='original_measured_fk_to_phase_locked_goal',
            phase_goal_orientation=target_pose['orientation'],
            orientation_step_limit_rad=orientation_step,
            lateral_control_schema=expected_schema,
            reference_bias_qualification=bias_detail,
            goal_scope='absolute_native_object_XY_only; hand_Z_R_and_completion_original',
            native_xy_goal_world=state['entry_object_position'][:2],
            issued_biased_native_xy_goal_world=desired_native['position'][:2],
            desired_model_object_xy_world=desired_model['position'][:2],
            desired_tcp_xy_world=desired_tcp_xy,
            converted_object_in_control_position=relative_p,
            converted_object_in_control_orientation=relative_q,
            original_eef_capture_position=capture_p,
            original_eef_capture_orientation=capture_q)
        return request

    def _cartesian_command_servo_target_pose(
        self,
        *,
        phase_key,
        current_pose: dict,
        target_pose: dict,
        max_position_step: float,
        max_orientation_step: float,
        spec: dict,
    ) -> dict:
        command_pose = self._cartesian_servo_target_pose(
            current_pose=current_pose,
            target_pose=target_pose,
            max_position_step=max_position_step,
            max_orientation_step=max_orientation_step,
        )
        if (spec.get('beam_assisted') and spec.get('requires_held_object')
                and max_position_step > 0.0):
            # Preserve only this phase's accepted Cartesian progress, bounded
            # against the live TCP. Restarting a tiny step from the sagging TCP
            # can command less than the gravity compensation error indefinitely.
            command_pose['position'] = self._accumulated_cartesian_command_position(
                phase_key=phase_key,
                current_position=np.asarray(current_pose['position'], float),
                one_step_position=np.asarray(command_pose['position'], float),
                gate_position=np.asarray(target_pose['position'], float),
                enabled=True, lookahead=.003, allow_gate_overdrive=False,
                accumulation_step=max_position_step,
            )
        if not bool(spec.get('cartesian_orientation_command_warm_start', False)) or max_orientation_step <= 0.0:
            return command_pose

        previous_orientation = self._cartesian_command_orientations.get(phase_key)
        if previous_orientation is None:
            previous_orientation = normalize_quat(current_pose['orientation'])
        orientation_reference_pose = {
            'position': np.zeros(3, dtype=float),
            'orientation': normalize_quat(previous_orientation),
        }
        orientation_target_pose = {
            'position': np.zeros(3, dtype=float),
            'orientation': normalize_quat(target_pose['orientation']),
        }
        accumulated = self._cartesian_servo_target_pose(
            current_pose=orientation_reference_pose,
            target_pose=orientation_target_pose,
            max_position_step=0.0,
            max_orientation_step=max_orientation_step,
        )
        lookahead = max(
            float(
                spec.get(
                    'cartesian_orientation_command_lookahead',
                    max_orientation_step * 4.0,
                )
            ),
            max_orientation_step,
        )
        bounded = self._cartesian_servo_target_pose(
            current_pose={
                'position': np.zeros(3, dtype=float),
                'orientation': normalize_quat(current_pose['orientation']),
            },
            target_pose=accumulated,
            max_position_step=0.0,
            max_orientation_step=lookahead,
        )
        command_pose['orientation'] = normalize_quat(bounded['orientation'])
        return command_pose

    def _accumulated_cartesian_command_position(
        self,
        *,
        phase_key,
        current_position: np.ndarray,
        one_step_position: np.ndarray,
        gate_position: np.ndarray,
        enabled: bool,
        lookahead: float,
        allow_gate_overdrive: bool = False,
        accumulation_step: float | None = None,
    ) -> np.ndarray:
        current_position = np.asarray(current_position, dtype=float)
        one_step_position = np.asarray(one_step_position, dtype=float)
        gate_position = np.asarray(gate_position, dtype=float)
        if not enabled:
            return one_step_position
        if (
            current_position.shape != (3,)
            or one_step_position.shape != (3,)
            or gate_position.shape != (3,)
            or not np.all(np.isfinite(current_position))
            or not np.all(np.isfinite(one_step_position))
            or not np.all(np.isfinite(gate_position))
            or not np.isfinite(lookahead)
            or lookahead <= 0.0
            or (accumulation_step is not None and (not np.isfinite(accumulation_step) or accumulation_step <= 0.0))
        ):
            raise ValueError(
                'Cartesian position command accumulation requires finite 3D '
                'positions and a finite positive lookahead.'
            )

        increment = one_step_position - current_position
        previous_position = self._cartesian_command_positions.get(phase_key)
        if previous_position is None:
            candidate_position = one_step_position
        else:
            previous_position = np.asarray(previous_position, dtype=float)
            if previous_position.shape != (3,) or not np.all(np.isfinite(previous_position)):
                previous_position = current_position
            increment_distance = float(np.linalg.norm(increment))
            if accumulation_step is not None and increment_distance > accumulation_step:
                increment = increment * (accumulation_step / increment_distance)
            candidate_position = previous_position + increment

        gate_delta = gate_position - current_position
        candidate_delta = candidate_position - current_position
        gate_distance = float(np.linalg.norm(gate_delta))
        candidate_distance = float(np.linalg.norm(candidate_delta))
        if gate_distance <= 1e-12 and not allow_gate_overdrive:
            candidate_position = gate_position
        elif not allow_gate_overdrive:
            gate_direction = gate_delta / gate_distance
            candidate_progress = float(np.dot(candidate_delta, gate_direction))
            if candidate_progress >= gate_distance:
                candidate_position = gate_position

        candidate_delta = candidate_position - current_position
        candidate_distance = float(np.linalg.norm(candidate_delta))
        if candidate_distance > lookahead:
            candidate_position = current_position + candidate_delta * (lookahead / candidate_distance)
        return np.asarray(candidate_position, dtype=float)

    def _remember_cartesian_command_position(
        self,
        *,
        phase_key,
        command_target_pose: dict,
    ) -> None:
        position = command_target_pose.get('position')
        if position is None:
            return
        position = np.asarray(position, dtype=float)
        if position.shape == (3,) and np.all(np.isfinite(position)):
            self._cartesian_command_positions[phase_key] = position.copy()

    def _remember_cartesian_command_orientation(
        self,
        *,
        phase_key,
        command_target_pose: dict,
    ) -> None:
        orientation = command_target_pose.get('orientation')
        if orientation is None:
            return
        try:
            orientation = normalize_quat(orientation)
        except Exception:
            return
        if orientation.shape == (4,) and np.all(np.isfinite(orientation)):
            self._cartesian_command_orientations[phase_key] = orientation.copy()

    def _target_pose(  # noqa: C901
        self,
        *,
        phase_key=None,
        task,
        robot_name: str,
        spec: dict,
        tracked_robots: dict,
        tracked_objects: dict,
    ):
        if bool(spec.get('relative_to_current_tcp', False)):
            raw_current_pose = self._current_robot_pose(
                task=task,
                robot_name=robot_name,
                tracked_robots=tracked_robots,
            )
            current_pose = self._current_tcp_pose(current_pose=raw_current_pose, spec=spec)
            if spec.get('inherit_grasp_drive_target'):
                saved = getattr(task, '_ur5e_contact_hold_commands', {}).get(robot_name)
                if saved is None or saved.get('object') != self._object_name_from_spec(spec):
                    return None
                current_pose = saved['pose']
            if current_pose is None:
                return None
            offset = np.asarray(spec.get('offset', [0.0, 0.0, 0.0]), dtype=float)
            offset_frame = str(spec.get('offset_frame', 'world')).lower()
            if spec.get('offset_reference_object'):
                reference = self._object_pose(task=task, object_name=spec['offset_reference_object'],
                                              tracked_objects=tracked_objects)
                if reference is None:
                    return None
                offset = quat_rotate(reference['orientation'], offset)
            elif offset_frame in {'target', 'eef', 'tcp', 'gripper'}:
                offset = quat_rotate(current_pose['orientation'], offset)
            target_position = np.asarray(current_pose['position'], dtype=float) + offset
            minimum_planar_radius = spec.get('workspace_minimum_planar_radius')
            if minimum_planar_radius is not None:
                workspace_center = spec.get('workspace_center')
                if workspace_center is None:
                    return None
                try:
                    target_position = self._bound_relative_target_to_planar_workspace(
                        current_position=current_pose['position'],
                        target_position=target_position,
                        workspace_center=workspace_center,
                        minimum_planar_radius=float(minimum_planar_radius),
                    )
                except (TypeError, ValueError):
                    return None
            return {
                'position': target_position,
                'orientation': normalize_quat(current_pose['orientation']),
            }

        grasp_relative_pose = self._configured_grasp_relative_pose(spec)
        if grasp_relative_pose is not None:
            object_name = self._object_name_from_spec(spec)
            if object_name is None:
                return None
            object_pose = self._object_pose(
                task=task,
                object_name=object_name,
                tracked_objects=tracked_objects,
            )
            if object_pose is None:
                return None
            relative_position, relative_orientation = grasp_relative_pose
            orientation = normalize_quat(
                quat_multiply(
                    object_pose['orientation'],
                    self._quat_conjugate(relative_orientation),
                )
            )
            position = np.asarray(object_pose['position'], dtype=float) - quat_rotate(
                orientation,
                relative_position,
            )
            if bool(spec.get('align_grasp_axis_to_world_down', False)):
                pad_distance = float(spec.get('grasp_pad_distance', 0.143))
                reach = float(spec.get('grasp_pad_reach', pad_distance))
                finger_axis = spec.get('align_finger_to_object_axis')
                finger_direction = None
                if finger_axis is not None:
                    finger_direction = quat_rotate(
                        object_pose['orientation'],
                        np.asarray(finger_axis, dtype=float),
                    )
                    max_tilt = spec.get('align_finger_max_tilt_rad')
                    if max_tilt is not None:
                        finger_direction = _limit_finger_tilt(
                            np.asarray(finger_direction, dtype=float),
                            float(max_tilt),
                        )
                position, orientation = _vertical_pad_pose(
                    position,
                    orientation,
                    pad_distance,
                    reach,
                    finger_direction,
                )
            grasp_offset = np.asarray(spec.get('grasp_object_frame_offset', [0.0, 0.0, 0.0]), dtype=float)
            if grasp_offset.shape != (3,) or not np.all(np.isfinite(grasp_offset)):
                return None
            position = position + quat_rotate(object_pose['orientation'], grasp_offset)
            approach_clearance = float(spec.get('approach_clearance', 0.0))
            if approach_clearance < 0.0 or not np.isfinite(approach_clearance):
                return None
            relative_distance = float(np.linalg.norm(relative_position))
            if approach_clearance > 0.0 and relative_distance > 1e-8:
                retreat_in_target = -relative_position * (approach_clearance / relative_distance)
                position = position + quat_rotate(orientation, retreat_in_target)
            approach_offset = np.asarray(spec.get('offset', [0.0, 0.0, 0.0]), dtype=float)
            offset_frame = str(spec.get('offset_frame', 'world')).lower()
            if offset_frame in {'object', 'local', 'part'}:
                position = position + quat_rotate(object_pose['orientation'], approach_offset)
            elif offset_frame in {'target', 'eef', 'tcp', 'gripper'}:
                position = position + quat_rotate(orientation, approach_offset)
            else:
                position = position + approach_offset
            return {
                'position': np.asarray(position, dtype=float),
                'orientation': orientation,
            }

        object_pose = None
        direct_target_pose = None
        target_object_pose = self._target_object_pose(task=task, spec=spec)
        target_object_position = None if target_object_pose is None else target_object_pose['position']
        if target_object_position is not None:
            object_name = self._object_name_from_spec(spec)
            if object_name is None:
                return None
            object_pose = self._object_pose(
                task=task,
                object_name=object_name,
                tracked_objects=tracked_objects,
            )
            if object_pose is None:
                return None
        elif spec.get('target_pose_target') is not None or spec.get('target_pose') is not None:
            target_name = spec.get('target_pose_target') or spec.get('target_pose')
            direct_target_pose = self._target_pose_by_name(
                task=task,
                target_name=None if target_name is None else str(target_name),
            )
            if direct_target_pose is None:
                return None
            position = direct_target_pose['position']
        elif spec.get('target_position') is not None:
            position = np.asarray(spec['target_position'], dtype=float)
        else:
            object_name = self._object_name_from_spec(spec)
            if object_name is None:
                return None
            object_pose = self._object_pose(
                task=task,
                object_name=object_name,
                tracked_objects=tracked_objects,
            )
            if object_pose is None:
                return None
            offset = np.asarray(spec.get('offset', [0.0, 0.0, 0.0]), dtype=float)
            if str(spec.get('offset_frame', 'world')).lower() in {'object', 'local', 'part'}:
                position, _ = compose_pose(
                    base_position=object_pose['position'],
                    base_orientation=object_pose['orientation'],
                    local_position=offset,
                    local_orientation=[1.0, 0.0, 0.0, 0.0],
                )
            else:
                position = object_pose['position'] + offset

        has_explicit_orientation = any(
            spec.get(name) is not None for name in ('target_orientation', 'orientation', 'orientation_euler')
        )
        derive_tcp_orientation = bool(
            target_object_position is not None and self._derive_tcp_orientation_from_target_object(spec=spec)
        )
        relative_pose = None
        if derive_tcp_orientation:
            relative_pose = self._object_tcp_relative_pose(
                phase_key=phase_key,
                task=task,
                robot_name=robot_name,
                object_name=object_name,
                spec=spec,
                tracked_robots=tracked_robots,
                object_pose=object_pose,
                tracked_objects=tracked_objects,
            )
            if relative_pose is None or target_object_pose.get('orientation') is None:
                return None
            _, relative_orientation = relative_pose
            orientation = normalize_quat(
                quat_multiply(
                    target_object_pose['orientation'],
                    self._quat_conjugate(relative_orientation),
                )
            )
        elif direct_target_pose is not None and not has_explicit_orientation:
            orientation = direct_target_pose['orientation']
        else:
            orientation = self._target_orientation(
                task=task,
                robot_name=robot_name,
                spec=spec,
                tracked_robots=tracked_robots,
                object_pose=object_pose,
            )
        if orientation is None:
            return None
        if target_object_position is not None:
            if relative_pose is None:
                relative_pose = self._object_tcp_relative_pose(
                    phase_key=phase_key,
                    task=task,
                    robot_name=robot_name,
                    object_name=object_name,
                    spec=spec,
                    tracked_robots=tracked_robots,
                    object_pose=object_pose,
                    tracked_objects=tracked_objects,
                )
            if relative_pose is None:
                return None
            relative_position, _ = relative_pose
            position = np.asarray(target_object_position, dtype=float) - quat_rotate(
                normalize_quat(orientation),
                relative_position,
            )
        return {
            'position': np.asarray(position, dtype=float),
            'orientation': normalize_quat(orientation),
        }

    @staticmethod
    def _bound_relative_target_to_planar_workspace(
        *,
        current_position,
        target_position,
        workspace_center,
        minimum_planar_radius: float,
    ) -> np.ndarray:
        """Stop an inward Cartesian segment at the workspace's inner radial boundary."""

        current = np.asarray(current_position, dtype=float)
        target = np.asarray(target_position, dtype=float)
        center = np.asarray(workspace_center, dtype=float)
        if current.shape != (3,) or target.shape != (3,) or center.shape != (3,):
            raise ValueError('Workspace-bounded Cartesian positions must be 3-vectors.')
        if not (
            np.all(np.isfinite(current))
            and np.all(np.isfinite(target))
            and np.all(np.isfinite(center))
            and np.isfinite(minimum_planar_radius)
            and minimum_planar_radius > 0.0
        ):
            raise ValueError('Workspace-bounded Cartesian positions must be finite.')

        current_radial = current[:2] - center[:2]
        target_radial = target[:2] - center[:2]
        radius = float(minimum_planar_radius)
        if float(np.linalg.norm(target_radial)) >= radius:
            return target.copy()

        result = target.copy()
        current_radius = float(np.linalg.norm(current_radial))
        if current_radius <= radius:
            result[:2] = current[:2]
            return result

        planar_delta = target[:2] - current[:2]
        quadratic_a = float(np.dot(planar_delta, planar_delta))
        quadratic_b = 2.0 * float(np.dot(current_radial, planar_delta))
        quadratic_c = float(np.dot(current_radial, current_radial) - radius * radius)
        discriminant = quadratic_b * quadratic_b - 4.0 * quadratic_a * quadratic_c
        if quadratic_a <= 1e-16 or discriminant < 0.0:
            result[:2] = current[:2]
            return result

        square_root = math.sqrt(max(discriminant, 0.0))
        intersections = sorted(
            (
                (-quadratic_b - square_root) / (2.0 * quadratic_a),
                (-quadratic_b + square_root) / (2.0 * quadratic_a),
            )
        )
        segment_ratio = next(
            (value for value in intersections if 0.0 <= value <= 1.0),
            None,
        )
        if segment_ratio is None:
            result[:2] = current[:2]
            return result
        result[:2] = current[:2] + float(segment_ratio) * planar_delta
        return result

    @staticmethod
    def _configured_grasp_relative_pose(spec: dict) -> tuple[np.ndarray, np.ndarray] | None:
        position = spec.get(
            'grasp_relative_position',
            spec.get('object_in_tcp_position', spec.get('object_in_gripper_position')),
        )
        orientation = spec.get(
            'grasp_relative_orientation',
            spec.get('object_in_tcp_orientation', spec.get('object_in_gripper_orientation')),
        )
        if position is None and orientation is None:
            return None
        if position is None or orientation is None:
            return None
        relative_position = np.asarray(position, dtype=float)
        relative_orientation = normalize_quat(orientation)
        if relative_position.shape != (3,) or not np.all(np.isfinite(relative_position)):
            return None
        if relative_orientation.shape != (4,) or not np.all(np.isfinite(relative_orientation)):
            return None
        return relative_position, relative_orientation

    @staticmethod
    def _quat_conjugate(quat) -> np.ndarray:
        quat = normalize_quat(quat)
        return np.array([quat[0], -quat[1], -quat[2], -quat[3]], dtype=float)

    @staticmethod
    def _target_pose_by_name(*, task, target_name: str | None) -> dict | None:
        if not target_name:
            return None
        target_poses = getattr(task, 'target_poses', None)
        if not isinstance(target_poses, dict) or target_name not in target_poses:
            return None
        target_pose = target_poses[target_name]
        if target_pose.get('position') is None:
            return None
        return {
            'position': np.asarray(target_pose['position'], dtype=float),
            'orientation': normalize_quat(target_pose.get('orientation', [1.0, 0.0, 0.0, 0.0])),
        }

    def _target_object_pose(self, *, task, spec: dict) -> dict | None:
        if spec.get('target_object_position') is not None:
            position = np.asarray(spec['target_object_position'], dtype=float)
            orientation = self._target_object_orientation_from_spec(task=task, spec=spec)
        else:
            target_name = spec.get('target_object_target') or spec.get('target_object') or spec.get('object_target')
            target_pose = self._target_pose_by_name(
                task=task,
                target_name=None if target_name is None else str(target_name),
            )
            if target_pose is None:
                return None
            position = target_pose['position']
            orientation = target_pose['orientation']
            override_orientation = self._target_object_orientation_from_spec(task=task, spec=spec)
            if override_orientation is not None:
                orientation = override_orientation
        offset = spec.get('target_object_offset')
        if offset is not None:
            offset = np.asarray(offset, dtype=float)
            offset_frame = str(spec.get('target_object_offset_frame', 'world')).lower()
            if offset_frame in {'target', 'local', 'object_target'}:
                if orientation is None:
                    return None
                position = position + quat_rotate(orientation, offset)
            else:
                position = position + offset
        return {
            'position': np.asarray(position, dtype=float),
            'orientation': None if orientation is None else normalize_quat(orientation),
        }

    @staticmethod
    def _target_object_orientation_from_spec(*, task, spec: dict) -> np.ndarray | None:
        if spec.get('target_object_orientation') is not None:
            return normalize_quat(spec['target_object_orientation'])
        if spec.get('target_object_orientation_euler') is not None:
            return euler_xyz_to_quat(spec['target_object_orientation_euler'])
        target_name = spec.get('target_object_orientation_target') or spec.get('object_orientation_target')
        if target_name is None:
            return None
        target_pose = UR5eAssemblyAtomicSkillAdapter._target_pose_by_name(
            task=task,
            target_name=str(target_name),
        )
        if target_pose is None:
            return None
        return normalize_quat(target_pose['orientation'])

    def _target_object_position(self, *, task, spec: dict) -> np.ndarray | None:
        target_pose = self._target_object_pose(task=task, spec=spec)
        if target_pose is None:
            return None
        return np.asarray(target_pose['position'], dtype=float)

    def _object_tcp_relative_position(
        self,
        *,
        phase_key,
        task,
        robot_name: str,
        object_name: str,
        spec: dict,
        tracked_robots: dict,
        object_pose: dict,
    ) -> np.ndarray | None:
        relative_pose = self._object_tcp_relative_pose(
            phase_key=phase_key,
            task=task,
            robot_name=robot_name,
            object_name=object_name,
            spec=spec,
            tracked_robots=tracked_robots,
            object_pose=object_pose,
        )
        if relative_pose is None:
            return None
        return relative_pose[0].copy()

    def _object_tcp_relative_pose(
        self,
        *,
        phase_key,
        task,
        robot_name: str,
        object_name: str,
        spec: dict,
        tracked_robots: dict,
        object_pose: dict,
        tracked_objects: dict | None = None,
    ) -> tuple[np.ndarray, np.ndarray] | None:
        cache = getattr(task, '_ur5e_plumbers_object_tcp_relative_poses', None)
        if not isinstance(cache, dict):
            cache = {}
            setattr(task, '_ur5e_plumbers_object_tcp_relative_poses', cache)
        cache_key = (str(robot_name), str(object_name))
        tracked_objects = tracked_objects or {}
        object_state = tracked_objects.get(object_name, {})
        attachment = object_state.get('attachment') or {}
        attachment_robot = attachment.get('robot_name')
        if attachment_robot is None:
            attachment_robot = object_state.get('attached_to')
        attachment_mode = str(attachment.get('mode', '')).strip().lower()
        attachment_identity = None
        if attachment_robot == robot_name and attachment_mode:
            attachment_identity = (
                str(attachment_robot),
                attachment_mode,
                attachment.get('attach_step'),
                attachment.get('joint_path'),
            )

        if attachment_identity is not None and attachment_mode == 'fixed_joint' and self._tcp_offset(spec) is None:
            try:
                attachment_position = np.asarray(attachment['position'], dtype=float)
                attachment_orientation = normalize_quat(attachment['orientation'])
            except (KeyError, TypeError, ValueError):
                attachment_position = None
                attachment_orientation = None
            if (
                attachment_position is not None
                and attachment_position.shape == (3,)
                and attachment_orientation is not None
                and attachment_orientation.shape == (4,)
                and np.all(np.isfinite(attachment_position))
                and np.all(np.isfinite(attachment_orientation))
            ):
                convert_relative_pose = getattr(
                    task,
                    '_physical_relative_pose_to_control_frame',
                    None,
                )
                if callable(convert_relative_pose):
                    try:
                        attachment_position, attachment_orientation = convert_relative_pose(
                            robot_name,
                            attachment_position,
                            attachment_orientation,
                        )
                        attachment_position = np.asarray(attachment_position, dtype=float)
                        attachment_orientation = normalize_quat(attachment_orientation)
                    except Exception:
                        return None
                cache[cache_key] = {
                    'position': attachment_position.copy(),
                    'orientation': attachment_orientation.copy(),
                    'attachment_identity': attachment_identity,
                    'source': 'observed_attachment_control_frame',
                }
                return (
                    attachment_position.copy(),
                    attachment_orientation.copy(),
                )

        cached = cache.get(cache_key)
        if cached is not None:
            if cached.get('attachment_identity') != attachment_identity:
                cache.pop(cache_key, None)
                cached = None
        if cached is not None:
            try:
                cached_position = np.asarray(cached['position'], dtype=float)
                cached_orientation = normalize_quat(cached['orientation'])
                if (
                    cached_position.shape == (3,)
                    and cached_orientation.shape == (4,)
                    and np.all(np.isfinite(cached_position))
                    and np.all(np.isfinite(cached_orientation))
                ):
                    return cached_position.copy(), cached_orientation.copy()
            except Exception:
                pass

        raw_current_pose = self._current_robot_pose(task=task, robot_name=robot_name, tracked_robots=tracked_robots)
        current_tcp_pose = self._current_tcp_pose(current_pose=raw_current_pose, spec=spec)
        if current_tcp_pose is None:
            return None
        relative_world = np.asarray(object_pose['position'], dtype=float) - np.asarray(
            current_tcp_pose['position'],
            dtype=float,
        )
        relative_tcp = quat_rotate(
            self._quat_conjugate(current_tcp_pose['orientation']),
            relative_world,
        )
        if relative_tcp.shape != (3,) or not np.all(np.isfinite(relative_tcp)):
            return None
        relative_orientation = normalize_quat(
            quat_multiply(
                self._quat_conjugate(current_tcp_pose['orientation']),
                object_pose['orientation'],
            )
        )
        if relative_orientation.shape != (4,) or not np.all(np.isfinite(relative_orientation)):
            return None
        cache[cache_key] = {
            'position': relative_tcp.copy(),
            'orientation': relative_orientation.copy(),
            'attachment_identity': attachment_identity,
            'source': 'observed_tcp_pose',
        }
        if self._debug_grasp_enabled():
            print(
                '[ur5e-grasp-debug] '
                f'captured_object_tcp_relative robot={robot_name} object={object_name} '
                f'phase_key={phase_key} relative_tcp={relative_tcp.tolist()} '
                f'relative_orientation={relative_orientation.tolist()} '
                f"object_position={np.asarray(object_pose['position'], dtype=float).tolist()} "
                f"tcp_position={np.asarray(current_tcp_pose['position'], dtype=float).tolist()}",
                flush=True,
            )
        return relative_tcp.copy(), relative_orientation.copy()

    @staticmethod
    def _derive_tcp_orientation_from_target_object(*, spec: dict) -> bool:
        for name in (
            'derive_tcp_orientation_from_target_object',
            'target_orientation_from_object_target',
            'use_target_object_orientation',
        ):
            if name in spec:
                return bool(spec.get(name))
        return False

    def _locked_target_pose(self, *, phase_key, target_pose: dict, spec: dict) -> dict:
        lock_orientation = bool(spec.get('lock_target_orientation', True))
        lock_position = bool(spec.get('lock_target_position', False))
        if not lock_orientation and not lock_position:
            return target_pose

        locked = self._phase_locks.setdefault(phase_key, {})
        result = {
            'position': np.asarray(target_pose['position'], dtype=float).copy(),
            'orientation': normalize_quat(target_pose['orientation']).copy(),
        }
        if lock_position:
            if 'position' not in locked:
                locked['position'] = result['position'].copy()
            result['position'] = locked['position'].copy()
        if lock_orientation:
            if 'orientation' not in locked:
                locked['orientation'] = result['orientation'].copy()
            result['orientation'] = locked['orientation'].copy()
        return result

    @staticmethod
    def _close_gate_stability(*, state, spec, ready, current_pose):
        """Require a fixed-window stationary pose before starting closure."""
        already_started = 'close_started_step' in state
        stationary = bool(spec.get('close_gate_freeze_at_start')) and not already_started
        motion = {}
        if ready and stationary:
            anchor = state.get('close_settle_anchor')
            if anchor is not None:
                dp, dq = pose_error(
                    current_position=current_pose['position'], current_orientation=current_pose['orientation'],
                    target_position=anchor['position'], target_orientation=anchor['orientation'],
                )
                motion = {'position_drift': dp, 'orientation_drift': dq}
                if dp > float(spec.get('close_gate_stationary_position_tolerance', 0.0001)) or (
                    dq is not None and dq > float(spec.get('close_gate_stationary_orientation_tolerance', 0.002))
                ):
                    state['ready_steps'] = 0
                    state.pop('close_settle_anchor', None)
            if 'close_settle_anchor' not in state:
                state['close_settle_anchor'] = {key: np.asarray(current_pose[key], dtype=float).copy()
                                               for key in ('position', 'orientation')}
        if ready:
            state['ready_steps'] = int(state.get('ready_steps', 0)) + 1
        else:
            state['ready_steps'] = 0
            state.pop('close_settle_anchor', None)
            # A lost pose gate after freezing must fail, never reopen/restart.
            if not state.get('close_arm_frozen'):
                state.pop('close_started_step', None)
                state.pop('hold_q', None)
        required = max(int(spec.get('close_ready_stable_steps', 4)), 1)
        return bool(ready and state['ready_steps'] >= required), {
            'ready_steps': state['ready_steps'], 'required_ready_steps': required,
            'stationary_window': stationary, **motion,
        }

    def _close_pose_gate_action(
        self,
        *,
        phase_key,
        task,
        robot_name: str,
        spec: dict,
        tracked_robots: dict,
        tracked_objects: dict,
    ) -> tuple[bool, OrderedDict, dict[str, Any]]:
        state = self._close_gate_state.setdefault(phase_key, {'ready_steps': 0})
        gate_spec = dict(spec)
        for name in (
            'offset',
            'offset_frame',
            'target_orientation',
            'target_orientation_frame',
            'orientation',
            'orientation_frame',
            'orientation_euler',
            'ik_target_offset',
            'ik_target_offset_frame',
            'grasp_tcp_offset',
            'grasp_tcp_offset_frame',
            'tcp_offset',
            'tcp_offset_frame',
        ):
            override_name = f'close_gate_{name}'
            if override_name in spec:
                gate_spec[name] = spec[override_name]

        target_pose = self._target_pose(
            phase_key=phase_key,
            task=task,
            robot_name=robot_name,
            spec=gate_spec,
            tracked_robots=tracked_robots,
            tracked_objects=tracked_objects,
        )
        if target_pose is None:
            action = self._hold_joint_action(task=task, robot_name=robot_name)
            action[_GRIPPER_CONTROLLER] = [
                float(gate_spec.get('preclose_openness', gate_spec.get('open_openness', 1.0)))
            ]
            state['ready_steps'] = 0
            detail = {'reason': 'close_gate_target_pose_unavailable'}
            self._debug_close_gate_step(task=task, robot_name=robot_name, detail=detail)
            return False, action, detail
        current_pose = self._current_tcp_pose(
            current_pose=self._current_robot_pose(
                task=task,
                robot_name=robot_name,
                tracked_robots=tracked_robots,
            ),
            spec=gate_spec,
        )
        if current_pose is not None:
            state['close_tcp_position_world'] = np.asarray(current_pose['position'], dtype=float).copy()
        # Observe/cancel before constructing this tick's arm target. Cancelling
        # later in the close controller would still publish a stale IK command.
        recenter_stop = None
        if (current_pose is not None and spec.get('close_force_recenter_stop_on_bilateral')
                and state.get('force_recenter_pending') is not None):
            observation = self._grasp_contact_ready(
                task=task, robot_name=robot_name,
                spec={**spec, 'require_dual_finger_contact': spec.get('require_dual_finger_contact', True)},
            )
            state['close_contact_observation'] = (int(task.step_counter), observation)
            recenter_stop = self._stop_recenter_on_bilateral(
                state=state, spec=spec, metrics=observation[1].get('contact_metrics') or {},
                current_position=current_pose['position'],
            )
        regulated_contact = bool(spec.get('close_force_regulation', False) and state.get('contact_control_active'))
        frozen_arm = bool(state.get('close_arm_frozen'))
        if (frozen_arm or regulated_contact) and current_pose is not None:
            if 'contact_arm_anchor' not in state:
                state['contact_arm_anchor'] = {
                    'position': np.asarray(current_pose['position'], dtype=float).copy(),
                    'orientation': np.asarray(current_pose['orientation'], dtype=float).copy(),
                }
            anchor = state['contact_arm_anchor']
            target_pose = {key: value.copy() for key, value in anchor.items()}
            state['recenter_anchor_position_world'] = anchor['position'].copy()
            gate_spec = {**gate_spec, 'lock_target_position': False, 'lock_target_orientation': False}
        recenter_offset = np.asarray(
            state.get('recenter_offset_world', np.zeros(3, dtype=float)),
            dtype=float,
        )
        if recenter_offset.shape == (3,) and np.all(np.isfinite(recenter_offset)):
            target_position = np.asarray(target_pose['position'], dtype=float)
            if (
                bool(gate_spec.get('close_gate_recenter_single_finger_contact', False))
                and float(np.linalg.norm(recenter_offset)) > 1e-12
            ):
                if 'recenter_anchor_position_world' not in state:
                    state['recenter_anchor_position_world'] = (
                        target_position.copy()
                        if current_pose is None
                        else np.asarray(current_pose['position'], dtype=float).copy()
                    )
                target_position = (
                    np.asarray(
                        state['recenter_anchor_position_world'],
                        dtype=float,
                    )
                    + recenter_offset
                )
            target_pose = {
                'position': target_position,
                'orientation': normalize_quat(target_pose['orientation']).copy(),
            }
        lock_spec = gate_spec
        if (
            bool(gate_spec.get('close_gate_recenter_single_finger_contact', False))
            and float(np.linalg.norm(recenter_offset)) > 1e-12
        ):
            lock_spec = {**gate_spec, 'lock_target_position': False}
        target_pose = self._locked_target_pose(
            phase_key=phase_key,
            target_pose=target_pose,
            spec=lock_spec,
        )
        # Keep a terminal Panda IK solution once the measured TCP is close to
        # the contact pose.  Re-solving the same 7-DoF endpoint every frame
        # lets the redundant wrist joints drift between equivalent branches;
        # that drift is especially harmful while the fingers are closing.
        terminal_ik_target_pose = self._ik_target_pose(target_pose=target_pose, spec=gate_spec)
        terminal_target_q = self._coerce_arm_q(
            state.get('terminal_target_q'),
            bound_revolute=False,
        )
        terminal_lock_active = False
        cached_terminal_pose = state.get('terminal_ik_target_pose')
        if (not bool(gate_spec.get('continuous_physics', False))
                and terminal_target_q is not None and isinstance(cached_terminal_pose, dict)):
            try:
                cached_position = np.asarray(cached_terminal_pose['position'], dtype=float)
                cached_orientation = normalize_quat(cached_terminal_pose['orientation'])
                same_position = bool(
                    cached_position.shape == (3,)
                    and np.linalg.norm(cached_position - terminal_ik_target_pose['position']) <= 1e-6
                )
                _, cached_orientation_error = pose_error(
                    current_position=np.zeros(3, dtype=float),
                    current_orientation=cached_orientation,
                    target_position=np.zeros(3, dtype=float),
                    target_orientation=terminal_ik_target_pose['orientation'],
                )
                terminal_lock_active = bool(same_position and (cached_orientation_error or 0.0) <= 1e-6)
            except (KeyError, TypeError, ValueError):
                terminal_lock_active = False
            if not terminal_lock_active:
                state.pop('terminal_target_q', None)
                state.pop('terminal_ik_target_pose', None)
                terminal_target_q = None
        command_target_pose = target_pose
        if bool(gate_spec.get('close_gate_cartesian_servo', True)) and current_pose is not None:
            command_target_pose = self._cartesian_servo_target_pose(
                current_pose=current_pose,
                target_pose=target_pose,
                max_position_step=float(
                    gate_spec.get(
                        'close_gate_cartesian_position_step',
                        gate_spec.get('cartesian_position_step', 0.004),
                    )
                ),
                max_orientation_step=float(
                    gate_spec.get(
                        'close_gate_cartesian_orientation_step',
                        gate_spec.get('cartesian_orientation_step', 0.015),
                    )
                ),
            )

        current_q = self._current_arm_q(task, robot_name)
        reference_q = self._command_reference_q(task=task, robot_name=robot_name, current_q=current_q, spec=gate_spec)
        object_name = self._object_name_from_spec(gate_spec)
        pickup_terminal_seed_q = None
        if object_name is not None:
            pickup_terminal_seed_q = self._coerce_arm_q(
                self._pickup_terminal_ik_seeds.get((id(task), robot_name, object_name)),
                bound_revolute=False,
                joint_count=None if reference_q is None else reference_q.shape[0],
            )
        ik_target_pose = self._ik_target_pose(target_pose=command_target_pose, spec=gate_spec)
        terminal_position_window = float(
            gate_spec.get('close_gate_terminal_ik_position_window', 0.04)
        )
        terminal_orientation_window = float(
            gate_spec.get('close_gate_terminal_ik_orientation_window', 0.50)
        )
        if (
            not terminal_lock_active
            and not bool(gate_spec.get('continuous_physics', False))
            and bool(gate_spec.get('close_gate_lock_terminal_ik_target', True))
            and current_pose is not None
            and np.isfinite(terminal_position_window)
            and terminal_position_window > 0.0
            and np.isfinite(terminal_orientation_window)
            and terminal_orientation_window > 0.0
        ):
            terminal_position_error, terminal_orientation_error = pose_error(
                current_position=current_pose['position'],
                current_orientation=current_pose['orientation'],
                target_position=target_pose['position'],
                target_orientation=target_pose['orientation'],
            )
            if (
                terminal_position_error <= terminal_position_window
                and (
                    terminal_orientation_error is None
                    or terminal_orientation_error <= terminal_orientation_window
                )
            ):
                terminal_candidate = self._solve_ik(
                    task=task,
                    robot_name=robot_name,
                    target_pose=terminal_ik_target_pose,
                    warm_start=(
                        pickup_terminal_seed_q
                        if pickup_terminal_seed_q is not None
                        else reference_q
                    ),
                    spec=gate_spec,
                )
                terminal_candidate = self._coerce_arm_q(
                    terminal_candidate,
                    bound_revolute=False,
                )
                if terminal_candidate is not None:
                    terminal_target_q = terminal_candidate
                    terminal_lock_active = True
                    ik_target_pose = terminal_ik_target_pose

        ik_result = terminal_target_q if terminal_lock_active else self._solve_ik(
            task=task,
            robot_name=robot_name,
            target_pose=ik_target_pose,
            warm_start=reference_q,
            spec=gate_spec,
        )
        if gate_spec.get('close_gate_local_ik') and reference_q is not None:
            candidate = None if ik_result is None else self._unwrap_to_reference(
                target_q=ik_result, reference_q=reference_q,
                preferred_abs_limit=gate_spec.get('preferred_joint_abs_limit', 3.05),
                hard_preferred_abs_limit=bool(gate_spec.get('hard_preferred_joint_abs_limit', True)))
            if candidate is None or self._ik_branch_jump_detected(
                    reference_q=reference_q, target_q=candidate, spec=gate_spec):
                # The global solver can return a different elbow branch even
                # for a sub-mm request. Refine FK locally; keep the branch guard.
                ik_result = self._local_grasp_ik(
                    task=task, robot_name=robot_name, target_pose=ik_target_pose,
                    reference_q=reference_q, spec=gate_spec,
                    joint_radius=float(gate_spec.get('close_gate_local_ik_radius', .04)))
        if ik_result is None:
            action = self._hold_joint_action(task=task, robot_name=robot_name)
            action[_GRIPPER_CONTROLLER] = [
                float(gate_spec.get('preclose_openness', gate_spec.get('open_openness', 1.0)))
            ]
            state['ready_steps'] = 0
            detail = {
                'reason': 'close_gate_ik_failed',
                'target_position': target_pose['position'].tolist(),
                'target_orientation': target_pose['orientation'].tolist(),
                'current_position': None if current_pose is None else current_pose['position'].tolist(),
                'reference_q': None if reference_q is None else reference_q.tolist(),
            }
            self._debug_close_gate_step(task=task, robot_name=robot_name, detail=detail)
            return False, action, detail

        target_q = self._joint_target_near_reference(
            target_q=ik_result,
            reference_q=reference_q,
            spec=gate_spec,
            preferred_abs_limit=gate_spec.get('preferred_joint_abs_limit', 3.05),
            hard_preferred_abs_limit=bool(gate_spec.get('hard_preferred_joint_abs_limit', True)),
        )
        if reference_q is None:
            action = self._hold_joint_action(task=task, robot_name=robot_name)
            action[_GRIPPER_CONTROLLER] = [
                float(gate_spec.get('preclose_openness', gate_spec.get('open_openness', 1.0)))
            ]
            state['ready_steps'] = 0
            detail = {
                'reason': 'close_gate_current_joint_state_unavailable',
                'target_position': target_pose['position'].tolist(),
                'target_orientation': target_pose['orientation'].tolist(),
                'current_position': None if current_pose is None else current_pose['position'].tolist(),
            }
            self._debug_close_gate_step(task=task, robot_name=robot_name, detail=detail)
            return False, action, detail
        branch_reference_q = self._ik_branch_reference_q(
            phase_key=phase_key,
            reference_q=reference_q,
            spec=gate_spec,
        )
        pickup_terminal_seed_match = False
        if terminal_lock_active and pickup_terminal_seed_q is not None:
            try:
                seed_tolerance = float(
                    gate_spec.get('close_gate_pickup_terminal_seed_tolerance', 0.15)
                )
            except (TypeError, ValueError):
                seed_tolerance = 0.0
            pickup_terminal_seed_match = bool(
                np.isfinite(seed_tolerance)
                and seed_tolerance > 0.0
                and pickup_terminal_seed_q.shape == target_q.shape
                and float(np.max(np.abs(target_q - pickup_terminal_seed_q)))
                <= seed_tolerance
            )
        branch_jump_detected = self._ik_branch_jump_detected(
            reference_q=branch_reference_q,
            target_q=target_q,
            spec=gate_spec,
        )
        if (
            bool(gate_spec.get('close_gate_guard_ik_branch_jump', True))
            and branch_jump_detected
            and not pickup_terminal_seed_match
        ):
            action = self._hold_joint_action(task=task, robot_name=robot_name)
            action[_GRIPPER_CONTROLLER] = [
                float(gate_spec.get('preclose_openness', gate_spec.get('open_openness', 1.0)))
            ]
            state['ready_steps'] = 0
            detail = {
                'reason': 'close_gate_ik_branch_jump_guard',
                'target_position': target_pose['position'].tolist(),
                'target_orientation': target_pose['orientation'].tolist(),
                'current_position': None if current_pose is None else current_pose['position'].tolist(),
                'reference_q': branch_reference_q.tolist(),
                'target_q': target_q.tolist(),
                'pickup_terminal_seed_match': pickup_terminal_seed_match,
            }
            self._debug_close_gate_step(task=task, robot_name=robot_name, detail=detail)
            return False, action, detail
        if terminal_lock_active:
            state['terminal_target_q'] = np.asarray(target_q, dtype=float).copy()
            state['terminal_ik_target_pose'] = {
                'position': np.asarray(terminal_ik_target_pose['position'], dtype=float).copy(),
                'orientation': normalize_quat(terminal_ik_target_pose['orientation']).copy(),
            }
        command_q = self._limited_joint_target(
            current_q=reference_q,
            target_q=target_q,
            max_joint_step=float(gate_spec.get('close_gate_max_joint_step', gate_spec.get('max_joint_step', 0.025))),
        )
        command_q = self._continuous_command_q(
            task=task,
            robot_name=robot_name,
            command_q=command_q,
            spec={
                **gate_spec,
                'max_joint_step': gate_spec.get(
                    'close_gate_max_joint_step',
                    gate_spec.get('max_joint_step', 0.025),
                ),
            },
        )
        command_q = self._limit_command_to_measured_state(
            current_q=current_q,
            command_q=command_q,
            spec=gate_spec,
        )

        action = OrderedDict()
        action[_ARM_JOINT_CONTROLLER] = [command_q.tolist()]
        self._remember_arm_command(task, robot_name, command_q)
        action[_GRIPPER_CONTROLLER] = [float(gate_spec.get('preclose_openness', gate_spec.get('open_openness', 1.0)))]

        detail = {
            'target_position': target_pose['position'].tolist(),
            'target_orientation': target_pose['orientation'].tolist(),
            'command_target_position': command_target_pose['position'].tolist(),
            'command_target_orientation': command_target_pose['orientation'].tolist(),
            'ik_target_position': ik_target_pose['position'].tolist(),
            'ik_target_orientation': ik_target_pose['orientation'].tolist(),
            'recenter_offset_world': recenter_offset.tolist(),
            'recenter_stop': recenter_stop,
            'current_position': None if current_pose is None else current_pose['position'].tolist(),
            'reference_q': reference_q.tolist(),
            'target_q': target_q.tolist(),
            'terminal_ik_locked': terminal_lock_active,
            'pickup_terminal_seed_match': pickup_terminal_seed_match,
            'branch_jump_bypassed_for_pickup_terminal_seed': bool(
                branch_jump_detected and pickup_terminal_seed_match
            ),
        }
        ready = False
        if current_pose is not None:
            position_tolerance = float(
                gate_spec.get('close_position_tolerance', gate_spec.get('position_tolerance', 0.01))
            )
            orientation_tolerance = gate_spec.get('close_orientation_tolerance', gate_spec.get('orientation_tolerance'))
            orientation_tolerance = None if orientation_tolerance is None else float(orientation_tolerance)
            position_error, orientation_error = pose_error(
                current_position=current_pose['position'],
                current_orientation=current_pose['orientation'],
                target_position=target_pose['position'],
                target_orientation=target_pose['orientation'],
            )
            ready = position_error <= position_tolerance and (
                orientation_tolerance is None or orientation_error is None or orientation_error <= orientation_tolerance
            )
            detail.update(
                {
                    'position_error': position_error,
                    'orientation_error': orientation_error,
                    'position_tolerance': position_tolerance,
                    'orientation_tolerance': orientation_tolerance,
                }
            )
            recenter_target_tolerance = float(gate_spec.get('close_gate_recenter_target_tolerance', 0.00035))
            state['recenter_target_ready'] = bool(position_error <= recenter_target_tolerance)
            pending = state.get('force_recenter_pending')
            if gate_spec.get('close_force_recenter_measure_progress') and pending is not None:
                motion_ready, motion_detail = self._recenter_motion_ready(
                    pending=pending, current_position=current_pose['position'],
                    overall_pose_ready=ready, tolerance=recenter_target_tolerance,
                )
                state['recenter_target_ready'] = motion_ready
                detail.update(motion_detail)
            detail.update(
                {
                    'recenter_target_ready': state['recenter_target_ready'],
                    'recenter_target_tolerance': recenter_target_tolerance,
                }
            )

        joint_tolerance = gate_spec.get('close_joint_position_tolerance', gate_spec.get('joint_position_tolerance'))
        if joint_tolerance is not None and current_q is not None:
            joint_error = float(np.max(np.abs(np.asarray(target_q, dtype=float) - np.asarray(current_q, dtype=float))))
            ready = bool(ready and joint_error <= float(joint_tolerance))
            detail.update(
                {
                    'joint_error': joint_error,
                    'joint_position_tolerance': float(joint_tolerance),
                }
            )

        gate_ready, stability_detail = self._close_gate_stability(
            state=state, spec=gate_spec, ready=ready, current_pose=current_pose,
        )
        detail.update(stability_detail)
        detail['gate_ready'] = gate_ready
        state['hold_command_pose'] = {k: np.asarray(command_target_pose[k]).copy()
                                      for k in ('position', 'orientation')}
        if not bool(gate_spec.get('continuous_physics', False)):
            self._last_targets[phase_key] = {
                'position': target_pose['position'].copy(),
                'orientation': target_pose['orientation'].copy(),
                'target_q': target_q.copy(),
            }
        self._debug_close_gate_step(task=task, robot_name=robot_name, detail=detail)
        if gate_ready:
            if 'close_started_step' not in state:
                state['close_started_step'] = int(getattr(task, 'phase_step_counter', 0))
                if bool(gate_spec.get('close_gate_freeze_at_start')):
                    state['close_arm_frozen'] = True
                    state['contact_arm_anchor'] = {key: np.asarray(current_pose[key], dtype=float).copy()
                                                   for key in ('position', 'orientation')}
                    hold_q = current_q if current_q is not None else command_q
                    self._remember_arm_command(task, robot_name, hold_q)
                elif bool(gate_spec.get('close_gate_hold_refined_command', False)):
                    hold_q = command_q
                else:
                    hold_q = current_q if current_q is not None else command_q
                state['hold_q'] = np.asarray(hold_q, dtype=float).copy()
            elif frozen_arm or regulated_contact or bool(gate_spec.get('close_gate_track_object_during_close', False)):
                # Frozen closure tracks only its fixed world anchor plus bounded recentering.
                state['hold_q'] = np.asarray(command_q, dtype=float).copy()
        trace_path = os.environ.get('BEAM_CLOSE_GATE_TRACE_PATH')
        if trace_path and spec.get('close_gate_freeze_at_start'):
            object_pose = self._object_pose(
                task=task, object_name=self._object_name_from_spec(spec), tracked_objects=tracked_objects,
            )
            with open(trace_path, 'a', encoding='utf-8') as handle:
                handle.write(json.dumps({
                    'step': int(task.step_counter), 'phase': task.phase, 'robot': robot_name,
                    **detail, 'current_position': None if current_pose is None else np.asarray(current_pose['position']).tolist(),
                    'current_orientation': None if current_pose is None else np.asarray(current_pose['orientation']).tolist(),
                    'current_q': None if current_q is None else np.asarray(current_q).tolist(),
                    'command_q': command_q.tolist(), 'close_started_step': state.get('close_started_step'),
                    'arm_frozen': bool(state.get('close_arm_frozen')),
                    'hold_q': None if state.get('hold_q') is None else np.asarray(state['hold_q']).tolist(),
                    'object_position': None if object_pose is None else np.asarray(object_pose['position']).tolist(),
                    'object_orientation': None if object_pose is None else np.asarray(object_pose['orientation']).tolist(),
                }) + '\n')
        return gate_ready, action, detail

    def _prealign_action(self, *, phase_key, task, robot_name: str, target_pose: dict, spec: dict):
        prealign_steps = int(spec.get('prealign_steps', 0) or 0)
        if prealign_steps <= 0:
            return None
        phase_step_counter = int(getattr(task, 'phase_step_counter', 0))
        until_converged = bool(spec.get('prealign_until_converged', False))
        if not until_converged and phase_step_counter >= prealign_steps:
            return None
        prealign_state = self._prealign_state.setdefault(phase_key, {})
        if until_converged and bool(prealign_state.get('converged', False)):
            return None

        current_q = self._current_arm_q(task, robot_name)
        reference_q = self._command_reference_q(task=task, robot_name=robot_name, current_q=current_q, spec=spec)
        if reference_q is None or reference_q.shape[0] < 1:
            if until_converged:
                return self._failure_or_hold(
                    task,
                    robot_name,
                    spec,
                    'prealign_joint_state_unavailable',
                    diagnostics={'phase_step_counter': phase_step_counter},
                )
            return None

        desired_q = None
        if bool(spec.get('prealign_target_ik', False)):
            desired_q = self._coerce_arm_q(
                prealign_state.get('target_q'),
                bound_revolute=False,
            )
            if desired_q is None:
                ik_target_pose = self._ik_target_pose(target_pose=target_pose, spec=spec)
                terminal_seed_q = None
                if bool(spec.get('prealign_terminal_ik_seed', False)):
                    terminal_target_pose = self._prealign_terminal_target_pose(
                        target_pose=target_pose,
                        spec=spec,
                    )
                    if terminal_target_pose is not None:
                        terminal_seed_q = self._solve_ik(
                            task=task,
                            robot_name=robot_name,
                            target_pose=self._ik_target_pose(
                                target_pose=terminal_target_pose,
                                spec=spec,
                            ),
                            warm_start=reference_q,
                            spec={
                                **spec,
                                'require_warm_start_ik': False,
                                'warm_start_ik_only': False,
                            },
                        )
                        if terminal_seed_q is not None:
                            terminal_seed_q = self._joint_target_near_reference(
                                target_q=terminal_seed_q,
                                reference_q=reference_q,
                                spec=spec,
                                preferred_abs_limit=spec.get('preferred_joint_abs_limit', 3.05),
                                hard_preferred_abs_limit=bool(
                                    spec.get('hard_preferred_joint_abs_limit', True)
                                ),
                            )
                prealign_require_warm_start = bool(
                    spec.get(
                        'prealign_require_warm_start_ik',
                        terminal_seed_q is not None,
                    )
                )
                prealign_warm_start_only = bool(
                    spec.get(
                        'prealign_warm_start_ik_only',
                        prealign_require_warm_start,
                    )
                )
                ik_result = self._solve_ik(
                    task=task,
                    robot_name=robot_name,
                    target_pose=ik_target_pose,
                    warm_start=terminal_seed_q if terminal_seed_q is not None else reference_q,
                    spec={
                        **spec,
                        'require_warm_start_ik': prealign_require_warm_start,
                        'warm_start_ik_only': prealign_warm_start_only,
                    },
                )
                if ik_result is not None:
                    desired_q = self._joint_target_near_reference(
                        target_q=ik_result,
                        reference_q=reference_q,
                        spec=spec,
                        preferred_abs_limit=spec.get('preferred_joint_abs_limit', 3.05),
                        hard_preferred_abs_limit=bool(spec.get('hard_preferred_joint_abs_limit', True)),
                    )
                    prealign_state['target_q'] = desired_q.copy()
                    if terminal_seed_q is not None:
                        prealign_state['terminal_seed_q'] = terminal_seed_q.copy()
                        object_name = self._object_name_from_spec(spec)
                        if object_name is not None:
                            self._pickup_terminal_ik_seeds[
                                (id(task), robot_name, object_name)
                            ] = terminal_seed_q.copy()
                    print(
                        '[assembly-ik-prealign] '
                        f"step={getattr(task, 'step_counter', None)} "
                        f"phase={getattr(task, 'phase', None)} robot={robot_name} "
                        f"maximum_joint_delta={float(np.max(np.abs(desired_q - reference_q))):.6f} "
                        f"terminal_seed={terminal_seed_q is not None}",
                        flush=True,
                    )

        if desired_q is None:
            desired_q = reference_q.copy()
            if spec.get('prealign_joint_positions') is not None:
                joint_values = np.asarray(spec['prealign_joint_positions'], dtype=float)
                desired_q[: min(desired_q.shape[0], joint_values.shape[0])] = joint_values[: desired_q.shape[0]]
            else:
                shoulder_pan = spec.get('prealign_shoulder_pan')
                if shoulder_pan is None and bool(spec.get('prealign_shoulder_pan_from_target', False)):
                    shoulder_pan = self._target_facing_shoulder_pan(
                        task=task,
                        robot_name=robot_name,
                        target_position=target_pose['position'],
                        yaw_offset=float(spec.get('prealign_shoulder_pan_yaw_offset', -0.47)),
                    )
                if shoulder_pan is None:
                    return None
                desired_q[0] = float(shoulder_pan)

        if until_converged:
            try:
                tolerance = float(spec.get('prealign_joint_position_tolerance', 0.05))
            except (TypeError, ValueError):
                tolerance = float('nan')
            try:
                timeout_steps = int(spec.get('prealign_timeout_steps', max(prealign_steps, 1)))
            except (TypeError, ValueError):
                timeout_steps = 0
            if not np.isfinite(tolerance) or tolerance <= 0.0 or timeout_steps <= 0:
                return self._failure_or_hold(
                    task,
                    robot_name,
                    spec,
                    'invalid_prealign_convergence_policy',
                    diagnostics={
                        'prealign_joint_position_tolerance': spec.get('prealign_joint_position_tolerance'),
                        'prealign_timeout_steps': spec.get('prealign_timeout_steps'),
                    },
                )

            measured_q = self._coerce_arm_q(
                current_q,
                bound_revolute=False,
                joint_count=desired_q.shape[0],
            )
            if measured_q is None:
                return self._failure_or_hold(
                    task,
                    robot_name,
                    spec,
                    'prealign_joint_state_unavailable',
                    diagnostics={'phase_step_counter': phase_step_counter},
                )
            measured_q = self._joint_target_near_reference(
                target_q=measured_q,
                reference_q=desired_q,
                spec=spec,
                preferred_abs_limit=None,
                hard_preferred_abs_limit=False,
            )
            joint_error = float(np.max(np.abs(desired_q - measured_q)))
            arm_dynamics = self._current_arm_dynamics(task=task, robot_name=robot_name)
            joint_velocity = self._coerce_arm_q(
                arm_dynamics.get('joint_velocity'),
                bound_revolute=False,
                joint_count=desired_q.shape[0],
            )
            max_joint_velocity = None
            if joint_velocity is not None:
                max_joint_velocity = float(np.max(np.abs(joint_velocity)))
            velocity_tolerance = spec.get('prealign_joint_velocity_tolerance')
            velocity_ready = True
            if velocity_tolerance is not None and max_joint_velocity is not None:
                velocity_ready = max_joint_velocity <= float(velocity_tolerance)
            position_ready = joint_error <= tolerance
            if position_ready and velocity_ready:
                prealign_state['ready_steps'] = int(prealign_state.get('ready_steps', 0)) + 1
            else:
                prealign_state['ready_steps'] = 0
            required_ready_steps = max(int(spec.get('prealign_ready_stable_steps', 1)), 1)
            prealign_state['joint_error'] = joint_error
            prealign_state['max_joint_velocity'] = max_joint_velocity
            if int(prealign_state['ready_steps']) >= required_ready_steps:
                prealign_state['converged'] = True
                if not bool(prealign_state.get('convergence_logged', False)):
                    print(
                        '[assembly-prealign-converged] '
                        f"step={getattr(task, 'step_counter', None)} "
                        f"phase={getattr(task, 'phase', None)} robot={robot_name} "
                        f'phase_step={phase_step_counter} joint_error={joint_error:.6f} '
                        f'tolerance={tolerance:.6f} max_joint_velocity={max_joint_velocity} '
                        f'ready_steps={prealign_state["ready_steps"]}',
                        flush=True,
                    )
                    prealign_state['convergence_logged'] = True
                return None
            if phase_step_counter >= timeout_steps:
                return self._failure_or_hold(
                    task,
                    robot_name,
                    spec,
                    'prealign_timeout',
                    diagnostics={
                        'phase_step_counter': phase_step_counter,
                        'prealign_timeout_steps': timeout_steps,
                        'joint_error': joint_error,
                        'joint_position_tolerance': tolerance,
                        'max_joint_velocity': max_joint_velocity,
                        'joint_velocity_tolerance': velocity_tolerance,
                        'ready_steps': int(prealign_state.get('ready_steps', 0)),
                        'required_ready_steps': required_ready_steps,
                        'current_q': measured_q.tolist(),
                        'target_q': desired_q.tolist(),
                    },
                )

        command_reference_q = current_q if current_q is not None else reference_q
        command_q = self._limited_joint_target(
            current_q=command_reference_q,
            target_q=desired_q,
            max_joint_step=float(spec.get('prealign_max_joint_step', spec.get('max_joint_step', 0.035))),
        )
        command_q = self._continuous_command_q(
            task=task,
            robot_name=robot_name,
            command_q=command_q,
            spec={
                **spec,
                'max_joint_step': spec.get(
                    'prealign_max_joint_step',
                    spec.get('max_joint_step', 0.035),
                ),
            },
        )
        prealign_tracking_error = spec.get(
            'prealign_max_command_tracking_error',
            spec.get('max_command_tracking_error', 0.18),
        )
        command_q = self._limit_command_to_measured_state(
            current_q=current_q,
            command_q=command_q,
            spec={
                **spec,
                'max_command_tracking_error': prealign_tracking_error,
                'max_wrist_command_tracking_error': spec.get(
                    'prealign_max_wrist_command_tracking_error',
                    prealign_tracking_error,
                ),
            },
        )
        if self._debug_grasp_enabled():
            debug_every = max(int(os.environ.get('UR5E_DEBUG_JOINT_TARGET_EVERY', '120')), 1)
            if phase_step_counter <= 5 or phase_step_counter % debug_every == 0:
                dynamics = self._current_arm_dynamics(task=task, robot_name=robot_name)
                print(
                    '[assembly-prealign-debug] '
                    f"step={getattr(task, 'step_counter', None)} "
                    f"phase={getattr(task, 'phase', None)} phase_step={phase_step_counter} "
                    f'robot={robot_name} '
                    f'current_q={np.asarray(current_q, dtype=float).tolist()} '
                    f'reference_q={np.asarray(reference_q, dtype=float).tolist()} '
                    f'target_q={np.asarray(desired_q, dtype=float).tolist()} '
                    f'command_q={np.asarray(command_q, dtype=float).tolist()} '
                    f"joint_velocity={dynamics.get('joint_velocity')} "
                    f"measured_effort={dynamics.get('measured_effort')} "
                    f"applied_effort={dynamics.get('applied_effort')} "
                    f"max_force={dynamics.get('max_force')}",
                    flush=True,
                )
        action = OrderedDict()
        action[_ARM_JOINT_CONTROLLER] = [command_q.tolist()]
        self._remember_arm_command(task, robot_name, command_q)
        action[_GRIPPER_CONTROLLER] = [
            self._gripper_command_value(task=task, robot_name=robot_name, command=spec.get('gripper_command', 'open'))
        ]
        return action

    @staticmethod
    def _target_facing_shoulder_pan(*, task, robot_name: str, target_position, yaw_offset: float) -> float | None:
        robot = task.robots.get(robot_name)
        if robot is None:
            return None
        try:
            base_position, _ = robot.articulation.get_pose()
        except Exception:
            return None
        target_position = np.asarray(target_position, dtype=float)
        base_position = np.asarray(base_position, dtype=float)
        delta = target_position[:2] - base_position[:2]
        if float(np.linalg.norm(delta)) < 1e-6:
            return None
        return float(np.arctan2(delta[1], delta[0]) + yaw_offset)

    @staticmethod
    def _prealign_terminal_target_pose(*, target_pose: dict, spec: dict) -> dict | None:
        """Recover the grasp endpoint whose IK branch must remain valid during descent."""

        offset = spec.get('offset')
        if offset is None:
            return None
        offset = np.asarray(offset, dtype=float)
        if offset.shape != (3,) or not np.all(np.isfinite(offset)):
            return None
        position = np.asarray(target_pose.get('position'), dtype=float)
        orientation = normalize_quat(target_pose.get('orientation'))
        if position.shape != (3,) or not np.all(np.isfinite(position)):
            return None

        offset_frame = str(spec.get('offset_frame', 'world')).lower()
        if offset_frame in {'object', 'local', 'part'}:
            relative_pose = UR5eAssemblyAtomicSkillAdapter._configured_grasp_relative_pose(spec)
            if relative_pose is None:
                return None
            _, relative_orientation = relative_pose
            object_orientation = normalize_quat(quat_multiply(orientation, relative_orientation))
            world_offset = quat_rotate(object_orientation, offset)
        elif offset_frame in {'target', 'eef', 'tcp', 'gripper'}:
            world_offset = quat_rotate(orientation, offset)
        else:
            world_offset = offset
        return {
            'position': position - np.asarray(world_offset, dtype=float),
            'orientation': orientation,
        }

    @staticmethod
    def _current_tcp_pose(*, current_pose: dict | None, spec: dict) -> dict | None:
        if current_pose is None:
            return None
        position = np.asarray(current_pose['position'], dtype=float).copy()
        orientation = normalize_quat(current_pose['orientation'])
        tcp_offset = UR5eAssemblyAtomicSkillAdapter._tcp_offset(spec)
        if tcp_offset is None:
            return {'position': position, 'orientation': orientation}
        position = UR5eAssemblyAtomicSkillAdapter._position_with_offset(
            position=position,
            orientation=orientation,
            offset=tcp_offset,
            offset_frame=UR5eAssemblyAtomicSkillAdapter._tcp_offset_frame(spec),
            sign=1.0,
        )
        return {'position': position, 'orientation': orientation}

    @staticmethod
    def _ik_target_pose(*, target_pose: dict, spec: dict) -> dict:
        position = np.asarray(target_pose['position'], dtype=float).copy()
        orientation = normalize_quat(target_pose['orientation'])
        tcp_offset = UR5eAssemblyAtomicSkillAdapter._tcp_offset(spec)
        if tcp_offset is not None:
            position = UR5eAssemblyAtomicSkillAdapter._position_with_offset(
                position=position,
                orientation=orientation,
                offset=tcp_offset,
                offset_frame=UR5eAssemblyAtomicSkillAdapter._tcp_offset_frame(spec),
                sign=-1.0,
            )
        offset = spec.get('ik_target_offset')
        if offset is not None:
            offset = np.asarray(offset, dtype=float)
            offset_frame = str(spec.get('ik_target_offset_frame', 'world')).lower()
            if offset_frame in {'target', 'local', 'eef', 'gripper'}:
                position = position + quat_rotate(orientation, offset)
            else:
                position = position + offset
        return {'position': position, 'orientation': orientation}

    @staticmethod
    def _tcp_offset(spec: dict) -> np.ndarray | None:
        offset = spec.get('grasp_tcp_offset', spec.get('tcp_offset'))
        if offset is None:
            return None
        offset = np.asarray(offset, dtype=float)
        if offset.shape != (3,) or not np.all(np.isfinite(offset)):
            return None
        return offset

    @staticmethod
    def _tcp_offset_frame(spec: dict) -> str:
        return str(spec.get('grasp_tcp_offset_frame', spec.get('tcp_offset_frame', 'target'))).lower()

    @staticmethod
    def _position_with_offset(
        *,
        position: np.ndarray,
        orientation: np.ndarray,
        offset: np.ndarray,
        offset_frame: str,
        sign: float,
    ) -> np.ndarray:
        if offset_frame in {'target', 'local', 'eef', 'tool', 'gripper'}:
            return position + float(sign) * quat_rotate(orientation, offset)
        return position + float(sign) * offset

    @staticmethod
    def _target_orientation(
        *, task, robot_name: str, spec: dict, tracked_robots: dict, object_pose: dict | None = None
    ):
        del task
        if spec.get('target_orientation') is not None:
            orientation = np.asarray(spec['target_orientation'], dtype=float)
        elif spec.get('orientation') is not None:
            orientation = np.asarray(spec['orientation'], dtype=float)
        elif spec.get('orientation_euler') is not None:
            orientation = euler_xyz_to_quat(spec['orientation_euler'])
        else:
            robot_state = tracked_robots.get(robot_name, {})
            if robot_state.get('orientation') is not None:
                orientation = np.asarray(robot_state['orientation'], dtype=float)
            else:
                orientation = np.array([1.0, 0.0, 0.0, 0.0], dtype=float)

        orientation_frame = str(spec.get('target_orientation_frame', spec.get('orientation_frame', 'world'))).lower()
        if orientation_frame in {'object', 'local', 'part'}:
            if object_pose is None:
                return None
            return normalize_quat(quat_multiply(object_pose['orientation'], orientation))
        return normalize_quat(orientation)

    @staticmethod
    def _object_pose(*, task, object_name: str, tracked_objects: dict):
        object_state = tracked_objects.get(object_name, {})
        if object_state.get('position') is not None and object_state.get('orientation') is not None:
            return {
                'position': np.asarray(object_state['position'], dtype=float),
                'orientation': normalize_quat(object_state['orientation']),
            }
        try:
            position, orientation = task._resolve_object(object_name).get_pose()  # noqa: SLF001
        except Exception:
            return None
        return {
            'position': np.asarray(position, dtype=float),
            'orientation': normalize_quat(orientation),
        }

    @staticmethod
    def _current_robot_pose(*, task, robot_name: str, tracked_robots: dict):
        # Cartesian IK must measure error in the solver's end-effector frame.
        # The physical gripper body remains the source of truth for contacts
        # and recorded state, but some UR5e assets mount it with a fixed pi
        # rotation relative to Lula's configured frame.
        get_kinematics_pose = getattr(task, '_get_robot_kinematics_pose', None)
        if callable(get_kinematics_pose):
            try:
                kinematics_pose = get_kinematics_pose(robot_name)
            except Exception:
                kinematics_pose = None
            if kinematics_pose is not None:
                position, orientation = kinematics_pose
                return {
                    'position': np.asarray(position, dtype=float),
                    'orientation': normalize_quat(orientation),
                }
        robot_state = tracked_robots.get(robot_name, {})
        if robot_state.get('position') is not None and robot_state.get('orientation') is not None:
            return {
                'position': np.asarray(robot_state['position'], dtype=float),
                'orientation': normalize_quat(robot_state['orientation']),
            }
        try:
            position, orientation = task._get_robot_task_pose(robot_name)  # noqa: SLF001
        except Exception:
            return None
        return {
            'position': np.asarray(position, dtype=float),
            'orientation': normalize_quat(orientation),
        }

    def _current_arm_q(self, task, robot_name: str) -> np.ndarray | None:
        """Read measured joint state; cached commands are not measurements."""
        robot = task.robots.get(robot_name)
        if robot is None:
            self._arm_measurement_status[robot_name] = {'valid': False, 'reason': 'robot_unavailable'}
            return None
        controller = robot.controllers.get(_ARM_JOINT_CONTROLLER)
        arm_joint_names = self._arm_joint_names(robot=robot, controller=controller)
        arm_joint_count = len(arm_joint_names)
        errors = []
        try:
            subset = (controller.get_joint_subset() if controller is not None and hasattr(controller, 'get_joint_subset')
                      else getattr(controller, 'joint_subset', None))
        except Exception as exc:
            subset = None
            errors.append(f'joint_subset:{type(exc).__name__}')
        if subset is not None:
            try:
                joint_positions = self._coerce_arm_q(
                    subset.get_joint_positions(),
                    joint_count=arm_joint_count,
                    bound_revolute=False,
                )
                if joint_positions is not None:
                    self._arm_measurement_status[robot_name] = {'valid': True, 'source': 'joint_subset'}
                    return joint_positions
            except Exception as exc:
                errors.append(f'joint_subset_positions:{type(exc).__name__}')
        articulation = getattr(robot, 'articulation', None)
        if articulation is not None:
            try:
                indices = np.asarray([articulation.get_dof_index(name) for name in arm_joint_names], dtype=np.int64)
                joint_positions = self._coerce_arm_q(
                    articulation.get_joint_positions(joint_indices=indices),
                    joint_count=arm_joint_count,
                    bound_revolute=False,
                )
                if joint_positions is not None:
                    self._arm_measurement_status[robot_name] = {'valid': True, 'source': 'articulation_named_indices'}
                    return joint_positions
            except Exception as exc:
                errors.append(f'articulation_named_indices:{type(exc).__name__}')
            try:
                all_joint_positions = np.asarray(articulation.get_joint_positions(), dtype=float)
                dof_names = list(getattr(articulation, 'dof_names', []) or [])
                if dof_names:
                    indices = [dof_names.index(name) for name in arm_joint_names if name in dof_names]
                    if len(indices) == arm_joint_count:
                        joint_positions = self._coerce_arm_q(
                            all_joint_positions[np.asarray(indices, dtype=np.int64)],
                            joint_count=arm_joint_count,
                            bound_revolute=False,
                        )
                        if joint_positions is not None:
                            self._arm_measurement_status[robot_name] = {'valid': True, 'source': 'articulation_dof_names'}
                            return joint_positions
                # A nameless buffer is safe only if it contains exactly the arm.
                # Never assume a mixed arm/gripper buffer starts with arm joints.
                if not dof_names and all_joint_positions.shape == (arm_joint_count,):
                    joint_positions = self._coerce_arm_q(
                        all_joint_positions, joint_count=arm_joint_count, bound_revolute=False,
                    )
                    if joint_positions is not None:
                        self._arm_measurement_status[robot_name] = {'valid': True, 'source': 'articulation_arm_only'}
                        return joint_positions
            except Exception as exc:
                errors.append(f'articulation_all_positions:{type(exc).__name__}')
        self._arm_measurement_status[robot_name] = {'valid': False, 'source': None, 'errors': errors,
                                                   'reason': 'measured_joint_state_unavailable'}
        return None

    def _current_arm_dynamics(self, *, task, robot_name: str) -> dict[str, list[float]]:
        """Read optional PhysX drive diagnostics without affecting control."""

        robots = getattr(task, 'robots', None)
        if not isinstance(robots, dict):
            return {}
        robot = robots.get(robot_name)
        if robot is None:
            return {}
        articulation = getattr(robot, 'articulation', None)
        if articulation is None:
            return {}
        controllers = getattr(robot, 'controllers', {})
        controller = controllers.get(_ARM_JOINT_CONTROLLER)
        joint_names = self._arm_joint_names(robot=robot, controller=controller)
        try:
            indices = np.asarray([articulation.get_dof_index(name) for name in joint_names], dtype=np.int64)
        except Exception:
            return {}

        result: dict[str, list[float]] = {}

        def _store(name: str, values) -> bool:
            try:
                array = np.asarray(values, dtype=float)
                if array.ndim > 1:
                    array = array[0]
                array = array.reshape(-1)
                if array.size != indices.size:
                    array = array[indices]
                if array.size != indices.size or not np.all(np.isfinite(array)):
                    return False
                result[name] = array.tolist()
                return True
            except Exception:
                return False

        try:
            _store('joint_velocity', articulation.get_joint_velocities(joint_indices=indices))
        except Exception:
            pass

        try:
            unwrapped = articulation.unwrap()
        except Exception:
            unwrapped = None
        for result_name, method_names in (
            ('measured_effort', ('get_measured_joint_efforts', 'get_joint_efforts')),
            ('applied_effort', ('get_applied_joint_efforts',)),
        ):
            for candidate in (unwrapped, articulation):
                if candidate is None:
                    continue
                for method_name in method_names:
                    method = getattr(candidate, method_name, None)
                    if not callable(method):
                        continue
                    try:
                        values = method(joint_indices=indices)
                    except TypeError:
                        try:
                            values = method()
                        except Exception:
                            continue
                    except Exception:
                        continue
                    if _store(result_name, values):
                        break
                if result_name in result:
                    break

        try:
            physics_view = articulation._articulation_view._physics_view
        except Exception:
            physics_view = None
        if physics_view is not None:
            for result_name, method_name in (
                ('stiffness', 'get_dof_stiffnesses'),
                ('damping', 'get_dof_dampings'),
                ('max_force', 'get_dof_max_forces'),
            ):
                method = getattr(physics_view, method_name, None)
                if callable(method):
                    try:
                        _store(result_name, method())
                    except Exception:
                        pass
        return result

    @staticmethod
    def _arm_joint_names(*, robot, controller=None) -> tuple[str, ...]:
        configured_names = tuple(getattr(controller, 'joint_names', None) or ())
        if len(configured_names) in {6, 7}:
            return configured_names
        articulation = getattr(robot, 'articulation', None)
        dof_names = set(getattr(articulation, 'dof_names', []) or [])
        for names in _SUPPORTED_ARM_JOINT_NAMES:
            if all(name in dof_names for name in names):
                return names
        robot_type = str(getattr(getattr(robot, 'config', None), 'type', '')).lower()
        if 'franka' in robot_type or 'panda' in robot_type:
            return _FRANKA_ARM_JOINT_NAMES
        return _UR5E_ARM_JOINT_NAMES

    @staticmethod
    def _coerce_arm_q(
        joint_positions,
        *,
        bound_revolute: bool = True,
        joint_count: int | None = None,
    ) -> np.ndarray | None:
        if joint_positions is None:
            return None
        try:
            values = np.asarray(joint_positions, dtype=float).reshape(-1)
        except Exception:
            return None
        if joint_count is None:
            joint_count = 7 if values.shape[0] >= 7 else 6
        if joint_count not in {6, 7} or values.shape[0] < joint_count:
            return None
        values = values[:joint_count]
        if not np.all(np.isfinite(values)):
            return None
        if not bound_revolute:
            return values.copy()
        return UR5eAssemblyAtomicSkillAdapter._bounded_revolute_joint_values(values)

    @staticmethod
    def _bounded_revolute_joint_values(values) -> np.ndarray:
        values = np.asarray(values, dtype=float).copy()
        wrapped = (values + np.pi) % (2.0 * np.pi) - np.pi
        # UR wrists can legitimately cross multiple pi turns during continuous
        # motion.  Wrapping too early makes the cached command state jump across
        # branches, so only fold back values that are far outside a nearby branch.
        return np.where(np.abs(values) > 4.0 * np.pi + 0.25, wrapped, values)

    def _remember_arm_command(self, task, robot_name: str, command_q: np.ndarray) -> None:
        joint_positions = self._coerce_arm_q(command_q, bound_revolute=False)
        if joint_positions is not None:
            self._last_arm_command_q[robot_name] = joint_positions
            task_cache = getattr(task, '_ur5e_plumbers_last_arm_command_q', None)
            if task_cache is None:
                task_cache = {}
                setattr(task, '_ur5e_plumbers_last_arm_command_q', task_cache)
            task_cache[robot_name] = joint_positions.copy()

    def _last_command_q(self, *, task, robot_name: str) -> np.ndarray | None:
        task_cache = getattr(task, '_ur5e_plumbers_last_arm_command_q', None)
        last_q = None
        if isinstance(task_cache, dict):
            last_q = task_cache.get(robot_name)
        if last_q is None:
            last_q = self._last_arm_command_q.get(robot_name)
        return self._coerce_arm_q(last_q, bound_revolute=False)

    def _command_reference_q(
        self, *, task, robot_name: str, current_q: np.ndarray | None, spec: dict
    ) -> np.ndarray | None:
        current_q = self._coerce_arm_q(current_q)
        reference_mode = str(spec.get('ik_reference_mode', spec.get('reference_mode', ''))).strip().lower()
        last_q = self._last_command_q(task=task, robot_name=robot_name)
        if reference_mode in {'current', 'current_q', 'actual', 'measured'}:
            if current_q is not None and last_q is not None:
                return self._joint_target_near_reference(
                    target_q=current_q,
                    reference_q=last_q,
                    spec=spec,
                    preferred_abs_limit=None,
                    hard_preferred_abs_limit=False,
                )
            return current_q
        if reference_mode in {'hybrid', 'bounded_command', 'command_bounded'}:
            if last_q is None:
                return current_q
            if current_q is None:
                return last_q
            measured_reference = self._joint_target_near_reference(
                target_q=current_q,
                reference_q=last_q,
                spec=spec,
                preferred_abs_limit=None,
                hard_preferred_abs_limit=False,
            )
            try:
                raw_limit = np.asarray(
                    spec.get('ik_reference_command_max_tracking_error', 0.12),
                    dtype=float,
                ).reshape(-1)
            except Exception:
                return measured_reference
            if raw_limit.size == 0 or not np.all(np.isfinite(raw_limit)):
                return measured_reference
            if raw_limit.size == 1:
                limits = np.full(last_q.shape[0], float(raw_limit[0]), dtype=float)
            else:
                limits = np.full(last_q.shape[0], float(raw_limit[-1]), dtype=float)
                limits[: min(raw_limit.size, last_q.shape[0])] = raw_limit[: last_q.shape[0]]
            if np.any(limits <= 0.0):
                return measured_reference
            if np.any(np.abs(last_q - measured_reference) > limits):
                return measured_reference
            return last_q
        if last_q is None:
            return current_q
        if current_q is None:
            return last_q
        reset_threshold = spec.get('ik_reference_reset_threshold')
        if reset_threshold is not None:
            try:
                if float(np.max(np.abs(last_q - current_q))) > float(reset_threshold):
                    return current_q
            except Exception:
                return current_q
        return last_q

    def _continuous_command_q(
        self,
        *,
        task,
        robot_name: str,
        command_q: np.ndarray,
        spec: dict,
    ) -> np.ndarray:
        command_q = self._coerce_arm_q(command_q, bound_revolute=False)
        if command_q is None:
            return command_q
        if not bool(spec.get('enforce_continuous_joint_commands', True)):
            return command_q
        last_q = self._last_command_q(task=task, robot_name=robot_name)
        if last_q is None:
            return command_q
        command_q = self._joint_target_near_reference(
            target_q=command_q,
            reference_q=last_q,
            spec=spec,
            preferred_abs_limit=None,
            hard_preferred_abs_limit=False,
        )
        max_command_step = self._command_joint_step_limits(spec=spec, joint_count=command_q.shape[0])
        if max_command_step is None:
            return command_q
        return self._limited_joint_target(
            current_q=last_q,
            target_q=command_q,
            max_joint_step=max_command_step,
        )

    @staticmethod
    def _command_joint_step_limits(*, spec: dict, joint_count: int) -> np.ndarray | float | None:
        explicit = spec.get('max_command_joint_step')
        raw_limit = explicit if explicit is not None else spec.get('max_joint_step')
        if raw_limit is None:
            return None
        try:
            limit_values = np.asarray(raw_limit, dtype=float).reshape(-1)
        except Exception:
            return None
        if limit_values.size == 0 or not np.all(np.isfinite(limit_values)):
            return None
        if limit_values.size == 1:
            scalar_limit = float(limit_values[0])
            if scalar_limit <= 0.0:
                return scalar_limit
            if explicit is None:
                default_cap = float(spec.get('default_max_command_joint_step', 0.08))
                if default_cap > 0.0:
                    scalar_limit = min(scalar_limit, default_cap)
                limits = np.full(int(joint_count), scalar_limit, dtype=float)
                wrist_cap = float(spec.get('default_max_command_wrist_joint_step', 0.025))
                if wrist_cap > 0.0 and limits.shape[0] >= 6:
                    limits[3:] = np.minimum(limits[3:], wrist_cap)
                return limits
            return scalar_limit
        limits = np.full(int(joint_count), float(limit_values[-1]), dtype=float)
        copy_count = min(int(joint_count), int(limit_values.size))
        limits[:copy_count] = limit_values[:copy_count]
        return limits

    @staticmethod
    def _limit_command_to_measured_state(
        *,
        current_q: np.ndarray | None,
        command_q: np.ndarray,
        spec: dict,
    ) -> np.ndarray:
        command_q = np.asarray(command_q, dtype=float)
        if not bool(spec.get('limit_command_to_measured_state', True)):
            return command_q
        current_q = UR5eAssemblyAtomicSkillAdapter._coerce_arm_q(current_q, bound_revolute=False)
        if current_q is None or current_q.shape != command_q.shape:
            return command_q
        command_q = UR5eAssemblyAtomicSkillAdapter._joint_target_near_reference(
            target_q=command_q,
            reference_q=current_q,
            spec=spec,
            preferred_abs_limit=None,
            hard_preferred_abs_limit=False,
        )
        raw_limit = spec.get('max_command_tracking_error', 0.18)
        if raw_limit is None:
            return command_q
        try:
            values = np.asarray(raw_limit, dtype=float).reshape(-1)
        except Exception:
            return command_q
        if values.size == 0 or not np.all(np.isfinite(values)):
            return command_q
        if values.size == 1:
            limits = np.full(command_q.shape[0], float(values[0]), dtype=float)
        else:
            limits = np.full(command_q.shape[0], float(values[-1]), dtype=float)
            limits[: min(values.size, command_q.shape[0])] = values[: command_q.shape[0]]
        wrist_limit = spec.get('max_wrist_command_tracking_error', 0.12)
        if wrist_limit is not None and limits.shape[0] >= 6:
            try:
                wrist_limit = float(wrist_limit)
                if np.isfinite(wrist_limit) and wrist_limit > 0.0:
                    limits[3:] = np.minimum(limits[3:], wrist_limit)
            except Exception:
                pass
        if np.any(limits <= 0.0):
            return command_q
        return UR5eAssemblyAtomicSkillAdapter._limited_joint_target(
            current_q=current_q,
            target_q=command_q,
            max_joint_step=limits,
        )

    @staticmethod
    def _ik_branch_jump_detected(*, reference_q: np.ndarray, target_q: np.ndarray, spec: dict) -> bool:
        reference_q = np.asarray(reference_q, dtype=float)
        target_q = np.asarray(target_q, dtype=float)
        if reference_q.shape != target_q.shape:
            return False
        max_joint_step = float(spec.get('max_joint_step', spec.get('close_gate_max_joint_step', 0.035)))
        default_limit = max(0.18, max_joint_step * 4.0)
        jump_limit = float(spec.get('ik_branch_jump_limit', default_limit))
        if jump_limit <= 0.0:
            return False
        default_branch_joint_indices = [0, 3, reference_q.shape[0] - 1]
        branch_joint_indices = spec.get('ik_branch_guard_joint_indices', default_branch_joint_indices)
        try:
            indices = [int(index) for index in branch_joint_indices]
        except Exception:
            indices = default_branch_joint_indices
        deltas = []
        for index in indices:
            if 0 <= index < reference_q.shape[0]:
                deltas.append(abs(float(target_q[index] - reference_q[index])))
        if not deltas:
            return False
        return max(deltas) > jump_limit

    def _ik_branch_reference_q(
        self,
        *,
        phase_key,
        reference_q: np.ndarray,
        spec: dict,
    ) -> np.ndarray | None:
        """Use the measured/command reference until a phase has an accepted IK target."""

        if str(spec.get('ik_branch_jump_reference_mode', 'reference')).strip().lower() != 'previous_target':
            return reference_q
        previous_target_q = self._coerce_arm_q(
            self._last_targets.get(phase_key, {}).get('target_q'),
            bound_revolute=False,
            joint_count=reference_q.shape[0],
        )
        if previous_target_q is None and bool(spec.get('allow_initial_ik_branch_jump', False)):
            # The first free-space endpoint can be far from home while every
            # emitted command remains bounded by the per-joint step limiter.
            # Guard continuity once an accepted IK branch exists for the phase.
            return None
        return reference_q if previous_target_q is None else previous_target_q

    @staticmethod
    def _use_locked_transport_ik_target(spec: dict) -> bool:
        """Use one stable redundant IK solution for free-space held-object motion."""

        return bool(
            spec.get('lock_transport_ik_target', False)
            and spec.get('requires_held_object', False)
            and spec.get('target_object_target') is not None
            and spec.get('target_object_convergence_axis') is None
            and spec.get('target_object_final_target') is None
        )

    @staticmethod
    def _use_locked_pickup_ik_target(
        *,
        skill_name: str,
        spec: dict,
        current_pose: dict | None = None,
        target_pose: dict | None = None,
        already_locked: bool = False,
    ) -> bool:
        """Lock the terminal IK branch only inside the final pickup window."""

        configured = bool(
            spec.get('lock_pickup_ik_target', False)
            and skill_name in {'ur5e_descend_to_grasp', 'descend_to_grasp'}
            and spec.get('object') is not None
        )
        if not configured or current_pose is None or target_pose is None:
            return configured
        # Latch the terminal branch for the rest of the phase. Contact or PD
        # tracking can move the measured TCP just outside the entry window for
        # one frame; dropping back to Cartesian IK there compares a local
        # solution with the cached endpoint and falsely reports a branch jump.
        if already_locked:
            return True

        position_window = spec.get('pickup_terminal_ik_position_window')
        orientation_window = spec.get('pickup_terminal_ik_orientation_window')
        if position_window is None and orientation_window is None:
            return configured
        try:
            position_error, orientation_error = pose_error(
                current_position=current_pose['position'],
                current_orientation=current_pose['orientation'],
                target_position=target_pose['position'],
                target_orientation=target_pose['orientation'],
            )
            if position_window is not None and position_error > float(position_window):
                return False
            if (
                orientation_window is not None
                and orientation_error is not None
                and orientation_error > float(orientation_window)
            ):
                return False
        except (KeyError, TypeError, ValueError):
            return False
        return True

    def _locked_transport_ik_target(
        self,
        *,
        phase_key,
        task,
        robot_name: str,
        target_pose: dict,
        reference_q: np.ndarray | None,
        spec: dict,
    ) -> np.ndarray | None:
        if phase_key in self._continuous_transport_ik_fallbacks:
            return None
        cached = self._coerce_arm_q(
            self._locked_transport_ik_targets.get(phase_key),
            bound_revolute=False,
        )
        if cached is not None:
            return cached

        result = self._solve_ik(
            task=task,
            robot_name=robot_name,
            target_pose=target_pose,
            warm_start=reference_q,
            spec=spec,
        )
        if result is None and reference_q is not None:
            result = self._solve_ik(
                task=task,
                robot_name=robot_name,
                target_pose=target_pose,
                warm_start=None,
                spec={
                    **spec,
                    'use_command_warm_start': False,
                    'require_warm_start_ik': False,
                    'warm_start_ik_only': False,
                },
            )
        if result is None:
            # An exact free-space endpoint can be outside the local Panda
            # branch even when the segment leading to it is reachable.  Let
            # the caller switch to its bounded Cartesian continuation instead
            # of turning one failed endpoint solve into an episode failure.
            if bool(spec.get('locked_transport_fallback_on_ik_failure', True)):
                self._locked_transport_ik_targets.pop(phase_key, None)
                self._continuous_transport_ik_fallbacks.add(phase_key)
                print(
                    '[assembly-ik-target-lock] '
                    f"step={getattr(task, 'step_counter', None)} phase={getattr(task, 'phase', None)} "
                    f'robot={robot_name} fallback=continuous_cartesian reason=endpoint_ik_failed',
                    flush=True,
                )
            return None

        result = self._joint_target_near_reference(
            target_q=result,
            reference_q=reference_q,
            spec=spec,
            preferred_abs_limit=spec.get('preferred_joint_abs_limit', 3.05),
            hard_preferred_abs_limit=bool(spec.get('hard_preferred_joint_abs_limit', True)),
        )
        self._locked_transport_ik_targets[phase_key] = result.copy()
        maximum_joint_delta = None
        if reference_q is not None and reference_q.shape == result.shape:
            maximum_joint_delta = float(np.max(np.abs(result - reference_q)))
        fallback_limit = spec.get('locked_transport_fallback_joint_delta')
        if (
            maximum_joint_delta is not None
            and fallback_limit is not None
            and float(fallback_limit) > 0.0
            and maximum_joint_delta > float(fallback_limit)
        ):
            self._locked_transport_ik_targets.pop(phase_key, None)
            self._continuous_transport_ik_fallbacks.add(phase_key)
            print(
                '[assembly-ik-target-lock] '
                f"step={getattr(task, 'step_counter', None)} phase={getattr(task, 'phase', None)} "
                f'robot={robot_name} maximum_joint_delta={maximum_joint_delta} '
                f'fallback=continuous_cartesian limit={float(fallback_limit)}',
                flush=True,
            )
            return None
        print(
            '[assembly-ik-target-lock] '
            f"step={getattr(task, 'step_counter', None)} phase={getattr(task, 'phase', None)} "
            f'robot={robot_name} maximum_joint_delta={maximum_joint_delta}',
            flush=True,
        )
        return result

    def _solve_ik(
        self,
        *,
        task,
        robot_name: str,
        target_pose: dict,
        warm_start: np.ndarray | None = None,
        spec: dict | None = None,
    ) -> np.ndarray | None:
        robot = task.robots.get(robot_name)
        if robot is None:
            return None
        ik_controller = robot.controllers.get(_ARM_IK_CONTROLLER)
        if ik_controller is None or not hasattr(ik_controller, '_kinematics_solver'):
            return None
        spec = spec or {}
        target_position = np.asarray(target_pose['position'], dtype=float) / ik_controller._robot_scale  # noqa: SLF001
        target_orientation = np.asarray(target_pose['orientation'], dtype=float)
        warm_start = self._coerce_arm_q(warm_start)
        position_tolerance, orientation_tolerance = self._ik_solver_tolerances(spec)
        assisted_local = bool(spec.get('beam_assisted') and spec.get('requires_held_object'))
        if assisted_local and warm_start is None:
            warm_start = self._current_arm_q(task, robot_name)
        try:
            ik_base_pose = ik_controller.get_ik_base_world_pose()
            ik_controller._kinematics_solver.set_robot_base_pose(  # noqa: SLF001
                robot_position=ik_base_pose[0] / ik_controller._robot_scale,  # noqa: SLF001
                robot_orientation=ik_base_pose[1],
            )
            used_warm_start = warm_start is not None and (assisted_local or bool(spec.get('use_command_warm_start', True)))
            if used_warm_start:
                solver_wrapper = ik_controller._kinematics_solver  # noqa: SLF001
                raw_solver = None
                get_raw_solver = getattr(solver_wrapper, 'get_kinematics_solver', None)
                if callable(get_raw_solver):
                    raw_solver = get_raw_solver()
                if raw_solver is None:
                    raw_solver = getattr(solver_wrapper, '_kinematics_solver', None)
                if raw_solver is None:
                    raw_solver = getattr(solver_wrapper, '_kinematics', None)
                get_ee_frame = getattr(solver_wrapper, 'get_end_effector_frame', None)
                ee_frame = get_ee_frame() if callable(get_ee_frame) else getattr(solver_wrapper, '_ee_frame', None)
                if raw_solver is not None and ee_frame is not None:
                    if spec.get('beam_assisted') and spec.get('requires_held_object'):
                        from .beam_assisted_ik import bounded_local_ik
                        result, detail = bounded_local_ik(
                            lambda q: raw_solver.compute_forward_kinematics(ee_frame, q),
                            warm_start, target_position, target_orientation,
                            position_tolerance=float(position_tolerance or 1e-5),
                            orientation_tolerance=float(orientation_tolerance or 1e-4))
                        if int(task.step_counter) % 8 == 0 or result is None:
                            task._assisted_event('local_cartesian_inverse', robot=robot_name,
                                target_position=target_position,
                                target_orientation=target_orientation, **detail)
                        return result
                    restore_default_seeds = None
                    set_default_seeds = getattr(raw_solver, 'set_default_cspace_seeds', None)
                    if bool(spec.get('warm_start_ik_only', False)) and callable(set_default_seeds):
                        get_default_seeds = getattr(raw_solver, 'get_default_cspace_seeds', None)
                        if callable(get_default_seeds):
                            restore_default_seeds = list(get_default_seeds())
                            set_default_seeds([])
                    try:
                        ik_result, success = raw_solver.compute_inverse_kinematics(
                            ee_frame,
                            target_position,
                            target_orientation,
                            warm_start=warm_start,
                            position_tolerance=position_tolerance,
                            orientation_tolerance=orientation_tolerance,
                        )
                    finally:
                        if restore_default_seeds is not None:
                            try:
                                set_default_seeds(restore_default_seeds)
                            except Exception:
                                pass
                    if spec.get('inherit_grasp_drive_target'):
                        self._debug_loaded_ik(task=task, robot_name=robot_name,
                            raw_solver=raw_solver, frame=ee_frame, warm_start=warm_start,
                            result=ik_result, success=success, target_position=target_position,
                            target_orientation=target_orientation, spec=spec)
                    if success and ik_result is not None:
                        ik_result = np.asarray(ik_result, dtype=float)
                        if np.all(np.isfinite(ik_result)):
                            return ik_result
            if used_warm_start and bool(spec.get('require_warm_start_ik', False)):
                return None
            goal_action, success = ik_controller._kinematics_solver.compute_inverse_kinematics(  # noqa: SLF001
                target_position=target_position,
                target_orientation=target_orientation,
            )
        except Exception:
            return None
        if not success or goal_action is None or goal_action.joint_positions is None:
            return None
        joint_positions = np.asarray(goal_action.joint_positions, dtype=float)
        if not np.all(np.isfinite(joint_positions)):
            return None
        return joint_positions

    @staticmethod
    def _debug_loaded_ik(*, task, robot_name, raw_solver, frame, warm_start,
                         result, success, target_position, target_orientation, spec,
                         path='command_warm_start'):
        trace = os.environ.get('BEAM_MOTION_TRACE_PATH')
        if not trace:
            return
        detail = {'step': int(task.step_counter), 'phase': task.phase, 'robot': robot_name,
            'path': path, 'success': bool(success), 'frame': frame,
            'position_tolerance': spec.get('ik_position_tolerance'),
            'orientation_tolerance': spec.get('ik_orientation_tolerance'),
            'target_position': target_position.tolist(), 'target_orientation': target_orientation.tolist(),
            'warm_start': warm_start.tolist(), 'result': None if result is None else np.asarray(result).tolist()}
        for name, q in (('reference', warm_start), ('result', result)):
            if q is None:
                continue
            try:
                position, rotation = raw_solver.compute_forward_kinematics(frame, np.asarray(q))
                orientation = _quat_from_axes(rotation[:, 0], rotation[:, 1], rotation[:, 2])
                pos_error, rot_error = pose_error(current_position=position, current_orientation=orientation,
                    target_position=target_position, target_orientation=target_orientation)
                detail[name + '_fk'] = {'position': np.asarray(position).tolist(),
                    'orientation': orientation.tolist(), 'position_error': float(pos_error),
                    'orientation_error': float(rot_error)}
            except Exception as exc:
                detail[name + '_fk_error'] = f'{type(exc).__name__}: {exc}'
        path = os.path.join(os.path.dirname(trace), 'ik_trace.jsonl')
        with open(path, 'a', encoding='utf-8') as handle:
            handle.write(json.dumps(detail) + '\n')

    @staticmethod
    def _ik_solution_stalled(
        *,
        ik_result: np.ndarray | None,
        measured_q: np.ndarray | None,
        warm_start_q: np.ndarray | None,
        current_pose: dict | None,
        command_target_pose: dict,
        spec: dict,
    ) -> bool:
        """Detect a false-positive IK result that leaves a Cartesian servo static."""

        if ik_result is None or measured_q is None or current_pose is None:
            return ik_result is None
        candidate_q = np.asarray(ik_result, dtype=float)
        measured_q = np.asarray(measured_q, dtype=float)
        if candidate_q.shape != measured_q.shape or not np.all(np.isfinite(candidate_q)):
            return True
        joint_delta = float(np.max(np.abs(candidate_q - measured_q))) if candidate_q.size else 0.0
        warm_start_delta = math.inf
        if warm_start_q is not None:
            warm_start_q = np.asarray(warm_start_q, dtype=float)
            if warm_start_q.shape == candidate_q.shape and np.all(np.isfinite(warm_start_q)):
                warm_start_delta = (
                    float(np.max(np.abs(candidate_q - warm_start_q))) if candidate_q.size else 0.0
                )
        stationary_joint_tolerance = max(float(spec.get('ik_stationary_joint_tolerance', 1e-6)), 0.0)
        if min(joint_delta, warm_start_delta) > stationary_joint_tolerance:
            return False
        position_error, orientation_error = pose_error(
            current_pose['position'],
            current_pose['orientation'],
            command_target_pose['position'],
            command_target_pose['orientation'],
        )
        position_tolerance, orientation_tolerance = UR5eAssemblyAtomicSkillAdapter._ik_solver_tolerances(spec)
        position_threshold = max(
            float(spec.get('ik_stationary_position_error', 0.0)),
            2.0 * float(position_tolerance or 0.0),
            0.25 * float(spec.get('cartesian_position_step', 0.0)),
            1e-5,
        )
        orientation_threshold = max(
            float(spec.get('ik_stationary_orientation_error', 0.0)),
            2.0 * float(orientation_tolerance or 0.0),
            0.25 * float(spec.get('cartesian_orientation_step', 0.0)),
            1e-4,
        )
        return bool(
            position_error is not None
            and float(position_error) > position_threshold
            or orientation_error is not None
            and float(orientation_error) > orientation_threshold
        )

    @staticmethod
    def _ik_solver_tolerances(spec: dict) -> tuple[float | None, float | None]:
        """Keep Lula's convergence deadband smaller than one Cartesian servo step."""

        position_tolerance = spec.get('ik_position_tolerance')
        orientation_tolerance = spec.get('ik_orientation_tolerance')
        if not bool(spec.get('cartesian_servo', False)):
            return position_tolerance, orientation_tolerance

        if position_tolerance is None:
            position_step = float(spec.get('cartesian_position_step', 0.01))
            if np.isfinite(position_step) and position_step > 0.0:
                position_tolerance = max(min(position_step * 0.05, 5e-4), 1e-5)
        if orientation_tolerance is None:
            orientation_step = float(spec.get('cartesian_orientation_step', 0.01))
            if np.isfinite(orientation_step) and orientation_step > 0.0:
                orientation_tolerance = max(min(orientation_step * 0.1, 2e-3), 1e-4)
        return position_tolerance, orientation_tolerance

    @staticmethod
    def _limited_joint_target(*, current_q: np.ndarray, target_q: np.ndarray, max_joint_step) -> np.ndarray:
        current_q = np.asarray(current_q, dtype=float)
        target_q = np.asarray(target_q, dtype=float)
        if not np.all(np.isfinite(current_q)):
            return target_q
        if not np.all(np.isfinite(target_q)):
            return current_q
        if current_q.shape != target_q.shape:
            return target_q
        try:
            step_limits = np.asarray(max_joint_step, dtype=float).reshape(-1)
        except Exception:
            return target_q
        if step_limits.size == 0 or not np.all(np.isfinite(step_limits)):
            return target_q
        if step_limits.size == 1:
            scalar_limit = float(step_limits[0])
            if scalar_limit <= 0.0:
                return target_q
            delta = target_q - current_q
            max_abs = float(np.max(np.abs(delta))) if delta.size else 0.0
            if max_abs <= scalar_limit:
                return target_q
            return current_q + delta * (scalar_limit / max_abs)
        if step_limits.size < current_q.shape[0]:
            padded = np.full(current_q.shape[0], float(step_limits[-1]), dtype=float)
            padded[: step_limits.size] = step_limits
            step_limits = padded
        else:
            step_limits = step_limits[: current_q.shape[0]]
        if np.any(step_limits <= 0.0):
            return target_q
        delta = target_q - current_q
        if np.all(np.abs(delta) <= step_limits):
            return target_q
        nonzero = np.abs(delta) > 1e-12
        scale = float(np.min(step_limits[nonzero] / np.abs(delta[nonzero]))) if np.any(nonzero) else 1.0
        return current_q + delta * min(scale, 1.0)

    @staticmethod
    def _unwrap_to_reference(
        *,
        target_q: np.ndarray,
        reference_q: np.ndarray | None,
        preferred_abs_limit=None,
        hard_preferred_abs_limit: bool = True,
    ) -> np.ndarray:
        target_q = np.asarray(target_q, dtype=float).copy()
        if reference_q is None:
            return target_q
        reference_q = np.asarray(reference_q, dtype=float)
        if target_q.shape != reference_q.shape:
            return target_q

        period = 2.0 * np.pi
        preferred_abs_limit = None if preferred_abs_limit is None else float(preferred_abs_limit)
        for joint_index, target_value in enumerate(target_q):
            candidates = target_value + np.arange(-4, 5, dtype=float) * period
            nearest_candidate = candidates[int(np.argmin(np.abs(candidates - reference_q[joint_index])))]
            if hard_preferred_abs_limit and preferred_abs_limit is not None and preferred_abs_limit > 0.0:
                bounded = candidates[np.abs(candidates) <= preferred_abs_limit]
                if bounded.size:
                    bounded_candidate = bounded[int(np.argmin(np.abs(bounded - reference_q[joint_index])))]
                    nearest_delta = abs(float(nearest_candidate - reference_q[joint_index]))
                    bounded_delta = abs(float(bounded_candidate - reference_q[joint_index]))
                    # A preferred range must not turn an equivalent +/-pi wrap
                    # into an almost 2*pi command jump.
                    if bounded_delta <= max(0.5, nearest_delta * 4.0):
                        candidates = bounded
            cost = np.abs(candidates - reference_q[joint_index])
            if not hard_preferred_abs_limit and preferred_abs_limit is not None and preferred_abs_limit > 0.0:
                cost = cost + 2.0 * np.maximum(np.abs(candidates) - preferred_abs_limit, 0.0)
            target_q[joint_index] = candidates[int(np.argmin(cost))]
        return target_q

    @staticmethod
    def _joint_target_near_reference(
        *,
        target_q: np.ndarray,
        reference_q: np.ndarray | None,
        spec: dict,
        preferred_abs_limit=None,
        hard_preferred_abs_limit: bool = True,
    ) -> np.ndarray:
        """Normalize IK output according to the platform's joint topology."""

        target_q = np.asarray(target_q, dtype=float).copy()
        if not bool(spec.get('unwrap_revolute_joints', True)):
            return target_q
        return UR5eAssemblyAtomicSkillAdapter._unwrap_to_reference(
            target_q=target_q,
            reference_q=reference_q,
            preferred_abs_limit=preferred_abs_limit,
            hard_preferred_abs_limit=hard_preferred_abs_limit,
        )

    def _hold_joint_action(self, *, task, robot_name: str) -> OrderedDict:
        action = OrderedDict()
        current_q = self._current_arm_q(task, robot_name)
        hold_q = self._command_reference_q(task=task, robot_name=robot_name, current_q=current_q, spec={})
        if hold_q is not None:
            action[_ARM_JOINT_CONTROLLER] = [hold_q.tolist()]
        return action

    def _move_arm_to_joint_positions_action(
        self,
        *,
        phase_key,
        task,
        robot_name: str,
        skill_name: str,
        spec: dict,
    ) -> OrderedDict:
        current_q = self._current_arm_q(task, robot_name)
        if current_q is None:
            return self._failure_or_hold(task, robot_name, spec, 'current_joint_state_unavailable')

        delta_state = None
        if 'beam_assisted_joint_target_delta' in spec:
            try:
                delta = np.asarray(spec['beam_assisted_joint_target_delta'], dtype=float)
                if (not spec.get('beam_assisted_native_joint_target')
                        or current_q.shape != (6,) or delta.shape != (6,)
                        or not np.all(np.isfinite([current_q, delta]))):
                    raise ValueError('native delta target needs six finite measured joints and deltas')
                delta_state = self._completion_state.setdefault(phase_key, {}).get('native_delta_target')
                if delta_state is None:
                    delta_state = {'entry_joint_positions': current_q.tolist(),
                        'delta_joint_positions': delta.tolist(),
                        'target_joint_positions': (current_q + delta).tolist()}
                    self._completion_state[phase_key]['native_delta_target'] = delta_state
                    event = getattr(task, '_assisted_event', None)
                    if callable(event):
                        event('native_joint_target_entry', robot=robot_name,
                              **copy.deepcopy(delta_state))
                if delta_state['delta_joint_positions'] != delta.tolist():
                    raise ValueError('native joint delta changed within the same phase entry')
                target_q = np.asarray(delta_state['target_joint_positions'], dtype=float)
                if target_q.shape != (6,) or not np.all(np.isfinite(target_q)):
                    raise ValueError('captured native delta target is invalid')
            except (TypeError, ValueError, KeyError) as exc:
                return self._failure_or_hold(task, robot_name,
                    {**spec, 'require_success': True}, 'invalid_native_joint_target_delta',
                    diagnostics={'error': str(exc)})
        else:
            target_q = self._coerce_arm_q(
                spec.get('joint_positions'),
                bound_revolute=False,
                joint_count=current_q.shape[0],
            )
        if target_q is None or target_q.shape != current_q.shape:
            return self._failure_or_hold(
                task,
                robot_name,
                spec,
                'invalid_joint_target',
                diagnostics={'joint_positions': spec.get('joint_positions')},
            )

        reference_q = self._command_reference_q(
            task=task,
            robot_name=robot_name,
            current_q=current_q,
            spec=spec,
        )
        if reference_q is None or reference_q.shape != target_q.shape:
            reference_q = current_q
        target_q = self._joint_target_near_reference(
            target_q=target_q,
            reference_q=reference_q,
            spec=spec,
            preferred_abs_limit=spec.get('preferred_joint_abs_limit'),
            hard_preferred_abs_limit=False,
        )
        step_limits = self._command_joint_step_limits(
            spec=spec,
            joint_count=current_q.shape[0],
        )
        if step_limits is None:
            step_limits = float(spec.get('max_joint_step', 0.020))
        command_q = self._limited_joint_target(
            current_q=reference_q,
            target_q=target_q,
            max_joint_step=step_limits,
        )
        command_q = self._continuous_command_q(
            task=task,
            robot_name=robot_name,
            command_q=command_q,
            spec=spec,
        )
        command_q = self._limit_command_to_measured_state(
            current_q=current_q,
            command_q=command_q,
            spec=spec,
        )

        action = OrderedDict()
        action[_ARM_JOINT_CONTROLLER] = [command_q.tolist()]
        action[_GRIPPER_CONTROLLER] = [
            self._gripper_command_value(
                task=task,
                robot_name=robot_name,
                command=spec.get('gripper_command', 'open'),
            )
        ]
        self._remember_arm_command(task, robot_name, command_q)

        joint_error = float(np.max(np.abs(target_q - current_q)))
        tolerance = float(spec.get('joint_position_tolerance', 0.025))
        phase_step = int(getattr(task, 'phase_step_counter', 0))
        debug_every = max(int(os.environ.get('UR5E_DEBUG_JOINT_TARGET_EVERY', '120')), 1)
        if self._debug_grasp_enabled() and (phase_step <= 5 or phase_step % debug_every == 0):
            print(
                '[assembly-joint-target-debug] '
                f"step={getattr(task, 'step_counter', None)} phase={getattr(task, 'phase', None)} "
                f'phase_step={phase_step} robot={robot_name} joint_error={joint_error} '
                f'tolerance={tolerance} current_q={current_q.tolist()} '
                f'target_q={target_q.tolist()} command_q={command_q.tolist()}',
                flush=True,
            )
        state = self._completion_state.setdefault(phase_key, {})
        if spec.get('beam_assisted_native_joint_target'):
            from .beam_assisted_state import consecutive_native_gate
            native_gate = state.setdefault('joint_target_native_gate', {})
            reader = getattr(task, '_beam_physics_stamp', None)
            native_stamp = reader() if callable(reader) else {'valid': False}
            if not isinstance(native_stamp, dict):
                native_stamp = {'valid': False}
            qualified = consecutive_native_gate(native_gate, native_stamp, joint_error <= tolerance,
                max(int(spec.get('joint_target_stable_steps', 8)), 1))
            state['joint_target_stable_steps'] = native_gate.get('count', 0)
            state['joint_target_native_qualified'] = qualified
        elif joint_error <= tolerance:
            state['joint_target_stable_steps'] = int(state.get('joint_target_stable_steps', 0)) + 1
        else:
            state['joint_target_stable_steps'] = 0
        stable_steps = int(state['joint_target_stable_steps'])
        required_stable_steps = max(int(spec.get('joint_target_stable_steps', 8)), 1)
        if (state.get('joint_target_native_qualified') if spec.get('beam_assisted_native_joint_target')
                else stable_steps >= required_stable_steps):
            detail = {
                'target_joint_positions': target_q.tolist(),
                'joint_error': joint_error,
                'joint_position_tolerance': tolerance,
                'stable_steps': stable_steps,
                'required_stable_steps': required_stable_steps,
            }
            if delta_state is not None:
                detail['native_delta_target'] = copy.deepcopy(delta_state)
            self._mark_complete(
                task=task,
                robot_name=robot_name,
                skill_name=skill_name,
                detail=detail,
            )
        return action

    def _preshape_gripper_action(
        self,
        *,
        phase_key,
        task,
        robot_name: str,
        skill_name: str,
        spec: dict,
        tracked_objects: dict,
    ) -> OrderedDict:
        action = self._hold_joint_action(task=task, robot_name=robot_name)
        openness = self._gripper_value(spec.get('gripper_openness', spec.get('gripper_command', 1.0)))
        action[_GRIPPER_CONTROLLER] = [openness]

        state = self._preshape_state.setdefault(phase_key, {'stable_steps': 0})
        gripper_q = self._current_gripper_q(task=task, robot_name=robot_name)
        open_q, closed_q = self._gripper_open_closed_q(task=task, robot_name=robot_name)
        target_q = None
        actual_openness = None
        if open_q is not None and closed_q is not None:
            target_q = float(open_q) + (1.0 - openness) * (float(closed_q) - float(open_q))
            joint_span = float(closed_q) - float(open_q)
            if gripper_q is not None and abs(joint_span) > 1e-9:
                actual_openness = float(
                    np.clip(1.0 - (float(gripper_q) - float(open_q)) / joint_span, 0.0, 1.0)
                )
        target_gripper_ready = bool(
            gripper_q is not None
            and target_q is not None
            and abs(float(gripper_q) - target_q) <= float(spec.get('gripper_position_tolerance', 0.015))
        )
        minimum_openness = spec.get('minimum_gripper_openness')
        minimum_opening_ready = False
        if minimum_openness is not None:
            minimum_openness = float(minimum_openness)
            if not np.isfinite(minimum_openness) or not 0.0 <= minimum_openness <= 1.0:
                return self._failure_or_hold(
                    task,
                    robot_name,
                    spec,
                    'invalid_minimum_gripper_openness',
                    diagnostics={'minimum_gripper_openness': minimum_openness},
                )
            minimum_opening_ready = bool(
                actual_openness is not None and actual_openness >= minimum_openness
            )
        # Exact aperture remains preferred.  The geometric minimum is a safe
        # fallback only when it preserves the clearance needed for the grasp.
        gripper_ready = bool(target_gripper_ready or minimum_opening_ready)

        motion_detail = {'valid': True, 'checked': False}
        motion_ready = True
        if bool(spec.get('require_object_static', True)):
            motion_detail = self._object_motion_detail(
                task=task,
                object_name=self._object_name_from_spec(spec),
                tracked_objects=tracked_objects,
            )
            motion_detail['checked'] = True
            linear_speed = motion_detail.get('linear_speed')
            angular_speed = motion_detail.get('angular_speed')
            velocity_ready = bool(
                motion_detail.get('valid')
                and linear_speed is not None
                and angular_speed is not None
                and float(linear_speed) <= float(spec.get('max_object_linear_speed', 0.01))
                and float(angular_speed) <= float(spec.get('max_object_angular_speed', 0.10))
            )
            pose_stable_ready = bool(
                spec.get('allow_pose_stable_override', True) and motion_detail.get('pose_stable_override') is True
            )
            motion_ready = bool(velocity_ready or pose_stable_ready)

        if gripper_ready and motion_ready:
            state['stable_steps'] = int(state.get('stable_steps', 0)) + 1
        else:
            state['stable_steps'] = 0
        required_stable_steps = max(int(spec.get('stable_steps', 12)), 1)
        detail = {
            'gripper_openness': openness,
            'gripper_joint_position': None if gripper_q is None else float(gripper_q),
            'target_gripper_joint_position': target_q,
            'actual_gripper_openness': actual_openness,
            'minimum_gripper_openness': minimum_openness,
            'target_gripper_ready': target_gripper_ready,
            'minimum_opening_ready': minimum_opening_ready,
            'gripper_ready': gripper_ready,
            'motion_ready': motion_ready,
            'motion_detail': motion_detail,
            'stable_steps': int(state['stable_steps']),
            'required_stable_steps': required_stable_steps,
        }
        if int(state['stable_steps']) >= required_stable_steps:
            self._mark_complete(
                task=task,
                robot_name=robot_name,
                skill_name=skill_name,
                detail=detail,
            )
        elif int(getattr(task, 'phase_step_counter', 0)) >= int(spec.get('preshape_timeout_steps', 240)):
            return self._failure_or_hold(
                task,
                robot_name,
                spec,
                'preshape_not_stable',
                diagnostics=detail,
            )
        return action

    @staticmethod
    def _gripper_value(command) -> float:
        if isinstance(command, str):
            lowered = command.strip().lower()
            if lowered == 'open':
                return 1.0
            if lowered == 'close':
                return 0.0
        try:
            return float(np.clip(float(command), 0.0, 1.0))
        except Exception:
            return 1.0

    def _gripper_command_value(self, *, task, robot_name: str, command) -> float:
        if isinstance(command, str) and command.strip().lower() in {'contact_hold', 'hold_contact', 'grasp_hold'}:
            hold_openness = self._last_gripper_hold_openness(task=task, robot_name=robot_name)
            if hold_openness is not None:
                return float(hold_openness)
            return 0.0
        return self._gripper_value(command)

    @staticmethod
    def _last_gripper_hold_openness(*, task, robot_name: str) -> float | None:
        cache = getattr(task, '_ur5e_plumbers_gripper_hold_openness', None)
        if not isinstance(cache, dict):
            return None
        value = cache.get(robot_name)
        if value is None:
            return None
        try:
            return float(np.clip(float(value), 0.0, 1.0))
        except Exception:
            return None

    @staticmethod
    def _remember_gripper_hold_openness(*, task, robot_name: str, openness: float) -> None:
        cache = getattr(task, '_ur5e_plumbers_gripper_hold_openness', None)
        if not isinstance(cache, dict):
            cache = {}
            setattr(task, '_ur5e_plumbers_gripper_hold_openness', cache)
        cache[robot_name] = float(np.clip(float(openness), 0.0, 1.0))

    @staticmethod
    def _gripper_openness_from_q(
        *,
        gripper_q: float | None,
        open_q: float | None,
        closed_q: float | None,
        squeeze_margin: float,
    ) -> float | None:
        if gripper_q is None or open_q is None or closed_q is None:
            return None
        denom = float(open_q) - float(closed_q)
        if abs(denom) < 1e-8:
            return None
        openness = (float(gripper_q) - float(closed_q)) / denom
        return float(np.clip(openness - float(squeeze_margin), 0.0, 1.0))

    @staticmethod
    def _object_name_from_spec(spec: dict) -> str | None:
        object_name = spec.get('held_object') or spec.get('object') or spec.get('object_name')
        if object_name is None:
            return None
        return str(object_name)

    def _object_motion_detail(
        self,
        *,
        task,
        object_name: str | None,
        tracked_objects: dict,
    ) -> dict[str, Any]:
        if not object_name:
            return {'valid': False, 'reason': 'missing_object_name'}
        state = tracked_objects.get(object_name, {}) if isinstance(tracked_objects, dict) else {}
        linear_speed = state.get('linear_speed')
        angular_speed = state.get('angular_speed')
        linear_velocity = state.get('linear_velocity')
        angular_velocity = state.get('angular_velocity')
        is_static = state.get('is_static')
        pose_stable_override = state.get('pose_stable_override')
        pose_stability_position_drift = state.get('pose_stability_position_drift')
        pose_stability_orientation_drift = state.get('pose_stability_orientation_drift')

        if linear_speed is None and linear_velocity is not None:
            try:
                linear_speed = float(np.linalg.norm(np.asarray(linear_velocity, dtype=float)))
            except Exception:
                linear_speed = None
        if angular_speed is None and angular_velocity is not None:
            try:
                angular_speed = float(np.linalg.norm(np.asarray(angular_velocity, dtype=float)))
            except Exception:
                angular_speed = None

        if (
            linear_speed is None
            or angular_speed is None
            or pose_stable_override is None
            or pose_stability_position_drift is None
            or pose_stability_orientation_drift is None
        ):
            velocity_fn = getattr(task, '_object_velocity_metrics', None)
            if callable(velocity_fn):
                try:
                    metrics = velocity_fn(object_name)
                    linear_speed = metrics.get('linear_speed', linear_speed)
                    angular_speed = metrics.get('angular_speed', angular_speed)
                    linear_velocity = metrics.get('linear_velocity', linear_velocity)
                    angular_velocity = metrics.get('angular_velocity', angular_velocity)
                    is_static = metrics.get('is_static', is_static)
                    pose_stable_override = metrics.get('pose_stable_override', pose_stable_override)
                    pose_stability_position_drift = metrics.get(
                        'pose_stability_position_drift',
                        pose_stability_position_drift,
                    )
                    pose_stability_orientation_drift = metrics.get(
                        'pose_stability_orientation_drift',
                        pose_stability_orientation_drift,
                    )
                except Exception:
                    pass

        valid = linear_speed is not None and angular_speed is not None
        return {
            'valid': bool(valid),
            'object': object_name,
            'linear_speed': None if linear_speed is None else float(linear_speed),
            'angular_speed': None if angular_speed is None else float(angular_speed),
            'linear_velocity': linear_velocity,
            'angular_velocity': angular_velocity,
            'is_static': None if is_static is None else bool(is_static),
            'pose_stable_override': None if pose_stable_override is None else bool(pose_stable_override),
            'pose_stability_position_drift': (
                None if pose_stability_position_drift is None else float(pose_stability_position_drift)
            ),
            'pose_stability_orientation_drift': (
                None if pose_stability_orientation_drift is None else float(pose_stability_orientation_drift)
            ),
        }

    @staticmethod
    def _pose_history_velocity_override_ready(
        *,
        spec: dict,
        motion_detail: dict,
    ) -> bool:
        if not bool(spec.get('target_object_allow_pose_history_velocity_override', False)):
            return False
        position_drift = motion_detail.get('pose_stability_position_drift')
        orientation_drift = motion_detail.get('pose_stability_orientation_drift')
        if position_drift is None or orientation_drift is None:
            return False
        position_tolerance = float(spec.get('pose_history_velocity_override_position_tolerance', 0.0005))
        orientation_tolerance = float(spec.get('pose_history_velocity_override_orientation_tolerance', 0.01))
        if (
            not np.isfinite(position_tolerance)
            or position_tolerance <= 0.0
            or not np.isfinite(orientation_tolerance)
            or orientation_tolerance <= 0.0
        ):
            return False
        return bool(
            motion_detail.get('valid')
            and motion_detail.get('is_static') is True
            and motion_detail.get('pose_stable_override') is True
            and np.isfinite(float(position_drift))
            and np.isfinite(float(orientation_drift))
            and float(position_drift) <= position_tolerance
            and float(orientation_drift) <= orientation_tolerance
        )

    def _object_tcp_slip_failure(
        self,
        *,
        phase_key,
        task,
        robot_name: str,
        spec: dict,
        tracked_objects: dict,
        current_pose: dict | None,
    ) -> dict[str, Any] | None:
        max_slip = spec.get('max_object_tcp_slip')
        if max_slip is None or current_pose is None:
            return None
        object_name = self._object_name_from_spec(spec)
        if object_name is None:
            return None
        _, _, attachment_mode = self._compliant_attachment_allowance(
            object_name=object_name,
            tracked_objects=tracked_objects,
        )
        if (
            attachment_mode == 'compliant_joint'
            and bool(spec.get('require_target_object_pose_convergence', False))
            and bool(spec.get('allow_compliant_object_tcp_slip', True))
        ):
            # A compliant insertion intentionally lets the part move relative
            # to the TCP. Its physical joint and object-pose convergence gates
            # remain authoritative; the rigid-grasp slip gate is not.
            return None
        object_pose = self._object_pose(
            task=task,
            object_name=object_name,
            tracked_objects=tracked_objects,
        )
        if object_pose is None:
            return None

        current_relative_world = np.asarray(object_pose['position'], dtype=float) - np.asarray(
            current_pose['position'], dtype=float
        )
        current_relative_tcp = quat_rotate(
            self._quat_conjugate(current_pose['orientation']),
            current_relative_world,
        )
        if current_relative_tcp.shape != (3,) or not np.all(np.isfinite(current_relative_tcp)):
            return None
        state = self._grasp_slip_state.setdefault(phase_key, {})
        if 'initial_relative_tcp_position' not in state:
            state['initial_relative_tcp_position'] = current_relative_tcp.copy()
            state['initial_relative_world_position'] = current_relative_world.copy()
            state['initial_object_position'] = np.asarray(object_pose['position'], dtype=float).copy()
            state['initial_tcp_position'] = np.asarray(current_pose['position'], dtype=float).copy()
            state['initial_tcp_orientation'] = normalize_quat(current_pose['orientation']).copy()
            return None

        initial_relative_tcp = np.asarray(state['initial_relative_tcp_position'], dtype=float)
        slip = float(np.linalg.norm(current_relative_tcp - initial_relative_tcp))
        threshold = float(max_slip)
        if slip <= threshold:
            return None
        initial_relative_world = np.asarray(
            state.get('initial_relative_world_position', current_relative_world),
            dtype=float,
        )
        return {
            'object': object_name,
            'robot': robot_name,
            'slip': slip,
            'slip_frame': 'tcp',
            'max_object_tcp_slip': threshold,
            'initial_relative_position': initial_relative_tcp.tolist(),
            'current_relative_position': current_relative_tcp.tolist(),
            'initial_relative_tcp_position': initial_relative_tcp.tolist(),
            'current_relative_tcp_position': current_relative_tcp.tolist(),
            'initial_relative_world_position': initial_relative_world.tolist(),
            'current_relative_world_position': current_relative_world.tolist(),
            'world_relative_delta': float(np.linalg.norm(current_relative_world - initial_relative_world)),
            'initial_tcp_orientation': np.asarray(state.get('initial_tcp_orientation'), dtype=float).tolist(),
            'current_tcp_orientation': normalize_quat(current_pose['orientation']).tolist(),
            'initial_object_position': np.asarray(state.get('initial_object_position'), dtype=float).tolist(),
            'initial_tcp_position': np.asarray(state.get('initial_tcp_position'), dtype=float).tolist(),
            'current_object_position': np.asarray(object_pose['position'], dtype=float).tolist(),
            'current_tcp_position': np.asarray(current_pose['position'], dtype=float).tolist(),
        }

    @staticmethod
    def _close_object_motion_abort(
        *,
        close_detail: dict[str, Any],
        spec: dict,
        close_elapsed_steps: int,
    ) -> bool:
        if not bool(spec.get('close_abort_on_object_motion', False)):
            return False
        min_steps = int(spec.get('close_abort_min_steps', 0))
        if int(close_elapsed_steps) < min_steps:
            return False
        motion_detail = close_detail.get('motion_detail')
        if not isinstance(motion_detail, dict) or not bool(motion_detail.get('valid')):
            return False
        linear_speed = motion_detail.get('linear_speed')
        angular_speed = motion_detail.get('angular_speed')
        max_linear_speed = spec.get('close_abort_max_object_speed', spec.get('close_contact_max_object_speed'))
        max_angular_speed = spec.get('close_abort_max_angular_speed', spec.get('close_contact_max_angular_speed'))
        linear_abort = (
            max_linear_speed is not None and linear_speed is not None and float(linear_speed) > float(max_linear_speed)
        )
        angular_abort = (
            max_angular_speed is not None
            and angular_speed is not None
            and float(angular_speed) > float(max_angular_speed)
        )
        return bool(linear_abort or angular_abort)

    @staticmethod
    def _known_probe_force(finger):
        """Return a reliable force; an unavailable observation stays unknown."""
        if not finger.get('force_probe_valid'):
            return None
        try:
            force = float(finger['force'])
        except (KeyError, TypeError, ValueError):
            return None
        return force if np.isfinite(force) else None

    @staticmethod
    def _contact_close_control(*, state: dict, spec: dict, metrics: dict,
                               gripper_q: float, open_q: float, closed_q: float,
                               requested_openness: float, min_openness: float) -> dict:
        """Position-based force regulation; contact capture is separate from success."""
        fingers = [metrics.get(side) or {} for side in ('left_finger', 'right_finger')]
        track_weak_side = bool(spec.get('close_force_recenter_track_weak_side', False))
        if track_weak_side:
            forces = [UR5eAssemblyAtomicSkillAdapter._known_probe_force(f) for f in fingers]
            valid = all(force is not None for force in forces)
        else:
            valid = all(f.get('force_probe_valid') and np.isfinite(f.get('force', float('nan'))) for f in fingers)
            forces = [float(f.get('force', 0.0)) for f in fingers]
        threshold = float(spec.get('contact_force_threshold', 0.1))
        dt = float((fingers[0].get('force_observation') or {}).get('physics_dt', 1.0 / 240.0))
        if not np.isfinite(dt) or dt <= 0:
            raise ValueError('Invalid contact control timestep')
        span = abs(closed_q - open_q)
        if span <= 1e-8 or not np.isfinite(gripper_q):
            raise ValueError('Invalid gripper state for contact regulation')
        direction = math.copysign(1.0, closed_q - open_q)
        measured = (gripper_q - open_q) * direction
        previous = float(state.get('contact_command_closure', measured))
        requested = span * (1.0 - max(requested_openness, min_openness))
        maximum = span * (1.0 - min_openness)
        loaded = [valid and force >= threshold for force in forces]
        first_contact = any(loaded) and not state.get('contact_control_active', False)
        if first_contact:
            state['contact_control_active'] = True
            state['contact_capture_closure'] = measured
            previous = measured  # Discard the advancing pre-contact trajectory.
        peak = max(forces) if valid else 0.0
        force_low = float(spec.get('close_force_low', 4.0))
        force_high = float(spec.get('close_force_high', 12.0))
        force_limit = float(spec.get('close_force_limit', 40.0))
        rate = float(spec.get('close_force_joint_rate', 0.025))
        if not valid:
            command = min(previous, measured)
            mode = 'invalid_probe_hold'
            if track_weak_side and any(force is not None and force >= force_limit for force in forces):
                command -= float(spec.get('close_force_unload_rate', 0.06)) * dt
                mode = 'force_limit_unload'
        elif state.get('contact_control_active'):
            maximum = min(maximum, float(state['contact_capture_closure']) + float(spec.get('close_force_max_seek', 0.03)))
            if peak > force_high:
                unload_rate = float(spec.get('close_force_unload_rate', 0.06)) if peak > force_limit else rate
                # Ordinary regulation changes the last published target at its
                # configured rate. Tracking lag is not another target increment.
                # Hard overload retains its separate emergency unwind path.
                reference = min(previous, measured) if peak > force_limit else previous
                command = reference - unload_rate * dt
                mode = 'force_limit_unload' if peak > force_limit else 'unload'
            elif peak < force_low:
                lead_limit = measured + float(spec.get('close_force_max_command_lead', 0.001))
                # Pause an already leading target rather than rebasing it down
                # to a lagging measurement while nominally seeking more closure.
                command = min(previous + rate * dt, max(previous, lead_limit))
                mode = 'gentle_seek' if not any(loaded) else 'preload'
            else:
                command = previous
                mode = 'bilateral_hold' if all(loaded) else 'single_contact_hold'
        else:
            # Jaw width is only a speed cue, never a contact/success substitute.
            expected = span * (1.0 - float(spec.get('jaw_width_thickness_m', 0.018)) /
                               float(spec.get('jaw_width_stroke_m', 0.085)))
            slow_start = max(expected - float(spec.get('close_approach_joint_margin', 0.06)), 0.0)
            if max(previous, measured) >= slow_start:
                command = min(requested, previous + float(spec.get('close_approach_joint_rate', 0.10)) * dt)
                mode = 'slow_approach'
            else:
                command = min(requested, slow_start)
                mode = 'approach'
        command = float(np.clip(command, 0.0, maximum))
        state['contact_command_closure'] = command
        openness = float(np.clip(1.0 - command / span, min_openness, 1.0))
        state['hold_gripper_openness'] = openness
        return {'mode': mode, 'probe_valid': bool(valid), 'forces': forces,
                'first_contact': bool(first_contact), 'contact_control_active': bool(state.get('contact_control_active')),
                'physics_dt': dt, 'force_limit': force_limit,
                'force_low': force_low, 'force_high': force_high, 'peak_force': peak,
                'force_within_limit': bool(valid and peak <= force_limit),
                'command_q': float(open_q + direction * command), 'command_openness': openness}

    def _record_recenter_final_action(self, *, state, pending, action, task, robot_name, spec):
        """Record the final returned action, without claiming SDK execution."""
        q = self._coerce_arm_q((action.get(_ARM_JOINT_CONTROLLER) or [None])[0], bound_revolute=False)
        pose = None if q is None else self._grasp_command_fk_pose(
            task=task, robot_name=robot_name, spec=spec, command_q=q,
        )
        start = state.get('close_tcp_position_world')
        if pose is None or start is None:
            return False
        start = np.asarray(start, dtype=float)
        delta = np.asarray(pending['motion_delta_world'], dtype=float)
        if start.shape != (3,) or not np.all(np.isfinite(start)):
            return False
        # The measured increment starts at issuance, not at planning. Keep
        # its nominal displacement and fixed anchor separate from model FK.
        pending.update(
            lifecycle='final_action_issued', issued_step=int(task.step_counter),
            motion_start_position_world=start.copy(),
            motion_target_position_world=start + delta,
            issued_command_q=q.copy(),
            issued_command_tcp_position_world=np.asarray(pose['position']).copy(),
            elapsed_steps=0, settle_steps=0,
        )
        state['recenter_target_ready'] = False
        path = os.environ.get('BEAM_RECENTER_LIFECYCLE_TRACE_PATH')
        if path:
            with open(path, 'a', encoding='utf-8') as handle:
                handle.write(json.dumps({
                    'step': int(task.step_counter), 'phase': task.phase, 'robot': robot_name,
                    'lifecycle': pending['lifecycle'], 'planned_step': pending.get('planned_step'),
                    'issued_command_q': q.tolist(),
                    'issued_command_tcp_position_world': np.asarray(pose['position']).tolist(),
                    'motion_start_position_world': start.tolist(),
                    'motion_target_position_world': (start + delta).tolist(),
                    'motion_delta_world': delta.tolist(),
                    'evidence_level': 'final returned action; SDK/native execution requires separate feedback',
                }) + '\n')
        return True

    @staticmethod
    def _stop_recenter_on_bilateral(*, state, spec, metrics, current_position):
        """Cancel unexecuted translation; this event never declares a grasp."""
        pending = state.get('force_recenter_pending')
        if pending is None:
            return None
        fingers = [metrics.get(s) or {} for s in ('left_finger', 'right_finger')]
        threshold = float(spec.get('contact_force_threshold', 0.1))
        track_weak_side = bool(spec.get('close_force_recenter_track_weak_side', False))
        if track_weak_side:
            forces = [UR5eAssemblyAtomicSkillAdapter._known_probe_force(f) for f in fingers]
        else:
            if not all(f.get('force_probe_valid') and np.isfinite(f.get('force', float('nan'))) for f in fingers):
                return None
            forces = [float(f['force']) for f in fingers]
        stop_cause = 'bilateral_contact'
        if (track_weak_side and any(force is not None and force >= float(spec.get('close_force_limit', 40.0))
                                    for force in forces)):
            # This hook runs before the next arm target is constructed. Stop
            # the unexecuted move as well as unwinding the overloaded gripper.
            stop_cause = 'hard_force_limit'
        elif track_weak_side and any(force is None for force in forces):
            stop_cause = 'contact_probe_unavailable'
        elif pending.get('mode') == 'force_margin':
            side = int(pending['loaded_side'])
            margin_ready = min(forces) >= float(spec['close_force_balance_min'])
            reversed_side = forces[1 - side] >= threshold and forces[1 - side] > forces[side]
            if not margin_ready and not reversed_side:
                return None
            stop_cause = 'force_margin_reached' if margin_ready else 'force_balance_side_reversed'
        elif not all(force >= threshold for force in forces):
            return None
        if not all(k in pending for k in ('motion_start_position_world', 'motion_delta_world', 'offset_before')):
            return None
        delta = np.asarray(pending['motion_delta_world'], dtype=float)
        start = np.asarray(pending['motion_start_position_world'], dtype=float)
        current = np.asarray(current_position, dtype=float)
        before = np.asarray(pending['offset_before'], dtype=float)
        if any(a.shape != (3,) or not np.all(np.isfinite(a)) for a in (delta, start, current, before)):
            return None
        length_squared = float(np.dot(delta, delta))
        if length_squared <= 1e-16:
            return None
        measured_delta = current - start
        issued = pending.get('lifecycle') != 'planned'
        progress = (float(np.clip(np.dot(measured_delta, delta) / length_squared, 0.0, 1.0))
                    if issued else 0.0)
        offset = before + progress * delta
        state['recenter_offset_world'] = offset
        # Preserve the original world anchor and conservative command-travel
        # charge. Project only along the issued move, not arbitrary TCP drift.
        state.pop('force_recenter_pending')
        state['force_single_steps'] = 0
        state.pop('force_single_side', None)
        state['force_recenter_pause_steps'] = int(spec.get('close_force_recenter_settle_steps', 8))
        if spec.get('close_force_recenter_adaptive_step'):
            state['force_recenter_step'] = max(
                float(spec.get('close_force_recenter_min_step', 0.000025)),
                0.5 * float(state.get('force_recenter_step', spec.get('close_gate_recenter_step', 0.0002))),
            )
        event = {'reason': 'bilateral_motion_cancelled', 'progress_fraction': progress,
                 'lifecycle': pending.get('lifecycle', 'legacy_issued'),
                 'issued_step': pending.get('issued_step'),
                 'stop_cause': stop_cause, 'motion_mode': pending.get('mode', 'single_contact'),
                 'offset_world': offset.tolist(), 'forces': forces,
                 'motion_start_position_world': start.tolist(), 'stop_position_world': current.tolist(),
                 'motion_delta_world': delta.tolist(), 'offset_before': before.tolist(),
                 'cancelled_distance': (1.0 - progress) * float(np.sqrt(length_squared))}
        state['force_recenter_stop_event'] = event
        return event

    @staticmethod
    def _recenter_motion_ready(*, pending, current_position, overall_pose_ready, tolerance):
        if pending.get('lifecycle') == 'planned':
            return False, {'recenter_motion_error': None, 'recenter_lifecycle': 'planned'}
        target = pending.get('motion_target_position_world')
        if target is None:
            return False, {'recenter_motion_error': None}
        error = float(np.linalg.norm(np.asarray(current_position) - np.asarray(target)))
        delta = pending.get('motion_delta_world')
        if pending.get('adaptive_progress') and delta is not None:
            delta = np.asarray(delta)
            length = float(np.linalg.norm(delta))
            if length <= 1e-8:
                return False, {'recenter_motion_error': error}
            axis = delta / length
            residual = np.asarray(current_position) - np.asarray(target)
            axial = abs(float(np.dot(residual, axis)))
            lateral = float(np.linalg.norm(residual - np.dot(residual, axis) * axis))
            axial_tolerance = min(tolerance, length * 0.25)
            return bool(overall_pose_ready and axial <= axial_tolerance and lateral <= tolerance), {
                'recenter_motion_error': error, 'recenter_motion_axial_error': axial,
                'recenter_motion_lateral_error': lateral, 'recenter_motion_axial_tolerance': axial_tolerance,
                'recenter_motion_target_position': np.asarray(target).tolist(),
            }
        # A fixed servo bias must not prevent acknowledging a measured small move.
        # The original world anchor and full pose gate remain in force.
        return bool(overall_pose_ready and error <= tolerance), {
            'recenter_motion_error': error, 'recenter_motion_target_position': np.asarray(target).tolist(),
        }

    @staticmethod
    def _update_force_recenter(*, state: dict, metrics: dict, spec: dict) -> dict:
        offset = np.asarray(state.get('recenter_offset_world', np.zeros(3)), dtype=float)
        result = {'enabled': True, 'updated': False, 'source': 'pair_force', 'offset_world': offset.tolist()}
        track_weak_side = bool(spec.get('close_force_recenter_track_weak_side', False))

        def clear_confirmation():
            state['force_single_steps'] = 0
            state.pop('force_single_side', None)
            state.pop('force_recenter_confirmation_mode', None)
            state.pop('force_recenter_confirmation_direction', None)
            state.pop('force_recenter_confirmation_peak_imbalance', None)

        if track_weak_side:
            observation_step = state.get('force_recenter_observation_step')
            result['confirmation_clock_guarded'] = observation_step is not None
            result['observation_task_step'] = observation_step
            if observation_step is not None:
                previous_step = state.get('force_recenter_last_observation_step')
                if previous_step == observation_step:
                    return {**result, 'reason': 'repeat_observation'}
                if previous_step is not None and observation_step != previous_step + 1:
                    clear_confirmation()
                state['force_recenter_last_observation_step'] = observation_step

        def contact_direction(side):
            configured = spec.get('physical_contact_axes')
            if configured is None:
                configured = 'y'
            try:
                axes = ([axis.strip().lower() for axis in configured.split(',') if axis.strip()]
                        if isinstance(configured, str) else [str(axis).strip().lower() for axis in configured])
            except TypeError:
                return None, None, 'recenter_axis_unavailable'
            if len(axes) > 1 and 'y' in axes and all(axis in {'x', 'y', 'z'} for axis in axes):
                # Legacy multi-axis recipes have always recentered along Y.
                # A clearly configured single axis can now choose X or Z.
                axes = ['y']
            if len(axes) != 1 or axes[0] not in {'x', 'y', 'z'}:
                return None, None, 'recenter_axis_unavailable'
            finger = fingers[side]
            contacts = [c for c in (finger.get('force_observation') or {}).get('contacts', [])
                        if abs(c['normal_force']) > 0.01]
            if not contacts or metrics.get('contact_box_orientation') is None or metrics.get('contact_box_center') is None:
                return None, None, 'loaded_contact_frame_unavailable'
            orientation = np.asarray(metrics['contact_box_orientation'], dtype=float)
            center = np.asarray(metrics['contact_box_center'], dtype=float)
            points = np.asarray([c['point_world'] for c in contacts], dtype=float)
            weights = np.asarray([abs(c['normal_force']) for c in contacts], dtype=float)
            if (orientation.shape != (4,) or center.shape != (3,) or points.shape != (len(contacts), 3)
                    or not all(np.all(np.isfinite(v)) for v in (orientation, center, points, weights))
                    or np.linalg.norm(orientation) <= 1e-9):
                return None, None, 'loaded_contact_frame_unavailable'
            local_axis = np.eye(3)[{'x': 0, 'y': 1, 'z': 2}[axes[0]]]
            axis = quat_rotate(normalize_quat(orientation), local_axis)
            point = np.average(points, axis=0, weights=weights)
            signed = float(np.dot(point - center, axis))
            if not np.isfinite(signed) or abs(signed) < 1e-6:
                return None, None, 'contact_side_unavailable'
            return axis, signed, None

        fingers = [metrics.get(s) or {} for s in ('left_finger', 'right_finger')]
        probes_valid = (all(UR5eAssemblyAtomicSkillAdapter._known_probe_force(f) is not None for f in fingers)
                        if track_weak_side else all(f.get('force_probe_valid')
                            and np.isfinite(f.get('force', float('nan'))) for f in fingers))
        if not probes_valid:
            state['force_single_steps'] = 0
            if track_weak_side:
                clear_confirmation()
            return {**result, 'reason': 'invalid_probe'}
        forces = [float(f['force']) for f in fingers]
        threshold = float(spec.get('contact_force_threshold', 0.1))
        loaded = [f >= threshold for f in forces]
        result['forces'] = forces
        hard_limit = max(forces) >= float(spec.get('close_force_limit', 40.0))
        if track_weak_side and hard_limit:
            clear_confirmation()
        stop_event = state.pop('force_recenter_stop_event', None)
        if stop_event is not None:
            return {**result, **stop_event}
        if state.get('force_recenter_fault'):
            return {**result, 'reason': state['force_recenter_fault']}
        if state.get('force_recenter_pause_steps', 0) > 0:
            state['force_recenter_pause_steps'] -= 1
            state['force_single_steps'] = 0
            state.pop('force_single_side', None)
            return {**result, 'reason': 'contact_stop_settling'}
        pending = state.get('force_recenter_pending')
        if pending is not None:
            if pending.get('lifecycle') == 'planned':
                return {**result, 'reason': 'awaiting_final_action', 'lifecycle': 'planned'}
            pending['elapsed_steps'] = int(pending.get('elapsed_steps', 0)) + 1
            if not state.get('recenter_target_ready', False):
                pending['settle_steps'] = 0
                if pending['elapsed_steps'] >= int(spec.get('close_force_recenter_timeout_steps', 240)):
                    state['force_recenter_fault'] = 'recenter_motion_timeout'
                    return {**result, 'reason': state['force_recenter_fault']}
                return {**result, 'reason': 'servo_in_progress'}
            pending['settle_steps'] += 1
            if pending['settle_steps'] < int(spec.get('close_force_recenter_settle_steps', 8)):
                return {**result, 'reason': 'settling'}
            if abs(forces[0] - forces[1]) > 1.5 * pending['imbalance'] + 2.0:
                state['force_recenter_fault'] = 'force_imbalance_increased'
                return {**result, 'reason': state['force_recenter_fault']}
            state.pop('force_recenter_pending')
        balance_min = spec.get('close_force_balance_min')
        if track_weak_side:
            # A force-band or single/bilateral label change does not change
            # the observed strong side. Qualify that side, but issue no move
            # during unloading or at the hard force limit.
            if hard_limit:
                clear_confirmation()
                return {**result, 'reason': 'force_limit_before_recenter'}
            balance_needed = bool(balance_min is not None and min(forces) < float(balance_min)
                                  and any(loaded) and forces[0] != forces[1])
            if not balance_needed:
                clear_confirmation()
                return {**result, 'reason': 'bilateral' if all(loaded) else 'no_contact'}
            mode, side = 'force_margin', int(np.argmax(forces))
            axis, signed, direction_error = contact_direction(side)
            if direction_error:
                clear_confirmation()
                return {**result, 'reason': direction_error}
            direction = math.copysign(1.0, signed) * axis
            previous_direction = state.get('force_recenter_confirmation_direction')
            same_candidate = (state.get('force_single_side') == side and previous_direction is not None
                              and float(np.dot(previous_direction, direction)) > 0.0)
            state['force_recenter_confirmation_direction'] = direction.copy()
        else:
            balance_needed = bool(
                balance_min is not None and all(loaded) and min(forces) < float(balance_min)
                and max(forces) >= float(spec.get('close_force_balance_peak', 4.0))
            )
            if loaded[0] == loaded[1] and not balance_needed:
                clear_confirmation()
                return {**result, 'reason': 'bilateral' if all(loaded) else 'no_contact'}
            if max(forces) > float(spec.get('close_force_high', 12.0)):
                # Preserve the established single-contact approach timing.
                if balance_needed or state.get('force_recenter_confirmation_mode') == 'force_margin':
                    state['force_single_steps'] = 0
                return {**result, 'reason': 'unload_before_recenter'}
            mode = 'force_margin' if balance_needed else 'single_contact'
            side = int(np.argmax(forces)) if balance_needed else (0 if loaded[0] else 1)
            same_candidate = (state.get('force_single_side') == side
                              and state.get('force_recenter_confirmation_mode') == mode)
        previous_confirmation_steps = int(state.get('force_single_steps', 0))
        state['force_single_steps'] = int(state.get('force_single_steps', 0)) + 1 if same_candidate else 1
        state['force_single_side'] = side
        state['force_recenter_confirmation_mode'] = mode
        if track_weak_side:
            imbalance = abs(forces[0] - forces[1])
            previous_peak = state.get('force_recenter_confirmation_peak_imbalance', imbalance)
            state['force_recenter_confirmation_peak_imbalance'] = (
                max(previous_peak, imbalance) if same_candidate and previous_confirmation_steps > 0 else imbalance
            )
            result.update(confirmation_steps=state['force_single_steps'], strong_side=side,
                          confirmation_peak_imbalance=state['force_recenter_confirmation_peak_imbalance'])
        if track_weak_side and max(forces) > float(spec.get('close_force_high', 12.0)):
            return {**result, 'reason': 'unload_before_recenter'}
        if state['force_single_steps'] < int(spec.get('close_gate_recenter_stable_steps', 4)):
            return {**result, 'reason': 'single_contact_confirmation'}
        if not track_weak_side:
            axis, signed, direction_error = contact_direction(side)
            if direction_error:
                return {**result, 'reason': direction_error}
        step = float(state.get('force_recenter_step', spec.get('close_gate_recenter_step', 0.0002)))
        if spec.get('close_force_recenter_adaptive_step'):
            previous_side = state.get('force_recenter_last_side')
            if previous_side is not None and previous_side != side:
                step = max(step * 0.5, float(spec.get('close_force_recenter_min_step', 0.000025)))
        if balance_needed:
            step = min(step, float(spec.get('close_force_balance_step', 0.000025)))
        limit = float(spec.get('close_gate_recenter_max_offset', 0.002))
        # Limit total travelled distance, not just net displacement.
        remaining = max(limit - float(state.get('force_recenter_travel', 0.0)), 0.0)
        if remaining < 1e-7:
            return {**result, 'reason': 'travel_limit'}
        delta = math.copysign(min(step, remaining), signed) * axis
        motion_start = state.get('close_tcp_position_world')
        if spec.get('close_force_recenter_measure_progress') and motion_start is None:
            return {**result, 'reason': 'tcp_observation_unavailable'}
        state['recenter_offset_world'] = offset + delta
        state['force_recenter_last_side'] = side
        state['force_recenter_step'] = step
        state['force_recenter_travel'] = float(state.get('force_recenter_travel', 0.0)) + float(np.linalg.norm(delta))
        state['force_recenter_pending'] = {
            'lifecycle': 'planned' if track_weak_side else 'legacy_issued',
            'planned_step': state.get('force_recenter_observation_step'),
            'imbalance': (state.pop('force_recenter_confirmation_peak_imbalance', abs(forces[0] - forces[1]))
                          if track_weak_side else abs(forces[0] - forces[1])), 'settle_steps': 0,
            'mode': mode, 'loaded_side': side,
            'offset_before': offset.copy(), 'motion_delta_world': delta.copy(),
            'adaptive_progress': bool(spec.get('close_force_recenter_adaptive_step')),
        }
        if motion_start is not None:
            state['force_recenter_pending']['motion_start_position_world'] = np.asarray(motion_start).copy()
            state['force_recenter_pending']['motion_target_position_world'] = np.asarray(motion_start) + delta
        state['recenter_target_ready'] = False
        state['force_single_steps'] = 0
        return {**result, 'updated': True, 'offset_world': (offset + delta).tolist(),
                'motion_mode': mode,
                'motion_start_position_world': None if motion_start is None else np.asarray(motion_start).tolist(),
                'motion_delta_world': delta.tolist(),
                'travel': state['force_recenter_travel'], 'loaded_side': side}

    @staticmethod
    def _update_close_recenter_offset(
        *,
        state: dict[str, Any],
        close_detail: dict[str, Any],
        spec: dict,
        close_ready: bool,
    ) -> dict[str, Any]:
        """Shift the TCP away from a prematurely contacting finger during closure."""
        enabled = bool(spec.get('close_gate_recenter_single_finger_contact', False))
        result: dict[str, Any] = {
            'enabled': enabled,
            'updated': False,
            'offset_world': np.asarray(
                state.get('recenter_offset_world', np.zeros(3, dtype=float)),
                dtype=float,
            ).tolist(),
        }
        if not enabled or close_ready:
            return result

        contact_detail = close_detail.get('contact_detail') or {}
        metrics = contact_detail.get('contact_metrics') or {}
        if bool(spec.get('close_force_regulation', False)):
            return UR5eAssemblyAtomicSkillAdapter._update_force_recenter(state=state, metrics=metrics, spec=spec)
        left = metrics.get('left_finger') or {}
        right = metrics.get('right_finger') or {}

        def surface_gap(finger: dict[str, Any]) -> float | None:
            local_contact = finger.get('local_contact') or {}
            value = local_contact.get('best_surface_gap', finger.get('surface_gap'))
            if value is None:
                return None
            value = float(value)
            return value if math.isfinite(value) else None

        left_gap = surface_gap(left)
        right_gap = surface_gap(right)
        result.update({'left_gap': left_gap, 'right_gap': right_gap})
        if left_gap is None or right_gap is None:
            state['recenter_single_finger_steps'] = 0
            state.pop('recenter_single_finger_side', None)
            return result

        contact_distance = float(
            spec.get(
                'close_gate_recenter_contact_distance',
                spec.get('finger_contact_distance', 0.006),
            )
        )
        minimum_gap_imbalance = float(spec.get('close_gate_recenter_min_gap_imbalance', 0.004))
        left_near = left_gap <= contact_distance
        right_near = right_gap <= contact_distance
        if left_near == right_near or abs(left_gap - right_gap) < minimum_gap_imbalance:
            state['recenter_single_finger_steps'] = 0
            state.pop('recenter_single_finger_side', None)
            return result

        side = 'left' if left_near else 'right'
        finger = left if left_near else right
        if state.get('recenter_single_finger_side') == side:
            stable_steps = int(state.get('recenter_single_finger_steps', 0)) + 1
        else:
            stable_steps = 1
        state['recenter_single_finger_side'] = side
        state['recenter_single_finger_steps'] = stable_steps
        required_steps = max(
            int(spec.get('close_gate_recenter_stable_steps', 2)),
            1,
        )
        result.update(
            {
                'single_finger_side': side,
                'stable_steps': stable_steps,
                'required_stable_steps': required_steps,
            }
        )
        if stable_steps < required_steps:
            return result

        local_contact = finger.get('local_contact') or {}
        axis_name = local_contact.get('best_axis')
        local_point = local_contact.get('local_point')
        contact_box_orientation = metrics.get('contact_box_orientation')
        latched_direction = np.asarray(
            state.get('recenter_direction_world', np.zeros(3, dtype=float)),
            dtype=float,
        )
        direction_latched = bool(
            state.get('recenter_direction_side') == side
            and latched_direction.shape == (3,)
            and np.all(np.isfinite(latched_direction))
            and float(np.linalg.norm(latched_direction)) > 1e-9
        )
        if direction_latched:
            world_direction = latched_direction / float(np.linalg.norm(latched_direction))
            axis_name = state.get('recenter_direction_axis', axis_name)
        else:
            left_sample = left.get('best_sample_position') or left.get('fingertip_position')
            right_sample = right.get('best_sample_position') or right.get('fingertip_position')
            contact_box_center = metrics.get('contact_box_center')
            pair_values = (left_sample, right_sample, contact_box_center)
            pair_available = all(value is not None for value in pair_values)
            if pair_available:
                left_position, right_position, object_center = (
                    np.asarray(value, dtype=float) for value in pair_values
                )
                pair_available = bool(
                    all(value.shape == (3,) and np.all(np.isfinite(value)) for value in (
                        left_position,
                        right_position,
                        object_center,
                    ))
                )
            if pair_available:
                finger_axis = left_position - right_position
                finger_axis_norm = float(np.linalg.norm(finger_axis))
                if finger_axis_norm > 1e-9:
                    finger_axis /= finger_axis_norm
                    finger_midpoint = 0.5 * (left_position + right_position)
                    center_error = float(np.dot(object_center - finger_midpoint, finger_axis))
                    if math.isfinite(center_error) and abs(center_error) > 1e-9:
                        world_direction = math.copysign(1.0, center_error) * finger_axis
                        axis_name = 'finger_pair'
                        result['finger_pair_center_error'] = center_error
                    else:
                        pair_available = False
                else:
                    pair_available = False
            if not pair_available:
                if axis_name not in {'x', 'y', 'z'} or local_point is None or contact_box_orientation is None:
                    result['reason'] = 'contact_frame_unavailable'
                    return result
                axis_index = {'x': 0, 'y': 1, 'z': 2}[str(axis_name)]
                signed_coordinate = float(local_point[axis_index])
                if not math.isfinite(signed_coordinate) or abs(signed_coordinate) <= 1e-9:
                    result['reason'] = 'contact_side_unavailable'
                    return result

                local_direction = np.zeros(3, dtype=float)
                # Translate toward the side occupied by the first contacting
                # finger, moving the opposite pad toward the object center.
                local_direction[axis_index] = math.copysign(1.0, signed_coordinate)
                world_direction = quat_rotate(
                    normalize_quat(np.asarray(contact_box_orientation, dtype=float)),
                    local_direction,
                )
                world_direction = np.asarray(world_direction, dtype=float)
                norm = float(np.linalg.norm(world_direction))
                if norm <= 1e-9 or not np.all(np.isfinite(world_direction)):
                    result['reason'] = 'contact_direction_unavailable'
                    return result
                world_direction /= norm
            # A sampled box can report a different best face while the same
            # finger remains the only contacting finger. Keep the first valid
            # correction direction until contact is centered so the servo does
            # not alternate between unrelated Cartesian targets.
            state['recenter_direction_world'] = world_direction.copy()
            state['recenter_direction_side'] = side
            state['recenter_direction_axis'] = str(axis_name)

        gap_imbalance = abs(left_gap - right_gap)
        step = max(float(spec.get('close_gate_recenter_step', 0.00075)), 0.0)
        configured_gap_gain = spec.get('close_gate_recenter_gap_gain')
        gap_gain = None if configured_gap_gain is None else float(configured_gap_gain)
        maximum_step = max(float(spec.get('close_gate_recenter_max_step', step)), step)
        if gap_gain is not None and math.isfinite(gap_gain) and gap_gain > 0.0:
            step = max(step, min(maximum_step, gap_gain * gap_imbalance))
        maximum_offset = max(
            float(spec.get('close_gate_recenter_max_offset', 0.025)),
            0.0,
        )
        previous = np.asarray(
            state.get('recenter_offset_world', np.zeros(3, dtype=float)),
            dtype=float,
        )
        if float(np.linalg.norm(previous)) > 1e-12 and not bool(state.get('recenter_target_ready', False)):
            result['reason'] = 'previous_offset_servo_in_progress'
            return result
        updated = previous + world_direction * step
        updated_norm = float(np.linalg.norm(updated))
        if maximum_offset > 0.0 and updated_norm > maximum_offset:
            updated *= maximum_offset / updated_norm
        state['recenter_offset_world'] = updated
        result.update(
            {
                'updated': bool(np.linalg.norm(updated - previous) > 1e-12),
                'axis': axis_name,
                'direction_latched': direction_latched,
                'step': step,
                'gap_imbalance': gap_imbalance,
                'gap_gain': gap_gain,
                'maximum_offset': maximum_offset,
                'offset_world': updated.tolist(),
            }
        )
        return result

    def _close_until_contact_ready(
        self,
        *,
        state: dict[str, Any],
        task,
        robot_name: str,
        spec: dict,
        tracked_objects: dict,
        close_elapsed_steps: int,
        gripper_openness: float,
    ) -> tuple[bool, dict[str, Any]]:
        if spec.get('continuous_physics'):
            generation = getattr(task, '_continuous_grasp_loss_generation', {}).get(
                self._object_name_from_spec(spec), 0)
            if state.get('grasp_loss_generation', 0) != generation:
                state['close_contact_stable_steps'] = 0
                state.pop('contact_stability_pose', None)
                state.pop('close_contact_observation', None)
            state['grasp_loss_generation'] = generation
        min_steps = max(int(spec.get('close_until_contact_min_steps', spec.get('close_ramp_steps', 24))), 0)
        required_stable_steps = max(int(spec.get('close_contact_stable_steps', 8)), 1)
        gripper_q = self._current_gripper_q(task=task, robot_name=robot_name)
        open_q, closed_q = self._gripper_open_closed_q(task=task, robot_name=robot_name)
        joint_range = None
        if open_q is not None and closed_q is not None:
            joint_range = abs(float(open_q) - float(closed_q))

        # The Robotiq drive spans about 0.8 while each Panda finger spans only
        # 0.04. Scale implicit gates to the configured joint range so a valid
        # short-stroke gripper can satisfy the same normalized grasp checks.
        default_stall_delta = 0.0015 if joint_range is None else min(0.0015, 0.05 * joint_range)
        default_blocked_margin = 0.025 if joint_range is None else min(0.025, 0.25 * joint_range)
        default_min_closure = 0.05 if joint_range is None else min(0.05, 0.0625 * joint_range)
        default_short_command_closure = 0.05 if joint_range is None else min(0.05, 0.10 * joint_range)
        default_target_tolerance = 0.025 if joint_range is None else min(0.025, 0.05 * joint_range)
        stall_delta = float(spec.get('close_contact_stall_joint_delta', default_stall_delta))
        blocked_margin = float(spec.get('close_contact_blocked_joint_margin', default_blocked_margin))
        min_closure = float(spec.get('close_contact_min_joint_closure', default_min_closure))
        short_command_closure = float(
            spec.get('close_contact_short_command_max_joint_closure', default_short_command_closure)
        )
        target_tolerance = float(spec.get('close_gripper_target_tolerance', default_target_tolerance))
        hold_squeeze_margin = float(spec.get('close_contact_hold_squeeze_margin', 0.04))

        last_q = state.get('last_gripper_q')
        joint_delta = None
        if gripper_q is not None and last_q is not None:
            joint_delta = abs(float(gripper_q) - float(last_q))
        if gripper_q is not None:
            state['last_gripper_q'] = float(gripper_q)

        contact_ready = False
        contact_detail: dict[str, Any] = {'contact_checked': False}
        if bool(spec.get('use_contact_for_close_until_contact', True)):
            observation = state.pop('close_contact_observation', None)
            if observation is not None and observation[0] == int(getattr(task, 'step_counter', -1)):
                contact_ready, contact_detail = observation[1]
            else:
                contact_ready, contact_detail = self._grasp_contact_ready(
                    task=task,
                    robot_name=robot_name,
                    spec={**spec, 'require_dual_finger_contact': spec.get('require_dual_finger_contact', True)},
                )
            contact_detail['contact_checked'] = True

        if bool(spec.get('close_force_regulation', False)):
            if any(value is None for value in (gripper_q, open_q, closed_q)):
                return False, {'control_error': 'gripper_state_unavailable', 'contact_detail': contact_detail}
            metrics = contact_detail.get('contact_metrics') or {}
            config = getattr(task.robots.get(robot_name), 'config', None)
            control = self._contact_close_control(
                state=state, spec=spec, metrics=metrics, gripper_q=float(gripper_q),
                open_q=float(open_q), closed_q=float(closed_q), requested_openness=gripper_openness,
                min_openness=float(getattr(config, 'gripper_close_openness', 0.0) or 0.0),
            )
            candidate = bool(contact_ready and control['force_within_limit'] and
                             min(control['forces']) >= float(spec.get('close_force_min_stable', 1.0)))
            center = metrics.get('contact_box_center')
            orientation = metrics.get('contact_box_orientation')
            motion_detail = {'checked': True, 'method': 'fixed_pose_window', 'valid': False}
            if candidate and center is not None and orientation is not None:
                if state.get('close_contact_stable_steps', 0) == 0:
                    state['contact_stability_pose'] = (np.asarray(center).copy(), np.asarray(orientation).copy())
                reference_position, reference_orientation = state['contact_stability_pose']
                position_error, orientation_error = pose_error(
                    current_position=np.asarray(center), current_orientation=np.asarray(orientation),
                    target_position=reference_position, target_orientation=reference_orientation)
                motion_detail.update(valid=True, position_error=position_error, orientation_error=orientation_error)
                candidate = bool(position_error <= float(spec.get('close_stable_position_tolerance', 0.001)) and
                                 orientation_error <= float(spec.get('close_stable_orientation_tolerance', 0.02)))
            else:
                candidate = False
            state['close_contact_stable_steps'] = int(state.get('close_contact_stable_steps', 0)) + 1 if candidate else 0
            required = max(required_stable_steps, int(spec.get('close_force_validation_steps', 96)))
            ready = bool(close_elapsed_steps >= min_steps and state['close_contact_stable_steps'] >= required)
            if ready:
                self._remember_gripper_hold_openness(task=task, robot_name=robot_name, openness=control['command_openness'])
            return ready, {
                'closed': ready, 'close_until_contact': True, 'completion_reason': control['mode'],
                'stable_steps': state['close_contact_stable_steps'], 'required_stable_steps': required,
                'contact_ready': contact_ready, 'contact_detail': contact_detail, 'control': control,
                'gripper_joint_position': gripper_q, 'target_gripper_joint_position': control['command_q'],
                'hold_gripper_openness': control['command_openness'], 'gripper_openness_command': control['command_openness'],
                'motion_ready': candidate, 'motion_detail': motion_detail,
            }

        blocked_before_full_close = False
        moved_from_open = False
        target_q = None
        reached_gripper_target = False
        if gripper_q is not None and open_q is not None and closed_q is not None:
            blocked_before_full_close = abs(float(gripper_q) - float(closed_q)) >= blocked_margin
            moved_from_open = abs(float(gripper_q) - float(open_q)) >= min_closure
            target_q = float(closed_q) + float(gripper_openness) * (float(open_q) - float(closed_q))
            reached_gripper_target = abs(float(gripper_q) - target_q) <= target_tolerance
        stalled = bool(joint_delta is not None and joint_delta <= stall_delta)
        commanded_closure_from_open = (
            None if target_q is None or open_q is None else abs(float(target_q) - float(open_q))
        )
        initial_strict_contact_for_short_close = bool(
            spec.get('allow_initial_strict_contact_for_short_close', False)
            and contact_ready
            and contact_detail.get('strict_contact_ready') is True
            and blocked_before_full_close
            and commanded_closure_from_open is not None
            and commanded_closure_from_open <= short_command_closure + 1e-9
        )
        initial_strict_contact_without_closure = bool(
            spec.get('allow_initial_strict_contact_without_closure', False)
            and contact_ready
            and contact_detail.get('strict_contact_ready') is True
            and blocked_before_full_close
        )
        initial_strict_contact_candidate = bool(
            initial_strict_contact_for_short_close or initial_strict_contact_without_closure
        )
        contact_candidate = bool(contact_ready and (moved_from_open or initial_strict_contact_candidate))
        require_strict_contact = bool(spec.get('require_strict_physical_contact', False))
        stall_contact = bool(
            not require_strict_contact
            and bool(spec.get('use_joint_stall_for_close_until_contact', True))
            and stalled
            and blocked_before_full_close
            and moved_from_open
        )
        detected_clamp = bool(contact_candidate or stall_contact)
        if (
            bool(spec.get('allow_jaw_width_completion', False))
            and gripper_q is not None
            and open_q is not None
            and closed_q is not None
            and spec.get('jaw_width_thickness_m') is not None
        ):
            stroke = float(spec.get('jaw_width_stroke_m', 0.085))
            if stroke > 0.0:
                ratio = min(max(float(spec['jaw_width_thickness_m']) / stroke, 0.0), 1.0)
                expected_q = float(open_q) + (1.0 - ratio) * (float(closed_q) - float(open_q))
                tolerance = float(spec.get('jaw_width_joint_tolerance', 0.08))
                # A rim touch while the jaw is still wide is not the pinch.
                # Latching it slams the command shut and spins the beam (v81).
                if abs(float(gripper_q) - expected_q) > tolerance:
                    detected_clamp = False
                    contact_candidate = False
                    stall_contact = False

        configured_latch_after_stable = spec.get('close_contact_latch_after_stable')
        use_transient_hold_candidate = bool(
            configured_latch_after_stable is None and not require_strict_contact
        )
        if detected_clamp:
            state['close_contact_stable_steps'] = int(state.get('close_contact_stable_steps', 0)) + 1
            if (
                use_transient_hold_candidate
                and close_elapsed_steps >= min_steps
                and state.get('hold_gripper_openness') is None
            ):
                hold_openness = self._gripper_openness_from_q(
                    gripper_q=gripper_q,
                    open_q=open_q,
                    closed_q=closed_q,
                    squeeze_margin=hold_squeeze_margin,
                )
                if hold_openness is not None:
                    max_hold_openness = spec.get('max_hold_gripper_openness', spec.get('closed_openness'))
                    if max_hold_openness is not None:
                        hold_openness = min(float(hold_openness), float(max_hold_openness))
                    state['hold_gripper_openness'] = float(hold_openness)
        else:
            state['close_contact_stable_steps'] = 0
            if use_transient_hold_candidate:
                state.pop('hold_gripper_openness', None)

        motion_ready = True
        motion_detail: dict[str, Any] = {'checked': False}
        motion_stable_steps = 0
        max_linear_speed = spec.get('close_contact_max_object_speed')
        max_angular_speed = spec.get('close_contact_max_angular_speed')
        if max_linear_speed is not None or max_angular_speed is not None:
            motion_detail = self._object_motion_detail(
                task=task,
                object_name=self._object_name_from_spec(spec),
                tracked_objects=tracked_objects,
            )
            motion_detail['checked'] = True
            linear_speed = motion_detail.get('linear_speed')
            angular_speed = motion_detail.get('angular_speed')
            linear_ok = max_linear_speed is None or (
                linear_speed is not None and float(linear_speed) <= float(max_linear_speed)
            )
            angular_ok = max_angular_speed is None or (
                angular_speed is not None and float(angular_speed) <= float(max_angular_speed)
            )
            raw_velocity_thresholds_passed = bool(linear_ok and angular_ok)
            pose_stable_override_used = bool(
                spec.get('close_contact_allow_pose_stable_override', False)
                and motion_detail.get('pose_stable_override') is True
            )
            velocity_thresholds_passed = bool(raw_velocity_thresholds_passed or pose_stable_override_used)
            motion_detail['raw_velocity_thresholds_passed'] = raw_velocity_thresholds_passed
            motion_detail['pose_stable_override_used'] = pose_stable_override_used
            motion_detail['velocity_thresholds_passed'] = velocity_thresholds_passed
            motion_ready = bool(motion_detail.get('valid') and velocity_thresholds_passed)
            if detected_clamp and motion_ready:
                state['close_contact_motion_stable_steps'] = int(state.get('close_contact_motion_stable_steps', 0)) + 1
            else:
                state['close_contact_motion_stable_steps'] = 0
            motion_stable_steps = int(state.get('close_contact_motion_stable_steps', 0))

        stable_steps = int(state.get('close_contact_stable_steps', 0))
        required_motion_stable_steps = 0
        if max_linear_speed is not None or max_angular_speed is not None:
            required_motion_stable_steps = max(int(spec.get('close_contact_motion_stable_steps', 1)), 1)
        motion_stable_ready = bool(
            required_motion_stable_steps <= 0 or motion_stable_steps >= required_motion_stable_steps
        )
        closed_target_candidate = bool(
            bool(spec.get('allow_closed_gripper_completion', False)) and reached_gripper_target and moved_from_open
        )
        if closed_target_candidate and motion_ready:
            state['close_closed_target_stable_steps'] = int(state.get('close_closed_target_stable_steps', 0)) + 1
        else:
            state['close_closed_target_stable_steps'] = 0
        closed_target_stable_steps = int(state.get('close_closed_target_stable_steps', 0))
        required_closed_target_stable_steps = max(
            int(spec.get('close_closed_target_stable_steps', required_motion_stable_steps or 1)),
            1,
        )
        closed_target_ready = bool(
            closed_target_candidate
            and motion_ready
            and closed_target_stable_steps >= required_closed_target_stable_steps
        )
        jaw_width_ready = False
        jaw_width_lead = None
        jaw_width_expected_q = None
        jaw_width_stable_steps = 0
        if (
            bool(spec.get('allow_jaw_width_completion', False))
            and gripper_q is not None
            and target_q is not None
            and open_q is not None
            and closed_q is not None
        ):
            thickness = spec.get('jaw_width_thickness_m')
            stroke = float(spec.get('jaw_width_stroke_m', 0.085))
            if thickness is not None and stroke > 0.0:
                ratio = min(max(float(thickness) / stroke, 0.0), 1.0)
                jaw_width_expected_q = float(open_q) + (1.0 - ratio) * (float(closed_q) - float(open_q))
                tolerance = float(spec.get('jaw_width_joint_tolerance', 0.08))
                jaw_width_lead = float(target_q) - float(gripper_q)
                in_band = abs(float(gripper_q) - jaw_width_expected_q) <= tolerance
                blocked = jaw_width_lead >= float(spec.get('jaw_width_command_lead', 0.05))
                if in_band and blocked and moved_from_open:
                    state['jaw_width_stable_steps'] = int(state.get('jaw_width_stable_steps', 0)) + 1
                else:
                    state['jaw_width_stable_steps'] = 0
                jaw_width_stable_steps = int(state.get('jaw_width_stable_steps', 0))
                required_jaw_steps = max(int(spec.get('jaw_width_stable_steps', 8)), 1)
                jaw_width_ready = jaw_width_stable_steps >= required_jaw_steps
        ready = bool(
            close_elapsed_steps >= min_steps
            and (stable_steps >= required_stable_steps or closed_target_ready or jaw_width_ready)
            and motion_ready
            and motion_stable_ready
        )
        latch_after_stable = configured_latch_after_stable
        if latch_after_stable is None:
            max_deferred_latch_steps = max(
                int(spec.get('close_contact_deferred_latch_max_steps', 8)),
                0,
            )
            latch_after_stable = bool(
                require_strict_contact and required_stable_steps <= max_deferred_latch_steps
            )
        latch_after_stable = bool(latch_after_stable)
        latch_ready = bool(ready or not latch_after_stable)
        if use_transient_hold_candidate and ready:
            hold_openness = state.get('hold_gripper_openness')
            if hold_openness is not None:
                self._remember_gripper_hold_openness(
                    task=task,
                    robot_name=robot_name,
                    openness=float(hold_openness),
                )
        elif (
            latch_ready
            and (detected_clamp or jaw_width_ready)
            and close_elapsed_steps >= min_steps
            and state.get('hold_gripper_openness') is None
        ):
            hold_openness = self._gripper_openness_from_q(
                gripper_q=gripper_q,
                open_q=open_q,
                closed_q=closed_q,
                squeeze_margin=hold_squeeze_margin,
            )
            if hold_openness is not None:
                max_hold_openness = spec.get('max_hold_gripper_openness', spec.get('closed_openness'))
                if max_hold_openness is not None:
                    hold_openness = min(float(hold_openness), float(max_hold_openness))
                state['hold_gripper_openness'] = float(hold_openness)
                self._remember_gripper_hold_openness(
                    task=task,
                    robot_name=robot_name,
                    openness=float(hold_openness),
                )
        reason = (
            'contact'
            if contact_candidate
            else 'joint_stall'
            if stall_contact
            else 'closed_target'
            if closed_target_ready
            else 'jaw_width'
            if jaw_width_ready
            else 'closing'
        )
        return ready, {
            'closed': ready,
            'close_until_contact': True,
            'completion_reason': reason,
            'close_elapsed_steps': int(close_elapsed_steps),
            'min_steps': min_steps,
            'stable_steps': stable_steps,
            'required_stable_steps': required_stable_steps,
            'motion_ready': motion_ready,
            'motion_stable_steps': motion_stable_steps,
            'required_motion_stable_steps': required_motion_stable_steps,
            'motion_detail': motion_detail,
            'allow_closed_gripper_completion': bool(spec.get('allow_closed_gripper_completion', False)),
            'target_gripper_joint_position': target_q,
            'reached_gripper_target': reached_gripper_target,
            'closed_target_candidate': closed_target_candidate,
            'closed_target_stable_steps': closed_target_stable_steps,
            'required_closed_target_stable_steps': required_closed_target_stable_steps,
            'closed_target_ready': closed_target_ready,
            'jaw_width_ready': jaw_width_ready,
            'jaw_width_lead': jaw_width_lead,
            'jaw_width_expected_q': jaw_width_expected_q,
            'jaw_width_stable_steps': jaw_width_stable_steps,
            'gripper_openness_command': float(gripper_openness),
            'hold_gripper_openness': state.get('hold_gripper_openness'),
            'gripper_joint_position': None if gripper_q is None else float(gripper_q),
            'gripper_joint_delta': None if joint_delta is None else float(joint_delta),
            'gripper_open_position': None if open_q is None else float(open_q),
            'gripper_closed_position': None if closed_q is None else float(closed_q),
            'gripper_joint_range': joint_range,
            'close_contact_stall_joint_delta': stall_delta,
            'close_contact_blocked_joint_margin': blocked_margin,
            'close_contact_min_joint_closure': min_closure,
            'close_contact_short_command_max_joint_closure': short_command_closure,
            'commanded_closure_from_open': commanded_closure_from_open,
            'initial_strict_contact_for_short_close': initial_strict_contact_for_short_close,
            'initial_strict_contact_without_closure': initial_strict_contact_without_closure,
            'initial_strict_contact_candidate': initial_strict_contact_candidate,
            'close_gripper_target_tolerance': target_tolerance,
            'blocked_before_full_close': blocked_before_full_close,
            'moved_from_open': moved_from_open,
            'stalled': stalled,
            'contact_ready': contact_ready,
            'contact_candidate': contact_candidate,
            'stall_contact': stall_contact,
            'require_strict_physical_contact': require_strict_contact,
            'detected_clamp': detected_clamp,
            'contact_detail': contact_detail,
        }

    @staticmethod
    def _current_gripper_q(*, task, robot_name: str) -> float | None:
        robot = task.robots.get(robot_name)
        if robot is None:
            return None
        dof_name = str(getattr(getattr(robot, 'config', None), 'gripper_dof_name', None) or 'finger_joint')
        articulation = getattr(robot, 'articulation', None)
        if articulation is not None:
            try:
                index = articulation.get_dof_index(dof_name)
                values = articulation.get_joint_positions(joint_indices=np.asarray([index], dtype=np.int64))
                values = np.asarray(values, dtype=float).reshape(-1)
                if values.size:
                    return float(values[0])
            except Exception:
                pass
            try:
                values = np.asarray(articulation.get_joint_positions(), dtype=float).reshape(-1)
                dof_names = list(getattr(articulation, 'dof_names', []) or [])
                if dof_name in dof_names:
                    return float(values[dof_names.index(dof_name)])
            except Exception:
                pass
        try:
            controller = robot.controllers.get(_GRIPPER_CONTROLLER)
            obs = controller.get_obs()
            values = np.asarray(obs.get('gripper_pos'), dtype=float).reshape(-1)
            if values.size:
                return float(values[0])
        except Exception:
            pass
        return None

    @staticmethod
    def _gripper_open_closed_q(*, task, robot_name: str) -> tuple[float | None, float | None]:
        robot = task.robots.get(robot_name)
        config = getattr(robot, 'config', None) if robot is not None else None
        try:
            open_q = float(getattr(config, 'gripper_open_position'))
            closed_q = float(getattr(config, 'gripper_closed_position'))
            return open_q, closed_q
        except Exception:
            return None, None

    @staticmethod
    def _mark_complete(*, task, robot_name: str, skill_name: str, detail: dict[str, Any]) -> None:
        marker = getattr(task, 'mark_local_skill_complete', None)
        if callable(marker):
            marker(robot_name=robot_name, skill_name=skill_name, detail=detail)

    @staticmethod
    def _request_insertion_capture_transition(
        *,
        task,
        robot_name: str,
        skill_name: str,
        spec: dict,
        capture_detail: dict[str, Any],
    ) -> bool:
        target_phase = spec.get('insertion_capture_transition_phase')
        if target_phase is None:
            return False
        try:
            position_error = float(capture_detail['position_error'])
            position_tolerance = float(
                spec.get('insertion_capture_transition_position_tolerance', 0.015)
            )
        except (KeyError, TypeError, ValueError):
            return False
        if (
            not np.isfinite(position_error)
            or not np.isfinite(position_tolerance)
            or position_tolerance <= 0.0
            or position_error > position_tolerance
        ):
            return False
        requester = getattr(task, 'request_phase_transition', None)
        if not callable(requester):
            return False
        phase_index = getattr(task, 'phase_index', None)
        phase_entry_step = getattr(task, 'phase_entry_step', None)
        if phase_index is None or phase_entry_step is None:
            return False
        return bool(
            requester(
                target_phase=str(target_phase),
                expected_phase_index=int(phase_index),
                expected_phase_entry_step=int(phase_entry_step),
                robot_name=str(robot_name),
                skill_name=str(skill_name),
                reason='final-insertion-captured',
                detail=copy.deepcopy(capture_detail),
            )
        )

    def _grasp_contact_ready(self, *, task, robot_name: str, spec: dict) -> tuple[bool, dict[str, Any]]:
        object_name = str(spec.get('object', spec.get('object_name', spec.get('held_object', ''))))
        if not object_name:
            return False, {'reason': 'missing_object_for_grasp_check'}
        metrics_fn = getattr(task, '_gripper_contact_metrics', None)
        if not callable(metrics_fn):
            return False, {'reason': 'gripper_contact_metrics_unavailable', 'object': object_name}
        attach_spec = {
            'require_dual_finger_contact': bool(spec.get('require_dual_finger_contact', True)),
            'require_force_contact': bool(spec.get('require_force_contact', spec.get('require_contact_report', False))),
            'finger_contact_distance': float(spec.get('finger_contact_distance', 0.006)),
            'contact_force_threshold': float(spec.get('contact_force_threshold', 0.2)),
            'physical_attach_surface_gap': float(spec.get('physical_attach_surface_gap', 0.006)),
        }
        for key in (
            'require_dual_force_contact',
            'require_pair_force_contact',
            'require_opposing_force_contact',
            'contact_box_min_half_extent',
            'continuous_physics',
            'measure_force_contact',
            'allow_cross_axis_dual_finger_contact',
            'contact_box_scale',
            'contact_box_half_extents',
            'contact_box_offset',
            'caging_contact_distance',
            'physical_grasp_min_opening_ratio',
            'physical_contact_axes',
            'physical_contact_interior_scale',
            'physical_contact_interior_margin',
            'strict_finger_surface_gap',
            'strict_finger_contact_distance',
        ):
            if key in spec:
                attach_spec[key] = spec[key]
        try:
            metrics = metrics_fn(object_name, robot_name, attach_spec=attach_spec)
        except Exception as exc:
            return False, {
                'reason': 'gripper_contact_metrics_error',
                'object': object_name,
                'error': str(exc),
            }

        strict_ready = False
        strict_fn = getattr(task, '_strict_physical_grasp_contact', None)
        if callable(strict_fn):
            try:
                strict_ready = bool(
                    strict_fn(object_name, metrics, attach_spec=attach_spec).get('physical_contact_ready')
                )
            except Exception:
                strict_ready = False
        if bool(spec.get('require_strict_physical_contact', False)):
            contact_ready = strict_ready
        else:
            contact_ready = bool(metrics.get('contact_ready') or strict_ready)
        return contact_ready, {
            'object': object_name,
            'contact_ready': contact_ready,
            'strict_contact_ready': strict_ready,
            'contact_metrics': metrics,
        }

    def _failure_or_hold(
        self,
        task,
        robot_name: str,
        spec: dict,
        reason: str,
        diagnostics: dict[str, Any] | None = None,
    ) -> dict:
        if bool(spec.get('require_success', False)):
            return {
                '__local_skill_failure__': True,
                'reason': reason,
                'diagnostics': {
                    'skill': spec.get('name'),
                    'robot': robot_name,
                    **(diagnostics or {}),
                },
            }
        action = self._hold_joint_action(task=task, robot_name=robot_name)
        gripper_command = spec.get('gripper_command')
        if gripper_command is not None:
            action[_GRIPPER_CONTROLLER] = [
                self._gripper_command_value(task=task, robot_name=robot_name, command=gripper_command)
            ]
        return action


# Backward-compatible import for existing recipes and downstream code.
AssemblyAtomicSkillAdapter = UR5eAssemblyAtomicSkillAdapter
UR5ePlumbersBlockAtomicSkillAdapter = UR5eAssemblyAtomicSkillAdapter

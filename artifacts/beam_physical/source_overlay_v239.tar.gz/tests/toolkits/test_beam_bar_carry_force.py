"""CC15 bar preload: actual regulator/publisher, ownership and hard limits."""
import copy
import unittest
import test_beam_turn_force as turn


class BarPublisher(unittest.TestCase):
    publish=turn.PublisherForceBand.publish
    closure=turn.PublisherForceBand.closure

    def setUp(self):
        turn.PublisherForceBand.setUp(self)
        self.saved['object']='fabrica_beam_1'
        self.task._attachments['fabrica_beam_1']={'attach_spec':copy.deepcopy(turn.CARRY)}
        self.task.phase='assemble_02_part_1_grip_settle'
        self.phase_spec={'local_skill':{'object':'fabrica_beam_1','robot':'left',
            'requires_held_object':True,'beam_bar_carry_peak_force_band_N':[18.,24.]}}

    def test_original_low_forces_preload_once_with_caps_and_unchanged_anchor(self):
        self.metrics['left_finger']['force']=4.8;self.metrics['right_finger']['force']=5.1
        before=copy.deepcopy(self.task._attachments)
        result=self.publish();control=self.saved['loaded_force_state']['last_control']
        self.assertEqual(control['mode'],'preload')
        self.assertAlmostEqual(self.closure(result),.715+.025/240)
        self.assertLessEqual(self.closure(result)-.715,.001)
        self.assertEqual(self.task._attachments,before)
        self.assertEqual(self.saved['loaded_force_state']['contact_capture_closure'],.715)
        state=copy.deepcopy(self.saved);self.assertEqual(self.publish(),result);self.assertEqual(self.saved,state)

    def test_band_hold_unload_and_original_hard_limit(self):
        for forces,mode in [((19.,20.),'bilateral_hold'),((19.,25.),'unload')]:
            self.metrics['left_finger']['force'],self.metrics['right_finger']['force']=forces
            self.task.step_counter+=1;self.publish()
            self.assertEqual(self.saved['loaded_force_state']['last_control']['mode'],mode)
        self.metrics['left_finger']['force']=40.01;self.task.step_counter+=1
        before=self.saved['gripper_openness'];result=self.publish()
        self.assertEqual(result['reason'],'loaded_gripper_force_limit')
        self.assertEqual(self.saved['gripper_openness'],before)

    def test_invalid_bands_cannot_change_openness_or_capture(self):
        for value in [[18.,41.],[18.],[float('nan'),24.],'bad','89',None]:
            self.phase_spec['local_skill']['beam_bar_carry_peak_force_band_N']=value
            self.task.step_counter+=1;before=copy.deepcopy(self.saved)
            result=self.publish()
            self.assertEqual(result['reason'],'loaded_bar_carry_force_band_invalid')
            self.assertEqual(self.saved['gripper_openness'],before['gripper_openness'])
            self.assertEqual(self.task._attachments['fabrica_beam_1']['attach_spec'],turn.CARRY)

    def test_wrong_object_robot_or_holder_flag_ignores_key(self):
        for field,value in [('object','fabrica_beam_0'),('robot','right'),('requires_held_object',False)]:
            spec=copy.deepcopy(self.phase_spec);self.phase_spec['local_skill'][field]=value
            self.task.step_counter+=1
            self.assertAlmostEqual(self.closure(self.publish()),.715)
            self.phase_spec=spec
        for object_name in ['fabrica_beam_2','fabrica_beam_3']:
            self.saved['object']=object_name
            self.task._attachments[object_name]={'attach_spec':copy.deepcopy(turn.CARRY)}
            self.task.step_counter+=1
            self.assertAlmostEqual(self.closure(self.publish()),.715)

    def test_band_regulates_peak_not_a_new_weak_finger_gate(self):
        # The existing regulator uses peak force. This counterexample records
        # the distinction for CC rather than silently changing its algorithm.
        self.metrics['left_finger']['force']=17.;self.metrics['right_finger']['force']=19.
        self.publish()
        self.assertEqual(self.saved['loaded_force_state']['last_control']['mode'],'bilateral_hold')


if __name__=='__main__':unittest.main()

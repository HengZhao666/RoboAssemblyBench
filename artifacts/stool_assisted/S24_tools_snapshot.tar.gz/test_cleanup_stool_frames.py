"""Synthetic filesystem/media receipts only; no real video decode or run deletion."""
import copy, hashlib, importlib.util, json, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('cleanup',Path(__file__).with_name('cleanup_stool_frames.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class CleanupTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name).resolve();self.run=self.root/'runs/S05';self.run.mkdir(parents=True)
        self.write('finished_at','2026-10-22T01:00:00Z');self.write('formal_closure.json',dict(id='S05',closed=True,main_task_success=False))
        self.clock=[];self.media=[]
        for name in m.CAMERAS:
            video='episode_0000_live_videos/observation_images_'+name+'.mp4';self.write(video,('synthetic_video_'+name).encode());sha=m.digest(self.run/video)
            self.media.append(dict(camera='observation.images.'+name,path=video,decoded=True,sha256_verified=True,sha256=sha,sha256_before=sha,sha256_after=sha,decode=dict(passed=True,exit_code=0,frame_count=50)))
        for i in range(50):
            for name in m.CAMERAS:
                path=f'episode_0000_live_frames/observation_images_{name}/frame_{i:05d}.png';self.write(path,f'synthetic_png_{name}_{i}'.encode());self.clock.append(dict(camera='observation.images.'+name,frame_index=i,image_path=path,physics_stamp=self.stamp(3+i*5)))
        self.write('media_verification.json',dict(status='passed',all_three_original_videos_decoded=True,sha256_verified=True,files=self.media))
        self.jsonl('video_frame_clock.jsonl',self.clock)
        d=json.loads((self.run/'media_verification.json').read_text());d['raw_clock']=dict(passed=True,raw_clock_sha256=m.digest(self.run/'video_frame_clock.jsonl'));self.write('media_verification.json',d)
        self.jsonl('assisted_trace.jsonl',[dict(event='fabrica_final_published_batch',phase='phase_a',physics_stamp=self.stamp(3)),dict(event='fabrica_final_published_batch',phase='phase_b',physics_stamp=self.stamp(73)),dict(event='attach_measured_pose',phase='phase_b',object='part_2',physics_stamp=self.stamp(107))])
        self.write('episode_0000.json',dict(phase_blueprint=['phase_a','phase_b'],metrics=dict(phase_history=['phase_a','phase_b','failed'])))
        self.write('production_control_failure.json',dict(physics_stamp=self.stamp(184)))
        self.protected=['independent_native_trace.jsonl','startup_front.png','terminal_front.png','source_snapshot.tar.gz']
        for name in self.protected:self.write(name,b'protected_original')
    def tearDown(self):self.temp.cleanup()
    @staticmethod
    def stamp(i):return dict(valid=True,epoch=0,index=i,time=i/240)
    def write(self,name,value):
        p=self.run/name;p.parent.mkdir(parents=True,exist_ok=True)
        if isinstance(value,dict):p.write_text(json.dumps(value))
        elif isinstance(value,str):p.write_text(value)
        else:p.write_bytes(value)
    def jsonl(self,name,rows):self.write(name,''.join(json.dumps(x)+'\n' for x in rows))
    def seal(self):
        value=m.plan(self.run,'download receipt path and SHA: human-reviewed note only');path=self.root/'manifest.json';path.write_text(json.dumps(value));return value,path,m.digest(path)
    def execute(self,path,sha):return m.execute(self.run,path,sha,self.root/'receipt.json')
    def test_retention_and_neighbor_clock_claims(self):
        value=m.plan(self.run);self.assertTrue(value['delete']);self.assertEqual(len(value['keep']),63)
        for name in m.CAMERAS:
            for i in [0,1,2,12,13,14,15,16,18,19,20,21,22,23,34,35,36,37,38,39,49]:self.assertIn(f'episode_0000_live_frames/observation_images_{name}/frame_{i:05d}.png',value['keep'])
        mappings=value['event_frame_mappings'];self.assertTrue(any(x['exact_event_clock_available'] for x in mappings));self.assertTrue(all(not x['exact_event_clock_available'] for x in mappings if x['event']['kind'] in ['attach','first_failure']))
    def test_synthetic_execute_only_expected_pngs_and_one_receipt(self):
        value,path,sha=self.seal();protected={n:m.digest(self.run/n) for n in self.protected};result=self.execute(path,sha)
        self.assertTrue(result['passed']);self.assertEqual(len(result['deleted']),len(value['delete']));self.assertEqual(result['logical_deleted_bytes'],value['logical_delete_bytes']);self.assertIn('free',result['disk_before']);self.assertIn('free',result['disk_after'])
        self.assertTrue(all((self.run/n).is_file() for n in value['keep']));self.assertTrue(all(m.digest(self.run/n)==s for n,s in protected.items()))
        with self.assertRaises(ValueError):self.execute(path,sha)
    def test_wrong_approved_sha_deletes_nothing(self):
        value,path,sha=self.seal()
        with self.assertRaises(ValueError):self.execute(path,'0'*64)
        self.assertTrue(all((self.run/x['path']).exists() for x in value['delete']))
    def test_changed_target_same_size_prevents_all_deletions(self):
        value,path,sha=self.seal();p=self.run/value['delete'][-1]['path'];data=p.read_bytes();p.write_bytes(bytes([data[0]^1])+data[1:]);result=self.execute(path,sha)
        self.assertFalse(result['passed']);self.assertEqual(result['deleted'],[]);self.assertTrue((self.run/value['delete'][0]['path']).exists())
    def test_changed_video_same_size_prevents_all_deletions(self):
        value,path,sha=self.seal();p=self.run/self.media[0]['path'];data=p.read_bytes();p.write_bytes(bytes([data[0]^1])+data[1:]);self.assertFalse(self.execute(path,sha)['passed'])
    def test_modified_receipt_protected_plan_cannot_bypass_even_with_new_sha(self):
        value,path,sha=self.seal();value['delete'].append(m.record(self.run,value['keep'][0]));path.write_text(json.dumps(value));result=self.execute(path,m.digest(path));self.assertFalse(result['passed']);self.assertEqual(result['deleted'],[])
    def test_raw_deletion_path_cannot_be_approved(self):
        value,path,sha=self.seal();value['delete']=[m.record(self.run,self.protected[0])];path.write_text(json.dumps(value));self.assertFalse(self.execute(path,m.digest(path))['passed']);self.assertTrue((self.run/self.protected[0]).exists())
    def test_decode_failure_rejected(self):
        d=json.loads((self.run/'media_verification.json').read_text());d['files'][0]['decode']['passed']=False;self.write('media_verification.json',d)
        with self.assertRaises(ValueError):m.plan(self.run)
    def test_unclosed_or_unfinished_run_rejected(self):
        self.write('formal_closure.json',dict(id='S05',closed=False,main_task_success=False))
        with self.assertRaises(ValueError):m.plan(self.run)
        self.write('formal_closure.json',dict(id='S05',closed=True,main_task_success=False));(self.run/'finished_at').unlink()
        with self.assertRaises(ValueError):m.plan(self.run)
    def test_camera_directory_symlink_rejected(self):
        camera=self.run/'episode_0000_live_frames/observation_images_front';real=self.root/'outside_camera';camera.rename(real);camera.symlink_to(real,target_is_directory=True)
        with self.assertRaises(ValueError):m.plan(self.run)
    def test_frame_symlink_rejected(self):
        p=self.run/self.clock[0]['image_path'];p.unlink();p.symlink_to(self.run/self.protected[0])
        with self.assertRaises(ValueError):m.plan(self.run)
    def test_run_symlink_rejected(self):
        alias=self.root/'alias';alias.symlink_to(self.run,target_is_directory=True)
        with self.assertRaises(ValueError):m.plan(alias)
    def test_wrong_camera_duplicate_or_missing_ordinal_rejected(self):
        self.clock[3]['frame_index']=0;self.jsonl('video_frame_clock.jsonl',self.clock)
        with self.assertRaises(ValueError):m.plan(self.run)
    def test_missing_phase_event_rejected(self):
        episode=json.loads((self.run/'episode_0000.json').read_text());episode['phase_blueprint'].append('phase_c');episode['metrics']['phase_history'].append('phase_c');self.write('episode_0000.json',episode)
        with self.assertRaises(ValueError):m.plan(self.run)
    def test_failure_without_native_stamp_rejected(self):
        (self.run/'production_control_failure.json').unlink()
        with self.assertRaises(ValueError):m.plan(self.run)
    def test_unclocked_png_rejected(self):
        self.write('episode_0000_live_frames/observation_images_front/frame_99999.png',b'unclocked')
        with self.assertRaises(ValueError):m.plan(self.run)
    def test_symlink_receipt_rejected_before_deletion(self):
        value,path,sha=self.seal();receipt=self.root/'receipt.json';receipt.symlink_to(self.root/'missing')
        with self.assertRaises(ValueError):self.execute(path,sha)
        self.assertTrue(all((self.run/x['path']).exists() for x in value['delete']))
    def test_note_not_a_machine_verified_download_gate(self):
        value=m.plan(self.run,'not verified by this utility');self.assertEqual(value['download_proof_note'],'not verified by this utility');self.assertIn('not independently proved',value['download_archive_review'])

if __name__=='__main__':unittest.main()

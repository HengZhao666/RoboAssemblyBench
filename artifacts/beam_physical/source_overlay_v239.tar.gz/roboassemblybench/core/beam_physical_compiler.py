"""Server v169 compiler preserved for continuous Beam regression experiments.

This module is intentionally isolated from upstream demonstration compilation:
layout/grasp selection, contact gates, support phases and seed rules must remain
comparable with v169. Shared simulator, robot/controller and skill implementations
still receive upstream integration and are verified on the server.
Source checkpoint: 901667d86d2dcb07819088b646625ddd94b2b74d.
"""
from __future__ import annotations

import copy
import json
import math
import os
import warnings
from functools import lru_cache
from pathlib import Path
from typing import Any

import numpy as np

from roboassemblybench.core.paths import BENCHMARK_ROOT
from roboassemblybench.core.scene_profiles import deep_merge
from toolkits.factory_dual_franka_assembly.ur5e_skill_api import UR5eAssemblySkillAPI

class _BeamAssemblySkillAPI(UR5eAssemblySkillAPI):
    _motion_defaults = {
        'cartesian_servo': True,
        'cartesian_position_step': 0.015,
        'cartesian_orientation_step': 0.030,
        'guard_ik_branch_jump': True,
        'ik_branch_jump_limit': 0.30,
        'default_max_command_joint_step': 0.060,
        'default_max_command_wrist_joint_step': 0.040,
        'limit_command_to_measured_state': True,
        'max_command_tracking_error': 0.18,
        'max_wrist_command_tracking_error': 0.12,
    }
    _transport_motion_defaults = {
        **_motion_defaults,
        'cartesian_orientation_step': 0.030,
        'default_max_command_joint_step': 0.060,
        'default_max_command_wrist_joint_step': 0.040,
        'servo_target_object_pose': True,
    }
    _hold_motion_defaults = {
        **_motion_defaults,
        'cartesian_position_step': 0.001,
        'cartesian_orientation_step': 0.015,
        'default_max_command_joint_step': 0.015,
        'default_max_command_wrist_joint_step': 0.010,
    }
    _descend_motion_defaults = {
        **_motion_defaults,
        'cartesian_position_step': 0.004,
        'cartesian_orientation_step': 0.015,
        'default_max_command_joint_step': 0.035,
        'default_max_command_wrist_joint_step': 0.015,
    }
    _retreat_motion_defaults = {
        **_motion_defaults,
        'relative_to_current_tcp': True,
        'offset': [0.0, 0.0, 0.15],
        'offset_frame': 'world',
        'lock_target_position': True,
        'lock_target_orientation': True,
        'cartesian_position_step': 0.008,
        'default_max_command_joint_step': 0.035,
        'default_max_command_wrist_joint_step': 0.020,
    }


CANONICAL_METADATA_PATH = BENCHMARK_ROOT / 'assets/Fabrica/canonical_7_bundles/canonical_tasks.json'
CANONICAL_SCHEMA_VERSION = 'roboassemblybench.fabrica_canonical/v3'
PICKUP_TCP_ORIENTATION_REFERENCE_WXYZ = [0.0, 1.0, 0.0, 0.0]
DEFAULT_PICKUP_YAW_CANDIDATES_DEGREES = [0.0, 90.0, -90.0, 180.0]


def _vector(value: Any, *, size: int, name: str) -> list[float]:
    result = [float(item) for item in value]
    if len(result) != size or not all(math.isfinite(item) for item in result):
        raise ValueError(f'{name} must contain {size} finite numbers.')
    return result


def _add(left: list[float], right: list[float]) -> list[float]:
    return [float(a + b) for a, b in zip(left, right)]


def _quat_conjugate(quaternion: list[float]) -> list[float]:
    w, x, y, z = quaternion
    return [w, -x, -y, -z]


def _quat_multiply(left: list[float], right: list[float]) -> list[float]:
    lw, lx, ly, lz = left
    rw, rx, ry, rz = right
    result = [
        lw * rw - lx * rx - ly * ry - lz * rz,
        lw * rx + lx * rw + ly * rz - lz * ry,
        lw * ry - lx * rz + ly * rw + lz * rx,
        lw * rz + lx * ry - ly * rx + lz * rw,
    ]
    norm = math.sqrt(sum(value * value for value in result))
    if norm <= 1e-12:
        raise ValueError('Cannot normalize a zero quaternion.')
    return [float(value / norm) for value in result]


def _quat_rotate(quaternion: list[float], vector: list[float]) -> list[float]:
    vector_quaternion = [0.0, *vector]
    rotated = _quat_multiply_raw(
        _quat_multiply_raw(quaternion, vector_quaternion),
        _quat_conjugate(quaternion),
    )
    return [float(value) for value in rotated[1:]]


def _quat_multiply_raw(left: list[float], right: list[float]) -> list[float]:
    lw, lx, ly, lz = left
    rw, rx, ry, rz = right
    return [
        lw * rw - lx * rx - ly * ry - lz * rz,
        lw * rx + lx * rw + ly * rz - lz * ry,
        lw * ry - lx * rz + ly * rw + lz * rx,
        lw * rz + lx * ry - ly * rx + lz * rw,
    ]


def _compose_pose(
    base_position: list[float],
    base_orientation: list[float],
    local_position: list[float],
    local_orientation: list[float],
) -> tuple[list[float], list[float]]:
    return (
        _add(base_position, _quat_rotate(base_orientation, local_position)),
        _quat_multiply(base_orientation, local_orientation),
    )


def _yaw_quaternion(degrees: float) -> list[float]:
    half_angle = math.radians(float(degrees)) * 0.5
    return [math.cos(half_angle), 0.0, 0.0, math.sin(half_angle)]


def _orientation_continuity(
    orientation: list[float],
    reference: list[float],
) -> float:
    return abs(float(sum(left * right for left, right in zip(orientation, reference))))


def _normalized_direction(values: list[float], *, name: str) -> list[float]:
    direction = _vector(values, size=3, name=name)
    norm = math.sqrt(sum(value * value for value in direction))
    if norm <= 1e-9:
        raise ValueError(f'{name} must have non-zero length.')
    return [value / norm for value in direction]


def _projected_box_minimum_lateral_extent(
    *,
    bbox_size: list[float],
    orientation: list[float],
    axis: list[float],
) -> float:
    """Return the minimum width of an oriented box perpendicular to ``axis``."""

    normalized_axis = np.asarray(
        _normalized_direction(axis, name='box lateral-extent axis'),
        dtype=float,
    )
    world_axes = [
        np.asarray(
            _quat_rotate(
                orientation,
                [1.0 if local_axis == axis_index else 0.0 for local_axis in range(3)],
            ),
            dtype=float,
        )
        for axis_index in range(3)
    ]
    lateral_directions: list[np.ndarray] = []
    for world_axis in world_axes:
        direction = np.cross(normalized_axis, world_axis)
        norm = float(np.linalg.norm(direction))
        if norm > 1e-9:
            lateral_directions.append(direction / norm)
    if not lateral_directions:
        raise ValueError('Cannot derive a lateral direction for the oriented box.')
    return min(
        sum(float(size) * abs(float(np.dot(world_axis, direction))) for size, world_axis in zip(bbox_size, world_axes))
        for direction in lateral_directions
    )


@lru_cache(maxsize=4)
def _load_metadata_cached(path: str) -> dict[str, Any]:
    payload = json.loads(Path(path).read_text(encoding='utf-8'))
    if payload.get('schema_version') != CANONICAL_SCHEMA_VERSION:
        raise ValueError(f'Unsupported canonical Fabrica metadata schema ' f'{payload.get("schema_version")!r}.')
    tasks = payload.get('tasks')
    if not isinstance(tasks, dict) or not tasks:
        raise ValueError('Canonical Fabrica metadata does not define any tasks.')
    return payload


def load_fabrica_canonical_metadata(path: str | Path | None = None) -> dict[str, Any]:
    resolved_path = Path(path or CANONICAL_METADATA_PATH).expanduser().resolve()
    return copy.deepcopy(_load_metadata_cached(str(resolved_path)))


def _merge_named_entries(generated: list[dict], existing: list[dict]) -> list[dict]:
    existing_by_name = {
        str(entry['name']): entry for entry in existing if isinstance(entry, dict) and entry.get('name') is not None
    }
    result = []
    generated_names = set()
    for entry in generated:
        name = str(entry['name'])
        generated_names.add(name)
        result.append(deep_merge(entry, existing_by_name.get(name, {})))
    result.extend(
        copy.deepcopy(entry)
        for entry in existing
        if not isinstance(entry, dict) or entry.get('name') is None or str(entry['name']) not in generated_names
    )
    return result


def _asset_path(relative_path: str) -> str:
    return str((BENCHMARK_ROOT.parent / relative_path).resolve())


def _contact_box(part: dict[str, Any]) -> tuple[list[float], list[float]]:
    bbox_min = _vector(part['bbox_min'], size=3, name='part bbox_min')
    bbox_max = _vector(part['bbox_max'], size=3, name='part bbox_max')
    center = [(lower + upper) * 0.5 for lower, upper in zip(bbox_min, bbox_max)]
    scale = [max(upper - lower, 0.008) for lower, upper in zip(bbox_min, bbox_max)]
    return center, scale


def _tcp_pose_for_object_pose(
    *,
    object_position: list[float],
    object_orientation: list[float],
    grasp: dict[str, Any],
) -> tuple[list[float], list[float]]:
    tcp_orientation = _quat_multiply(
        object_orientation,
        _quat_conjugate(
            _vector(
                grasp['object_in_tcp_orientation'],
                size=4,
                name='grasp object_in_tcp_orientation',
            )
        ),
    )
    tcp_position = _add(
        object_position,
        [
            -value
            for value in _quat_rotate(
                tcp_orientation,
                _vector(
                    grasp['object_in_tcp_position'],
                    size=3,
                    name='grasp object_in_tcp_position',
                ),
            )
        ],
    )
    return tcp_position, tcp_orientation


def _point_aabb_distance(
    point: list[float],
    lower: list[float],
    upper: list[float],
) -> float:
    squared_distance = 0.0
    for value, minimum, maximum in zip(point, lower, upper):
        delta = max(minimum - value, 0.0, value - maximum)
        squared_distance += delta * delta
    return math.sqrt(squared_distance)


def _pickup_fixture_body_clearance(
    *,
    grasp_center: list[float],
    tcp_position: list[float],
    pickup_origin: list[float],
    pickup_orientation: list[float],
    fixture_bbox_min: list[float],
    fixture_bbox_max: list[float],
    footprint_margin: float,
    body_start_fraction: float,
    body_sample_count: int,
) -> float:
    """Estimate gripper-body clearance above a tabletop pickup fixture.

    The fingertips may enter a fixture pocket, so only the established gripper-body
    segment is sampled.  Measurements are made in fixture coordinates and the
    footprint is expanded to account for the body's radial extent.
    """

    inverse_pickup_orientation = _quat_conjugate(pickup_orientation)
    clearance = math.inf
    for sample_index in range(body_sample_count):
        interpolation = body_start_fraction + (
            (1.0 - body_start_fraction) * sample_index / max(body_sample_count - 1, 1)
        )
        sample = [center + interpolation * (tcp - center) for center, tcp in zip(grasp_center, tcp_position)]
        fixture_local = _quat_rotate(
            inverse_pickup_orientation,
            [value - origin for value, origin in zip(sample, pickup_origin)],
        )
        if (
            fixture_bbox_min[0] - footprint_margin <= fixture_local[0] <= fixture_bbox_max[0] + footprint_margin
            and fixture_bbox_min[1] - footprint_margin <= fixture_local[1] <= fixture_bbox_max[1] + footprint_margin
        ):
            clearance = min(clearance, fixture_local[2] - fixture_bbox_max[2])
    return 1.0 if not math.isfinite(clearance) else clearance


@lru_cache(maxsize=2)
def _ur5e_ik_chain(urdf_path: str):
    from ikpy.chain import Chain

    with warnings.catch_warnings():
        warnings.simplefilter('ignore', UserWarning)
        chain = Chain.from_urdf_file(urdf_path)
    chain.active_links_mask = np.asarray(
        [link.joint_type != 'fixed' for link in chain.links],
        dtype=bool,
    )
    return chain


def _rotation_matrix(quaternion: list[float]) -> np.ndarray:
    w, x, y, z = _vector(quaternion, size=4, name='rotation quaternion')
    norm = math.sqrt(w * w + x * x + y * y + z * z)
    if norm <= 1e-12:
        raise ValueError('rotation quaternion cannot be zero.')
    w, x, y, z = (value / norm for value in (w, x, y, z))
    return np.asarray(
        [
            [1.0 - 2.0 * (y * y + z * z), 2.0 * (x * y - z * w), 2.0 * (x * z + y * w)],
            [2.0 * (x * y + z * w), 1.0 - 2.0 * (x * x + z * z), 2.0 * (y * z - x * w)],
            [2.0 * (x * z - y * w), 2.0 * (y * z + x * w), 1.0 - 2.0 * (x * x + y * y)],
        ],
        dtype=float,
    )


def _ur5e_initial_ik_configuration(chain, robot: dict[str, Any]) -> np.ndarray:
    configured = robot.get('initial_joint_positions') or {}
    if not isinstance(configured, dict):
        raise ValueError('UR5e initial_joint_positions must be a mapping.')
    result = np.zeros(len(chain.links), dtype=float)
    for index, link in enumerate(chain.links):
        if link.name in configured:
            result[index] = float(configured[link.name])
    return result


def _pose_in_robot_frame(
    *,
    position: list[float],
    orientation: list[float],
    robot_position: list[float],
    robot_orientation: list[float],
) -> tuple[list[float], list[float]]:
    inverse_robot_orientation = _quat_conjugate(robot_orientation)
    return (
        _quat_rotate(
            inverse_robot_orientation,
            [value - origin for value, origin in zip(position, robot_position)],
        ),
        _quat_multiply(inverse_robot_orientation, orientation),
    )


def _solve_ur5e_ik_pose(
    *,
    chain,
    position: list[float],
    orientation: list[float],
    robot_position: list[float],
    robot_orientation: list[float],
    warm_start: np.ndarray,
    fallback_start: np.ndarray,
    max_iterations: int,
) -> tuple[np.ndarray, float, float]:
    local_position, local_orientation = _pose_in_robot_frame(
        position=position,
        orientation=orientation,
        robot_position=robot_position,
        robot_orientation=robot_orientation,
    )
    target = np.eye(4, dtype=float)
    target[:3, :3] = _rotation_matrix(local_orientation)
    target[:3, 3] = np.asarray(local_position, dtype=float)
    best: tuple[np.ndarray, float, float] | None = None
    for seed in (warm_start, fallback_start):
        try:
            solution = np.asarray(
                chain.inverse_kinematics_frame(
                    target,
                    initial_position=np.asarray(seed, dtype=float),
                    orientation_mode='all',
                    max_iter=max_iterations,
                ),
                dtype=float,
            )
            actual = np.asarray(chain.forward_kinematics(solution), dtype=float)
        except Exception:
            continue
        position_error = float(np.linalg.norm(actual[:3, 3] - target[:3, 3]))
        delta_rotation = actual[:3, :3].T @ target[:3, :3]
        cosine = min(max((float(np.trace(delta_rotation)) - 1.0) * 0.5, -1.0), 1.0)
        orientation_error = math.acos(cosine)
        candidate = (solution, position_error, orientation_error)
        if best is None or (position_error, orientation_error) < (best[1], best[2]):
            best = candidate
    if best is None:
        return fallback_start.copy(), math.inf, math.inf
    return best


def _ur5e_jacobian_metrics(
    chain,
    configuration: np.ndarray,
    *,
    finite_difference_step: float = 1e-5,
) -> tuple[float, float]:
    active_indices = np.flatnonzero(chain.active_links_mask)
    current = np.asarray(chain.forward_kinematics(configuration), dtype=float)
    jacobian = np.zeros((6, len(active_indices)), dtype=float)
    for column, link_index in enumerate(active_indices):
        shifted = np.asarray(configuration, dtype=float).copy()
        shifted[link_index] += finite_difference_step
        pose = np.asarray(chain.forward_kinematics(shifted), dtype=float)
        jacobian[:3, column] = (pose[:3, 3] - current[:3, 3]) / finite_difference_step
        rotation_delta = pose[:3, :3] @ current[:3, :3].T
        jacobian[3:, column] = np.asarray(
            [
                rotation_delta[2, 1] - rotation_delta[1, 2],
                rotation_delta[0, 2] - rotation_delta[2, 0],
                rotation_delta[1, 0] - rotation_delta[0, 1],
            ],
            dtype=float,
        ) / (2.0 * finite_difference_step)
    singular_values = np.linalg.svd(jacobian, compute_uv=False)
    minimum_singular_value = float(singular_values[-1])
    condition_number = (
        math.inf if minimum_singular_value <= 1e-12 else float(singular_values[0] / minimum_singular_value)
    )
    return minimum_singular_value, condition_number


def _move_grasp_ik_metrics(
    *,
    candidate: dict[str, Any],
    part: dict[str, Any],
    step: dict[str, Any],
    pickup_origin: list[float],
    pickup_orientation: list[float],
    assembly_origin: list[float],
    assembly_orientation: list[float],
    workspace_offset: list[float],
    robot: dict[str, Any],
    transport_tcp_height: float,
    lift_distance: float,
    position_tolerance: float,
    orientation_tolerance: float,
    minimum_manipulability: float,
    max_iterations: int,
) -> dict[str, Any]:
    from internutopia_extension.configs.robots.ur5e import arm_ik_cfg

    chain = _ur5e_ik_chain(str(arm_ik_cfg.robot_urdf_path))
    initial_configuration = _ur5e_initial_ik_configuration(chain, robot)
    robot_position = _vector(
        robot.get('position', [0.0, 0.0, 0.0]),
        size=3,
        name='UR5e IK robot position',
    )
    if bool(robot.get('apply_workspace_offset', True)):
        robot_position = _add(robot_position, workspace_offset)
    robot_orientation = _vector(
        robot.get('orientation', [1.0, 0.0, 0.0, 0.0]),
        size=4,
        name='UR5e IK robot orientation',
    )

    pickup_part_position, pickup_part_orientation = _part_pickup_pose(
        part,
        pickup_origin=pickup_origin,
        pickup_orientation=pickup_orientation,
    )
    pickup_tcp_position, pickup_tcp_orientation = _tcp_pose_for_object_pose(
        object_position=pickup_part_position,
        object_orientation=pickup_part_orientation,
        grasp=candidate,
    )
    pickup_tcp_position = _add(pickup_tcp_position, workspace_offset)

    path = list(reversed(step['disassembly_path']))
    assembly_waypoints = [
        _compose_pose(
            assembly_origin,
            assembly_orientation,
            _vector(waypoint['position'], size=3, name='IK waypoint position'),
            _vector(waypoint['orientation'], size=4, name='IK waypoint orientation'),
        )
        for waypoint in path
    ]
    first_object_position, first_object_orientation = assembly_waypoints[0]
    assembly_clearance_object_position = _object_position_at_tcp_height(
        object_position=first_object_position,
        object_orientation=first_object_orientation,
        grasp=candidate,
        tcp_height=transport_tcp_height,
    )
    assembly_clearance_tcp_position, assembly_clearance_tcp_orientation = _tcp_pose_for_object_pose(
        object_position=assembly_clearance_object_position,
        object_orientation=first_object_orientation,
        grasp=candidate,
    )
    targets = [
        (
            'pickup_approach',
            _add(pickup_tcp_position, [0.0, 0.0, lift_distance]),
            pickup_tcp_orientation,
        ),
        ('pickup', pickup_tcp_position, pickup_tcp_orientation),
        (
            'lift',
            [
                pickup_tcp_position[0],
                pickup_tcp_position[1],
                max(
                    pickup_tcp_position[2] + lift_distance,
                    transport_tcp_height + workspace_offset[2],
                ),
            ],
            pickup_tcp_orientation,
        ),
        (
            'assembly_clearance',
            _add(assembly_clearance_tcp_position, workspace_offset),
            assembly_clearance_tcp_orientation,
        ),
    ]
    for waypoint_index, (object_position, object_orientation) in enumerate(assembly_waypoints):
        tcp_position, tcp_orientation = _tcp_pose_for_object_pose(
            object_position=object_position,
            object_orientation=object_orientation,
            grasp=candidate,
        )
        target_name = (
            'insertion_final' if waypoint_index == len(assembly_waypoints) - 1 else f'insertion_{waypoint_index:02d}'
        )
        targets.append(
            (
                target_name,
                _add(tcp_position, workspace_offset),
                tcp_orientation,
            )
        )
    configuration = initial_configuration.copy()
    errors: dict[str, dict[str, float]] = {}
    feasible = True
    maximum_position_error = 0.0
    maximum_orientation_error = 0.0
    minimum_path_manipulability = math.inf
    maximum_path_condition_number = 0.0
    for name, position, orientation in targets:
        configuration, position_error, orientation_error = _solve_ur5e_ik_pose(
            chain=chain,
            position=position,
            orientation=orientation,
            robot_position=robot_position,
            robot_orientation=robot_orientation,
            warm_start=configuration,
            fallback_start=configuration,
            max_iterations=max_iterations,
        )
        manipulability, condition_number = _ur5e_jacobian_metrics(
            chain,
            configuration,
        )
        errors[name] = {
            'position_error': position_error,
            'orientation_error': orientation_error,
            'minimum_jacobian_singular_value': manipulability,
            'jacobian_condition_number': condition_number,
        }
        maximum_position_error = max(maximum_position_error, position_error)
        maximum_orientation_error = max(maximum_orientation_error, orientation_error)
        minimum_path_manipulability = min(
            minimum_path_manipulability,
            manipulability,
        )
        maximum_path_condition_number = max(
            maximum_path_condition_number,
            condition_number,
        )
        if (
            position_error > position_tolerance
            or orientation_error > orientation_tolerance
            or manipulability < minimum_manipulability
        ):
            feasible = False
            break
    return {
        'ik_feasible': feasible,
        'ik_position_tolerance': position_tolerance,
        'ik_orientation_tolerance': orientation_tolerance,
        'ik_minimum_manipulability_threshold': minimum_manipulability,
        'ik_maximum_position_error': maximum_position_error,
        'ik_maximum_orientation_error': maximum_orientation_error,
        'ik_minimum_path_manipulability': minimum_path_manipulability,
        'ik_maximum_path_condition_number': maximum_path_condition_number,
        'ik_errors_by_target': errors,
    }


def _move_grasp_candidate_metrics(
    *,
    assembly: str,
    candidate: dict[str, Any],
    part: dict[str, Any],
    step: dict[str, Any],
    assembled_parts: list[dict[str, Any]],
    pickup_origin: list[float],
    pickup_orientation: list[float],
    assembly_origin: list[float],
    assembly_orientation: list[float],
    workspace_offset: list[float],
    fixture_bbox_min: list[float],
    fixture_bbox_max: list[float],
    fixture_footprint_margin: float,
    robot_position: list[float],
    orientation_reference: list[float],
    approach_height: float,
    body_start_fraction: float,
    body_sample_count: int,
) -> dict[str, Any]:
    part_id = str(part['part_id'])
    pickup_part_position, pickup_part_orientation = _part_pickup_pose(
        part,
        pickup_origin=pickup_origin,
        pickup_orientation=pickup_orientation,
    )
    pickup_tcp_position, pickup_tcp_orientation = _tcp_pose_for_object_pose(
        object_position=pickup_part_position,
        object_orientation=pickup_part_orientation,
        grasp=candidate,
    )
    pickup_grasp_center = _add(
        pickup_part_position,
        _quat_rotate(
            pickup_part_orientation,
            _vector(
                candidate['grasp_center_m'],
                size=3,
                name=f'{assembly} part {part_id} pickup grasp_center_m',
            ),
        ),
    )
    pickup_fixture_body_clearance = _pickup_fixture_body_clearance(
        grasp_center=pickup_grasp_center,
        tcp_position=pickup_tcp_position,
        pickup_origin=pickup_origin,
        pickup_orientation=pickup_orientation,
        fixture_bbox_min=fixture_bbox_min,
        fixture_bbox_max=fixture_bbox_max,
        footprint_margin=fixture_footprint_margin,
        body_start_fraction=body_start_fraction,
        body_sample_count=body_sample_count,
    )
    pickup_approach_position = _add(
        _add(pickup_tcp_position, [0.0, 0.0, approach_height]),
        workspace_offset,
    )
    pickup_reach = math.sqrt(sum((pickup_approach_position[axis] - robot_position[axis]) ** 2 for axis in range(3)))
    pickup_orientation_continuity = _orientation_continuity(
        pickup_tcp_orientation,
        orientation_reference,
    )

    path = list(reversed(step['disassembly_path']))
    if not path:
        raise ValueError(f'{assembly}: part {part_id} has an empty insertion path.')
    local_positions = [
        _vector(
            waypoint['position'],
            size=3,
            name=f'{assembly} part {part_id} insertion waypoint position',
        )
        for waypoint in path
    ]
    local_orientations = [
        _vector(
            waypoint['orientation'],
            size=4,
            name=f'{assembly} part {part_id} insertion waypoint orientation',
        )
        for waypoint in path
    ]
    insertion_delta = [final - initial for initial, final in zip(local_positions[0], local_positions[-1])]
    if math.sqrt(sum(value * value for value in insertion_delta)) <= 1e-9:
        insertion_axis = _normalized_direction(
            candidate['assembly_approach_direction'],
            name=f'{assembly} part {part_id} fallback insertion axis',
        )
    else:
        insertion_axis = _normalized_direction(
            insertion_delta,
            name=f'{assembly} part {part_id} insertion axis',
        )
    final_approach_direction = _quat_rotate(
        local_orientations[-1],
        _normalized_direction(
            candidate['assembly_approach_direction'],
            name=f'{assembly} part {part_id} assembly approach direction',
        ),
    )
    insertion_axis_alignment = -sum(
        direction * axis for direction, axis in zip(final_approach_direction, insertion_axis)
    )

    tcp_in_assembly_position = _vector(
        candidate['tcp_in_assembly_position'],
        size=3,
        name=f'{assembly} part {part_id} tcp_in_assembly_position',
    )
    tcp_in_assembly_orientation = _vector(
        candidate['tcp_in_assembly_orientation'],
        size=4,
        name=f'{assembly} part {part_id} tcp_in_assembly_orientation',
    )
    grasp_center = _vector(
        candidate['grasp_center_m'],
        size=3,
        name=f'{assembly} part {part_id} grasp_center_m',
    )
    obstacle_boxes = [
        (
            _vector(
                obstacle['bbox_min'],
                size=3,
                name=f'{assembly} obstacle bbox_min',
            ),
            _vector(
                obstacle['bbox_max'],
                size=3,
                name=f'{assembly} obstacle bbox_max',
            ),
        )
        for obstacle in assembled_parts
    ]
    insertion_body_clearance = math.inf
    assembly_reaches: list[float] = []
    for local_position, local_orientation in zip(local_positions, local_orientations):
        local_tcp_position, _ = _compose_pose(
            local_position,
            local_orientation,
            tcp_in_assembly_position,
            tcp_in_assembly_orientation,
        )
        local_grasp_center = _add(
            local_position,
            _quat_rotate(local_orientation, grasp_center),
        )
        world_object_position, world_object_orientation = _compose_pose(
            assembly_origin,
            assembly_orientation,
            local_position,
            local_orientation,
        )
        world_tcp_position, _ = _tcp_pose_for_object_pose(
            object_position=world_object_position,
            object_orientation=world_object_orientation,
            grasp=candidate,
        )
        world_tcp_position = _add(world_tcp_position, workspace_offset)
        assembly_reaches.append(
            math.sqrt(sum((world_tcp_position[axis] - robot_position[axis]) ** 2 for axis in range(3)))
        )
        for sample_index in range(body_sample_count):
            interpolation = body_start_fraction + (
                (1.0 - body_start_fraction) * sample_index / max(body_sample_count - 1, 1)
            )
            sample = [
                center + interpolation * (tcp - center) for center, tcp in zip(local_grasp_center, local_tcp_position)
            ]
            for lower, upper in obstacle_boxes:
                insertion_body_clearance = min(
                    insertion_body_clearance,
                    _point_aabb_distance(sample, lower, upper),
                )
    if not math.isfinite(insertion_body_clearance):
        insertion_body_clearance = 1.0
    maximum_reach = max([pickup_reach, *assembly_reaches])
    source_collision_count = int(candidate.get('source_collision_count', 0))
    interior_clearance_score = float(candidate.get('interior_clearance_score', 0.0))
    physical_score = (
        insertion_body_clearance
        + 0.04 * insertion_axis_alignment
        + 0.01 * pickup_orientation_continuity
        + 0.02 * min(max(interior_clearance_score, 0.0), 1.0)
        + 0.02 * min(max(pickup_fixture_body_clearance, 0.0), 0.10) / 0.10
        - 0.005 * maximum_reach
        - 0.001 * min(source_collision_count, 3)
    )
    return {
        'grasp_id': int(candidate['grasp_id']),
        'is_planner_grasp': bool(candidate.get('is_planner_grasp', False)),
        'pickup_orientation_continuity': pickup_orientation_continuity,
        'pickup_tcp_reach': pickup_reach,
        'pickup_fixture_body_clearance': pickup_fixture_body_clearance,
        'maximum_tcp_reach': maximum_reach,
        'insertion_axis': insertion_axis,
        'insertion_axis_alignment': insertion_axis_alignment,
        'insertion_body_clearance': insertion_body_clearance,
        'interior_clearance_score': interior_clearance_score,
        'source_collision_count': source_collision_count,
        'physical_score': physical_score,
    }


def _select_move_grasps_for_layout(
    *,
    assembly: str,
    task: dict[str, Any],
    pickup_origin: list[float],
    pickup_orientation: list[float],
    assembly_origin: list[float],
    assembly_orientation: list[float],
    workspace_offset: list[float],
    fixture_bbox_min: list[float],
    fixture_bbox_max: list[float],
    fixture_footprint_margin: float,
    robot: dict[str, Any],
    robot_position: list[float],
    orientation_reference: list[float],
    minimum_orientation_continuity: float,
    maximum_tcp_reach: float,
    approach_height: float,
    body_start_fraction: float,
    body_sample_count: int,
    reselection_minimum_gain: float,
    preferred_interior_clearance: float,
    minimum_relative_interior_clearance: float,
    minimum_fixture_clearance: float,
    minimum_relative_orientation_continuity: float,
    transport_tcp_height: float,
    ik_lift_distance: float,
    ik_position_tolerance: float,
    ik_orientation_tolerance: float,
    ik_minimum_manipulability: float,
    ik_max_iterations: int,
    grasp_id_overrides: dict[str, int] | None = None,
) -> tuple[dict[str, dict[str, Any]], dict[str, dict[str, Any]], bool]:
    parts_by_id = {str(part['part_id']): part for part in task['parts']}
    assembled_parts = [parts_by_id[str(task['base_part'])]]
    selected_by_part: dict[str, dict[str, Any]] = {}
    diagnostics_by_part: dict[str, dict[str, Any]] = {}
    all_steps_feasible = True
    for step in task['assembly_steps']:
        part_id = str(step['move_part'])
        candidates = step.get('move_grasp_candidates')
        if not isinstance(candidates, list) or not candidates:
            legacy_grasp = step.get('move_grasp')
            candidates = [legacy_grasp] if isinstance(legacy_grasp, dict) else []
        override_id = None if grasp_id_overrides is None else grasp_id_overrides.get(part_id)
        if override_id is not None:
            candidates = [
                candidate for candidate in candidates if int(candidate.get('grasp_id', -1)) == int(override_id)
            ]
            if not candidates:
                raise ValueError(
                    f'{assembly}: configured move grasp id {override_id} for part {part_id} '
                    'is not present in the canonical move grasp candidates.'
                )
        evaluated = [
            {
                'candidate': candidate,
                'metrics': _move_grasp_candidate_metrics(
                    assembly=assembly,
                    candidate=candidate,
                    part=parts_by_id[part_id],
                    step=step,
                    assembled_parts=assembled_parts,
                    pickup_origin=pickup_origin,
                    pickup_orientation=pickup_orientation,
                    assembly_origin=assembly_origin,
                    assembly_orientation=assembly_orientation,
                    workspace_offset=workspace_offset,
                    fixture_bbox_min=fixture_bbox_min,
                    fixture_bbox_max=fixture_bbox_max,
                    fixture_footprint_margin=fixture_footprint_margin,
                    robot_position=robot_position,
                    orientation_reference=orientation_reference,
                    approach_height=approach_height,
                    body_start_fraction=body_start_fraction,
                    body_sample_count=body_sample_count,
                ),
            }
            for candidate in candidates
        ]
        kinematically_feasible = [
            entry
            for entry in evaluated
            if entry['metrics']['pickup_orientation_continuity'] >= minimum_orientation_continuity
            and entry['metrics']['maximum_tcp_reach'] <= maximum_tcp_reach
        ]
        if kinematically_feasible:
            minimum_source_collision_count = min(
                entry['metrics']['source_collision_count'] for entry in kinematically_feasible
            )
            source_collision_feasible = [
                entry
                for entry in kinematically_feasible
                if entry['metrics']['source_collision_count'] == minimum_source_collision_count
            ]
            maximum_fixture_clearance = max(
                entry['metrics']['pickup_fixture_body_clearance'] for entry in source_collision_feasible
            )
            required_fixture_clearance = minimum_fixture_clearance
            fixture_feasible = [
                entry
                for entry in source_collision_feasible
                if entry['metrics']['pickup_fixture_body_clearance'] >= required_fixture_clearance
            ]
            if fixture_feasible:
                maximum_orientation_continuity = max(
                    entry['metrics']['pickup_orientation_continuity'] for entry in fixture_feasible
                )
                required_orientation_continuity = max(
                    minimum_orientation_continuity,
                    maximum_orientation_continuity * minimum_relative_orientation_continuity,
                )
                orientation_feasible = [
                    entry
                    for entry in fixture_feasible
                    if entry['metrics']['pickup_orientation_continuity'] >= required_orientation_continuity
                ]
                maximum_interior_clearance = max(
                    entry['metrics']['interior_clearance_score'] for entry in orientation_feasible
                )
                required_interior_clearance = min(
                    preferred_interior_clearance,
                    maximum_interior_clearance * minimum_relative_interior_clearance,
                )
                feasible = [
                    entry
                    for entry in orientation_feasible
                    if entry['metrics']['interior_clearance_score'] >= required_interior_clearance
                ]
            else:
                maximum_orientation_continuity = 0.0
                required_orientation_continuity = minimum_orientation_continuity
                orientation_feasible = []
                maximum_interior_clearance = 0.0
                required_interior_clearance = 0.0
                feasible = []
        else:
            minimum_source_collision_count = None
            source_collision_feasible = []
            maximum_fixture_clearance = 0.0
            required_fixture_clearance = 0.0
            fixture_feasible = []
            maximum_orientation_continuity = 0.0
            required_orientation_continuity = minimum_orientation_continuity
            orientation_feasible = []
            maximum_interior_clearance = 0.0
            required_interior_clearance = 0.0
            feasible = []
        if not feasible:
            all_steps_feasible = False
            diagnostics_by_part[part_id] = {
                'candidate_count': len(evaluated),
                'kinematically_feasible_candidate_count': len(kinematically_feasible),
                'minimum_source_collision_count': minimum_source_collision_count,
                'source_collision_feasible_candidate_count': len(source_collision_feasible),
                'fixture_feasible_candidate_count': len(fixture_feasible),
                'feasible_candidate_count': 0,
                'minimum_orientation_continuity': minimum_orientation_continuity,
                'maximum_tcp_reach': maximum_tcp_reach,
                'required_fixture_clearance': required_fixture_clearance,
                'maximum_fixture_clearance': maximum_fixture_clearance,
                'required_orientation_continuity': (required_orientation_continuity),
                'maximum_orientation_continuity': (maximum_orientation_continuity),
                'required_interior_clearance': required_interior_clearance,
                'maximum_interior_clearance': maximum_interior_clearance,
                'ik_evaluated_candidate_count': 0,
                'ik_feasible_candidate_count': 0,
            }
            assembled_parts.append(parts_by_id[part_id])
            continue
        ranked = sorted(
            feasible,
            key=lambda entry: (
                entry['metrics']['physical_score'],
                entry['metrics']['pickup_fixture_body_clearance'],
                entry['metrics']['insertion_body_clearance'],
                entry['metrics']['insertion_axis_alignment'],
                -entry['metrics']['maximum_tcp_reach'],
                -entry['metrics']['grasp_id'],
            ),
            reverse=True,
        )
        planner = next(
            (entry for entry in feasible if entry['metrics']['is_planner_grasp']),
            None,
        )

        def evaluate_ik(entry: dict[str, Any]) -> None:
            if 'ik_feasible' in entry['metrics']:
                return
            entry['metrics'].update(
                _move_grasp_ik_metrics(
                    candidate=entry['candidate'],
                    part=parts_by_id[part_id],
                    step=step,
                    pickup_origin=pickup_origin,
                    pickup_orientation=pickup_orientation,
                    assembly_origin=assembly_origin,
                    assembly_orientation=assembly_orientation,
                    workspace_offset=workspace_offset,
                    robot=robot,
                    transport_tcp_height=transport_tcp_height,
                    lift_distance=ik_lift_distance,
                    position_tolerance=ik_position_tolerance,
                    orientation_tolerance=ik_orientation_tolerance,
                    minimum_manipulability=ik_minimum_manipulability,
                    max_iterations=ik_max_iterations,
                )
            )

        best = None
        for entry in ranked:
            evaluate_ik(entry)
            if entry['metrics']['ik_feasible']:
                best = entry
                break
        if planner is not None:
            evaluate_ik(planner)

        ik_evaluated = [entry for entry in feasible if 'ik_feasible' in entry['metrics']]
        ik_feasible = [entry for entry in ik_evaluated if entry['metrics']['ik_feasible']]
        if best is None:
            all_steps_feasible = False
            diagnostics_by_part[part_id] = {
                'candidate_count': len(evaluated),
                'kinematically_feasible_candidate_count': len(kinematically_feasible),
                'minimum_source_collision_count': minimum_source_collision_count,
                'source_collision_feasible_candidate_count': len(source_collision_feasible),
                'fixture_feasible_candidate_count': len(fixture_feasible),
                'geometry_feasible_candidate_count': len(feasible),
                'feasible_candidate_count': 0,
                'minimum_orientation_continuity': minimum_orientation_continuity,
                'maximum_tcp_reach': maximum_tcp_reach,
                'required_fixture_clearance': required_fixture_clearance,
                'maximum_fixture_clearance': maximum_fixture_clearance,
                'required_orientation_continuity': (required_orientation_continuity),
                'maximum_orientation_continuity': (maximum_orientation_continuity),
                'required_interior_clearance': required_interior_clearance,
                'maximum_interior_clearance': maximum_interior_clearance,
                'ik_position_tolerance': ik_position_tolerance,
                'ik_orientation_tolerance': ik_orientation_tolerance,
                'ik_minimum_manipulability': ik_minimum_manipulability,
                'ik_evaluated_candidate_count': len(ik_evaluated),
                'ik_feasible_candidate_count': 0,
                'ik_rejections': [copy.deepcopy(entry['metrics']) for entry in ik_evaluated],
            }
            assembled_parts.append(parts_by_id[part_id])
            continue

        selected = best
        if (
            planner is not None
            and planner['metrics']['ik_feasible']
            and best['metrics']['physical_score'] - planner['metrics']['physical_score'] < reselection_minimum_gain
        ):
            selected = planner
        selected_grasp = copy.deepcopy(selected['candidate'])
        selected_grasp.update(
            {
                'selection_method': 'runtime_physical_move_grasp_selection',
                **selected['metrics'],
            }
        )
        selected_by_part[part_id] = selected_grasp
        diagnostics_by_part[part_id] = {
            'candidate_count': len(evaluated),
            'kinematically_feasible_candidate_count': len(kinematically_feasible),
            'minimum_source_collision_count': minimum_source_collision_count,
            'source_collision_feasible_candidate_count': len(source_collision_feasible),
            'fixture_feasible_candidate_count': len(fixture_feasible),
            'geometry_feasible_candidate_count': len(feasible),
            'feasible_candidate_count': len(ik_feasible),
            'ik_evaluated_candidate_count': len(ik_evaluated),
            'ik_feasible_candidate_count': len(ik_feasible),
            'ik_position_tolerance': ik_position_tolerance,
            'ik_orientation_tolerance': ik_orientation_tolerance,
            'ik_minimum_manipulability': ik_minimum_manipulability,
            'selected_grasp_id': int(selected_grasp['grasp_id']),
            'planner_grasp_id': int(selected_grasp.get('planner_grasp_id', selected_grasp['grasp_id'])),
            'reselection_minimum_gain': reselection_minimum_gain,
            'required_fixture_clearance': required_fixture_clearance,
            'maximum_fixture_clearance': maximum_fixture_clearance,
            'required_orientation_continuity': required_orientation_continuity,
            'maximum_orientation_continuity': maximum_orientation_continuity,
            'required_interior_clearance': required_interior_clearance,
            'maximum_interior_clearance': maximum_interior_clearance,
            'selected': copy.deepcopy(selected['metrics']),
            'best': copy.deepcopy(best['metrics']),
            'planner': (copy.deepcopy(planner['metrics']) if planner is not None else None),
        }
        assembled_parts.append(parts_by_id[part_id])
    return selected_by_part, diagnostics_by_part, all_steps_feasible


def _resolve_pickup_layout_and_grasps(
    *,
    assembly: str,
    task: dict[str, Any],
    spec: dict[str, Any],
    configured_pickup_origin: list[float],
    configured_pickup_orientation: list[float],
    board_origin: list[float],
    assembly_origin: list[float],
    assembly_orientation: list[float],
    workspace_offset: list[float],
    robots: list[dict[str, Any]],
) -> tuple[list[float], list[float], dict[str, Any], dict[str, dict[str, Any]], dict[str, Any]]:
    raw_yaw_candidates = spec.get(
        'pickup_yaw_candidates_degrees',
        DEFAULT_PICKUP_YAW_CANDIDATES_DEGREES,
    )
    if not isinstance(raw_yaw_candidates, list) or not raw_yaw_candidates:
        raise ValueError('pickup_yaw_candidates_degrees must be a non-empty list.')
    yaw_candidates = [float(value) for value in raw_yaw_candidates]
    if not all(math.isfinite(value) for value in yaw_candidates):
        raise ValueError('pickup_yaw_candidates_degrees must contain finite numbers.')

    minimum_vertical_clearance = float(spec.get('base_grasp_minimum_vertical_clearance', 0.70))
    minimum_interior_clearance = float(spec.get('base_grasp_minimum_interior_clearance', 0.20))
    minimum_support_clearance_ratio = float(spec.get('base_grasp_minimum_support_clearance_ratio', 0.70))
    minimum_orientation_continuity = float(spec.get('minimum_pickup_orientation_continuity', 0.50))
    maximum_pickup_tcp_reach = float(spec.get('pickup_tcp_maximum_reach', 0.82))
    move_grasp_body_start_fraction = float(spec.get('move_grasp_body_start_fraction', 0.30))
    move_grasp_body_sample_count = int(spec.get('move_grasp_body_sample_count', 24))
    move_grasp_reselection_minimum_gain = float(spec.get('move_grasp_reselection_minimum_gain', 0.015))
    move_grasp_preferred_interior_clearance = float(spec.get('move_grasp_preferred_interior_clearance', 0.40))
    move_grasp_minimum_relative_interior_clearance = float(
        spec.get('move_grasp_minimum_relative_interior_clearance', 0.75)
    )
    move_grasp_fixture_footprint_margin = float(spec.get('move_grasp_fixture_footprint_margin', 0.035))
    move_grasp_minimum_fixture_clearance = float(spec.get('move_grasp_minimum_fixture_clearance', 0.001))
    move_grasp_minimum_relative_orientation_continuity = float(
        spec.get('move_grasp_minimum_relative_orientation_continuity', 0.90)
    )
    move_grasp_ik_position_tolerance = float(spec.get('move_grasp_ik_position_tolerance', 0.01))
    move_grasp_ik_orientation_tolerance = float(spec.get('move_grasp_ik_orientation_tolerance', 0.03))
    move_grasp_ik_max_iterations = int(spec.get('move_grasp_ik_max_iterations', 200))
    move_grasp_ik_minimum_manipulability = float(spec.get('move_grasp_ik_minimum_manipulability', 0.08))
    move_grasp_ik_lift_distance = float(spec.get('move_grasp_ik_lift_distance', spec.get('approach_height', 0.10)))
    orientation_reference = _vector(
        spec.get(
            'pickup_tcp_orientation_reference',
            PICKUP_TCP_ORIENTATION_REFERENCE_WXYZ,
        ),
        size=4,
        name='pickup_tcp_orientation_reference',
    )
    reference_norm = math.sqrt(sum(value * value for value in orientation_reference))
    if reference_norm <= 1e-12:
        raise ValueError('pickup_tcp_orientation_reference cannot be zero.')
    orientation_reference = [value / reference_norm for value in orientation_reference]
    if (
        not 0.0 <= minimum_vertical_clearance <= 1.0
        or not 0.0 <= minimum_interior_clearance <= 1.0
        or not 0.0 <= minimum_support_clearance_ratio <= 1.0
        or not 0.0 <= minimum_orientation_continuity <= 1.0
        or not math.isfinite(maximum_pickup_tcp_reach)
        or maximum_pickup_tcp_reach <= 0.0
        or not math.isfinite(move_grasp_body_start_fraction)
        or not 0.0 <= move_grasp_body_start_fraction < 1.0
        or move_grasp_body_sample_count < 2
        or not math.isfinite(move_grasp_reselection_minimum_gain)
        or move_grasp_reselection_minimum_gain < 0.0
        or not 0.0 <= move_grasp_preferred_interior_clearance <= 1.0
        or not 0.0 <= move_grasp_minimum_relative_interior_clearance <= 1.0
        or not math.isfinite(move_grasp_fixture_footprint_margin)
        or move_grasp_fixture_footprint_margin < 0.0
        or not math.isfinite(move_grasp_minimum_fixture_clearance)
        or move_grasp_minimum_fixture_clearance < 0.0
        or not 0.0 <= move_grasp_minimum_relative_orientation_continuity <= 1.0
        or not math.isfinite(move_grasp_ik_position_tolerance)
        or move_grasp_ik_position_tolerance <= 0.0
        or not math.isfinite(move_grasp_ik_orientation_tolerance)
        or move_grasp_ik_orientation_tolerance <= 0.0
        or move_grasp_ik_max_iterations <= 0
        or not math.isfinite(move_grasp_ik_minimum_manipulability)
        or move_grasp_ik_minimum_manipulability <= 0.0
        or not math.isfinite(move_grasp_ik_lift_distance)
        or move_grasp_ik_lift_distance <= 0.0
    ):
        raise ValueError(
            'Canonical grasp selection scores must be in [0, 1], and maximum reach '
            'must be finite and positive; move-grasp body sampling and reselection '
            'gain must also be valid; fixture clearance must be finite and non-negative; '
            'IK tolerances, lift distance, and iteration limit must be positive.'
        )

    parts_by_id = {str(part['part_id']): part for part in task['parts']}
    base_part = str(task['base_part'])
    base_candidates = task.get('base_grasp_candidates')
    if not isinstance(base_candidates, list) or not base_candidates:
        legacy_base_grasp = task.get('base_grasp')
        if not isinstance(legacy_base_grasp, dict):
            raise ValueError(f'{assembly}: metadata has no base grasp candidates.')
        base_candidates = [legacy_base_grasp]
    configured_base_grasp_id = spec.get('base_grasp_id')
    if configured_base_grasp_id is not None:
        try:
            configured_base_grasp_id = int(configured_base_grasp_id)
        except (TypeError, ValueError) as exc:
            raise ValueError('base_grasp_id must be an integer grasp candidate id.') from exc
        base_candidates = [
            candidate for candidate in base_candidates if int(candidate.get('grasp_id', -1)) == configured_base_grasp_id
        ]
        if not base_candidates:
            raise ValueError(
                f'{assembly}: configured base_grasp_id={configured_base_grasp_id} is not present in the '
                'canonical base grasp candidates.'
            )
    base_bbox_min = _vector(
        parts_by_id[base_part]['bbox_min'],
        size=3,
        name=f'{assembly} base bbox_min',
    )
    base_support_clearances = [
        float(
            _vector(
                candidate['grasp_center_m'],
                size=3,
                name=f'{assembly} base grasp_center_m',
            )[2]
            - base_bbox_min[2]
        )
        for candidate in base_candidates
    ]
    maximum_support_clearance = max(base_support_clearances)
    if not math.isfinite(maximum_support_clearance) or maximum_support_clearance <= 0.0:
        raise ValueError(f'{assembly}: base grasp candidates have no positive support clearance.')

    fixture_bbox_min = _vector(task['fixture']['bbox_min'], size=3, name='fixture bbox_min')
    fixture_bbox_max = _vector(task['fixture']['bbox_max'], size=3, name='fixture bbox_max')
    default_rotation_pivot = [(lower + upper) * 0.5 for lower, upper in zip(fixture_bbox_min, fixture_bbox_max)]
    rotation_pivot = _vector(
        spec.get('pickup_rotation_pivot', default_rotation_pivot),
        size=3,
        name='pickup_rotation_pivot',
    )
    layout_offset = _vector(
        spec.get('pickup_layout_offset', [0.0, 0.0, 0.0]),
        size=3,
        name='pickup_layout_offset',
    )
    move_grasp_id_overrides = spec.get('move_grasp_id_overrides') or {}
    if not isinstance(move_grasp_id_overrides, dict):
        raise ValueError('move_grasp_id_overrides must be a mapping from part id to grasp id.')
    move_grasp_id_overrides = {
        str(part_id): int(grasp_id) for part_id, grasp_id in move_grasp_id_overrides.items()
    }
    pivot_world = _add(
        configured_pickup_origin,
        _quat_rotate(configured_pickup_orientation, rotation_pivot),
    )
    board_bbox_min = _add(
        board_origin,
        _vector(task['optical_board']['bbox_min'], size=3, name='board bbox_min'),
    )
    board_bbox_max = _add(
        board_origin,
        _vector(task['optical_board']['bbox_max'], size=3, name='board bbox_max'),
    )

    robots_by_name = {
        str(robot['name']): robot for robot in robots if isinstance(robot, dict) and robot.get('name') is not None
    }
    base_robot = str(spec.get('base_robot', 'franka_right'))
    assembly_robot = str(spec.get('assembly_robot', 'franka_left'))
    robot_by_role: dict[str, dict[str, Any]] = {}
    robot_position_by_role: dict[str, list[float]] = {}
    for role, robot_name in [('base', base_robot), ('assembly', assembly_robot)]:
        robot = robots_by_name.get(robot_name)
        if robot is None:
            raise ValueError(f'{assembly}: robot {robot_name!r} is not configured.')
        robot_by_role[role] = robot
        robot_position = _vector(
            robot.get('position', [0.0, 0.0, 0.0]),
            size=3,
            name=f'{robot_name} position',
        )
        if bool(robot.get('apply_workspace_offset', True)):
            robot_position = _add(robot_position, workspace_offset)
        robot_position_by_role[role] = robot_position
    approach_height = float(spec.get('approach_height', 0.10))

    evaluated: list[dict[str, Any]] = []
    for yaw_index, yaw_degrees in enumerate(yaw_candidates):
        pickup_orientation = _quat_multiply(
            _yaw_quaternion(yaw_degrees),
            configured_pickup_orientation,
        )
        pickup_origin = _add(
            _add(pivot_world, layout_offset),
            [-value for value in _quat_rotate(pickup_orientation, rotation_pivot)],
        )
        fixture_corners = [
            _add(pickup_origin, _quat_rotate(pickup_orientation, [x, y, z]))
            for x in (fixture_bbox_min[0], fixture_bbox_max[0])
            for y in (fixture_bbox_min[1], fixture_bbox_max[1])
            for z in (fixture_bbox_min[2], fixture_bbox_max[2])
        ]
        fixture_on_board = all(
            board_bbox_min[axis] - 1e-9 <= corner[axis] <= board_bbox_max[axis] + 1e-9
            for corner in fixture_corners
            for axis in (0, 1)
        )
        (selected_move_grasps, move_grasp_diagnostics, move_grasps_feasible,) = _select_move_grasps_for_layout(
            assembly=assembly,
            task=task,
            pickup_origin=pickup_origin,
            pickup_orientation=pickup_orientation,
            assembly_origin=assembly_origin,
            assembly_orientation=assembly_orientation,
            workspace_offset=workspace_offset,
            fixture_bbox_min=fixture_bbox_min,
            fixture_bbox_max=fixture_bbox_max,
            fixture_footprint_margin=move_grasp_fixture_footprint_margin,
            robot=robot_by_role['assembly'],
            robot_position=robot_position_by_role['assembly'],
            orientation_reference=orientation_reference,
            minimum_orientation_continuity=minimum_orientation_continuity,
            maximum_tcp_reach=maximum_pickup_tcp_reach,
            approach_height=approach_height,
            body_start_fraction=move_grasp_body_start_fraction,
            body_sample_count=move_grasp_body_sample_count,
            reselection_minimum_gain=move_grasp_reselection_minimum_gain,
            preferred_interior_clearance=(move_grasp_preferred_interior_clearance),
            minimum_relative_interior_clearance=(move_grasp_minimum_relative_interior_clearance),
            minimum_fixture_clearance=move_grasp_minimum_fixture_clearance,
            minimum_relative_orientation_continuity=(move_grasp_minimum_relative_orientation_continuity),
            transport_tcp_height=_transport_tcp_height(
                spec,
                pickup_origin=pickup_origin,
                assembly_origin=assembly_origin,
            ),
            ik_lift_distance=move_grasp_ik_lift_distance,
            ik_position_tolerance=move_grasp_ik_position_tolerance,
            ik_orientation_tolerance=move_grasp_ik_orientation_tolerance,
            ik_minimum_manipulability=move_grasp_ik_minimum_manipulability,
            ik_max_iterations=move_grasp_ik_max_iterations,
            grasp_id_overrides=move_grasp_id_overrides,
        )
        move_grasps = {
            str(step['move_part']): selected_move_grasps.get(
                str(step['move_part']),
                step['move_grasp'],
            )
            for step in task['assembly_steps']
        }
        for base_candidate in base_candidates:
            grasp_by_part = {base_part: base_candidate, **move_grasps}
            continuity_by_part: dict[str, float] = {}
            pickup_tcp_orientation_by_part: dict[str, list[float]] = {}
            pickup_tcp_reach_by_part: dict[str, float] = {}
            for part_id, grasp in grasp_by_part.items():
                part_position, part_orientation = _part_pickup_pose(
                    parts_by_id[part_id],
                    pickup_origin=pickup_origin,
                    pickup_orientation=pickup_orientation,
                )
                tcp_orientation = _quat_multiply(
                    part_orientation,
                    _quat_conjugate(
                        _vector(
                            grasp['object_in_tcp_orientation'],
                            size=4,
                            name=f'{assembly} part {part_id} object_in_tcp_orientation',
                        )
                    ),
                )
                pickup_tcp_orientation_by_part[part_id] = tcp_orientation
                continuity_by_part[part_id] = _orientation_continuity(
                    tcp_orientation,
                    orientation_reference,
                )
                tcp_position = _add(
                    _add(
                        part_position,
                        [
                            -value
                            for value in _quat_rotate(
                                tcp_orientation,
                                _vector(
                                    grasp['object_in_tcp_position'],
                                    size=3,
                                    name=(f'{assembly} part {part_id} ' 'object_in_tcp_position'),
                                ),
                            )
                        ],
                    ),
                    [0.0, 0.0, approach_height],
                )
                tcp_position = _add(tcp_position, workspace_offset)
                robot_role = 'base' if part_id == base_part else 'assembly'
                robot_position = robot_position_by_role[robot_role]
                pickup_tcp_reach_by_part[part_id] = math.sqrt(
                    sum((tcp_position[axis] - robot_position[axis]) ** 2 for axis in range(3))
                )

            approach_direction = _vector(
                base_candidate['assembly_approach_direction'],
                size=3,
                name=f'{assembly} base grasp assembly_approach_direction',
            )
            base_pickup_orientation = _quat_multiply(
                pickup_orientation,
                _vector(
                    parts_by_id[base_part]['pickup_orientation'],
                    size=4,
                    name=f'{assembly} base pickup_orientation',
                ),
            )
            assembly_approach_cosine = _quat_rotate(
                assembly_orientation,
                approach_direction,
            )[2]
            pickup_approach_cosine = _quat_rotate(
                base_pickup_orientation,
                approach_direction,
            )[2]
            vertical_clearance = min(
                assembly_approach_cosine,
                pickup_approach_cosine,
            )
            interior_clearance = float(base_candidate['interior_clearance_score'])
            support_clearance = float(
                _vector(
                    base_candidate['grasp_center_m'],
                    size=3,
                    name=f'{assembly} base grasp_center_m',
                )[2]
                - base_bbox_min[2]
            )
            support_clearance_ratio = support_clearance / maximum_support_clearance
            worst_continuity = min(continuity_by_part.values())
            base_orientation_continuity = continuity_by_part[base_part]
            worst_pickup_tcp_reach = max(pickup_tcp_reach_by_part.values())
            selected_move_metrics = [
                diagnostics['selected']
                for diagnostics in move_grasp_diagnostics.values()
                if diagnostics.get('selected') is not None
            ]
            maximum_move_tcp_reach = max(
                (float(metrics['maximum_tcp_reach']) for metrics in selected_move_metrics),
                default=worst_pickup_tcp_reach,
            )
            minimum_move_physical_score = min(
                (float(metrics['physical_score']) for metrics in selected_move_metrics),
                default=-math.inf,
            )
            evaluated.append(
                {
                    'yaw_index': yaw_index,
                    'pickup_yaw_degrees': yaw_degrees,
                    'pickup_origin': pickup_origin,
                    'pickup_orientation': pickup_orientation,
                    'base_grasp': base_candidate,
                    'assembly_approach_cosine': assembly_approach_cosine,
                    'pickup_approach_cosine': pickup_approach_cosine,
                    'vertical_clearance_score': vertical_clearance,
                    'interior_clearance_score': interior_clearance,
                    'support_clearance': support_clearance,
                    'support_clearance_ratio': support_clearance_ratio,
                    'orientation_continuity_score': worst_continuity,
                    'base_orientation_continuity_score': (base_orientation_continuity),
                    'orientation_continuity_by_part': continuity_by_part,
                    'pickup_tcp_orientation_by_part': pickup_tcp_orientation_by_part,
                    'maximum_pickup_tcp_reach': worst_pickup_tcp_reach,
                    'pickup_tcp_reach_by_part': pickup_tcp_reach_by_part,
                    'maximum_move_tcp_reach': maximum_move_tcp_reach,
                    'minimum_move_physical_score': minimum_move_physical_score,
                    'selected_move_grasps': selected_move_grasps,
                    'move_grasp_diagnostics': move_grasp_diagnostics,
                    'move_grasps_feasible': move_grasps_feasible,
                    'fixture_on_optical_board': fixture_on_board,
                    'feasible': (
                        vertical_clearance >= minimum_vertical_clearance
                        and interior_clearance >= minimum_interior_clearance
                        and support_clearance_ratio >= minimum_support_clearance_ratio
                        and worst_continuity >= minimum_orientation_continuity
                        and worst_pickup_tcp_reach <= maximum_pickup_tcp_reach
                        and maximum_move_tcp_reach <= maximum_pickup_tcp_reach
                        and move_grasps_feasible
                        and fixture_on_board
                    ),
                }
            )

    feasible = [candidate for candidate in evaluated if candidate['feasible']]
    if not feasible:
        best = max(
            evaluated,
            key=lambda candidate: (
                candidate['orientation_continuity_score'],
                candidate['base_orientation_continuity_score'],
                candidate['vertical_clearance_score'],
                candidate['support_clearance_ratio'],
                -candidate['maximum_pickup_tcp_reach'],
                candidate['interior_clearance_score'],
                candidate['minimum_move_physical_score'],
            ),
        )
        raise ValueError(
            f'{assembly}: no pickup yaw/base grasp pair satisfies the runtime thresholds; '
            f'best yaw={best["pickup_yaw_degrees"]:g}, '
            f'grasp={best["base_grasp"]["grasp_id"]}, '
            f'continuity={best["orientation_continuity_score"]:.3f}, '
            f'vertical={best["vertical_clearance_score"]:.3f}, '
            f'interior={best["interior_clearance_score"]:.3f}, '
            f'support_clearance_ratio={best["support_clearance_ratio"]:.3f}, '
            f'reach={best["maximum_pickup_tcp_reach"]:.3f}, '
            f'fixture_on_board={best["fixture_on_optical_board"]}.'
        )
    selected = max(
        feasible,
        key=lambda candidate: (
            candidate['orientation_continuity_score'],
            candidate['base_orientation_continuity_score'],
            candidate['vertical_clearance_score'],
            candidate['support_clearance_ratio'],
            -candidate['maximum_pickup_tcp_reach'],
            candidate['interior_clearance_score'],
            candidate['minimum_move_physical_score'],
            -candidate['yaw_index'],
            -int(candidate['base_grasp']['grasp_id']),
        ),
    )
    selected_grasp = copy.deepcopy(selected['base_grasp'])
    selected_grasp.update(
        {
            'selection_method': 'joint_pickup_yaw_base_grasp_runtime_selection',
            'pickup_yaw_degrees': selected['pickup_yaw_degrees'],
            'assembly_approach_cosine': selected['assembly_approach_cosine'],
            'pickup_approach_cosine': selected['pickup_approach_cosine'],
            'clearance_score': selected['vertical_clearance_score'],
            'support_clearance': selected['support_clearance'],
            'support_clearance_ratio': selected['support_clearance_ratio'],
            'maximum_pickup_tcp_reach': selected['maximum_pickup_tcp_reach'],
            'orientation_continuity_minimum': minimum_orientation_continuity,
            'orientation_continuity_score': selected['orientation_continuity_score'],
            'orientation_reference': copy.deepcopy(orientation_reference),
            'pickup_tcp_orientation': selected['pickup_tcp_orientation_by_part'][base_part],
        }
    )
    diagnostics = {
        'pickup_yaw_degrees': selected['pickup_yaw_degrees'],
        'configured_pickup_origin': configured_pickup_origin,
        'pickup_origin': selected['pickup_origin'],
        'pickup_orientation': selected['pickup_orientation'],
        'pickup_rotation_pivot': rotation_pivot,
        'pickup_layout_offset': layout_offset,
        'base_grasp_id': int(selected_grasp['grasp_id']),
        'base_grasp_candidate_count': len(base_candidates),
        'evaluated_pair_count': len(evaluated),
        'feasible_pair_count': len(feasible),
        'minimum_vertical_clearance': minimum_vertical_clearance,
        'minimum_interior_clearance': minimum_interior_clearance,
        'minimum_support_clearance_ratio': minimum_support_clearance_ratio,
        'maximum_support_clearance': maximum_support_clearance,
        'minimum_orientation_continuity': minimum_orientation_continuity,
        'orientation_reference': copy.deepcopy(orientation_reference),
        'pickup_tcp_maximum_reach': maximum_pickup_tcp_reach,
        'maximum_pickup_tcp_reach': selected['maximum_pickup_tcp_reach'],
        'pickup_tcp_reach_by_part': selected['pickup_tcp_reach_by_part'],
        'maximum_move_tcp_reach': selected['maximum_move_tcp_reach'],
        'minimum_move_physical_score': selected['minimum_move_physical_score'],
        'move_grasp_body_start_fraction': move_grasp_body_start_fraction,
        'move_grasp_body_sample_count': move_grasp_body_sample_count,
        'move_grasp_reselection_minimum_gain': move_grasp_reselection_minimum_gain,
        'move_grasp_preferred_interior_clearance': (move_grasp_preferred_interior_clearance),
        'move_grasp_minimum_relative_interior_clearance': (move_grasp_minimum_relative_interior_clearance),
        'move_grasp_fixture_footprint_margin': (move_grasp_fixture_footprint_margin),
        'move_grasp_minimum_fixture_clearance': move_grasp_minimum_fixture_clearance,
        'move_grasp_minimum_relative_orientation_continuity': (move_grasp_minimum_relative_orientation_continuity),
        'move_grasp_ik_position_tolerance': move_grasp_ik_position_tolerance,
        'move_grasp_ik_orientation_tolerance': (move_grasp_ik_orientation_tolerance),
        'move_grasp_ik_max_iterations': move_grasp_ik_max_iterations,
        'move_grasp_ik_minimum_manipulability': (move_grasp_ik_minimum_manipulability),
        'move_grasp_ik_lift_distance': move_grasp_ik_lift_distance,
        'move_grasp_selection': copy.deepcopy(selected['move_grasp_diagnostics']),
        'fixture_on_optical_board': selected['fixture_on_optical_board'],
        'vertical_clearance_score': selected['vertical_clearance_score'],
        'interior_clearance_score': selected['interior_clearance_score'],
        'support_clearance': selected['support_clearance'],
        'support_clearance_ratio': selected['support_clearance_ratio'],
        'orientation_continuity_score': selected['orientation_continuity_score'],
        'base_orientation_continuity_score': selected['base_orientation_continuity_score'],
        'orientation_continuity_by_part': selected['orientation_continuity_by_part'],
    }
    return (
        selected['pickup_origin'],
        selected['pickup_orientation'],
        selected_grasp,
        copy.deepcopy(selected['selected_move_grasps']),
        diagnostics,
    )


def _part_pickup_pose(
    part: dict[str, Any],
    *,
    pickup_origin: list[float],
    pickup_orientation: list[float],
) -> tuple[list[float], list[float]]:
    return _compose_pose(
        pickup_origin,
        pickup_orientation,
        _vector(part['pickup_position'], size=3, name='part pickup_position'),
        _vector(part['pickup_orientation'], size=4, name='part pickup_orientation'),
    )


def _part_object(
    assembly: str,
    part: dict[str, Any],
    *,
    pickup_origin: list[float],
    pickup_orientation: list[float],
) -> dict[str, Any]:
    position, orientation = _part_pickup_pose(
        part,
        pickup_origin=pickup_origin,
        pickup_orientation=pickup_orientation,
    )
    return {
        'name': f'fabrica_{assembly}_{part["part_id"]}',
        'kind': 'usd',
        'prim_path': f'/fabrica_{assembly}_{part["part_id"]}',
        'usd_path': _asset_path(part['usd_path']),
        'position': position,
        'orientation': orientation,
        'scale': [1.0, 1.0, 1.0],
        'collider': True,
        'auto_collider': False,
        'rigid_body': True,
        'tracked': True,
        'static_friction': 0.8,
        'dynamic_friction': 0.7,
        'restitution': 0.0,
        'linear_damping': 1.0,
        'angular_damping': 2.0,
        'sleep_threshold': 0.01,
        'stabilization_threshold': 0.001,
        'solver_position_iteration_count': 16,
        'solver_velocity_iteration_count': 4,
        'fabrica_part_id': str(part['part_id']),
        'fabrica_bbox_min': copy.deepcopy(part['bbox_min']),
        'fabrica_bbox_max': copy.deepcopy(part['bbox_max']),
    }


def _assembly_support_cube(*, board_origin: list[float], board: dict[str, Any]) -> dict[str, Any]:
    """Invisible box under the optical board.

    The authored board is a 1 cm SDF, and the visible table cube is 2 mm thick.
    A released part tunnels both. This box keeps the same top surface and is
    thick enough for a discrete physics step to catch the part.
    """
    bbox_min = _vector(board['bbox_min'], size=3, name='optical_board bbox_min')
    bbox_max = _vector(board['bbox_max'], size=3, name='optical_board bbox_max')
    # Thick enough that a discrete PhysX step cannot tunnel the top face
    # after a weld break; top surface stays flush with the board.
    thickness = 0.12
    top_z = float(board_origin[2]) + float(bbox_max[2])
    return {
        'name': 'assembly_support',
        'kind': 'static_cube',
        'prim_path': '/assembly_support',
        'position': [
            float(board_origin[0]) + 0.5 * (bbox_min[0] + bbox_max[0]),
            float(board_origin[1]) + 0.5 * (bbox_min[1] + bbox_max[1]),
            top_z - 0.5 * thickness,
        ],
        'orientation': [1.0, 0.0, 0.0, 0.0],
        'scale': [
            max(float(bbox_max[0] - bbox_min[0]), 0.05),
            max(float(bbox_max[1] - bbox_min[1]), 0.05),
            thickness,
        ],
        'color': [0.14, 0.14, 0.14],
        'visible': False,
        'tracked': False,
        'static_friction': 1.5,
        'dynamic_friction': 1.2,
        'restitution': 0.0,
    }


def _fixture_support_cube(
    *,
    pickup_origin: list[float],
    part_positions: list[list[float]],
    part_bottom_zs: list[float] | None = None,
) -> dict[str, Any]:
    """Invisible thick deck under the fixture tray.

    When parts start unlocked the authored nest bottoms can sit below
    pickup_origin.z; place the deck under the lowest nest bottom so freefall
    is a few millimetres (v36 tunnelled thin deck → parts at table height).
    """
    thickness = 0.25
    margin = 0.28
    xs = [float(pickup_origin[0])] + [float(p[0]) for p in part_positions]
    ys = [float(pickup_origin[1])] + [float(p[1]) for p in part_positions]
    min_x, max_x = min(xs) - margin, max(xs) + margin
    min_y, max_y = min(ys) - margin, max(ys) + margin
    if part_bottom_zs:
        # Tiny clearance under the lowest authored nest bottom.
        top_z = min(float(z) for z in part_bottom_zs) - 0.002
    else:
        top_z = float(pickup_origin[2])
    # Never place the deck above the pickup plane — that launches the nest.
    top_z = min(top_z, float(pickup_origin[2]))
    return {
        'name': 'fixture_support',
        'kind': 'static_cube',
        'prim_path': '/fixture_support',
        'position': [
            0.5 * (min_x + max_x),
            0.5 * (min_y + max_y),
            top_z - 0.5 * thickness,
        ],
        'orientation': [1.0, 0.0, 0.0, 0.0],
        'scale': [
            max(max_x - min_x, 0.30),
            max(max_y - min_y, 0.30),
            thickness,
        ],
        'color': [0.14, 0.14, 0.14],
        # Collision only. A visible 0.7 m slab z-fights the table and reads as
        # a wall in the front camera (v70).
        'visible': False,
        # Track world pose so a dropped/misplaced deck shows up in diagnostics.
        'tracked': True,
        # Smooth floor under the nest. Combine mode min so the part's 2.2
        # finger-grip friction does not glue the beam to this deck (v80).
        'static_friction': 0.35,
        'dynamic_friction': 0.25,
        'friction_combine_mode': 'min',
        'restitution': 0.0,
    }


def _deck_collision_actions(
    object_name: str,
    *,
    filter_held_from_deck: bool = True,
    held_collision: bool = True,
) -> dict[str, Any]:
    """Keep the fixture nest, pickup deck and table solid for remaining parts.

    Never globally disable fabrica_fixture/fixture_support/table: the nest walls
    are what hold the tall unlocked parts upright. While a part is kinematically
    carried, only that part's collision is muted so SDF contact cannot pin it
    to the deck (v49–v50 peel).
    """
    actions: dict[str, Any] = {
        'object_collisions': [
            {'object': object_name, 'enabled': bool(held_collision)},
            {'object': 'fabrica_fixture', 'enabled': True},
            {'object': 'fixture_support', 'enabled': True},
            {'object': 'factory_tabletop_visual', 'enabled': True},
        ],
    }
    actions['collision_filters'] = [
        {
            'object': object_name,
            'filter_objects': ['fixture_support', 'factory_tabletop_visual'],
            'enabled': bool(filter_held_from_deck),
        }
    ]
    return actions


def _static_asset_object(
    *,
    name: str,
    usd_path: str,
    position: list[float],
    orientation: list[float] | None = None,
    friction: float,
) -> dict[str, Any]:
    return {
        'name': name,
        'kind': 'usd',
        'prim_path': f'/{name}',
        'usd_path': _asset_path(usd_path),
        'position': copy.deepcopy(position),
        'orientation': copy.deepcopy(orientation or [1.0, 0.0, 0.0, 0.0]),
        'scale': [1.0, 1.0, 1.0],
        'collider': True,
        'auto_collider': False,
        'rigid_body': False,
        'tracked': False,
        'static_friction': float(friction),
        'dynamic_friction': float(friction),
        'restitution': 0.0,
    }


def _target(name: str, position: list[float], orientation: list[float]) -> dict[str, Any]:
    return {
        'name': name,
        'reference': 'world',
        'position': copy.deepcopy(position),
        'orientation': copy.deepcopy(orientation),
    }


def _transport_tcp_height(
    spec: dict[str, Any],
    *,
    pickup_origin: list[float],
    assembly_origin: list[float],
) -> float:
    work_surface_height = max(float(pickup_origin[2]), float(assembly_origin[2]))
    configured_height = spec.get('transport_tcp_height')
    if configured_height is None:
        clearance_height = float(spec.get('transport_clearance_height', 0.34))
        value = work_surface_height + clearance_height
    else:
        clearance_height = None
        value = float(configured_height)
    if clearance_height is not None and (not math.isfinite(clearance_height) or clearance_height <= 0.0):
        raise ValueError('transport_clearance_height must be finite and positive.')
    if not math.isfinite(value) or value <= work_surface_height:
        raise ValueError('transport_tcp_height must be finite and above both pickup and assembly origins.')
    return value


def _object_position_at_tcp_height(
    *,
    object_position: list[float],
    object_orientation: list[float],
    grasp: dict[str, Any],
    tcp_height: float,
) -> list[float]:
    relative_position = _vector(
        grasp['object_in_tcp_position'],
        size=3,
        name='grasp object_in_tcp_position',
    )
    relative_orientation = _vector(
        grasp['object_in_tcp_orientation'],
        size=4,
        name='grasp object_in_tcp_orientation',
    )
    tcp_orientation = _quat_multiply(
        object_orientation,
        _quat_conjugate(relative_orientation),
    )
    object_to_tcp = [-value for value in _quat_rotate(tcp_orientation, relative_position)]
    result = copy.deepcopy(object_position)
    result[2] = float(tcp_height - object_to_tcp[2])
    return result


def _skill_phase(
    *,
    skill: str,
    robot: str,
    phase_name: str,
    timeout_steps: int,
    parameters: dict[str, Any],
    phase_actions: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return _BeamAssemblySkillAPI.compile_call(
        {
            'skill': skill,
            'robot': robot,
            'phase_name': phase_name,
            'timeout_steps': timeout_steps,
            'phase_actions': phase_actions or {},
            **parameters,
        }
    )


# Pad-center distance in front of base_link along +Z.
# Open-mesh faces sit at 0.110–0.148 m. Commanding the Fabrica TCP (pinch
# 17 cm ahead) closed above the beam (v74). Moving the center to 0.143 m
# reached the near end (v76). Commanding 0.114 m did not go deeper: the
# partly closed fingers hit the end and tipped the beam (v77).
_ISAAC_ROBOTIQ_PAD_CENTER_M = 0.143
_ISAAC_ROBOTIQ_PAD_SHIFT_LIMIT_M = 0.08


def _grasp_aligned_to_isaac_pads(grasp: dict[str, Any]) -> dict[str, Any]:
    """Move the commanded base_link forward until the pad center meets the pinch."""

    if grasp.get('preserve_audited_tcp') or 'grasp_center_m' not in grasp:
        return grasp
    relative_position = _vector(
        grasp['object_in_tcp_position'],
        size=3,
        name='grasp object_in_tcp_position',
    )
    relative_orientation = _vector(
        grasp['object_in_tcp_orientation'],
        size=4,
        name='grasp object_in_tcp_orientation',
    )
    tcp_orientation = _quat_conjugate(relative_orientation)
    tcp_position = [-value for value in _quat_rotate(tcp_orientation, relative_position)]
    grasp_center = _vector(grasp['grasp_center_m'], size=3, name='grasp grasp_center_m')
    pinch_in_gripper = _quat_rotate(
        _quat_conjugate(tcp_orientation),
        [center - tcp for center, tcp in zip(grasp_center, tcp_position)],
    )
    shortfall = float(pinch_in_gripper[2]) - _ISAAC_ROBOTIQ_PAD_CENTER_M
    if not math.isfinite(shortfall) or shortfall <= 0.001:
        return grasp
    shortfall = min(shortfall, _ISAAC_ROBOTIQ_PAD_SHIFT_LIMIT_M)
    corrected = copy.deepcopy(grasp)
    corrected_position = list(relative_position)
    corrected_position[2] = float(corrected_position[2]) - shortfall
    corrected['object_in_tcp_position'] = corrected_position
    return corrected


def _grasp_parameters(
    object_name: str,
    grasp: dict[str, Any],
    *,
    grasp_pad_reach: float = 0.112,
) -> dict[str, Any]:
    return {
        'object': object_name,
        'grasp_relative_position': copy.deepcopy(grasp['object_in_tcp_position']),
        'grasp_relative_orientation': copy.deepcopy(grasp['object_in_tcp_orientation']),
        'lock_target_position': True,
        'lock_target_orientation': True,
        'guard_ik_branch_jump': True,
        'ik_reference_mode': 'current',
        'use_command_warm_start': True,
        'require_warm_start_ik': True,
        'align_grasp_axis_to_world_down': not grasp.get('preserve_audited_tcp', False),
        'grasp_pad_distance': _ISAAC_ROBOTIQ_PAD_CENTER_M,
        # 0.112 meets the plate at the fingertip lip (attachment z≈0.149).
        # A smaller reach lowers the hand so the pad face, not the lip, meets it.
        'grasp_pad_reach': float(grasp_pad_reach),
    }


def _append_pick_and_attach_phases(
    phases: list[dict[str, Any]],
    *,
    prefix: str,
    robot: str,
    object_name: str,
    grasp: dict[str, Any],
    part: dict[str, Any],
    approach_height: float,
    move_above_timeout_steps: int,
    move_above_orientation_first: bool,
    move_above_orientation_first_steps: int,
    move_above_orientation_first_tolerance: float,
    preshape_timeout_steps: int,
    preshape_open_margin: float,
    preshape_gripper_position_tolerance: float,
    descend_position_tolerance: float,
    descend_relaxed_position_tolerance: float,
    descend_relaxed_after_steps: int,
    prealign_steps: int,
    prealign_joint_positions: list[float] | None,
    prealign_shoulder_pan: float | None,
    fixture_release_after_steps: int,
    fixture_lock_target: str | None,
    filter_gripper_collisions_on_attach: bool = False,
    force_enable_collision_on_attach: bool = False,
    attachment_mode: str = 'fixed_joint',
    # When True, parts are already free on a support deck — skip pin handoff.
    parts_start_unlocked: bool = False,
    relax_ik_branch_jump: bool = False,
    descend_timeout_steps: int = 900,
    descend_target_object_position_tolerance: float = 0.012,
    include_lift: bool = True,
    lift_offset: list[float] | None = None,
    hover_above_object_com: bool = False,
    grasp_lateral_offset: list[float] | None = None,
    grip_settle_drop: float = 0.0,
    grasp_pad_reach: float = 0.112,
    align_finger_to_object_axis: list[float] | None = None,
    align_finger_max_tilt_rad: float | None = None,
) -> None:
    grasp = _grasp_aligned_to_isaac_pads(grasp)
    grasp_parameters = _grasp_parameters(
        object_name,
        grasp,
        grasp_pad_reach=grasp_pad_reach,
    )
    if align_finger_to_object_axis is not None:
        grasp_parameters['align_finger_to_object_axis'] = [
            float(value) for value in align_finger_to_object_axis
        ]
    if align_finger_max_tilt_rad is not None:
        grasp_parameters['align_finger_max_tilt_rad'] = float(align_finger_max_tilt_rad)
    if grasp_lateral_offset is not None and not hover_above_object_com:
        # Close was still aimed at the plate center, so the jaw returned
        # there after the shifted descend. Keep the same shift through close.
        grasp_parameters['offset'] = [float(value) for value in grasp_lateral_offset]
        grasp_parameters['offset_frame'] = 'world'
    preclose_openness = min(
        1.0,
        float(grasp['robotiq_open_ratio']) + float(preshape_open_margin),
    )
    # Grasp-frame picks approach along the part. A half-closed jaw hits the
    # end of a slotted beam and tips it (v76–v77). Stay fully open until the
    # pads are beside the thickness, then close.
    if not hover_above_object_com:
        preclose_openness = 1.0
    closed_openness = max(0.0, float(grasp['robotiq_open_ratio']) - (0.055 if parts_start_unlocked else 0.035))
    closed_joint_position = 0.8 * (1.0 - closed_openness)
    contact_box_offset, contact_box_scale = _contact_box(part)
    contact_parameters = {
        'require_dual_finger_contact': True,
        # Official Fabrica grasps commonly cage a convex corner with the two
        # pads on adjacent faces. Both pads must still satisfy the strict
        # surface-gap check before the grasp can be registered.
        'allow_cross_axis_dual_finger_contact': True,
        'finger_contact_distance': 0.008,
        'physical_attach_surface_gap': 0.006,
        'contact_force_threshold': 0.15,
        'measure_force_contact': True,
        'contact_box_offset': contact_box_offset,
        'contact_box_scale': contact_box_scale,
    }

    move_above_parameters = {
        **grasp_parameters,
        'ik_reference_mode': 'hybrid',
        'ik_reference_command_max_tracking_error': 0.12,
        'cartesian_orientation_command_warm_start': True,
        'cartesian_orientation_command_lookahead': 0.36,
        'max_command_joint_step': 0.06,
        'max_command_tracking_error': 0.24,
        'max_wrist_command_tracking_error': 0.24,
        'offset': [
            0.0 if grasp_lateral_offset is None else float(grasp_lateral_offset[0]),
            0.0 if grasp_lateral_offset is None else float(grasp_lateral_offset[1]),
            float(approach_height) + (0.0 if grasp_lateral_offset is None else float(grasp_lateral_offset[2])),
        ],
        'offset_frame': 'world',
        'gripper_command': 'open',
        'position_tolerance': 0.012,
        'orientation_tolerance': 0.12,
        'orientation_first_before_translation': bool(move_above_orientation_first),
        'orientation_first_max_steps': int(move_above_orientation_first_steps),
        'orientation_first_tolerance': float(move_above_orientation_first_tolerance),
    }
    if hover_above_object_com:
        # Hover above the live COM in world +Z. Using the authored grasp frame on a
        # settled/tipped skinny part puts TCP beside the optical board (v60–v64).
        # Only for later assemble picks — base pick must keep the grasp frame (v65).
        move_above_parameters.pop('grasp_relative_position', None)
        move_above_parameters.pop('grasp_relative_orientation', None)
        move_above_parameters['lock_target_orientation'] = False
        move_above_parameters['orientation_tolerance'] = 0.80
    if relax_ik_branch_jump:
        move_above_parameters.update(
            {
                'guard_ik_branch_jump': False,
                'ik_branch_jump_limit': 0.75,
                'ik_branch_jump_tolerance_steps': 96,
                'max_command_joint_step': 0.045,
                'position_tolerance': 0.018,
            }
        )
    if prealign_steps > 0:
        if prealign_joint_positions is not None:
            move_above_parameters.update(
                {
                    'prealign_steps': int(prealign_steps),
                    'prealign_joint_positions': copy.deepcopy(prealign_joint_positions),
                    'prealign_max_joint_step': 0.035,
                }
            )
        elif prealign_shoulder_pan is not None:
            move_above_parameters.update(
                {
                    'prealign_steps': int(prealign_steps),
                    'prealign_shoulder_pan': float(prealign_shoulder_pan),
                    'prealign_max_joint_step': 0.035,
                }
            )
    sibling_filter_actions = {}
    if parts_start_unlocked:
        sibling_filter_actions = {
            'gripper_sibling_filters': [
                {
                    'robot': robot,
                    'object': object_name,
                    'enabled': True,
                }
            ]
        }
    phases.append(
        _skill_phase(
            skill='move_above_part',
            robot=robot,
            phase_name=f'{prefix}_move_above',
            timeout_steps=move_above_timeout_steps,
            parameters=move_above_parameters,
            phase_actions=sibling_filter_actions or None,
        )
    )
    phases.append(
        _skill_phase(
            skill='preshape_gripper',
            robot=robot,
            phase_name=f'{prefix}_preshape',
            timeout_steps=preshape_timeout_steps + 24,
            parameters={
                'object': object_name,
                'gripper_openness': preclose_openness,
                'hold_steps': 36,
                'preshape_timeout_steps': preshape_timeout_steps,
                'gripper_position_tolerance': float(preshape_gripper_position_tolerance),
            },
            phase_actions=sibling_filter_actions or None,
        )
    )
    descend_parameters = {
        **grasp_parameters,
        'gripper_command': preclose_openness,
        'position_tolerance': float(descend_position_tolerance),
        'relaxed_position_tolerance': float(descend_relaxed_position_tolerance),
        'relaxed_position_tolerance_after_steps': int(descend_relaxed_after_steps),
        'orientation_tolerance': 0.10,
        'target_object_position_tolerance': float(descend_target_object_position_tolerance),
        'target_object_orientation_tolerance': 0.15,
    }
    if grasp_lateral_offset is not None and not hover_above_object_com:
        # v89 pinched the Y face but 2 cm off the plate edge (local z=-0.024),
        # so the beam kept turning. Shift the pinch onto the face center.
        descend_parameters['offset'] = [float(value) for value in grasp_lateral_offset]
        descend_parameters['offset_frame'] = 'world'
    if hover_above_object_com:
        # Descend onto the live COM. Grasp-frame TCP of a tipped beam is beside
        # the optical board (v66). Close can still form a friction pinch.
        descend_parameters.pop('grasp_relative_position', None)
        descend_parameters.pop('grasp_relative_orientation', None)
        descend_parameters['offset'] = [0.0, 0.0, 0.012]
        descend_parameters['offset_frame'] = 'world'
        descend_parameters['lock_target_orientation'] = False
        descend_parameters['orientation_tolerance'] = 0.80
        descend_parameters['target_object_orientation_tolerance'] = 0.80
        descend_parameters['position_tolerance'] = max(
            float(descend_parameters['position_tolerance']), 0.012
        )
        descend_parameters['relaxed_position_tolerance'] = max(
            float(descend_parameters.get('relaxed_position_tolerance') or 0.0), 0.018
        )
        descend_parameters['gripper_command'] = max(float(preclose_openness), 0.45)
        descend_parameters['cartesian_position_step'] = 0.006
    phases.append(
        _skill_phase(
            skill='descend_to_grasp',
            robot=robot,
            phase_name=f'{prefix}_descend',
            timeout_steps=int(descend_timeout_steps),
            parameters=descend_parameters,
            phase_actions=sibling_filter_actions or None,
        )
    )

    tcp_position = copy.deepcopy(grasp['tcp_in_assembly_position'])
    tcp_orientation = copy.deepcopy(grasp['tcp_in_assembly_orientation'])
    resolved_attachment_mode = str(attachment_mode or 'fixed_joint').lower()
    use_pure_physical_grasp = resolved_attachment_mode in {
        'pure_physical_grasp',
        'contact_pure_physical_grasp',
        'physical_hold',
        'physical',
        'contact_hold',
        'physical_grasp',
        'contact_physical_grasp',
    }
    # Physical grasp must keep finger↔part collision for friction. Filtering
    # pairs while "holding" with a fixed joint is what lets welded parts tunnel.
    resolved_filter_gripper = False if use_pure_physical_grasp else bool(filter_gripper_collisions_on_attach)
    resolved_force_collision = True if use_pure_physical_grasp else bool(force_enable_collision_on_attach)
    # Squeeze harder for friction-only carries (weld used to hide a soft pinch).
    physical_close_margin = 0.28 if use_pure_physical_grasp else 0.035
    closed_openness = max(0.0, float(grasp['robotiq_open_ratio']) - float(physical_close_margin))
    closed_joint_position = 0.8 * (1.0 - closed_openness)
    if use_pure_physical_grasp:
        contact_parameters = {
            **contact_parameters,
            'finger_contact_distance': 0.012,
            'physical_attach_surface_gap': 0.010,
            'contact_force_threshold': 0.10,
        }
    attach_spec = {
        'object': object_name,
        'robot': robot,
        'target': {
            'reference': object_name,
            'offset': tcp_position,
            'orientation': tcp_orientation,
            'ik_frame_compensation': 'none',
        },
        'attachment_mode': resolved_attachment_mode,
        'attachment_relative_pose_source': 'current',
        'disable_collision_on_attach': False,
        'filter_gripper_collisions_on_attach': resolved_filter_gripper,
        'force_enable_collision_on_attach': resolved_force_collision,
        'compliant_hold_linear_limit': 0.006,
        'compliant_hold_angular_limit_degrees': 6.0,
        'compliant_hold_linear_max_force': 20.0,
        'compliant_hold_linear_damping': 10.0,
        'compliant_hold_linear_stiffness': 500.0,
        'compliant_hold_angular_max_force': 2.0,
        'compliant_hold_angular_damping': 0.2,
        'compliant_hold_angular_stiffness': 5.0,
        'compliant_hold_gravity_force_multiplier': 6.0,
        'compliant_hold_drive_damping_ratio': 1.0,
        'compliant_hold_torque_force_fraction': 0.5,
        'compliant_hold_linear_force_cap': 120.0,
        'compliant_hold_angular_force_cap': 12.0,
        'require_contact': True,
        'require_physical_contact': True,
        'require_local_skill_complete_for_attach': True,
        'require_target_reached_for_attach': True,
        'allow_strict_contact_target_refinement': True,
        'strict_contact_target_refinement_max_distance': 0.025,
        'strict_contact_target_refinement_tracking_tolerance': 0.00035,
        'allow_noncontact_fixed_joint': False,
        'gripper_closed_threshold': min(0.8, closed_joint_position + 0.04),
        **contact_parameters,
        'min_attach_steps': 24,
        'position_tolerance': float(descend_position_tolerance),
        'orientation_tolerance': 0.10,
        'support_height_tolerance': None,
        'top_clearance': None,
    }
    if use_pure_physical_grasp:
        # Symbolic attach only: grip is finger contact + friction, no FixedJoint.
        attach_spec.update(
            {
                # Unlocked free parts: never accept caging/missing-contact as a
                # "hold" — v38 advanced on grace then left the part on the deck.
                'allow_caging_contact_for_physical_grasp': not parts_start_unlocked,
                'allow_caging_hold_for_physical_grasp': not parts_start_unlocked,
                'hold_grace_steps': 180 if parts_start_unlocked else 120,
                'post_attach_settle_steps': 72 if parts_start_unlocked else 48,
                'grasp_settle_steps': 72 if parts_start_unlocked else 48,
                'hold_position_slip_tolerance': 0.06 if parts_start_unlocked else 0.05,
                'hold_orientation_slip_tolerance': 1.2 if parts_start_unlocked else 1.0,
                'hold_grace_position_slip_tolerance': 0.10 if parts_start_unlocked else 0.08,
                'hold_grace_orientation_slip_tolerance': 1.60 if parts_start_unlocked else 1.40,
                'hold_grace_allow_missing_contact': False,
                'release_min_steps': 12,
                'release_require_contact_clear': False,
                'close_contact_hold_squeeze_margin': 0.20 if parts_start_unlocked else 0.12,
                'max_hold_gripper_openness': closed_openness,
                'release_lock_on_attach': bool(parts_start_unlocked),
            }
        )
    jaw_width_spec: dict[str, Any] = {}
    if use_pure_physical_grasp and parts_start_unlocked and not hover_above_object_com:
        # The nest pick stalls with the jaw at the part thickness (v80, 0.65 rad
        # on a 1.8 cm beam) while the pose/contact gate never accepts it, so
        # the lift is never commanded. Treat that stalled width as the pinch.
        pinch_thickness = abs(float(part['bbox_max'][1]) - float(part['bbox_min'][1]))
        jaw_width_spec = {
            'allow_jaw_width_completion': True,
            'allow_jaw_width_contact_for_physical_grasp': True,
            'jaw_width_thickness_m': pinch_thickness,
            'jaw_width_stroke_m': 0.085,
            'jaw_width_joint_tolerance': 0.08,
            'jaw_width_command_lead': 0.05,
            'jaw_width_stable_steps': 8,
            # Pinch the thin faces. A local-Z rim touch is not a grasp.
            'physical_contact_axes': 'y',
        }
        attach_spec['require_target_reached_for_attach'] = False
        attach_spec.update(jaw_width_spec)
    if hover_above_object_com:
        attach_spec['require_target_reached_for_attach'] = False
        attach_spec['position_tolerance'] = 0.04
        attach_spec['orientation_tolerance'] = 0.80
        attach_spec['allow_caging_contact_for_physical_grasp'] = True
        attach_spec['allow_caging_hold_for_physical_grasp'] = True
        attach_spec['require_strict_physical_contact'] = False
    # Keep the pickup pose frozen until the geometric/physical grasp gate
    # succeeds.  Releasing a dynamic mesh on a fixed step lets it fall away
    # during the close phase before the fingers have formed a stable pinch.
    close_phase_actions = {
        'gripper_commands': {robot: 'close'},
        'attach': [attach_spec],
    }
    if use_pure_physical_grasp:
        # Keep the fixture/world pin during close, but turn collision ON so
        # fingers form a real friction contact against solid geometry.
        # Unlocking here drops the part through the thin table (z≈-9 in v25).
        close_phase_actions['object_collisions'] = [{'object': object_name, 'enabled': True}]
    if fixture_lock_target is not None:
        close_phase_actions['fixture_lock'] = [
            {
                'object': object_name,
                'target': fixture_lock_target,
                'snap_free_object': True,
                'free_snap_steps': 0,
                # Physical grasp: collision stays on under the pin so the pinch
                # is real; unlock happens on lift once fingers are closed.
                'disable_collision_on_lock': not use_pure_physical_grasp,
            }
        ]
    close_phase = _skill_phase(
        skill='close_gripper',
        robot=robot,
        phase_name=f'{prefix}_close_and_attach',
        timeout_steps=480 if not use_pure_physical_grasp else 720,
        parameters={
            **grasp_parameters,
            'preclose_openness': preclose_openness,
            'closed_openness': closed_openness,
            'close_until_contact': True,
            'close_until_contact_min_steps': 24,
            'close_until_contact_timeout_steps': 240,
            'close_contact_stable_steps': 12 if not use_pure_physical_grasp else (36 if parts_start_unlocked else 24),
            'close_steps': 180 if not use_pure_physical_grasp else (320 if parts_start_unlocked else 240),
            'close_ramp_steps': 120 if not use_pure_physical_grasp else (200 if parts_start_unlocked else 160),
            'close_contact_hold_squeeze_margin': (
                0.20 if (use_pure_physical_grasp and parts_start_unlocked) else (0.08 if use_pure_physical_grasp else 0.04)
            ),
            'require_close_pose_gate': True,
            'close_position_tolerance': float(descend_position_tolerance),
            'close_orientation_tolerance': 0.10,
            'close_gate_hold_refined_command': True,
            'close_gate_track_object_during_close': True,
            'close_gate_recenter_single_finger_contact': True,
            'close_gate_recenter_contact_distance': 0.008,
            'close_gate_recenter_min_gap_imbalance': 0.004,
            'close_gate_recenter_stable_steps': 2,
            'close_gate_recenter_step': 0.00075,
            'close_gate_recenter_max_offset': 0.025,
            'close_gate_recenter_target_tolerance': 0.00035,
            'require_grasp_contact': True,
            'require_strict_physical_contact': True,
            **contact_parameters,
        },
        phase_actions=close_phase_actions,
    )
    if jaw_width_spec:
        close_phase['local_skill'].update(jaw_width_spec)
    if hover_above_object_com:
        close_phase['local_skill'].update(
            {
                'grasp_relative_position': None,
                'grasp_relative_orientation': None,
                'relative_to_current_tcp': True,
                'offset': [0.0, 0.0, 0.0],
                'offset_frame': 'world',
                'require_close_pose_gate': False,
                'lock_target_orientation': False,
                'require_target_reached_for_attach': False,
                'position_tolerance': 0.04,
                'orientation_tolerance': 0.80,
                'close_position_tolerance': 0.04,
                'close_orientation_tolerance': 0.80,
            }
        )
        close_phase['timeout_steps'] = 1200
    close_advance_min = 48 if use_pure_physical_grasp else 24
    close_phase['advance'] = {
        'type': 'all_of',
        'min_steps': close_advance_min,
        'conditions': [
            {
                'type': 'local_skill_complete',
                'robot': robot,
                'skill': 'ur5e_close_gripper',
                'min_steps': close_advance_min,
            },
            {'type': 'object_attached', 'object': object_name, 'robot': robot},
        ],
    }
    phases.append(close_phase)
    if not include_lift:
        return
    if use_pure_physical_grasp and parts_start_unlocked:
        # Squeeze in place so the pinch loads before peeling off the deck.
        grip_settle = _skill_phase(
            skill='retreat_vertical',
            robot=robot,
            phase_name=f'{prefix}_grip_settle',
            timeout_steps=240,
            parameters={
                'object': object_name,
                'requires_held_object': True,
                'relative_to_current_tcp': True,
                'offset': [0.0, 0.0, -float(grip_settle_drop)],
                'offset_frame': 'world',
                'gripper_command': 'contact_hold',
                'position_tolerance': 0.02,
                'cartesian_position_step': 0.001 if grip_settle_drop > 0.0 else 0.0005,
            },
            phase_actions={
                'object_collisions': [
                    {'object': object_name, 'enabled': True},
                    {'object': 'fabrica_fixture', 'enabled': True},
                    {'object': 'fixture_support', 'enabled': True},
                ],
            },
        )
        grip_settle['advance'] = {
            'type': 'all_of',
            'min_steps': 72,
            'conditions': [
                {'type': 'object_attached', 'object': object_name, 'robot': robot},
            ],
        }
        phases.append(grip_settle)
        # Prove the pinch by peeling the part off the deck before a tall lift.
        # Lateral nudge first breaks any residual sticktion on the cube face.
        peel = _skill_phase(
            skill='retreat_vertical',
            robot=robot,
            phase_name=f'{prefix}_peel_lift',
            timeout_steps=1500,
            parameters={
                'object': object_name,
                'requires_held_object': True,
                'relative_to_current_tcp': True,
                'offset': [0.0, 0.0, 0.06],
                'offset_frame': 'world',
                'gripper_command': 'contact_hold',
                'position_tolerance': 0.03,
                'cartesian_position_step': 0.0008,
                'max_command_joint_step': 0.008,
            },
            phase_actions={
                # Real pull out of the nest. Collision stays on; the nest
                # friction is low enough for the pinch to slide the part up.
                **_deck_collision_actions(object_name, held_collision=True, filter_held_from_deck=False),
                'object_gravity': [{'object': object_name, 'enabled': True}],
                'kinematic_carry': [{'object': object_name, 'enabled': False}],
            },
        )
        peel['advance'] = {
            'type': 'all_of',
            'min_steps': 24,
            'conditions': [
                {'type': 'object_attached', 'object': object_name, 'robot': robot},
                {
                    'type': 'object_lifted',
                    'object': object_name,
                    'robot': robot,
                    'min_lift': 0.008,
                    'require_attached': True,
                },
            ],
        }
        phases.append(peel)
        if use_pure_physical_grasp and parts_start_unlocked:
            # v72: contact_prime + gravity-on lift still dropped at grace expiry
            # (~240 steps). Squeeze while kinematic, hand off with gravity off,
            # lift, then restore gravity (v73).
            squeeze_openness = max(0.0, float(closed_openness) - 0.10)
            contact_prime = _skill_phase(
                skill='retreat_vertical',
                robot=robot,
                phase_name=f'{prefix}_grip_contact_prime',
                timeout_steps=480,
                parameters={
                    'object': object_name,
                    'requires_held_object': True,
                    'relative_to_current_tcp': True,
                    'offset': [0.0, 0.0, 0.0],
                    'offset_frame': 'world',
                    'gripper_command': squeeze_openness,
                    'position_tolerance': 0.02,
                    'cartesian_position_step': 0.0005,
                },
                phase_actions={
                    **_deck_collision_actions(
                        object_name,
                        held_collision=True,
                    ),
                    'gripper_commands': {robot: squeeze_openness},
                    'object_gravity': [{'object': object_name, 'enabled': True}],
                    'kinematic_carry': [{'object': object_name, 'enabled': False}],
                },
            )
            contact_prime['advance'] = {
                'type': 'all_of',
                'min_steps': 72,
                'conditions': [
                    {'type': 'object_attached', 'object': object_name, 'robot': robot},
                ],
            }
            phases.append(contact_prime)
            _append_kinematic_to_friction_handoff(
                phases,
                prefix=f'{prefix}_peel',
                robot=robot,
                object_name=object_name,
                clear_deck_filters=False,
                restore_gravity=False,
                gripper_command=squeeze_openness,
                # The beam stays pinched off-center and rocks. A 2 cm pose
                # gate makes the arm kick it (v82, 12 rad/s for the whole
                # handoff). Yield, and accept a slow residual swing.
                position_tolerance=0.06,
                static_linear_threshold=0.20,
                static_angular_threshold=6.0,
            )
    lift_xyz = [0.0, 0.0, 0.08 if use_pure_physical_grasp else 0.12]
    if parts_start_unlocked and use_pure_physical_grasp:
        lift_xyz = [0.0, 0.0, 0.06]
    if lift_offset is not None:
        lift_xyz = list(lift_offset)
    if use_pure_physical_grasp and not parts_start_unlocked:
        # Legacy path: part still fixture-pinned at close — hand off to support.
        pre_unlock = _skill_phase(
            skill='retreat_vertical',
            robot=robot,
            phase_name=f'{prefix}_grip_pre_unlock',
            timeout_steps=360,
            parameters={
                'object': object_name,
                'requires_held_object': True,
                'relative_to_current_tcp': True,
                'offset': [0.0, 0.0, 0.0],
                'offset_frame': 'world',
                'gripper_command': 'contact_hold',
                'position_tolerance': 0.02,
                'cartesian_position_step': 0.001,
            },
            phase_actions={
                'object_collisions': [
                    {'object': object_name, 'enabled': True},
                    {'object': 'fabrica_fixture', 'enabled': False},
                ],
            },
        )
        pre_unlock['advance'] = {
            'type': 'all_of',
            'min_steps': 48,
            'conditions': [
                {'type': 'object_attached', 'object': object_name, 'robot': robot},
            ],
        }
        phases.append(pre_unlock)
        handoff = _skill_phase(
            skill='retreat_vertical',
            robot=robot,
            phase_name=f'{prefix}_grip_handoff',
            timeout_steps=240,
            parameters={
                'object': object_name,
                'requires_held_object': False,
                'relative_to_current_tcp': True,
                'offset': [0.0, 0.0, 0.02],
                'offset_frame': 'world',
                'gripper_command': 'open',
                'position_tolerance': 0.03,
                'cartesian_position_step': 0.004,
            },
            phase_actions={
                'unlock': [object_name],
                'gripper_commands': {robot: 'open'},
                'detach': [
                    {
                        'object': object_name,
                        'require_open_gripper': True,
                        'release_min_steps': 4,
                    }
                ],
                'object_collisions': [
                    {'object': object_name, 'enabled': True},
                    {'object': 'fabrica_fixture', 'enabled': False},
                ],
            },
        )
        handoff['advance'] = {
            'type': 'all_of',
            'min_steps': 24,
            'conditions': [
                {'type': 'object_detached', 'object': object_name},
                {
                    'type': 'objects_static',
                    'objects': [object_name],
                    'min_steps': 16,
                    'linear_velocity_threshold': 0.10,
                    'angular_velocity_threshold': 4.0,
                },
            ],
        }
        phases.append(handoff)
        clear_grasp = {
            'name': f'{prefix}_clear_grasp',
            'timeout_steps': 120,
            'robot_targets': {},
            'gripper_commands': {robot: 'open'},
            'object_collisions': [
                {'object': object_name, 'enabled': True},
                {'object': 'fabrica_fixture', 'enabled': False},
            ],
            'advance': {
                'type': 'all_of',
                'min_steps': 12,
                'conditions': [
                    {
                        'type': 'objects_static',
                        'objects': [object_name],
                        'min_steps': 8,
                        'linear_velocity_threshold': 0.10,
                        'angular_velocity_threshold': 4.0,
                    },
                ],
            },
        }
        phases.append(clear_grasp)
        regrasp = _skill_phase(
            skill='close_gripper',
            robot=robot,
            phase_name=f'{prefix}_regrasp_from_support',
            timeout_steps=480,
            parameters={
                **grasp_parameters,
                'preclose_openness': min(1.0, closed_openness + 0.20),
                'closed_openness': closed_openness,
                'close_until_contact': True,
                'close_until_contact_min_steps': 16,
                'close_until_contact_timeout_steps': 180,
                'close_contact_stable_steps': 16,
                'close_steps': 160,
                'close_ramp_steps': 100,
                'close_contact_hold_squeeze_margin': 0.12,
                'require_close_pose_gate': False,
                'require_grasp_contact': True,
                'require_strict_physical_contact': False,
                **contact_parameters,
            },
            phase_actions={
                'gripper_commands': {robot: 'close'},
                'attach': [
                    {
                        **attach_spec,
                        'release_lock_on_attach': True,
                        'require_target_reached_for_attach': False,
                        'require_local_skill_complete_for_attach': True,
                        'min_attach_steps': 16,
                        'allow_caging_contact_for_physical_grasp': True,
                        'allow_caging_hold_for_physical_grasp': True,
                        'hold_grace_steps': 90,
                        'hold_grace_allow_missing_contact': False,
                    }
                ],
                'object_collisions': [
                    {'object': object_name, 'enabled': True},
                    {'object': 'fabrica_fixture', 'enabled': False},
                ],
            },
        )
        regrasp['advance'] = {
            'type': 'all_of',
            'min_steps': 24,
            'conditions': [
                {
                    'type': 'local_skill_complete',
                    'robot': robot,
                    'skill': 'ur5e_close_gripper',
                    'min_steps': 16,
                },
                {'type': 'object_attached', 'object': object_name, 'robot': robot},
            ],
        }
        phases.append(regrasp)
    lift_phase = _skill_phase(
        skill='retreat_vertical',
        robot=robot,
        phase_name=f'{prefix}_lift',
        timeout_steps=1200,
        parameters={
            'object': object_name,
            'requires_held_object': True,
            'relative_to_current_tcp': True,
            'offset': lift_xyz,
            'offset_frame': 'world',
            'gripper_command': (
                max(0.0, float(closed_openness) - 0.10)
                if use_pure_physical_grasp and parts_start_unlocked
                else 'contact_hold'
            ),
            'position_tolerance': 0.012,
            **(
                {
                    'cartesian_position_step': 0.0015 if parts_start_unlocked else 0.0025,
                    'max_command_joint_step': 0.015 if parts_start_unlocked else 0.02,
                }
                if use_pure_physical_grasp
                else {}
            ),
        },
    )
    if use_pure_physical_grasp:
        lift_phase.update(
            _deck_collision_actions(
                object_name,
                held_collision=True,
            )
        )
        if parts_start_unlocked:
            lift_phase['object_gravity'] = [{'object': object_name, 'enabled': True}]
            lift_phase['kinematic_carry'] = [{'object': object_name, 'enabled': False}]
            lift_phase['local_skill']['position_tolerance'] = 0.025
    phases.append(lift_phase)
    if use_pure_physical_grasp and parts_start_unlocked:
        _append_kinematic_to_friction_handoff(
            phases,
            prefix=f'{prefix}_post_lift',
            robot=robot,
            object_name=object_name,
            clear_deck_filters=False,
            skip_dynamic_handoff=True,
            gripper_command=max(0.0, float(closed_openness) - 0.10),
        )


def _append_kinematic_to_friction_handoff(
    phases: list[dict[str, Any]],
    *,
    prefix: str,
    robot: str,
    object_name: str,
    clear_deck_filters: bool = True,
    restore_gravity: bool = True,
    skip_dynamic_handoff: bool = False,
    gripper_command: Any = 'contact_hold',
    position_tolerance: float = 0.02,
    static_linear_threshold: float = 0.08,
    static_angular_threshold: float = 2.5,
) -> None:
    """Stagger kinematic→dynamic handoff before friction seating."""
    if not skip_dynamic_handoff:
        handoff = _skill_phase(
            skill='retreat_vertical',
            robot=robot,
            phase_name=f'{prefix}_grip_handoff_dynamic',
            timeout_steps=720,
            parameters={
                'object': object_name,
                'requires_held_object': True,
                'relative_to_current_tcp': True,
                'offset': [0.0, 0.0, 0.0],
                'offset_frame': 'world',
                'gripper_command': gripper_command,
                'position_tolerance': float(position_tolerance),
                'cartesian_position_step': 0.0005,
            },
            phase_actions={
                **_deck_collision_actions(object_name),
                'gripper_commands': {robot: gripper_command},
                'object_gravity': [{'object': object_name, 'enabled': False}],
                'kinematic_carry': [{'object': object_name, 'enabled': False}],
            },
        )
        # Place already put the part at assembly height (COM ≈ grasp z). Requiring
        # object_lifted vs attach_world_position can never pass (v58 dz≈5 mm).
        handoff['advance'] = {
            'type': 'all_of',
            'min_steps': 96,
            'conditions': [
                {'type': 'object_attached', 'object': object_name, 'robot': robot},
                {
                    'type': 'objects_static',
                    'objects': [object_name],
                    'min_steps': 24,
                    'linear_velocity_threshold': float(static_linear_threshold),
                    'angular_velocity_threshold': float(static_angular_threshold),
                },
            ],
        }
        phases.append(handoff)
    if not restore_gravity:
        return
    restore_gravity_phase = _skill_phase(
        skill='retreat_vertical',
        robot=robot,
        phase_name=f'{prefix}_restore_gravity',
        timeout_steps=360,
        parameters={
            'object': object_name,
            'requires_held_object': True,
            'relative_to_current_tcp': True,
            'offset': [0.0, 0.0, 0.0],
            'offset_frame': 'world',
            'gripper_command': gripper_command,
            'position_tolerance': float(position_tolerance),
            'cartesian_position_step': 0.0005,
        },
        phase_actions={
            **_deck_collision_actions(object_name),
            'gripper_commands': {robot: gripper_command},
            'object_gravity': [{'object': object_name, 'enabled': True}],
            'kinematic_carry': [{'object': object_name, 'enabled': False}],
        },
    )
    restore_gravity_phase['advance'] = {
        'type': 'all_of',
        'min_steps': 48,
        'conditions': [
            {'type': 'object_attached', 'object': object_name, 'robot': robot},
            {
                'type': 'objects_static',
                'objects': [object_name],
                'min_steps': 16,
                'linear_velocity_threshold': float(static_linear_threshold),
                'angular_velocity_threshold': float(static_angular_threshold),
            },
        ],
    }
    phases.append(restore_gravity_phase)
    if not clear_deck_filters:
        return
    clear_filters = {
        'name': f'{prefix}_clear_support_filters',
        'timeout_steps': 240,
        'robot_targets': {},
        'collision_filters': [
            {
                'object': object_name,
                'filter_objects': ['fixture_support', 'factory_tabletop_visual'],
                'enabled': False,
            }
        ],
        'object_collisions': [
            {'object': 'fixture_support', 'enabled': True},
            {'object': 'factory_tabletop_visual', 'enabled': True},
        ],
        'object_gravity': [{'object': object_name, 'enabled': True}],
        'kinematic_carry': [{'object': object_name, 'enabled': False}],
        'advance': {
            'type': 'all_of',
            'min_steps': 24,
            'conditions': [
                {'type': 'object_attached', 'object': object_name, 'robot': robot},
            ],
        },
    }
    phases.append(clear_filters)


def _append_transport_phase(
    phases: list[dict[str, Any]],
    *,
    phase_name: str,
    robot: str,
    object_name: str,
    target_name: str,
    insertion: bool,
    timeout_steps: int,
    strict_alignment: bool = False,
    insertion_relaxed_position_tolerance: float = 0.018,
    insertion_relaxed_after_steps: int = 600,
    insertion_axis: list[float] | None = None,
    insertion_lateral_position_tolerance: float | None = None,
    insertion_cartesian_position_step: float = 0.00025,
    insertion_lateral_alignment_cartesian_position_step: float = 0.00025,
    insertion_lateral_alignment_enter_tolerance: float | None = None,
    insertion_lateral_alignment_exit_tolerance: float | None = None,
    insertion_path_depth: float = 0.0,
    insertion_lateral_alignment_axial_clearance: float = 0.0,
    insertion_axial_recovery_cartesian_position_step: float = 0.001,
    insertion_axial_recovery_deadband: float = 0.0005,
    insertion_compliance_capture_max_linear_speed: float = 0.10,
    insertion_compliance_capture_max_angular_speed: float = 2.0,
    insertion_compliance_capture_stable_steps: int = 8,
    insertion_compliance_position_tolerance: float = 0.015,
    insertion_compliance_after_steps: int = 0,
    insertion_compliance_require_waypoint_proximity: bool = False,
    insertion_compliance_waypoint_position_tolerance: float = 0.010,
    insertion_compliance_waypoint_axial_position_tolerance: float | None = None,
    insertion_compliance_waypoint_lateral_position_tolerance: float | None = None,
    insertion_compliance_geometric_capture_after_steps: int = 0,
    insertion_compliance_minimum_gravity_alignment: float = 0.70,
    insertion_compliant_alignment_retraction_limit: float = 0.006,
    insertion_compliant_track_object_orientation: bool = False,
    target_object_entry_capture_max_steps: int = 0,
    cartesian_orientation_step: float | None = None,
    servo_target_object_pose: bool | None = None,
    measured_orientation_position_servo: bool | None = None,
    derive_tcp_orientation_from_target_object: bool | None = None,
    descend_in_place: bool = False,
    position_tolerance_override: float | None = None,
    orientation_tolerance_override: float | None = None,
    object_orientation_tolerance: float | None = None,
    final_target_name: str | None = None,
    settle_at_target: bool = True,
    kinematic_carry: bool = False,
) -> None:
    if cartesian_orientation_step is not None and (
        not math.isfinite(float(cartesian_orientation_step)) or float(cartesian_orientation_step) <= 0.0
    ):
        raise ValueError(f'{phase_name} cartesian_orientation_step must be finite and positive.')
    position_tolerance = 0.006 if insertion or strict_alignment else 0.014
    target_object_position_tolerance = 0.008 if insertion or strict_alignment else 0.014
    if position_tolerance_override is not None:
        position_tolerance = float(position_tolerance_override)
        target_object_position_tolerance = float(position_tolerance_override)
    relaxed_parameters = {}
    if insertion:
        relaxed_parameters = {
            'relaxed_position_tolerance': float(insertion_relaxed_position_tolerance),
            'relaxed_target_object_position_tolerance': float(insertion_relaxed_position_tolerance),
            'relaxed_position_tolerance_after_steps': int(insertion_relaxed_after_steps),
        }
        if insertion_axis is not None:
            relaxed_parameters['target_object_convergence_axis'] = _normalized_direction(
                insertion_axis,
                name=f'{phase_name} insertion axis',
            )
        if insertion_lateral_position_tolerance is not None:
            relaxed_parameters['target_object_lateral_position_tolerance'] = float(insertion_lateral_position_tolerance)
            relaxed_parameters['target_object_lateral_alignment_cartesian_position_step'] = float(
                insertion_lateral_alignment_cartesian_position_step
            )
            relaxed_parameters['target_object_lateral_alignment_axial_clearance'] = float(
                insertion_lateral_alignment_axial_clearance
            )
            relaxed_parameters['target_object_insertion_path_depth'] = float(insertion_path_depth)
            relaxed_parameters['target_object_lateral_alignment_stable_steps'] = 8 if settle_at_target else 1
            relaxed_parameters['target_object_axial_recovery_cartesian_position_step'] = float(
                insertion_axial_recovery_cartesian_position_step
            )
            relaxed_parameters['target_object_axial_recovery_deadband'] = float(insertion_axial_recovery_deadband)
            alignment_enter_tolerance = (
                0.5 * float(insertion_lateral_position_tolerance)
                if insertion_lateral_alignment_enter_tolerance is None
                else float(insertion_lateral_alignment_enter_tolerance)
            )
            alignment_exit_tolerance = (
                float(insertion_lateral_position_tolerance)
                if insertion_lateral_alignment_exit_tolerance is None
                else float(insertion_lateral_alignment_exit_tolerance)
            )
            relaxed_parameters['target_object_lateral_alignment_enter_tolerance'] = alignment_enter_tolerance
            relaxed_parameters['target_object_lateral_alignment_exit_tolerance'] = alignment_exit_tolerance
    transport_phase = _skill_phase(
            skill='move_part_to_target',
            robot=robot,
            phase_name=phase_name,
            timeout_steps=int(timeout_steps),
            parameters={
                'object': object_name,
                'requires_held_object': True,
                'target_object_target': target_name,
                'gripper_command': 'contact_hold',
                'lock_target_orientation': True,
                'derive_tcp_orientation_from_target_object': (
                    True
                    if derive_tcp_orientation_from_target_object is None
                    else bool(derive_tcp_orientation_from_target_object)
                ),
                'guard_ik_branch_jump': True,
                'ik_reference_mode': 'hybrid',
                'ik_reference_command_max_tracking_error': 0.12,
                'use_command_warm_start': True,
                'require_warm_start_ik': True,
                'cartesian_orientation_command_warm_start': True,
                'cartesian_orientation_command_lookahead': 0.36,
                'target_object_use_measured_orientation_for_position_servo': (
                    True
                    if measured_orientation_position_servo is None
                    else bool(measured_orientation_position_servo)
                ),
                'servo_target_object_pose': (
                    True if servo_target_object_pose is None else bool(servo_target_object_pose)
                ),
                'max_command_joint_step': 0.035 if insertion else 0.06,
                'max_command_tracking_error': 0.12 if insertion else 0.24,
                'max_wrist_command_tracking_error': 0.10 if insertion else 0.24,
                'cartesian_position_step': (
                    float(insertion_cartesian_position_step) if insertion else 0.003 if strict_alignment else 0.006
                ),
                'cartesian_orientation_step': (
                    float(cartesian_orientation_step)
                    if cartesian_orientation_step is not None
                    else 0.012 if insertion else 0.025
                ),
                'target_object_servo_position_command_warm_start': bool(insertion),
                'target_object_servo_position_command_gate_overdrive': bool(insertion),
                'target_object_servo_position_command_lookahead': 0.004,
                'target_object_servo_position_command_accumulation_step': 0.0001,
                'max_joint_step': 0.08 if insertion else 0.14,
                # Kinematic carry teleports the part with the TCP — slip guard
                # only applies to friction transport.
                'max_object_tcp_slip': None if kinematic_carry else 0.04,
                'position_tolerance': position_tolerance,
                **relaxed_parameters,
                'orientation_tolerance': (
                    float(orientation_tolerance_override)
                    if orientation_tolerance_override is not None
                    else 0.08 if insertion else 0.10 if strict_alignment else 0.12
                ),
                'require_target_object_pose_convergence': True,
                'target_object_position_tolerance': (
                    0.016 if descend_in_place else target_object_position_tolerance
                ),
                'target_object_orientation_tolerance': (
                    float(object_orientation_tolerance)
                    if object_orientation_tolerance is not None
                    else 0.10 if insertion else 0.15
                ),
                'require_target_object_static': bool(insertion),
                'target_object_max_linear_speed': 0.03,
                'target_object_max_angular_speed': 2.0,
                'target_object_allow_pose_stable_override': True,
                'target_object_stable_steps': 8 if settle_at_target else 1,
                'hold_for_target_object_settle': bool(insertion),
                'target_object_settle_hold_steps': 48,
                'target_object_settle_retry_servo_steps': 8,
                **(
                    {
                        'target_object_final_target': str(final_target_name),
                        'relax_fixed_attachment_within_final_position_tolerance': float(
                            insertion_compliance_position_tolerance
                        ),
                        'relax_fixed_attachment_after_steps': int(insertion_compliance_after_steps),
                        'relax_fixed_attachment_require_waypoint_proximity': bool(
                            insertion_compliance_require_waypoint_proximity
                        ),
                        'relax_fixed_attachment_waypoint_position_tolerance': float(
                            insertion_compliance_waypoint_position_tolerance
                        ),
                        'relax_fixed_attachment_geometric_capture_after_steps': int(
                            insertion_compliance_geometric_capture_after_steps
                        ),
                        'relax_fixed_attachment_minimum_gravity_alignment': float(
                            insertion_compliance_minimum_gravity_alignment
                        ),
                        **(
                            {
                                'relax_fixed_attachment_waypoint_axial_position_tolerance': float(
                                    insertion_compliance_waypoint_axial_position_tolerance
                                ),
                                'relax_fixed_attachment_waypoint_lateral_position_tolerance': float(
                                    insertion_compliance_waypoint_lateral_position_tolerance
                                ),
                            }
                            if insertion_compliance_waypoint_axial_position_tolerance is not None
                            and insertion_compliance_waypoint_lateral_position_tolerance is not None
                            else {}
                        ),
                        'relax_fixed_attachment_final_orientation_tolerance': 0.15,
                        'relax_fixed_attachment_max_linear_speed': float(insertion_compliance_capture_max_linear_speed),
                        'relax_fixed_attachment_max_angular_speed': float(
                            insertion_compliance_capture_max_angular_speed
                        ),
                        'relax_fixed_attachment_stable_steps': int(insertion_compliance_capture_stable_steps),
                        'relax_fixed_attachment_allow_pose_stable_override': True,
                        'compliant_servo_pause_linear_speed': 0.20,
                        'compliant_servo_pause_angular_speed': 5.0,
                        'compliant_servo_resume_linear_speed': 0.03,
                        'compliant_servo_resume_angular_speed': 2.0,
                        'compliant_servo_resume_stable_steps': 8,
                        'compliant_servo_allow_pose_stable_resume': True,
                        'target_object_allow_pose_history_velocity_override': True,
                        'pose_history_velocity_override_position_tolerance': 0.0005,
                        'pose_history_velocity_override_orientation_tolerance': 0.01,
                        'compliant_servo_settle_max_linear_speed': float(insertion_compliance_capture_max_linear_speed),
                        'compliant_servo_settle_max_angular_speed': min(
                            float(insertion_compliance_capture_max_angular_speed),
                            2.0,
                        ),
                        'compliant_servo_settle_stable_steps': 24,
                        'compliant_servo_velocity_rate_limit': True,
                        'compliant_servo_minimum_step_scale': 0.2,
                        'compliant_servo_max_position_step': 0.0005,
                        'compliant_servo_position_command_warm_start': True,
                        'compliant_servo_position_command_gate_overdrive': True,
                        'compliant_servo_position_command_lookahead': 0.004,
                        'compliant_servo_position_command_accumulation_step': 0.0001,
                        'compliant_servo_max_lateral_step': 0.0005,
                        'compliant_servo_max_alignment_retraction': float(
                            insertion_compliant_alignment_retraction_limit
                        ),
                        'compliant_servo_max_orientation_step': 0.002,
                        'compliant_servo_orientation_correction_deadband': 0.005,
                        'compliant_servo_hold_orientation_during_lateral_alignment': True,
                        'compliant_servo_track_object_orientation': bool(insertion_compliant_track_object_orientation),
                    }
                    if insertion and final_target_name is not None
                    else {}
                ),
                **(
                    {'target_object_entry_capture_max_steps': int(target_object_entry_capture_max_steps)}
                    if insertion and target_object_entry_capture_max_steps > 0
                    else {}
                ),
            },
        )
    if kinematic_carry:
        transport_phase['kinematic_carry'] = [{'object': object_name, 'enabled': True}]
        transport_phase['object_gravity'] = [{'object': object_name, 'enabled': False}]
        transport_phase['collision_filters'] = [
            {
                'object': object_name,
                'filter_objects': ['fixture_support', 'factory_tabletop_visual'],
                'enabled': True,
            }
        ]
        transport_phase.update(
            _deck_collision_actions(
                object_name,
                filter_held_from_deck=True,
                held_collision=False,
            )
        )
    if descend_in_place:
        # Drop straight down from the pose clearance already reached.
        # Re-deriving the wrist from a slipped pinch walks the arm back.
        transport_phase['local_skill'].update(
            {
                'relative_to_current_tcp': True,
                'offset': [0.0, 0.0, -0.0884],
                'offset_frame': 'world',
                'lock_target_position': True,
                'lock_target_orientation': True,
                # Object servo ignores the straight drop and walks back.
                'servo_target_object_pose': False,
            }
        )
    phases.append(transport_phase)


def _hold_companion_spec(*, robot: str, object_name: str, target_name: str) -> dict[str, Any]:
    phase = _skill_phase(
        skill='hold_part_end',
        robot=robot,
        phase_name='hold_companion',
        timeout_steps=1200,
        parameters={
            'object': object_name,
            'target_object_target': target_name,
            'gripper_command': 'contact_hold',
            'relative_to_current_tcp': True,
            'offset': [0.0, 0.0, 0.0],
            'offset_frame': 'world',
            'lock_target_position': True,
            'lock_target_orientation': True,
            'position_tolerance': 0.018,
        },
    )
    return phase['local_skill']


def _install_hold_companion(
    phase: dict[str, Any],
    *,
    robot: str,
    object_name: str,
    target_name: str,
) -> None:
    primary = phase.get('local_skill') or {}
    if primary.get('robot') == robot:
        return
    companions = phase.get('local_skills')
    if companions is None:
        companions = {}
        phase['local_skills'] = companions
    if not isinstance(companions, dict):
        return
    companions[robot] = _hold_companion_spec(
        robot=robot,
        object_name=object_name,
        target_name=target_name,
    )


def _append_release_and_retreat(
    phases: list[dict[str, Any]],
    *,
    prefix: str,
    robot: str,
    object_name: str,
    final_target: str,
    assembled_objects: list[str],
    retreat_offset: list[float],
    park_offset: list[float],
    park_workspace_center: list[float],
    park_minimum_planar_radius: float,
    disable_collision_on_lock: bool = True,
    pin_pose: bool = True,
    freeze_current_pose: bool = True,
    include_park: bool = True,
    include_retreat: bool = True,
    static_release: bool = True,
    detach_on_lock: bool = False,
    teleport_to_target_once: bool = False,
    snap_on_open: bool = False,
    position_tolerance: float = 0.015,
    orientation_tolerance: float = 0.12,
    release_snap_steps: int = 6,
    skip_lock: bool = False,
) -> None:
    # Physical release: open + break the carry weld, then wait for PhysX static.
    # No pin / teleport / pose snap — the part must stay seated by collision.
    phase: dict[str, Any] = {
        'name': f'{prefix}_release' if skip_lock else f'{prefix}_release_and_lock',
        'timeout_steps': 720,
        'robot_targets': {},
        'gripper_commands': {robot: 'open'},
        'object_collisions': [{'object': object_name, 'enabled': True}],
        'advance': (
            {
                'type': 'all_of',
                'min_steps': 72,
                'conditions': [
                    {
                        'type': 'objects_static',
                        'objects': copy.deepcopy(assembled_objects),
                        'min_steps': 72,
                        'linear_velocity_threshold': 0.05,
                        'angular_velocity_threshold': 2.0,
                    },
                    {
                        'type': 'object_targets_reached',
                        'tolerance': float(position_tolerance),
                        'orientation_tolerance': float(orientation_tolerance),
                        'objects': [
                            {
                                'object': object_name,
                                'target': final_target,
                            }
                        ],
                    },
                ],
            }
            if static_release
            else {'type': 'timer', 'min_steps': 12}
        ),
    }
    if skip_lock:
        # Keep finger↔part filters while opening so PhysX does not fire a
        # penetration impulse that ejects the seated peg from the hole.
        phase['detach'] = [
            {
                'object': object_name,
                'require_open_gripper': True,
                'keep_gripper_collision_filter': True,
                'release_min_steps': 12,
            }
        ]
        phase['unlock'] = [object_name]
    else:
        phase['detach'] = [object_name]
        phase['lock'] = [
            {
                'object': object_name,
                'target': final_target,
                'position_tolerance': float(position_tolerance),
                'orientation_tolerance': float(orientation_tolerance),
                'snap_on_open': bool(snap_on_open),
                'release_snap_steps': int(release_snap_steps),
                'freeze_current_pose': bool(freeze_current_pose),
                'pin_pose': bool(pin_pose),
                # Dynamic triangle meshes cannot stay collidable. SDF parts
                # keep collision when disable_collision_on_lock is false.
                'disable_collision_on_lock': bool(disable_collision_on_lock),
                'detach_on_lock': bool(detach_on_lock),
                'teleport_to_target_once': bool(teleport_to_target_once),
            }
        ]
    phases.append(phase)
    if not include_retreat:
        return
    phases.append(
        _skill_phase(
            skill='retreat_vertical',
            robot=robot,
            phase_name=f'{prefix}_retreat',
            timeout_steps=1200,
            parameters={
                'relative_to_current_tcp': True,
                'offset': copy.deepcopy(retreat_offset),
                'offset_frame': 'world',
                'gripper_command': 'open',
                'position_tolerance': 0.008,
            },
        )
    )
    if not include_park:
        return
    phases.append(
        _skill_phase(
            skill='retreat_vertical',
            robot=robot,
            phase_name=f'{prefix}_park',
            timeout_steps=1800,
            parameters={
                'relative_to_current_tcp': True,
                'offset': copy.deepcopy(park_offset),
                'offset_frame': 'world',
                'workspace_center': copy.deepcopy(park_workspace_center),
                'workspace_minimum_planar_radius': float(park_minimum_planar_radius),
                'lock_target_position': True,
                'lock_target_orientation': False,
                'gripper_command': 'open',
                'position_tolerance': 0.018,
                'cartesian_position_step': 0.010,
            },
        )
    )


def _compile_targets_and_phases(
    *,
    assembly: str,
    task: dict[str, Any],
    spec: dict[str, Any],
    pickup_origin: list[float],
    pickup_orientation: list[float],
    assembly_origin: list[float],
    assembly_orientation: list[float],
    robots: list[dict[str, Any]],
) -> tuple[list[dict], list[dict], list[dict], list[str], list[str]]:
    targets: list[dict] = []
    phases: list[dict] = []
    success: list[dict] = []
    pickup_target_names: list[str] = []
    assembly_target_names: list[str] = []
    parts_by_id = {str(part['part_id']): part for part in task['parts']}
    base_robot = str(spec.get('base_robot', 'franka_right'))
    assembly_robot = str(spec.get('assembly_robot', 'franka_left'))
    release_retreat_distance = float(spec.get('release_retreat_distance', 0.06))
    post_release_park_distance = float(spec.get('post_release_park_distance', 0.35))
    post_release_park_vertical_offset = float(spec.get('post_release_park_vertical_offset', 0.02))
    post_release_park_minimum_planar_radius = float(spec.get('post_release_park_minimum_planar_radius', 0.28))
    if (
        not math.isfinite(release_retreat_distance)
        or release_retreat_distance <= 0.0
        or not math.isfinite(post_release_park_distance)
        or post_release_park_distance <= 0.0
        or not math.isfinite(post_release_park_vertical_offset)
        or post_release_park_vertical_offset < 0.0
        or not math.isfinite(post_release_park_minimum_planar_radius)
        or post_release_park_minimum_planar_radius <= 0.0
    ):
        raise ValueError(
            'Release retreat and park distances must be finite and positive, and the '
            'park vertical offset must be finite and non-negative; the park workspace '
            'radius must be finite and positive.'
        )
    robots_by_name = {
        str(robot['name']): robot for robot in robots if isinstance(robot, dict) and robot.get('name') is not None
    }

    def post_release_park_offset(robot_name: str) -> list[float]:
        robot = robots_by_name.get(robot_name)
        if robot is None:
            raise ValueError(f'Post-release parking references missing robot {robot_name!r}.')
        robot_position = _vector(
            robot.get('position', [0.0, 0.0, 0.0]),
            size=3,
            name=f'{robot_name} position',
        )
        direction = [
            robot_position[0] - assembly_origin[0],
            robot_position[1] - assembly_origin[1],
        ]
        direction_norm = math.hypot(*direction)
        if direction_norm <= 1e-9:
            raise ValueError(f'Cannot derive a post-release parking direction for {robot_name!r}.')
        return [
            post_release_park_distance * direction[0] / direction_norm,
            post_release_park_distance * direction[1] / direction_norm,
            post_release_park_vertical_offset,
        ]

    def post_release_park_workspace_center(robot_name: str) -> list[float]:
        robot = robots_by_name.get(robot_name)
        if robot is None:
            raise ValueError(f'Post-release parking references missing robot {robot_name!r}.')
        return _vector(
            robot.get('position', [0.0, 0.0, 0.0]),
            size=3,
            name=f'{robot_name} position',
        )

    def release_retreat_offset(insertion_axis: list[float]) -> list[float]:
        direction = _normalized_direction(insertion_axis, name='release retreat axis')
        return [-release_retreat_distance * value for value in direction]

    approach_height = float(spec.get('approach_height', 0.10))
    transport_hover_height = float(spec.get('transport_hover_height', 0.12))
    move_above_timeout_steps = int(spec.get('move_above_timeout_steps', 2200))
    move_above_orientation_first = bool(spec.get('move_above_orientation_first', True))
    move_above_orientation_first_steps = int(spec.get('move_above_orientation_first_steps', 720))
    move_above_orientation_first_tolerance = float(spec.get('move_above_orientation_first_tolerance', 0.08))
    preshape_timeout_steps = int(spec.get('preshape_timeout_steps', 720))
    preshape_open_margin = float(spec.get('preshape_open_margin', 0.20))
    preshape_gripper_position_tolerance = float(spec.get('preshape_gripper_position_tolerance', 0.025))
    descend_position_tolerance = float(spec.get('descend_position_tolerance', 0.007))
    descend_relaxed_position_tolerance = float(spec.get('descend_relaxed_position_tolerance', 0.012))
    descend_relaxed_after_steps = int(spec.get('descend_relaxed_after_steps', 600))
    fixture_release_after_steps = int(spec.get('fixture_release_after_steps', 8))
    insertion_relaxed_position_tolerance = float(spec.get('insertion_relaxed_position_tolerance', 0.018))
    base_support_release_position_tolerance = float(spec.get('base_support_release_position_tolerance', 0.012))
    base_support_lateral_position_tolerance = float(spec.get('base_support_lateral_position_tolerance', 0.015))
    base_support_lateral_alignment_enter_tolerance = float(
        spec.get('base_support_lateral_alignment_enter_tolerance', 0.002)
    )
    base_support_lateral_alignment_exit_tolerance = float(
        spec.get('base_support_lateral_alignment_exit_tolerance', 0.004)
    )
    base_support_lateral_alignment_cartesian_position_step = float(
        spec.get(
            'base_support_lateral_alignment_cartesian_position_step',
            0.002,
        )
    )
    insertion_relaxed_after_steps = int(spec.get('insertion_relaxed_after_steps', 600))
    insertion_lateral_position_tolerance = float(spec.get('insertion_lateral_position_tolerance', 0.001))
    insertion_lateral_tolerance_object_extent_scale = float(
        spec.get('insertion_lateral_tolerance_object_extent_scale', 0.04)
    )
    intermediate_insertion_lateral_position_tolerance = float(
        spec.get('intermediate_insertion_lateral_position_tolerance', 0.002)
    )
    intermediate_insertion_lateral_alignment_cartesian_position_step = float(
        spec.get(
            'intermediate_insertion_lateral_alignment_cartesian_position_step',
            0.001,
        )
    )
    insertion_cartesian_position_step = float(spec.get('insertion_cartesian_position_step', 0.00025))
    insertion_lateral_alignment_cartesian_position_step = float(
        spec.get('insertion_lateral_alignment_cartesian_position_step', 0.00025)
    )
    insertion_lateral_alignment_entry_clearance = float(spec.get('insertion_lateral_alignment_entry_clearance', 0.01))
    insertion_lateral_alignment_clearance_object_extent_scale = float(
        spec.get(
            'insertion_lateral_alignment_clearance_object_extent_scale',
            1.0,
        )
    )
    insertion_axial_recovery_cartesian_position_step = float(
        spec.get('insertion_axial_recovery_cartesian_position_step', 0.001)
    )
    insertion_axial_recovery_deadband = float(spec.get('insertion_axial_recovery_deadband', 0.0005))
    insertion_compliance_capture_max_linear_speed = float(
        spec.get('insertion_compliance_capture_max_linear_speed', 0.10)
    )
    insertion_compliance_capture_max_angular_speed = float(
        spec.get('insertion_compliance_capture_max_angular_speed', 2.0)
    )
    insertion_compliance_capture_stable_steps = int(spec.get('insertion_compliance_capture_stable_steps', 8))
    insertion_compliance_geometric_capture_after_steps = int(
        spec.get('insertion_compliance_geometric_capture_after_steps', 1200)
    )
    insertion_compliance_minimum_gravity_alignment = float(
        spec.get('insertion_compliance_minimum_gravity_alignment', 0.70)
    )
    insertion_compliant_alignment_retraction_limit = float(
        spec.get('insertion_compliant_alignment_retraction_limit', 0.006)
    )
    insertion_compliant_track_object_orientation = bool(spec.get('insertion_compliant_track_object_orientation', False))
    transport_timeout_steps = int(spec.get('transport_timeout_steps', 4800))
    insertion_timeout_steps = int(spec.get('insertion_timeout_steps', 3600))
    base_place_timeout_steps = int(spec.get('base_place_timeout_steps', 4800))
    move_above_prealign_steps = int(spec.get('move_above_prealign_steps', 0))
    prealign_joint_positions_by_robot = spec.get('prealign_joint_positions_by_robot') or {}
    if not isinstance(prealign_joint_positions_by_robot, dict):
        raise ValueError('prealign_joint_positions_by_robot must be a mapping.')
    for robot_name, positions in prealign_joint_positions_by_robot.items():
        prealign_joint_positions_by_robot[robot_name] = _vector(
            positions,
            size=6,
            name=f'{robot_name} prealign_joint_positions',
        )
    prealign_shoulder_pan_by_robot = spec.get('prealign_shoulder_pan_by_robot') or {}
    if not isinstance(prealign_shoulder_pan_by_robot, dict):
        raise ValueError('prealign_shoulder_pan_by_robot must be a mapping.')
    if (
        move_above_timeout_steps <= 0
        or preshape_timeout_steps <= 0
        or insertion_relaxed_after_steps <= 0
        or transport_timeout_steps <= 0
        or insertion_timeout_steps <= 0
        or base_place_timeout_steps <= 0
        or move_above_orientation_first_steps < 0
        or move_above_prealign_steps < 0
        or not math.isfinite(preshape_open_margin)
        or preshape_open_margin < 0.0
        or preshape_open_margin > 1.0
        or not math.isfinite(preshape_gripper_position_tolerance)
        or preshape_gripper_position_tolerance <= 0.0
        or preshape_gripper_position_tolerance > 0.1
        or not math.isfinite(descend_position_tolerance)
        or descend_position_tolerance <= 0.0
        or not math.isfinite(descend_relaxed_position_tolerance)
        or descend_relaxed_position_tolerance < descend_position_tolerance
        or descend_relaxed_after_steps <= 0
        or fixture_release_after_steps < 0
        or not math.isfinite(insertion_relaxed_position_tolerance)
        or insertion_relaxed_position_tolerance < 0.008
        or not math.isfinite(base_support_release_position_tolerance)
        or base_support_release_position_tolerance < 0.008
        or base_support_release_position_tolerance > 0.015
        or not math.isfinite(base_support_lateral_position_tolerance)
        or base_support_lateral_position_tolerance < base_support_release_position_tolerance
        or base_support_lateral_position_tolerance > 0.02
        or not math.isfinite(base_support_lateral_alignment_enter_tolerance)
        or base_support_lateral_alignment_enter_tolerance <= 0.0
        or base_support_lateral_alignment_enter_tolerance > base_support_release_position_tolerance
        or not math.isfinite(base_support_lateral_alignment_exit_tolerance)
        or base_support_lateral_alignment_exit_tolerance < base_support_lateral_alignment_enter_tolerance
        or base_support_lateral_alignment_exit_tolerance > base_support_lateral_position_tolerance
        or not math.isfinite(base_support_lateral_alignment_cartesian_position_step)
        or base_support_lateral_alignment_cartesian_position_step <= 0.0
        or base_support_lateral_alignment_cartesian_position_step > base_support_lateral_alignment_enter_tolerance
        or not math.isfinite(insertion_lateral_position_tolerance)
        or insertion_lateral_position_tolerance <= 0.0
        or insertion_lateral_position_tolerance > insertion_relaxed_position_tolerance
        or not math.isfinite(insertion_lateral_tolerance_object_extent_scale)
        or insertion_lateral_tolerance_object_extent_scale < 0.0
        or insertion_lateral_tolerance_object_extent_scale > 0.25
        or not math.isfinite(intermediate_insertion_lateral_position_tolerance)
        or intermediate_insertion_lateral_position_tolerance < insertion_lateral_position_tolerance
        or intermediate_insertion_lateral_position_tolerance > 0.005
        or not math.isfinite(intermediate_insertion_lateral_alignment_cartesian_position_step)
        or intermediate_insertion_lateral_alignment_cartesian_position_step <= 0.0
        or intermediate_insertion_lateral_alignment_cartesian_position_step
        > intermediate_insertion_lateral_position_tolerance
        or not math.isfinite(insertion_cartesian_position_step)
        or insertion_cartesian_position_step <= 0.0
        or insertion_cartesian_position_step > 0.002
        or not math.isfinite(insertion_lateral_alignment_cartesian_position_step)
        or insertion_lateral_alignment_cartesian_position_step <= 0.0
        or insertion_lateral_alignment_cartesian_position_step > insertion_lateral_position_tolerance
        or not math.isfinite(insertion_lateral_alignment_entry_clearance)
        or insertion_lateral_alignment_entry_clearance < 0.0
        or insertion_lateral_alignment_entry_clearance > 0.05
        or not math.isfinite(insertion_lateral_alignment_clearance_object_extent_scale)
        or insertion_lateral_alignment_clearance_object_extent_scale < 0.0
        or insertion_lateral_alignment_clearance_object_extent_scale > 2.0
        or not math.isfinite(insertion_axial_recovery_cartesian_position_step)
        or insertion_axial_recovery_cartesian_position_step <= 0.0
        or insertion_axial_recovery_cartesian_position_step > 0.002
        or not math.isfinite(insertion_axial_recovery_deadband)
        or insertion_axial_recovery_deadband < 0.0
        or insertion_axial_recovery_deadband >= insertion_axial_recovery_cartesian_position_step
        or not math.isfinite(insertion_compliance_capture_max_linear_speed)
        or insertion_compliance_capture_max_linear_speed <= 0.0
        or not math.isfinite(insertion_compliance_capture_max_angular_speed)
        or insertion_compliance_capture_max_angular_speed <= 0.0
        or insertion_compliance_capture_stable_steps <= 0
        or insertion_compliance_geometric_capture_after_steps < 0
        or insertion_compliance_geometric_capture_after_steps >= insertion_timeout_steps
        or not math.isfinite(insertion_compliance_minimum_gravity_alignment)
        or insertion_compliance_minimum_gravity_alignment < 0.0
        or insertion_compliance_minimum_gravity_alignment > 1.0
        or not math.isfinite(insertion_compliant_alignment_retraction_limit)
        or insertion_compliant_alignment_retraction_limit <= 0.0
        or insertion_compliant_alignment_retraction_limit > 0.05
        or not math.isfinite(move_above_orientation_first_tolerance)
        or move_above_orientation_first_tolerance < 0.0
    ):
        raise ValueError(
            'Move-above and preshape timeouts must be positive, prealign steps cannot be negative, '
            'preshape_open_margin must be in [0, 1], descend tolerances must be positive and ordered, '
            'preshape gripper tolerance must be in (0, 0.1], transport/insertion/base-place '
            'timeouts must '
            'be positive, and delayed descend/insertion tolerances must be positive and ordered, '
            'fixture release delay cannot be negative, '
            'with insertion lateral tolerance no larger than the relaxed position tolerance; '
            'the insertion lateral-tolerance object-extent scale must be in [0, 0.25]; '
            'intermediate insertion lateral tolerance must be between the final tolerance '
            'and 0.005 m; '
            'the intermediate insertion lateral-alignment Cartesian step must be positive '
            'and no larger than the intermediate lateral tolerance; '
            'base support release tolerance must be in [0.008, 0.015]; '
            'base support lateral tolerance must be between the release tolerance '
            'and 0.02 m; '
            'base support lateral-alignment enter/exit tolerances must be positive, '
            'ordered, and no larger than the release/completion tolerances; '
            'the base support lateral-alignment Cartesian step must be positive and '
            'no larger than the alignment enter tolerance; '
            'the insertion Cartesian step must be in (0, 0.002]; '
            'the insertion lateral-alignment Cartesian step must be positive and no '
            'larger than the final insertion lateral tolerance; '
            'the insertion lateral-alignment entry clearance must be in [0, 0.05] m; '
            'the insertion lateral-alignment object-extent scale must be in [0, 2]; '
            'the insertion axial-recovery Cartesian step must be in (0, 0.002] and '
            'larger than its non-negative deadband; '
            'insertion-compliance capture speed limits and stable steps must be positive, '
            'and geometric capture delay must be non-negative and smaller than the '
            'insertion timeout; '
            'the insertion-compliance minimum gravity alignment must be in [0, 1]; '
            'the compliant alignment-retraction limit must be in (0, 0.05] m; '
            'orientation-first steps and tolerance '
            'must be non-negative.'
        )
    transport_tcp_height = _transport_tcp_height(
        spec,
        pickup_origin=pickup_origin,
        assembly_origin=assembly_origin,
    )

    def add_transport_clearance_targets(
        *,
        part_id: str,
        grasp: dict[str, Any],
        destination_position: list[float],
        destination_orientation: list[float],
    ) -> tuple[str, str]:
        source_position, source_orientation = _part_pickup_pose(
            parts_by_id[part_id],
            pickup_origin=pickup_origin,
            pickup_orientation=pickup_orientation,
        )
        pickup_clearance_name = f'part_{part_id}_pickup_clearance'
        targets.append(
            _target(
                pickup_clearance_name,
                _object_position_at_tcp_height(
                    object_position=source_position,
                    object_orientation=source_orientation,
                    grasp=grasp,
                    tcp_height=transport_tcp_height,
                ),
                source_orientation,
            )
        )
        pickup_target_names.append(pickup_clearance_name)

        assembly_clearance_name = f'part_{part_id}_assembly_clearance'
        clearance_orientation = destination_orientation
        targets.append(
            _target(
                assembly_clearance_name,
                _object_position_at_tcp_height(
                    object_position=destination_position,
                    object_orientation=clearance_orientation,
                    grasp=grasp,
                    tcp_height=transport_tcp_height,
                ),
                clearance_orientation,
            )
        )
        assembly_target_names.append(assembly_clearance_name)
        return pickup_clearance_name, assembly_clearance_name

    final_targets: dict[str, str] = {}
    fixture_pickup_targets: dict[str, str] = {}
    for part_id, part in parts_by_id.items():
        target_name = f'part_{part_id}_fixture_pickup'
        pickup_position, pickup_part_orientation = _part_pickup_pose(
            part,
            pickup_origin=pickup_origin,
            pickup_orientation=pickup_orientation,
        )
        fixture_pickup_targets[part_id] = target_name
        targets.append(
            _target(
                target_name,
                pickup_position,
                pickup_part_orientation,
            )
        )
        pickup_target_names.append(target_name)

    for part_id in parts_by_id:
        target_name = f'part_{part_id}_assembled'
        final_targets[part_id] = target_name
        targets.append(_target(target_name, assembly_origin, assembly_orientation))
        assembly_target_names.append(target_name)

    base_part_id = str(task['base_part'])
    base_object = f'fabrica_{assembly}_{base_part_id}'
    official_hold = bool(spec.get('official_bimanual_hold', False))
    base_hover_name = f'part_{base_part_id}_assembly_hover'
    _, base_pickup_orientation = _part_pickup_pose(
        parts_by_id[base_part_id],
        pickup_origin=pickup_origin,
        pickup_orientation=pickup_orientation,
    )
    # v13/v87: turn the plate flat on the way to the board, hover 12 cm up,
    # then place along that same orientation.
    targets.append(
        _target(
            base_hover_name,
            _add(assembly_origin, [0.0, 0.0, transport_hover_height]),
            assembly_orientation,
        )
    )
    assembly_target_names.append(base_hover_name)
    base_pickup_clearance, base_assembly_clearance = add_transport_clearance_targets(
        part_id=base_part_id,
        grasp=task['base_grasp'],
        destination_position=assembly_origin,
        destination_orientation=assembly_orientation,
    )
    physical_grasp_mode = 'pure_physical_grasp' if official_hold else 'fixed_joint'
    _append_pick_and_attach_phases(
        phases,
        prefix=f'base_{base_part_id}',
        robot=base_robot,
        object_name=base_object,
        grasp=task['base_grasp'],
        part=parts_by_id[base_part_id],
        approach_height=approach_height,
        move_above_timeout_steps=move_above_timeout_steps,
        move_above_orientation_first=move_above_orientation_first,
        move_above_orientation_first_steps=move_above_orientation_first_steps,
        move_above_orientation_first_tolerance=move_above_orientation_first_tolerance,
        preshape_timeout_steps=preshape_timeout_steps,
        preshape_open_margin=preshape_open_margin,
        preshape_gripper_position_tolerance=preshape_gripper_position_tolerance,
        descend_position_tolerance=descend_position_tolerance,
        descend_relaxed_position_tolerance=descend_relaxed_position_tolerance,
        descend_relaxed_after_steps=descend_relaxed_after_steps,
        prealign_steps=move_above_prealign_steps,
        prealign_joint_positions=prealign_joint_positions_by_robot.get(base_robot),
        prealign_shoulder_pan=prealign_shoulder_pan_by_robot.get(base_robot),
        fixture_release_after_steps=fixture_release_after_steps,
        fixture_lock_target=None if official_hold else fixture_pickup_targets[base_part_id],
        # Pure physical grasp: no FixedJoint weld, no finger collision filter.
        filter_gripper_collisions_on_attach=False,
        force_enable_collision_on_attach=True if official_hold else False,
        attachment_mode=physical_grasp_mode,
        parts_start_unlocked=bool(official_hold),
        # Come straight down onto the upper end. A 12 deg lean drove the
        # gripper into that end (v127). The pad center is 1.2 cm inside the
        # tip; the fingertip band that meets the plate stays on the two faces
        # and 5 mm above the edge that points down when the plate is laid flat.
        grasp_lateral_offset=(
            _quat_rotate(base_pickup_orientation, [-0.0099, 0.0, -0.0079])
            if official_hold
            else None
        ),
        grip_settle_drop=0.0,
        grasp_pad_reach=0.120 if official_hold else 0.112,
        align_finger_to_object_axis=[1.0, 0.0, 0.0] if official_hold else None,
        align_finger_max_tilt_rad=0.0 if official_hold else None,
        lift_offset=[0.0, 0.0, 0.14] if official_hold else None,
    )
    _append_transport_phase(
        phases,
        phase_name=f'base_{base_part_id}_pickup_clearance',
        robot=base_robot,
        object_name=base_object,
        target_name=base_pickup_clearance,
        insertion=False,
        timeout_steps=transport_timeout_steps,
        kinematic_carry=False,
    )
    # Keep fixture nest muted for the whole official-hold episode so free
    # remaining parts are not ejected from SDF cavities.
    _append_transport_phase(
        phases,
        phase_name=f'base_{base_part_id}_assembly_clearance',
        robot=base_robot,
        object_name=base_object,
        target_name=base_assembly_clearance,
        insertion=False,
        timeout_steps=transport_timeout_steps,
        kinematic_carry=False,
    )
    _append_transport_phase(
        phases,
        phase_name=f'base_{base_part_id}_transport_hover',
        robot=base_robot,
        object_name=base_object,
        target_name=base_hover_name,
        insertion=False,
        timeout_steps=transport_timeout_steps,
        strict_alignment=True,
        kinematic_carry=False,
    )
    _append_transport_phase(
        phases,
        phase_name=f'base_{base_part_id}_place',
        robot=base_robot,
        object_name=base_object,
        target_name=final_targets[base_part_id],
        insertion=True,
        timeout_steps=base_place_timeout_steps,
        insertion_relaxed_position_tolerance=min(
            base_support_release_position_tolerance,
            0.04,
        ),
        insertion_relaxed_after_steps=insertion_relaxed_after_steps,
        insertion_axis=_quat_rotate(
            assembly_orientation,
            [0.0, 0.0, -1.0],
        ),
        insertion_lateral_position_tolerance=(base_support_lateral_position_tolerance),
        insertion_cartesian_position_step=insertion_cartesian_position_step,
        insertion_lateral_alignment_cartesian_position_step=(base_support_lateral_alignment_cartesian_position_step),
        insertion_lateral_alignment_enter_tolerance=(base_support_lateral_alignment_enter_tolerance),
        insertion_lateral_alignment_exit_tolerance=(base_support_lateral_alignment_exit_tolerance),
        insertion_axial_recovery_cartesian_position_step=(insertion_axial_recovery_cartesian_position_step),
        insertion_axial_recovery_deadband=insertion_axial_recovery_deadband,
        kinematic_carry=False,
    )
    assembled_objects = [base_object]
    current_hold_id = base_part_id
    if official_hold:
        # Friction seating: end kinematic carry only after the part is at the
        # place pose (v47). Earlier handoff dropped the part on the deck.
        _append_kinematic_to_friction_handoff(
            phases,
            prefix=f'base_{base_part_id}',
            robot=base_robot,
            object_name=base_object,
        )
        # Seat with a closed friction grip (pure_physical_grasp — no weld).
        # World collision stays on so the board/support can take the load.
        set_down_phase = {
            'name': f'base_{base_part_id}_set_down',
            'timeout_steps': 720,
            'robot_targets': {},
            'gripper_commands': {base_robot: 'close'},
            'unlock': [base_object],
            'object_collisions': [{'object': base_object, 'enabled': True}],
            'advance': {
                'type': 'all_of',
                'min_steps': 48,
                'conditions': [
                    {
                        'type': 'object_targets_reached',
                        'tolerance': 0.012,
                        'orientation_tolerance': 0.25,
                        'objects': [
                            {
                                'object': base_object,
                                'target': final_targets[base_part_id],
                            }
                        ],
                    },
                    {
                        'type': 'objects_static',
                        'objects': [base_object],
                        'min_steps': 48,
                        'linear_velocity_threshold': 0.05,
                        'angular_velocity_threshold': 2.0,
                    },
                ],
            },
        }
        _install_hold_companion(
            set_down_phase,
            robot=base_robot,
            object_name=base_object,
            target_name=final_targets[base_part_id],
        )
        phases.append(set_down_phase)
    if not official_hold:
        _append_release_and_retreat(
            phases,
            prefix=f'base_{base_part_id}',
            robot=base_robot,
            object_name=base_object,
            final_target=final_targets[base_part_id],
            assembled_objects=assembled_objects,
            retreat_offset=release_retreat_offset(_quat_rotate(assembly_orientation, [0.0, 0.0, -1.0])),
            park_offset=post_release_park_offset(base_robot),
            park_workspace_center=post_release_park_workspace_center(base_robot),
            park_minimum_planar_radius=post_release_park_minimum_planar_radius,
        )

    for step_index, step in enumerate(task['assembly_steps']):
        part_id = str(step['move_part'])
        object_name = f'fabrica_{assembly}_{part_id}'
        prefix = f'assemble_{step_index:02d}_part_{part_id}'
        path = list(reversed(step['disassembly_path']))
        if not path:
            raise ValueError(f'{assembly}: part {part_id} has an empty insertion path.')

        waypoint_names = []
        waypoint_positions: list[list[float]] = []
        waypoint_orientations: list[list[float]] = []
        for waypoint_index, waypoint in enumerate(path):
            position, orientation = _compose_pose(
                assembly_origin,
                assembly_orientation,
                _vector(waypoint['position'], size=3, name='insertion waypoint position'),
                _vector(waypoint['orientation'], size=4, name='insertion waypoint orientation'),
            )
            is_final_waypoint = waypoint_index == len(path) - 1
            if is_final_waypoint:
                waypoint_name = final_targets[part_id]
            else:
                waypoint_name = f'part_{part_id}_insert_{waypoint_index:02d}'
                targets.append(_target(waypoint_name, position, orientation))
                assembly_target_names.append(waypoint_name)
            waypoint_names.append(waypoint_name)
            waypoint_positions.append(position)
            waypoint_orientations.append(orientation)

        first_waypoint = next(target for target in targets if target['name'] == waypoint_names[0])
        hover_name = f'part_{part_id}_preinsert_hover'
        targets.append(
            _target(
                hover_name,
                _add(first_waypoint['position'], [0.0, 0.0, transport_hover_height]),
                first_waypoint['orientation'],
            )
        )
        assembly_target_names.append(hover_name)
        pickup_clearance, assembly_clearance = add_transport_clearance_targets(
            part_id=part_id,
            grasp=step['move_grasp'],
            destination_position=first_waypoint['position'],
            destination_orientation=first_waypoint['orientation'],
        )

        hold_id = str(step['optimizer_hold_part'])
        if official_hold and hold_id != current_hold_id:
            _append_release_and_retreat(
                phases,
                prefix=f'hold_{current_hold_id}_to_{hold_id}_switch',
                robot=base_robot,
                object_name=f'fabrica_{assembly}_{current_hold_id}',
                final_target=final_targets[current_hold_id],
                assembled_objects=list(assembled_objects),
                retreat_offset=release_retreat_offset([0.0, 0.0, 1.0]),
                park_offset=post_release_park_offset(base_robot),
                park_workspace_center=post_release_park_workspace_center(base_robot),
                park_minimum_planar_radius=post_release_park_minimum_planar_radius,
                include_park=False,
                include_retreat=False,
                static_release=True,
            # Official hold: open fingers to release the friction grasp only.
            # Seated parts stay by PhysX collision on the board/support — no pin.
            skip_lock=True,
            )
            hold_object_name = f'fabrica_{assembly}_{hold_id}'
            # No prepare_regrasp pin / collision-off. Hold regrasp keeps full PhysX
            # collision and tracks the live free object; fingers form a new
            # friction grasp (pure_physical_grasp, no weld / no finger filter).
            # Lift clear of the just-released hold before swinging to the next
            # hold grasp; otherwise IK branch-jump aborts the transfer.
            # v9: +0.22m from a long hold near the stack timed out (arm stretched
            # to ~z=1.79). Shorter lift + looser tol is enough to free fingers.
            phases.append(
                _skill_phase(
                    skill='retreat_vertical',
                    robot=base_robot,
                    phase_name=f'hold_{hold_id}_approach_clearance',
                    timeout_steps=1800,
                    parameters={
                        'relative_to_current_tcp': True,
                        'offset': [0.0, 0.0, 0.10],
                        'offset_frame': 'world',
                        'gripper_command': 'open',
                        'position_tolerance': 0.06,
                        'cartesian_position_step': 0.012,
                        'guard_ik_branch_jump': False,
                    },
                )
            )
            _append_pick_and_attach_phases(
                phases,
                prefix=f'hold_{hold_id}',
                robot=base_robot,
                object_name=hold_object_name,
                grasp=step['hold_grasp'],
                part=parts_by_id[hold_id],
                approach_height=max(float(approach_height), 0.16),
                move_above_timeout_steps=max(int(move_above_timeout_steps), 2400),
                move_above_orientation_first=True,
                move_above_orientation_first_steps=max(int(move_above_orientation_first_steps), 240),
                move_above_orientation_first_tolerance=move_above_orientation_first_tolerance,
                preshape_timeout_steps=preshape_timeout_steps,
                preshape_open_margin=max(float(preshape_open_margin), 0.28),
                preshape_gripper_position_tolerance=preshape_gripper_position_tolerance,
                descend_position_tolerance=max(float(descend_position_tolerance), 0.018),
                descend_relaxed_position_tolerance=max(float(descend_relaxed_position_tolerance), 0.03),
                descend_relaxed_after_steps=min(int(descend_relaxed_after_steps), 180),
                descend_timeout_steps=2400,
                descend_target_object_position_tolerance=0.03,
                prealign_steps=move_above_prealign_steps,
                prealign_joint_positions=prealign_joint_positions_by_robot.get(base_robot),
                prealign_shoulder_pan=prealign_shoulder_pan_by_robot.get(base_robot),
                fixture_release_after_steps=fixture_release_after_steps,
                fixture_lock_target=None,
                filter_gripper_collisions_on_attach=False,
                force_enable_collision_on_attach=True,
                attachment_mode=physical_grasp_mode,
                parts_start_unlocked=True,
                relax_ik_branch_jump=True,
                include_lift=False,
            )
            current_hold_id = hold_id
        support_phase_start = len(phases)
        if official_hold:
            # Left arm starts across the optical board from the pickup deck.
            # Orientation-first in place drove the wrist into the board (v59).
            # Climb first, then translate at height to the live part.
            phases.append(
                _skill_phase(
                    skill='retreat_vertical',
                    robot=assembly_robot,
                    phase_name=f'{prefix}_transit_clearance',
                    timeout_steps=1800,
                    parameters={
                        'relative_to_current_tcp': True,
                        'offset': [0.0, 0.0, 0.22],
                        'offset_frame': 'world',
                        'gripper_command': 'open',
                        'position_tolerance': 0.06,
                        'cartesian_position_step': 0.012,
                        'guard_ik_branch_jump': False,
                    },
                )
            )

        _append_pick_and_attach_phases(
            phases,
            prefix=prefix,
            robot=assembly_robot,
            object_name=object_name,
            grasp=step['move_grasp'],
            part=parts_by_id[part_id],
            approach_height=(
                max(float(approach_height), 0.22) if official_hold else approach_height
            ),
            move_above_timeout_steps=(
                max(int(move_above_timeout_steps), 3600) if official_hold else move_above_timeout_steps
            ),
            move_above_orientation_first=(
                False if official_hold else move_above_orientation_first
            ),
            move_above_orientation_first_steps=move_above_orientation_first_steps,
            move_above_orientation_first_tolerance=move_above_orientation_first_tolerance,
            preshape_timeout_steps=preshape_timeout_steps,
            preshape_open_margin=preshape_open_margin,
            preshape_gripper_position_tolerance=preshape_gripper_position_tolerance,
            descend_position_tolerance=descend_position_tolerance,
            descend_relaxed_position_tolerance=descend_relaxed_position_tolerance,
            descend_relaxed_after_steps=descend_relaxed_after_steps,
            descend_timeout_steps=2400 if official_hold else 900,
            descend_target_object_position_tolerance=0.03 if official_hold else 0.012,
            prealign_steps=move_above_prealign_steps,
            prealign_joint_positions=prealign_joint_positions_by_robot.get(assembly_robot),
            prealign_shoulder_pan=prealign_shoulder_pan_by_robot.get(assembly_robot),
            fixture_release_after_steps=fixture_release_after_steps,
            fixture_lock_target=None,
            filter_gripper_collisions_on_attach=False,
            force_enable_collision_on_attach=bool(official_hold),
            attachment_mode=physical_grasp_mode,
            parts_start_unlocked=bool(official_hold),
            relax_ik_branch_jump=bool(official_hold),
            # Beam uses the native gripper base as TCP. The legacy COM shortcut
            # puts that base only 12 mm above the part origin and discards the
            # finger reach; retain the authored grasp through approach/close.
            hover_above_object_com=bool(official_hold) and assembly != 'beam',
        )
        _append_transport_phase(
            phases,
            phase_name=f'{prefix}_pickup_clearance',
            robot=assembly_robot,
            object_name=object_name,
            target_name=pickup_clearance,
            insertion=False,
            timeout_steps=transport_timeout_steps,
            insertion_relaxed_position_tolerance=insertion_relaxed_position_tolerance,
            insertion_relaxed_after_steps=insertion_relaxed_after_steps,
            kinematic_carry=False,
        )
        _append_transport_phase(
            phases,
            phase_name=f'{prefix}_assembly_clearance',
            robot=assembly_robot,
            object_name=object_name,
            target_name=assembly_clearance,
            insertion=False,
            timeout_steps=transport_timeout_steps,
            insertion_relaxed_position_tolerance=insertion_relaxed_position_tolerance,
            insertion_relaxed_after_steps=insertion_relaxed_after_steps,
            kinematic_carry=False,
        )
        _append_transport_phase(
            phases,
            phase_name=f'{prefix}_transport_hover',
            robot=assembly_robot,
            object_name=object_name,
            target_name=hover_name,
            insertion=False,
            timeout_steps=transport_timeout_steps,
            strict_alignment=True,
            insertion_relaxed_position_tolerance=insertion_relaxed_position_tolerance,
            insertion_relaxed_after_steps=insertion_relaxed_after_steps,
            kinematic_carry=False,
        )
        for waypoint_index, waypoint_name in enumerate(waypoint_names):
            is_final_waypoint = waypoint_name == final_targets[part_id]
            is_entry_waypoint = waypoint_index == 0
            is_pre_final_waypoint = len(waypoint_names) > 1 and waypoint_index == len(waypoint_names) - 2
            if len(waypoint_positions) > 1:
                previous_index = max(waypoint_index - 1, 0)
                next_index = min(waypoint_index + 1, len(waypoint_positions) - 1)
                segment_start = waypoint_positions[previous_index]
                segment_end = waypoint_positions[next_index]
                insertion_axis = [segment_end[axis] - segment_start[axis] for axis in range(3)]
            else:
                insertion_axis = _quat_rotate(
                    assembly_orientation,
                    _vector(
                        step['move_grasp']['assembly_approach_direction'],
                        size=3,
                        name='assembly approach direction',
                    ),
                )
            normalized_insertion_axis = _normalized_direction(
                insertion_axis,
                name=f'{prefix}_insert_{waypoint_index:02d} insertion axis',
            )
            insertion_entry_delta = [
                waypoint_positions[waypoint_index][axis] - waypoint_positions[0][axis] for axis in range(3)
            ]
            part_bbox_size = _vector(
                parts_by_id[part_id]['bbox_size'],
                size=3,
                name=f'{assembly} part {part_id} bbox_size',
            )
            part_world_axes = [
                _quat_rotate(
                    waypoint_orientations[waypoint_index],
                    [1.0 if local_axis == axis else 0.0 for local_axis in range(3)],
                )
                for axis in range(3)
            ]
            projected_object_extent = sum(
                abs(
                    sum(
                        part_world_axes[axis][world_axis] * normalized_insertion_axis[world_axis]
                        for world_axis in range(3)
                    )
                )
                * part_bbox_size[axis]
                for axis in range(3)
            )
            minimum_lateral_extent = _projected_box_minimum_lateral_extent(
                bbox_size=part_bbox_size,
                orientation=waypoint_orientations[waypoint_index],
                axis=normalized_insertion_axis,
            )
            geometry_lateral_tolerance = min(
                intermediate_insertion_lateral_position_tolerance,
                max(
                    insertion_lateral_position_tolerance,
                    minimum_lateral_extent * insertion_lateral_tolerance_object_extent_scale,
                ),
            )
            gravity_axis_alignment = abs(normalized_insertion_axis[2])
            if gravity_axis_alignment < insertion_compliance_minimum_gravity_alignment:
                geometry_lateral_tolerance = intermediate_insertion_lateral_position_tolerance
            compliance_waypoint_axial_tolerance = min(
                insertion_relaxed_position_tolerance,
                0.010,
            )
            compliance_waypoint_lateral_tolerance = intermediate_insertion_lateral_position_tolerance
            insertion_path_depth = max(
                sum(insertion_entry_delta[axis] * normalized_insertion_axis[axis] for axis in range(3)),
                0.0,
            )
            lateral_alignment_axial_clearance = insertion_path_depth + max(
                insertion_lateral_alignment_entry_clearance,
                projected_object_extent * insertion_lateral_alignment_clearance_object_extent_scale,
            )
            compliance_position_tolerance = max(
                0.015,
                min(0.020, 0.6 * min(part_bbox_size)),
            )
            if not is_final_waypoint:
                compliance_position_tolerance += math.dist(
                    waypoint_positions[waypoint_index],
                    waypoint_positions[-1],
                )
            _append_transport_phase(
                phases,
                phase_name=f'{prefix}_insert_{waypoint_index:02d}',
                robot=assembly_robot,
                object_name=object_name,
                target_name=waypoint_name,
                insertion=True,
                timeout_steps=insertion_timeout_steps,
                insertion_relaxed_position_tolerance=(
                    min(insertion_relaxed_position_tolerance, 0.015)
                    if is_final_waypoint
                    else min(insertion_relaxed_position_tolerance, 0.010)
                ),
                insertion_relaxed_after_steps=insertion_relaxed_after_steps,
                insertion_axis=insertion_axis,
                insertion_lateral_position_tolerance=(
                    geometry_lateral_tolerance
                    if is_entry_waypoint or is_pre_final_waypoint or is_final_waypoint
                    else intermediate_insertion_lateral_position_tolerance
                ),
                insertion_cartesian_position_step=(insertion_cartesian_position_step),
                insertion_lateral_alignment_cartesian_position_step=(
                    insertion_lateral_alignment_cartesian_position_step
                    if is_final_waypoint
                    else intermediate_insertion_lateral_alignment_cartesian_position_step
                ),
                insertion_lateral_alignment_exit_tolerance=(
                    intermediate_insertion_lateral_position_tolerance if is_pre_final_waypoint else None
                ),
                insertion_lateral_alignment_axial_clearance=(lateral_alignment_axial_clearance),
                insertion_path_depth=(
                    insertion_path_depth
                    if gravity_axis_alignment < insertion_compliance_minimum_gravity_alignment
                    else 0.0
                ),
                insertion_axial_recovery_cartesian_position_step=(insertion_axial_recovery_cartesian_position_step),
                insertion_axial_recovery_deadband=insertion_axial_recovery_deadband,
                insertion_compliance_capture_max_linear_speed=(insertion_compliance_capture_max_linear_speed),
                insertion_compliance_capture_max_angular_speed=(insertion_compliance_capture_max_angular_speed),
                insertion_compliance_capture_stable_steps=(insertion_compliance_capture_stable_steps),
                insertion_compliance_position_tolerance=(compliance_position_tolerance),
                insertion_compliance_after_steps=(0),
                insertion_compliance_require_waypoint_proximity=True,
                insertion_compliance_waypoint_position_tolerance=(min(insertion_relaxed_position_tolerance, 0.010)),
                insertion_compliance_waypoint_axial_position_tolerance=(compliance_waypoint_axial_tolerance),
                insertion_compliance_waypoint_lateral_position_tolerance=(compliance_waypoint_lateral_tolerance),
                insertion_compliance_geometric_capture_after_steps=(insertion_compliance_geometric_capture_after_steps),
                insertion_compliance_minimum_gravity_alignment=(insertion_compliance_minimum_gravity_alignment),
                insertion_compliant_alignment_retraction_limit=(insertion_compliant_alignment_retraction_limit),
                insertion_compliant_track_object_orientation=(insertion_compliant_track_object_orientation),
                target_object_entry_capture_max_steps=(
                    max(4, insertion_compliance_capture_stable_steps + 4) if is_final_waypoint else 0
                ),
                final_target_name=(final_targets[part_id]),
                settle_at_target=is_final_waypoint,
                kinematic_carry=False,
            )
        assembled_objects.append(object_name)
        # While the other arm is still holding, a 6 cm retreat leaves the
        # forearm in the shared workspace. Lift clear before the lateral park.
        assembly_retreat_offset = (
            [0.0, 0.0, 0.28] if official_hold else release_retreat_offset(insertion_axis)
        )
        if official_hold:
            _append_kinematic_to_friction_handoff(
                phases,
                prefix=prefix,
                robot=assembly_robot,
                object_name=object_name,
            )
        _append_release_and_retreat(
            phases,
            prefix=prefix,
            robot=assembly_robot,
            object_name=object_name,
            final_target=final_targets[part_id],
            assembled_objects=assembled_objects,
            retreat_offset=assembly_retreat_offset,
            park_offset=post_release_park_offset(assembly_robot),
            park_workspace_center=post_release_park_workspace_center(assembly_robot),
            park_minimum_planar_radius=post_release_park_minimum_planar_radius,
            disable_collision_on_lock=not official_hold,
            pin_pose=True,
            freeze_current_pose=not official_hold,
            static_release=True,
            detach_on_lock=bool(official_hold),
            teleport_to_target_once=bool(official_hold),
            # Official hold: no post-insert pin/teleport — stay seated by physics.
            skip_lock=bool(official_hold),
        )
        if official_hold:
            hold_object_name = f'fabrica_{assembly}_{current_hold_id}'
            hold_target_name = final_targets[current_hold_id]
            for support_phase in phases[support_phase_start:]:
                _install_hold_companion(
                    support_phase,
                    robot=base_robot,
                    object_name=hold_object_name,
                    target_name=hold_target_name,
                )

    if official_hold:
        _append_release_and_retreat(
            phases,
            prefix=f'hold_{current_hold_id}_final',
            robot=base_robot,
            object_name=f'fabrica_{assembly}_{current_hold_id}',
            final_target=final_targets[current_hold_id],
            assembled_objects=list(assembled_objects),
            retreat_offset=release_retreat_offset([0.0, 0.0, 1.0]),
            park_offset=post_release_park_offset(base_robot),
            park_workspace_center=post_release_park_workspace_center(base_robot),
            park_minimum_planar_radius=post_release_park_minimum_planar_radius,
            static_release=True,
            skip_lock=True,
        )
        place_phase = next(phase for phase in phases if phase.get('name') == f'base_{base_part_id}_place')
        place_phase['rebase_from_object'] = {
            'object': base_object,
            'anchor_target': final_targets[base_part_id],
            'targets': list(dict.fromkeys(assembly_target_names)),
            # Place can finish under the relaxed insertion tolerance (~4 cm).
            # Keep rebase loose enough to enable collision while the weld still holds.
            'position_tolerance': 0.05,
            'orientation_tolerance': 0.2,
            'enable_collision': True,
            'filter_gripper_collision': True,
            'preserve_z': True,
        }
    else:
        base_release_phase = next(
            phase for phase in phases if phase.get('name') == f'base_{base_part_id}_release_and_lock'
        )
        base_release_phase['lock'][0]['rebase_targets'] = list(dict.fromkeys(assembly_target_names))

    stabilize_fixture_parts = bool(spec.get('stabilize_fixture_parts', True))
    if stabilize_fixture_parts and not official_hold:
        phases[0]['lock'] = [
            {
                'object': f'fabrica_{assembly}_{part_id}',
                'target': fixture_pickup_targets[part_id],
                'position_tolerance': 0.03,
                'orientation_tolerance': 0.20,
                'snap_free_object': True,
                'free_snap_steps': 0,
                'disable_collision_on_lock': True,
            }
            for part_id in parts_by_id
        ]
    elif official_hold:
        # Start fully unlocked: every part rests in its fixture nest under
        # gravity; the nest walls keep the tall parts upright. Pose pins were
        # the root of the unlock/eject/freefall loop.
        part_names = [f'fabrica_{assembly}_{part_id}' for part_id in parts_by_id]
        settle_phase = {
            'name': 'fixture_parts_settle',
            'timeout_steps': 720,
            'robot_targets': {},
            'object_collisions': (
                [{'object': name, 'enabled': True} for name in part_names]
                + [
                    {'object': 'fabrica_fixture', 'enabled': True},
                    {'object': 'fixture_support', 'enabled': True},
                    {'object': 'factory_tabletop_visual', 'enabled': True},
                ]
            ),
            'advance': {
                'type': 'objects_static',
                'objects': list(part_names),
                'min_steps': 96,
                'linear_velocity_threshold': 0.04,
                'angular_velocity_threshold': 1.5,
            },
        }
        phases.insert(0, settle_phase)

    for part_id in parts_by_id:
        success.append(
            {
                'object': f'fabrica_{assembly}_{part_id}',
                'target': final_targets[part_id],
                'position_tolerance': 0.015,
                'orientation_tolerance': 0.15,
                'require_released': True,
                'require_static': True,
                'linear_velocity_threshold': 0.05,
                'angular_velocity_threshold': 2.0,
            }
        )
    return targets, phases, success, pickup_target_names, assembly_target_names


def _default_domain_randomization(
    *,
    spec: dict[str, Any],
    assembly: str,
    part_names: list[str],
    pickup_target_names: list[str],
    assembly_target_names: list[str],
    translation_constraints: dict[str, list[dict[str, Any]]],
    include_fixture_support: bool = False,
) -> dict[str, Any]:
    pickup_range = spec.get(
        'pickup_translation_range',
        {'x': [-0.03, 0.03], 'y': [-0.03, 0.03], 'z': [0.0, 0.0]},
    )
    assembly_range = spec.get(
        'assembly_translation_range',
        {'x': [-0.03, 0.03], 'y': [-0.03, 0.03], 'z': [0.0, 0.0]},
    )
    pickup_minimum_planar_distance = float(spec.get('pickup_translation_minimum_planar_distance', 0.0))
    pickup_maximum_planar_distance = float(spec.get('pickup_translation_maximum_planar_distance', math.inf))
    assembly_minimum_planar_distance = float(spec.get('assembly_translation_minimum_planar_distance', 0.0))
    assembly_maximum_planar_distance = float(spec.get('assembly_translation_maximum_planar_distance', math.inf))
    start_objects = ['fabrica_fixture', *part_names]
    if include_fixture_support:
        # Deck must translate with the nest so unlocked parts do not fall off.
        start_objects = ['fabrica_fixture', 'fixture_support', *part_names]
    return {
        'enabled': False,
        'seed_namespace': f'fabrica_{assembly}_canonical_ur5e_domain_v1',
        'fixed_objects': ['optical_board'],
        'groups': {
            'start_parts': {
                'translation': copy.deepcopy(pickup_range),
                **(
                    {'minimum_planar_distance': pickup_minimum_planar_distance}
                    if pickup_minimum_planar_distance > 0.0
                    else {}
                ),
                **(
                    {'maximum_planar_distance': pickup_maximum_planar_distance}
                    if math.isfinite(pickup_maximum_planar_distance)
                    else {}
                ),
                'translation_constraints': copy.deepcopy(translation_constraints.get('start_parts', [])),
                'objects': start_objects,
                'targets': copy.deepcopy(pickup_target_names),
            },
            'assembly_base': {
                'translation': copy.deepcopy(assembly_range),
                **(
                    {'minimum_planar_distance': assembly_minimum_planar_distance}
                    if assembly_minimum_planar_distance > 0.0
                    else {}
                ),
                **(
                    {'maximum_planar_distance': assembly_maximum_planar_distance}
                    if math.isfinite(assembly_maximum_planar_distance)
                    else {}
                ),
                'translation_constraints': copy.deepcopy(translation_constraints.get('assembly_base', [])),
                'objects': [],
                'targets': copy.deepcopy(assembly_target_names),
            },
        },
        'appearance': {
            'groups': {
                'table_surface': {
                    'objects': ['factory_tabletop_visual'],
                    'palette': [
                        [0.14, 0.14, 0.14],
                        [0.28, 0.31, 0.32],
                        [0.22, 0.30, 0.25],
                        [0.33, 0.24, 0.25],
                        [0.25, 0.27, 0.36],
                        [0.40, 0.36, 0.25],
                    ],
                },
                'background': {
                    'objects': [],
                    'lights': ['warehouse_dome_fill'],
                    'palette': [
                        [0.78, 0.84, 1.0],
                        [0.92, 0.82, 0.72],
                        [0.72, 0.88, 0.80],
                        [0.86, 0.76, 0.82],
                        [0.72, 0.82, 0.88],
                        [0.88, 0.88, 0.76],
                    ],
                },
            }
        },
    }


def _bbox_corners(
    *,
    position: list[float],
    orientation: list[float],
    bbox_min: list[float],
    bbox_max: list[float],
) -> list[list[float]]:
    return [
        _add(position, _quat_rotate(orientation, [x, y, z]))
        for x in (bbox_min[0], bbox_max[0])
        for y in (bbox_min[1], bbox_max[1])
        for z in (bbox_min[2], bbox_max[2])
    ]


def _tcp_position_for_object_pose(
    *,
    object_position: list[float],
    object_orientation: list[float],
    grasp: dict[str, Any],
) -> list[float]:
    tcp_position, _ = _tcp_pose_for_object_pose(
        object_position=object_position,
        object_orientation=object_orientation,
        grasp=grasp,
    )
    return tcp_position


def _canonical_translation_constraints(
    *,
    assembly: str,
    task: dict[str, Any],
    spec: dict[str, Any],
    generated_objects: list[dict[str, Any]],
    targets: list[dict[str, Any]],
    pickup_target_names: list[str],
    assembly_target_names: list[str],
    workspace_offset: list[float],
    robots: list[dict[str, Any]],
) -> dict[str, list[dict[str, Any]]]:
    objects_by_name = {str(entry['name']): entry for entry in generated_objects}
    targets_by_name = {str(entry['name']): entry for entry in targets}
    board = objects_by_name['optical_board']
    fixture = objects_by_name['fabrica_fixture']
    board_lower = _add(
        board['position'],
        _vector(task['optical_board']['bbox_min'], size=3, name='board bbox_min'),
    )
    board_upper = _add(
        board['position'],
        _vector(task['optical_board']['bbox_max'], size=3, name='board bbox_max'),
    )
    constraints: dict[str, list[dict[str, Any]]] = {
        'start_parts': [
            {
                'type': 'points_inside_bounds',
                'points': _bbox_corners(
                    position=fixture['position'],
                    orientation=fixture['orientation'],
                    bbox_min=_vector(
                        task['fixture']['bbox_min'],
                        size=3,
                        name='fixture bbox_min',
                    ),
                    bbox_max=_vector(
                        task['fixture']['bbox_max'],
                        size=3,
                        name='fixture bbox_max',
                    ),
                ),
                'lower': board_lower,
                'upper': board_upper,
                'axes': [0, 1],
            }
        ],
        'assembly_base': [],
    }

    final_assembly_corners = []
    for part in task['parts']:
        part_id = str(part['part_id'])
        final_target = targets_by_name[f'part_{part_id}_assembled']
        final_assembly_corners.extend(
            _bbox_corners(
                position=final_target['position'],
                orientation=final_target['orientation'],
                bbox_min=_vector(part['bbox_min'], size=3, name=f'{assembly} part {part_id} bbox_min'),
                bbox_max=_vector(part['bbox_max'], size=3, name=f'{assembly} part {part_id} bbox_max'),
            )
        )
    constraints['assembly_base'].append(
        {
            'type': 'points_inside_bounds',
            'points': final_assembly_corners,
            'lower': board_lower,
            'upper': board_upper,
            'axes': [0, 1],
        }
    )

    base_part = str(task['base_part'])
    grasp_by_part = {
        base_part: task['base_grasp'],
        **{str(step['move_part']): step['move_grasp'] for step in task['assembly_steps']},
    }
    robot_name_by_part = {
        part_id: str(
            spec.get('base_robot', 'franka_right')
            if part_id == base_part
            else spec.get('assembly_robot', 'franka_left')
        )
        for part_id in grasp_by_part
    }
    robots_by_name = {
        str(robot['name']): robot for robot in robots if isinstance(robot, dict) and robot.get('name') is not None
    }
    maximum_reach = float(spec.get('pickup_tcp_maximum_reach', 0.82))

    for group_name, target_names in (
        ('start_parts', pickup_target_names),
        ('assembly_base', assembly_target_names),
    ):
        tcp_points_by_robot: dict[str, list[list[float]]] = {}
        for target_name in target_names:
            tokens = str(target_name).split('_', 2)
            if len(tokens) < 3 or tokens[0] != 'part' or tokens[1] not in grasp_by_part:
                continue
            part_id = tokens[1]
            target = targets_by_name[str(target_name)]
            tcp_position = _tcp_position_for_object_pose(
                object_position=target['position'],
                object_orientation=target['orientation'],
                grasp=grasp_by_part[part_id],
            )
            tcp_points_by_robot.setdefault(robot_name_by_part[part_id], []).append(_add(tcp_position, workspace_offset))

        if group_name == 'start_parts':
            for part_id, grasp in grasp_by_part.items():
                part_object = objects_by_name[f'fabrica_{assembly}_{part_id}']
                tcp_position = _tcp_position_for_object_pose(
                    object_position=part_object['position'],
                    object_orientation=part_object['orientation'],
                    grasp=grasp,
                )
                tcp_points_by_robot.setdefault(robot_name_by_part[part_id], []).append(
                    _add(_add(tcp_position, [0.0, 0.0, 0.10]), workspace_offset)
                )

        for robot_name, points in tcp_points_by_robot.items():
            robot = robots_by_name.get(robot_name)
            if robot is None:
                raise ValueError(f'Domain randomization references missing robot {robot_name!r}.')
            robot_position = _vector(
                robot.get('position', [0.0, 0.0, 0.0]),
                size=3,
                name=f'{robot_name} position',
            )
            if bool(robot.get('apply_workspace_offset', True)):
                robot_position = _add(robot_position, workspace_offset)
            constraints[group_name].append(
                {
                    'type': 'points_within_distance',
                    'points': points,
                    'origin': robot_position,
                    'maximum_distance': maximum_reach,
                }
            )
    return constraints


# v232 (round 55): column 3 + cap 1 stand unheld from the hold-3 release until
# the hold-2 final release. Round 54 lost that stack 15.9k steps into the window
# (spontaneous rocking of cap 1, column-3 yaw 0.0501 > 0.05 rad) with no arm,
# part or held object within 65 mm. Shorten only part-0 free-space motion in
# that window; targets, paths, contact steps, gates and thresholds are unchanged.
_PART0_WINDOW_DESCEND = 'assemble_03_part_0_descend'
_PART0_WINDOW_CARRIES = ('assemble_03_part_0_pickup_clearance', 'assemble_03_part_0_assembly_clearance')
_PART0_WINDOW_INSERT = 'assemble_03_part_0_insert_00'


def _apply_part0_window_speedup(phases: list[dict[str, Any]]) -> None:
    flag = os.environ.get('BEAM_PART0_WINDOW_SPEEDUP', '0')
    if flag not in {'0', '1'}:
        raise ValueError('BEAM_PART0_WINDOW_SPEEDUP must be 0 or 1')
    if flag == '0':
        return
    by_name = {phase['name']: phase for phase in phases}
    names = (_PART0_WINDOW_DESCEND, *_PART0_WINDOW_CARRIES, _PART0_WINDOW_INSERT)
    missing = [name for name in names if name not in by_name]
    if missing:
        raise ValueError('Part-0 window speedup phases missing: ' + repr(missing))
    descend = by_name[_PART0_WINDOW_DESCEND]['local_skill']
    if (descend.get('name') != 'ur5e_descend_to_grasp' or descend.get('requires_held_object')
            or descend.get('cartesian_position_step') != 0.001
            or descend.get('max_command_joint_step') != 0.004
            or descend.get('relaxed_position_tolerance_after_steps') != 600):
        raise ValueError('Part-0 staged descent requires the original unloaded 1 mm descent')
    # Free space: 3 mm Cartesian lead (joint lead ~0.011 rad < 0.012 cap).
    # Last 50 mm to the grasp target keep the original 1 mm lead, so the phase
    # still ends at the 18 mm relaxed tolerance at the original approach speed.
    descend.update(beam_staged_far_position_step=0.003, beam_staged_slow_distance=0.05,
                   max_command_joint_step=0.012, max_joint_step=0.012)
    for name in _PART0_WINDOW_CARRIES:
        skill = by_name[name]['local_skill']
        if not (skill.get('requires_held_object') and skill.get('grasp_drive_smooth_transport')
                and skill.get('grasp_drive_linear_speed') == 0.04
                and skill.get('grasp_drive_position_lookahead') == 0.002):
            raise ValueError('Part-0 carry speedup requires the original smooth loaded drive: ' + name)
        # Scale speed and tracking lookahead together (same slowdown fractions,
        # joint speed/acceleration limits and all grasp/force gates unchanged).
        skill.update(grasp_drive_linear_speed=0.10, grasp_drive_position_lookahead=0.005,
                     grasp_drive_angular_speed=0.50, grasp_drive_orientation_lookahead=0.05)
    insert = by_name[_PART0_WINDOW_INSERT]['local_skill']
    if not (insert.get('servo_target_object_pose') and insert.get('target_object_target') == 'part_0_insert_00'
            and insert.get('target_object_servo_position_command_accumulation_step') == 0.0001
            and insert.get('cartesian_position_step') == 0.00025):
        raise ValueError('Part-0 insert_00 staging requires the original object servo')
    # Only while cap 0 is >45 mm from the insert_00 waypoint (>65 mm above its
    # seat); the final 45 mm and all later insert stages are unchanged.
    insert.update(beam_staged_far_accumulation_step=0.00025, beam_staged_slow_object_distance=0.045)


# Round 56 (v233, 2026-11-19 human instruction "改门，并提速"): extend the
# round-55 part-0 motion profile, which held every grasp, force and contact
# gate, to the other parts. Only free-space portions change: the last 50 mm of
# every descend and the last 45 mm before each insert_00 waypoint keep the
# original leads; hovers, lifts, peels, seats, releases and all gates stay.
_FAST_DESCENDS = ('assemble_00_part_3_descend', 'assemble_01_part_2_descend', 'assemble_02_part_1_descend',
                  'handover_left_2_descend', 'hold_3_descend', 'hold_2_descend')
# Loaded carries: (angular speed, orientation lookahead) or None to keep the
# original rotation limit. These carries turn the part by 1.6-3.1 rad, so the
# 0.2 rad/s limit dominates; column 3 keeps its validated <= 0.20 rad/s turn.
# Round 57 (v234): base 6 is not sped up. In round 56 its 0.4 rad/s carry left
# the grip-force regulation at 10.9 N (round 55: 9.6/9.8 N); the clamped base
# then read 0.45-0.9 rad/s of contact jitter and the seating controller's raw
# 0.5 rad/s motion gate never let it load (base_6_set_down timeout). Later
# column/cap gates use 2.0-6.0 rad/s raw limits.
_FAST_CARRIES = {
    'assemble_00_part_3_pickup_clearance': None,
    'assemble_00_part_3_assembly_clearance': None,
    'assemble_01_part_2_pickup_clearance': (0.40, 0.04),
    'assemble_01_part_2_assembly_clearance': (0.40, 0.04),
    'assemble_02_part_1_pickup_clearance': (0.40, 0.04),
    'assemble_02_part_1_assembly_clearance': (0.40, 0.04),
}
_FAST_INSERTS = {'assemble_00_part_3_insert_00': 'part_3_insert_00',
                 'assemble_01_part_2_insert_00': 'part_2_insert_00',
                 'assemble_02_part_1_insert_00': 'part_1_insert_00'}


def _apply_fast_motion(phases: list[dict[str, Any]]) -> None:
    flag = os.environ.get('BEAM_FAST_MOTION', '0')
    if flag not in {'0', '1'}:
        raise ValueError('BEAM_FAST_MOTION must be 0 or 1')
    if flag == '0':
        return
    if os.environ.get('BEAM_PART0_WINDOW_SPEEDUP') != '1':
        raise ValueError('BEAM_FAST_MOTION extends the round-55 part-0 profile and requires it')
    by_name = {phase['name']: phase for phase in phases}
    missing = [n for n in (*_FAST_DESCENDS, *_FAST_CARRIES, *_FAST_INSERTS) if n not in by_name]
    if missing:
        raise ValueError('Fast-motion phases missing: ' + repr(missing))
    for name in _FAST_DESCENDS:
        skill = by_name[name]['local_skill']
        if (skill.get('name') != 'ur5e_descend_to_grasp' or skill.get('requires_held_object')
                or skill.get('cartesian_position_step') != 0.001
                or skill.get('max_command_joint_step') != 0.004 or skill.get('max_joint_step') != 0.004
                or skill.get('relaxed_position_tolerance_after_steps') not in (180, 600)
                or 'beam_staged_far_position_step' in skill):
            raise ValueError('Fast descent requires the original unloaded 1 mm descent: ' + name)
        skill.update(beam_staged_far_position_step=0.003, beam_staged_slow_distance=0.05,
                     max_command_joint_step=0.012, max_joint_step=0.012)
    for name, rotation in _FAST_CARRIES.items():
        skill = by_name[name]['local_skill']
        if not (skill.get('requires_held_object') and skill.get('grasp_drive_smooth_transport')
                and skill.get('grasp_drive_linear_speed') == 0.04
                and skill.get('grasp_drive_position_lookahead') == 0.002
                and skill.get('grasp_drive_angular_speed') == 0.2
                and skill.get('grasp_drive_orientation_lookahead') == 0.02):
            raise ValueError('Fast carry requires the original smooth loaded drive: ' + name)
        skill.update(grasp_drive_linear_speed=0.10, grasp_drive_position_lookahead=0.005)
        if rotation is not None:
            skill.update(grasp_drive_angular_speed=rotation[0], grasp_drive_orientation_lookahead=rotation[1])
    for name, target in _FAST_INSERTS.items():
        skill = by_name[name]['local_skill']
        if not (skill.get('servo_target_object_pose') and skill.get('target_object_target') == target
                and skill.get('target_object_servo_position_command_accumulation_step') == 0.0001
                and skill.get('cartesian_position_step') == 0.00025
                and 'beam_staged_far_accumulation_step' not in skill):
            raise ValueError('Fast insert_00 requires the original object servo: ' + name)
        skill.update(beam_staged_far_accumulation_step=0.00025, beam_staged_slow_object_distance=0.045)


# Round 56 (human-approved 2026-11-19): the final support gate keeps 9.81 N but
# measures the load of every installed part on the support objects. Columns 3
# and 2 stand on assembly_support through the base, so base 6 alone carries
# ~3.3 N of the 12.26 N assembly weight. Base 6 keeps its own seat-time
# minimum of 1.962 N; gap, pose window and all other final conditions stay.
_FINAL_ASSEMBLY_LOAD_OBJECTS = ['fabrica_beam_6', 'fabrica_beam_3', 'fabrica_beam_2',
                                'fabrica_beam_1', 'fabrica_beam_0']


def _apply_final_assembly_load(phases: list[dict[str, Any]]) -> None:
    flag = os.environ.get('BEAM_FINAL_ASSEMBLY_LOAD', '0')
    if flag not in {'0', '1'}:
        raise ValueError('BEAM_FINAL_ASSEMBLY_LOAD must be 0 or 1')
    if flag == '0':
        return
    final = phases[-1]
    if final.get('name') != 'beam_final_unloaded_verification' or final.get('beam_final_pose_acceptance') is not True:
        raise ValueError('Final assembly load requires the final pose-window acceptance')
    conditions = [c for c in final['advance']['conditions'] if c.get('type') == 'beam_table_supported']
    if len(conditions) != 1:
        raise ValueError('Final verification must have exactly one table-support condition')
    condition = conditions[0]
    if not (condition.get('verification_mode') == 'unloaded'
            and condition.get('unloaded_pose_window_acceptance') is True
            and condition.get('minimum_vertical_force') == 9.81
            and 'assembly_load_objects' not in condition):
        raise ValueError('Final assembly load requires the original 9.81 N unloaded support condition')
    condition.update(minimum_vertical_force=1.962, legacy_minimum_vertical_force=9.81,
                     assembly_load_objects=list(_FINAL_ASSEMBLY_LOAD_OBJECTS),
                     minimum_assembly_vertical_force=9.81)


# Round 57: after the left fingers open, part 0 rocks on the stack (about
# +-0.5 mm, 1-3 rad/s) for as long as the open gripper stays over it; the
# rocking stopped 182 steps into the vertical retreat in round 55 and never
# with the arm held (1,920 steps in round 57). The release gate therefore keeps
# only part 0 on its target, and the unchanged five-part fixed-reference pose
# window (0.5 mm / 0.0087 rad, 30 physical steps) qualifies in the retreat that
# follows, together with the retreat skill completion.
_PART0_RELEASE = 'assemble_03_part_0_release'
_PART0_RETREAT = 'assemble_03_part_0_retreat'


def _apply_part0_release_after_clear(phases: list[dict[str, Any]]) -> None:
    flag = os.environ.get('BEAM_PART0_RELEASE_AFTER_CLEAR', '0')
    if flag not in {'0', '1'}:
        raise ValueError('BEAM_PART0_RELEASE_AFTER_CLEAR must be 0 or 1')
    if flag == '0':
        return
    names = [phase.get('name') for phase in phases]
    if names.count(_PART0_RELEASE) != 1 or names.count(_PART0_RETREAT) != 1:
        raise ValueError('Part-0 release/retreat phases must exist exactly once')
    index = names.index(_PART0_RELEASE)
    if names[index + 1] != _PART0_RETREAT:
        raise ValueError('Part-0 retreat must directly follow the part-0 release')
    release, retreat = phases[index], phases[index + 1]
    advance = release['advance']
    conditions = advance.get('conditions') or []
    stable = [c for c in conditions if c.get('type') == 'beam_staged_objects_stable']
    target = [c for c in conditions if c.get('type') == 'object_targets_reached']
    if not (advance.get('type') == 'all_of' and advance.get('physics_stable_steps') == 30
            and len(conditions) == 2 and len(stable) == 1 and len(target) == 1
            and stable[0].get('common_pose_window') is True
            and stable[0].get('objects') == ['fabrica_beam_6', 'fabrica_beam_3', 'fabrica_beam_2',
                                             'fabrica_beam_1', 'fabrica_beam_0']):
        raise ValueError('Part-0 release must hold the five-part pose window and the part-0 target')
    skill = retreat.get('advance') or {}
    if not (skill.get('type') == 'local_skill_complete' and skill.get('robot') == 'franka_left'
            and skill.get('skill') == 'ur5e_retreat_vertical' and retreat.get('timeout_steps') == 1200
            and (retreat.get('local_skill') or {}).get('gripper_command') == 'open'):
        raise ValueError('Part-0 retreat must be the open-gripper vertical retreat')
    advance['conditions'] = [copy.deepcopy(target[0])]
    retreat['advance'] = {'type': 'all_of', 'min_steps': int(skill.get('min_steps', 1)),
                          'conditions': [copy.deepcopy(skill), copy.deepcopy(stable[0])],
                          'physics_stable_steps': 30}
    retreat['timeout_steps'] = 2400


# Round 58 (v235): part 0 kept rocking on column 2 after both the left arm
# (retreat, park) and the right fingers (final release) had left it; the
# five-part 0.5 mm / 0.0087 rad window kept resetting, while the final
# verification's own window (2 mm / 0.03 rad, 240 steps) replayed on the same
# samples never reset. By human instruction (2026-11-19, "如果不管这些稳定门测验，
# 直接退开手"), the two intermediate five-part windows after part 0 is placed are
# dropped: the part-0 retreat advances on its skill completion (as before
# v235), and the final release of column 2 keeps only its part-2 target check.
# The final unloaded verification is unchanged and still owns stability.
_FINAL_HOLD_RELEASE = 'hold_2_final_release'


def _apply_release_without_stack_window(phases: list[dict[str, Any]]) -> None:
    flag = os.environ.get('BEAM_RELEASE_WITHOUT_STACK_WINDOW', '0')
    if flag not in {'0', '1'}:
        raise ValueError('BEAM_RELEASE_WITHOUT_STACK_WINDOW must be 0 or 1')
    if flag == '0':
        return
    if os.environ.get('BEAM_PART0_RELEASE_AFTER_CLEAR', '0') != '1':
        raise ValueError('BEAM_RELEASE_WITHOUT_STACK_WINDOW requires BEAM_PART0_RELEASE_AFTER_CLEAR=1')
    names = [phase.get('name') for phase in phases]
    if names.count(_PART0_RETREAT) != 1 or names.count(_FINAL_HOLD_RELEASE) != 1:
        raise ValueError('Part-0 retreat and final hold release must exist exactly once')
    retreat = phases[names.index(_PART0_RETREAT)]
    advance = retreat.get('advance') or {}
    conditions = advance.get('conditions') or []
    if not (advance.get('type') == 'all_of' and len(conditions) == 2
            and conditions[0].get('type') == 'local_skill_complete'
            and conditions[0].get('skill') == 'ur5e_retreat_vertical'
            and conditions[1].get('type') == 'beam_staged_objects_stable'
            and retreat.get('timeout_steps') == 2400):
        raise ValueError('Part-0 retreat must carry the v235 skill plus five-part window')
    retreat['advance'] = copy.deepcopy(conditions[0])
    retreat['timeout_steps'] = 1200
    final = phases[names.index(_FINAL_HOLD_RELEASE)]
    advance = final.get('advance') or {}
    conditions = advance.get('conditions') or []
    stable = [c for c in conditions if c.get('type') == 'beam_staged_objects_stable']
    target = [c for c in conditions if c.get('type') == 'object_targets_reached']
    if not (advance.get('type') == 'all_of' and advance.get('physics_stable_steps') == 30
            and len(conditions) == 2 and len(stable) == 1 and len(target) == 1
            and stable[0].get('common_pose_window') is True
            and [o.get('object') for o in target[0].get('objects', [])] == ['fabrica_beam_2']):
        raise ValueError('Final hold release must hold the five-part window and the part-2 target')
    advance['conditions'] = [copy.deepcopy(target[0])]


# Round 60 (human instruction 2026-11-20 "交接后微抬 1 mm"): in round 55 the
# left hand's handover grasp left column 2 hanging (0 N on the base) and the
# right hand then held it suspended; in rounds 57-59 the same grasp left it
# pressed on the base (1.8-3.1 N), the right hand caught it there with 5 N
# instead of 8 N, and part 0 was later jammed onto the over-constrained column.
# A new phase right after the handover grasp lifts the held column 1 mm with
# the left hand (the loaded vertical servo used by grip_contact_prime/peel_lift),
# so the right hand always grasps a suspended column. All gates stay.
_HANDOVER_CLOSE = 'handover_left_2_close_and_attach'
_HANDOVER_SWITCH = 'hold_3_to_2_switch_release'
_HANDOVER_LIFT = 'handover_left_2_unload_lift'
_HANDOVER_LIFT_TEMPLATE = 'assemble_01_part_2_grip_contact_prime'
_HANDOVER_LIFT_M = 0.001


def _apply_handover_unload_lift(phases: list[dict[str, Any]]) -> None:
    flag = os.environ.get('BEAM_HANDOVER_UNLOAD_LIFT', '0')
    if flag not in {'0', '1'}:
        raise ValueError('BEAM_HANDOVER_UNLOAD_LIFT must be 0 or 1')
    if flag == '0':
        return
    names = [phase.get('name') for phase in phases]
    if _HANDOVER_LIFT in names:
        raise ValueError('Handover unload lift already present')
    if names.count(_HANDOVER_CLOSE) != 1 or names.count(_HANDOVER_LIFT_TEMPLATE) != 1:
        raise ValueError('Handover close and lift template must exist exactly once')
    index = names.index(_HANDOVER_CLOSE)
    if index + 1 >= len(names) or names[index + 1] != _HANDOVER_SWITCH:
        raise ValueError('The column-3 switch release must directly follow the handover grasp')
    close = phases[index]
    skill = close.get('local_skill') or {}
    attach = close.get('attach') or []
    right = (close.get('local_skills') or {}).get('franka_right') or {}
    if not (skill.get('name') == 'ur5e_close_gripper' and skill.get('robot') == 'franka_left'
            and skill.get('object') == 'fabrica_beam_2' and len(attach) == 1
            and attach[0].get('object') == 'fabrica_beam_2' and attach[0].get('robot') == 'franka_left'
            and attach[0].get('attachment_mode') == 'pure_physical_grasp'
            and right.get('name') == 'ur5e_hold_part_end' and right.get('object') == 'fabrica_beam_3'):
        raise ValueError('Handover grasp must be the left physical grasp of column 2 with column 3 held right')
    template = copy.deepcopy(phases[names.index(_HANDOVER_LIFT_TEMPLATE)]['local_skill'])
    if not (template.get('name') == 'ur5e_retreat_vertical' and template.get('robot') == 'franka_left'
            and template.get('object') == 'fabrica_beam_2' and template.get('requires_held_object') is True
            and template.get('gripper_command') == 'contact_hold'
            and template.get('track_published_grasp_command') is True
            and template.get('relative_to_current_tcp') is True and template.get('offset') == [0.0, 0.0, 0.0]):
        raise ValueError('Lift template must be the loaded left vertical servo on column 2')
    # Round 62 (analysis 2026-11-24, five rounds authorized): rounds 55 and 59
    # held column 2 at the same height (-0.005 / +0.017 mm); round 55 merely had
    # 0 N on the base, so the compliant right-hand hold could yield sideways as
    # part 0 aligned, while round 59's 2.3 N base load locked it by friction and
    # part 0 jammed (3.4 N side load). 0.1 mm of rise already unloads the base;
    # the right-hand handover sags ~0.056 mm. Round 62 uses 0.2 mm (measured
    # rise ~0.15 mm, ~0.1 mm after the handover) instead of a height change.
    # Round 61 (human instruction 2026-11-20 "改 0.4 mm 再跑"): round 60's 1 mm
    # left column 2 ~1.0 mm above its seat and part 0, inserted to its nominal
    # pose, met it early (left finger force 51.5 N > 40 N). The height is now
    # BEAM_HANDOVER_UNLOAD_LIFT_M (default 0.001 = round 60, in [0.0002, 0.001]).
    # 0.1 mm per command; completes once the measured TCP is within half the
    # lift of the raised target (>= half the lift of real rise), then settles 72 steps.
    raw_lift = os.environ.get('BEAM_HANDOVER_UNLOAD_LIFT_M', '0.001')
    try:
        lift_m = float(raw_lift)
    except ValueError as exc:
        raise ValueError('BEAM_HANDOVER_UNLOAD_LIFT_M must be a number') from exc
    if not (math.isfinite(lift_m) and 0.0002 <= lift_m <= _HANDOVER_LIFT_M):
        raise ValueError('BEAM_HANDOVER_UNLOAD_LIFT_M must be in [0.0002, 0.001] m')
    # Round 62 (analysis 2026-11-24): the loaded left TCP settles ~0.255 mm
    # below its command (rounds 60/61 identical), so a lift / 2 tolerance can
    # never be met for small lifts (round 61 timeout). The completion tolerance
    # is max(lift / 2, 0.4 mm); the 1 mm default keeps 0.5 mm (round 60).
    template.update(offset=[0.0, 0.0, lift_m], cartesian_position_step=0.0001,
                    position_tolerance=max(lift_m / 2, 0.0004))
    lift = {
        'name': _HANDOVER_LIFT,
        'robot_targets': {},
        'local_skill': template,
        'advance': {'type': 'all_of', 'min_steps': 72, 'conditions': [
            {'type': 'local_skill_complete', 'robot': 'franka_left', 'skill': 'ur5e_retreat_vertical',
             'min_steps': 1},
            {'type': 'object_attached', 'object': 'fabrica_beam_2', 'robot': 'franka_left'}]},
        'timeout_steps': 720,
        'gripper_commands': {'franka_left': 'contact_hold', 'franka_right': 'contact_hold'},
        'object_collisions': copy.deepcopy(close.get('object_collisions') or []),
        'local_skills': {'franka_right': copy.deepcopy(right)},
    }
    for key in ('beam_idle_hold_anchor', 'beam_coordinated', 'beam_installed_parts',
                'beam_table_support_objects', 'beam_require_table_support',
                'beam_table_contact_force_relief', 'beam_physical_acceptance_profile'):
        if key in close:
            lift[key] = copy.deepcopy(close[key])
    phases.insert(index + 1, lift)


def _apply_continuous_beam_physics(phases: list[dict[str, Any]]) -> None:
    """Keep Beam dynamic and use the same force/contact gate throughout a grasp."""
    column3_pickup_depth = float(os.environ.get('BEAM_COLUMN3_PICKUP_DEPTH_M', '0'))
    if not math.isfinite(column3_pickup_depth) or not -0.012 <= column3_pickup_depth <= 0.0:
        raise ValueError('BEAM_COLUMN3_PICKUP_DEPTH_M must be finite and in [-0.012, 0].')
    # Cap part 0 rests tilted in the fixture; its audited pickup leaves only the
    # top ~3 mm of the cap faces between the pads. Fixture CAD clearance below
    # the fingertips is 2.6 mm at the audited relation, so the range is capped.
    cap0_pickup_depth = float(os.environ.get('BEAM_CAP0_PICKUP_DEPTH_M', '0'))
    if not math.isfinite(cap0_pickup_depth) or not -0.002 <= cap0_pickup_depth <= 0.0:
        raise ValueError('BEAM_CAP0_PICKUP_DEPTH_M must be finite and in [-0.002, 0].')
    column3_turn_speed = float(os.environ.get('BEAM_COLUMN3_TURN_ANGULAR_SPEED_RAD_S', '0.20'))
    if not math.isfinite(column3_turn_speed) or not 0.0 < column3_turn_speed <= 0.20:
        raise ValueError('BEAM_COLUMN3_TURN_ANGULAR_SPEED_RAD_S must be finite and in (0, 0.20].')
    try:
        turn_force_low, turn_force_high = map(float, os.environ.get(
            'BEAM_COLUMN3_TURN_PEAK_FORCE_BAND_N', '4,12').split(','))
    except ValueError as exc:
        raise ValueError('BEAM_COLUMN3_TURN_PEAK_FORCE_BAND_N requires two numbers.') from exc
    if not (math.isfinite(turn_force_low) and math.isfinite(turn_force_high)
            and 4.0 <= turn_force_low < turn_force_high <= 24.0):
        raise ValueError('Column-3 turn peak force band must satisfy 4 <= low < high <= 24 N.')
    try:
        carry_force_low, carry_force_high = map(float, os.environ.get(
            'BEAM_COLUMN3_CARRY_PEAK_FORCE_BAND_N', '4,12').split(','))
    except ValueError as exc:
        raise ValueError('BEAM_COLUMN3_CARRY_PEAK_FORCE_BAND_N requires two numbers.') from exc
    if not (math.isfinite(carry_force_low) and math.isfinite(carry_force_high)
            and 4.0 <= carry_force_low < carry_force_high <= 24.0):
        raise ValueError('Column-3 carry peak force band must satisfy 4 <= low < high <= 24 N.')
    contact_policy = {
        'continuous_physics': True,
        'hold_force_regulation': True,
        'require_force_contact': True,
        'require_dual_force_contact': True,
        'require_pair_force_contact': True,
        'require_opposing_force_contact': True,
        'measure_force_contact': True,
        'require_strict_physical_contact': True,
        'allow_cross_axis_dual_finger_contact': False,
        'physical_contact_axes': 'y',
        'contact_box_min_half_extent': 1e-6,
        'physical_contact_interior_scale': 1.0,
        'physical_contact_interior_margin': 0.0,
        'finger_contact_distance': 0.0035,
        'physical_attach_surface_gap': 0.0035,
        'contact_force_threshold': 0.10,
        'allow_jaw_width_completion': False,
        'allow_jaw_width_contact_for_physical_grasp': False,
        'allow_closed_gripper_completion': False,
        'use_joint_stall_for_close_until_contact': False,
        'close_contact_latch_after_stable': True,
        'allow_caging_contact_for_physical_grasp': False,
        'allow_caging_hold_for_physical_grasp': False,
        'hold_grace_allow_missing_contact': False,
        'hold_grace_steps': 0,
        'hold_position_slip_tolerance': 0.003,
        'hold_orientation_slip_tolerance': 0.0872664626,
    }
    for phase in phases:
        # Keep an unloaded arm's native command fixed across idle stages.
        # The policy still gives active work and physical support priority.
        phase['beam_idle_hold_anchor'] = True
        # There is no kinematic-to-dynamic transition in a friction grasp.
        phase.pop('kinematic_carry', None)
        phase.pop('gripper_sibling_filters', None)
        for entry in phase.get('object_gravity', []):
            entry['enabled'] = True
        for entry in phase.get('collision_filters', []):
            entry['enabled'] = False
        for entry in phase.get('object_collisions', []):
            entry['enabled'] = True
        rebase = phase.get('rebase_from_object')
        if isinstance(rebase, dict):
            rebase['filter_gripper_collision'] = False
        if phase['name'].endswith('_grip_handoff_dynamic'):
            phase['name'] = phase['name'].replace('_grip_handoff_dynamic', '_physical_hold_check')
        for entry in phase.get('attach', []):
            if entry.get('attachment_mode') in {'pure_physical_grasp', 'contact_pure_physical_grasp'}:
                entry.update(contact_policy)
        local_skill = phase.get('local_skill', {})
        if (phase['name'].startswith('assemble_') and local_skill.get('name') in
                {'ur5e_move_above_part', 'ur5e_descend_to_grasp'}):
            local_skill.update(trace_pregrasp=True, use_arm_ik_controller=False,
                               lock_target_orientation=True)
            if local_skill['name'] == 'ur5e_descend_to_grasp':
                # Contact approach must not accumulate a large tracking error
                # against the fixture while the arm continues to push.
                local_skill.update(cartesian_position_step=0.001, max_command_joint_step=0.004,
                    max_joint_step=0.004, max_command_tracking_error=0.04,
                    max_wrist_command_tracking_error=0.03)
        if (phase['name'].startswith('base_6_') and local_skill.get('object') == 'fabrica_beam_6'
                and local_skill.get('grasp_relative_position') is not None):
            # Shift the pickup relation along the part's thickness axis. This
            # raises the fingers at the final board pose, without changing the
            # assembled part target or moving an already grasped rigid body.
            local_skill['grasp_object_frame_offset'] = [0.0, 0.0, 0.028]
        if column3_pickup_depth and phase['name'] in {
            'assemble_00_part_3_move_above', 'assemble_00_part_3_descend',
            'assemble_00_part_3_close_and_attach',
        }:
            # Move this pickup relation into the column's wider shaft. Holds
            # and carrying keep the measured grasp relation captured at close.
            local_skill['grasp_object_frame_offset'] = [0.0, 0.0, column3_pickup_depth]
        if cap0_pickup_depth and phase['name'] in {
            'assemble_03_part_0_move_above', 'assemble_03_part_0_descend',
            'assemble_03_part_0_close_and_attach',
        }:
            # Same mechanism as column 3: only the pickup relation moves along
            # the cap thickness axis; carrying and insertion use the grasp
            # relation measured at close. Contact gates are unchanged.
            local_skill['grasp_object_frame_offset'] = [0.0, 0.0, cap0_pickup_depth]
        if local_skill.get('name') == 'ur5e_close_gripper':
            local_skill.update(contact_policy)
            local_skill.update({
                'close_force_regulation': True,
                'require_close_pose_gate': True,
                'close_gate_local_ik': True,
                'close_gate_local_ik_radius': 0.04,
                'close_gate_freeze_at_start': True,
                'close_gate_track_object_during_close': False,
                'close_position_tolerance': 0.001,
                'close_orientation_tolerance': 0.02,
                'close_ready_stable_steps': 24,
                'close_gate_stationary_position_tolerance': 0.0001,
                'close_gate_stationary_orientation_tolerance': 0.002,
                'close_pose_gate_timeout_steps': 720,
                'ik_position_tolerance': 0.000005,
                'ik_orientation_tolerance': 0.001,
                'close_contact_hold_squeeze_margin': 0.0,
                'close_until_contact_timeout_steps': 1200,
                'close_force_low': 4.0, 'close_force_high': 12.0, 'close_force_limit': 40.0,
                'close_force_min_stable': 1.0, 'close_force_validation_steps': 96,
                'close_force_joint_rate': 0.025, 'close_force_unload_rate': 0.06,
                'close_force_max_command_lead': 0.001, 'close_force_max_seek': 0.03,
                'close_approach_joint_rate': 0.10, 'close_approach_joint_margin': 0.06,
                'close_gate_recenter_stable_steps': 4, 'close_force_recenter_settle_steps': 8,
                'close_gate_recenter_step': 0.0002, 'close_gate_recenter_max_offset': 0.002,
                'close_gate_recenter_target_tolerance': 0.0001,
                'close_force_recenter_measure_progress': True,
                'close_force_recenter_timeout_steps': 240,
                'close_force_recenter_stop_on_bilateral': True,
                'close_force_recenter_adaptive_step': True,
                'close_force_recenter_min_step': 0.000025,
                'close_force_balance_min': 2.0,
                'close_force_balance_peak': 4.0,
                'close_force_balance_step': 0.000025,
            })
            if phase['name'] == 'assemble_00_part_3_close_and_attach':
                # Confirm the persistent weak side through contact/force-band
                # transitions before issuing a small bounded centering move.
                local_skill['close_force_recenter_track_weak_side'] = True
            phase['timeout_steps'] = max(int(phase.get('timeout_steps', 0)), 2000)
        elif local_skill.get('requires_held_object'):
            # Preserve the captured command through all physical carry phases.
            local_skill['gripper_command'] = 'contact_hold'
            robot_name = local_skill.get('robot')
            if robot_name in phase.get('gripper_commands', {}):
                phase['gripper_commands'][robot_name] = 'contact_hold'
            # The existing insertion servo keeps its alignment/settling logic,
            # but must hand subsequent holds the command it actually published.
            local_skill['track_published_grasp_command'] = True
            local_skill['use_arm_ik_controller'] = False
            if phase['name'].endswith('_grip_settle'):
                local_skill['hold_previous_grasp_command'] = True
            elif local_skill.get('relative_to_current_tcp'):
                local_skill.update(
                    inherit_grasp_drive_target=True,
                    lock_target_position=True,
                    grasp_drive_position_lookahead=0.001,
                    use_command_warm_start=True,
                    require_warm_start_ik=True,
                    ik_position_tolerance=0.000005,
                    ik_orientation_tolerance=0.001,
                )
            elif (phase['name'].endswith(('_pickup_clearance', '_assembly_clearance', '_transport_hover'))
                  or phase['name'] == 'base_6_place'):
                local_skill.update(
                    inherit_grasp_drive_target=True,
                    lock_target_position=True,
                    lock_target_orientation=True,
                    ik_reference_mode='command',
                    use_command_warm_start=True,
                    require_warm_start_ik=True,
                    # FK-based command integration cannot accumulate ignored
                    # sub-tolerance increments. Resolve the slow servo steps.
                    ik_position_tolerance=0.0000001,
                    ik_orientation_tolerance=0.00001,
                    cartesian_position_step=0.00025,
                    cartesian_orientation_step=0.001,
                    grasp_drive_position_lookahead=0.002,
                    grasp_drive_orientation_lookahead=0.02,
                    grasp_drive_joint_lookahead=0.04,
                    grasp_drive_smooth_transport=True,
                    grasp_drive_linear_speed=0.04,
                    grasp_drive_angular_speed=0.20,
                    grasp_drive_joint_speed=0.5,
                    grasp_drive_joint_acceleration=4.0,
                    grasp_drive_slowdown_start=0.55,
                    grasp_drive_slowdown_stop=0.95,
                    max_command_joint_step=0.008,
                    max_joint_step=0.008,
                )
                phase['timeout_steps'] = max(int(phase.get('timeout_steps', 0)), 12000)
                if phase['name'] == 'assemble_00_part_3_assembly_clearance':
                    local_skill['grasp_drive_angular_speed'] = column3_turn_speed
                    if (turn_force_low, turn_force_high) != (4.0, 12.0):
                        local_skill['beam_turn_peak_force_band_N'] = [turn_force_low, turn_force_high]
        if phase['name'] == 'base_6_peel_lift':
            local_skill.update(offset=[0.0, 0.0, 0.005], cartesian_position_step=0.0002,
                               position_tolerance=0.001)
            for condition in phase.get('advance', {}).get('conditions', []):
                if condition.get('type') == 'object_lifted':
                    condition['min_lift'] = 0.003
        if phase['name'] == 'base_6_lift':
            # v141 held real contact throughout the lift but only advanced
            # 27 mm in 1200 steps. Keep small increments while allowing a
            # modestly larger tracking lead and enough time for 140 mm.
            local_skill.update(grasp_drive_position_lookahead=0.002,
                               cartesian_position_step=0.00025)
            phase['timeout_steps'] = max(int(phase.get('timeout_steps', 0)), 4000)
        # Companion holds are stored separately from the primary moving skill.
        # Re-solving a zero-offset pose discards the loaded drive's preload.
        companions = phase.get('local_skills', {})
        for companion in companions.values():
            if companion.get('name') == 'ur5e_hold_part_end':
                companion.update(requires_held_object=True, hold_previous_grasp_command=True,
                                 use_arm_ik_controller=False, gripper_command='contact_hold')
                robot_name = companion.get('robot')
                if robot_name in phase.get('gripper_commands', {}):
                    phase['gripper_commands'][robot_name] = 'contact_hold'
        if phase['name'] == 'base_6_clear_support_filters':
            # This bookkeeping phase otherwise falls back to the generic policy,
            # which folds angles and holds the unloaded measured joint state.
            condition = next(c for c in phase['advance']['conditions'] if c.get('type') == 'object_attached')
            phase['local_skill'] = {
                'name': 'ur5e_hold_part_end', 'robot': condition['robot'], 'object': condition['object'],
                'requires_held_object': True, 'hold_previous_grasp_command': True,
                'gripper_command': 'contact_hold', 'relative_to_current_tcp': True,
                'offset': [0.0, 0.0, 0.0], 'lock_target_position': True, 'lock_target_orientation': True,
                'use_arm_ik_controller': False, 'max_command_tracking_error': 0.18,
                'max_wrist_command_tracking_error': 0.12,
            }
        if (phase['name'] in {'assemble_00_part_3_lift',
                             'assemble_00_part_3_post_lift_restore_gravity',
                             'assemble_00_part_3_pickup_clearance'}
                and local_skill.get('requires_held_object')
                and (carry_force_low, carry_force_high) != (4.0, 12.0)):
            # Establish the bounded transport preload before the long turn.
            # Admission, original slip anchor, seek budget and hard limits stay.
            local_skill['beam_carry_peak_force_band_N'] = [carry_force_low, carry_force_high]


def _apply_column3_transport_raise(targets: list[dict[str, Any]]) -> None:
    """Raise only the first column's pickup and turn clearance, before approach.

    Its original hover/insertion targets and all success/force/attachment gates
    are unchanged. The zero default reproduces the retained trajectory.
    """
    height = float(os.environ.get('BEAM_COLUMN3_TRANSPORT_RAISE_M', '0'))
    if not math.isfinite(height) or not 0.0 <= height <= 0.24:
        raise ValueError('BEAM_COLUMN3_TRANSPORT_RAISE_M must be finite and in [0, 0.24].')
    if height == 0.0:
        return
    names = ('part_3_pickup_clearance', 'part_3_assembly_clearance')
    selected = [target for target in targets if target.get('name') in names]
    if len(selected) != 2 or {target['name'] for target in selected} != set(names):
        raise ValueError('Column3 transport raise requires unique pickup and assembly clearance targets.')
    positions = [_vector(target['position'], size=3, name=target['name']) for target in selected]
    for target, position in zip(selected, positions):
        target['position'] = _add(position, [0.0, 0.0, height])


def compile_continuous_beam_recipe(payload: dict[str, Any]) -> dict[str, Any]:
    spec = payload.get('fabrica_canonical')
    if spec is None:
        return payload
    if not isinstance(spec, dict):
        raise ValueError('fabrica_canonical must be a mapping.')

    assembly = str(spec.get('assembly', '')).strip()
    if not assembly:
        raise ValueError('fabrica_canonical.assembly is required.')
    metadata_path = spec.get('metadata_path')
    metadata = load_fabrica_canonical_metadata(metadata_path)
    task = metadata['tasks'].get(assembly)
    if task is None:
        raise ValueError(
            f'Unknown canonical Fabrica assembly {assembly!r}; ' f'available tasks: {sorted(metadata["tasks"])}.'
        )

    configured_pickup_origin = _vector(
        spec.get('pickup_origin', [0.47, -0.45, 0.0125]),
        size=3,
        name='pickup_origin',
    )
    configured_pickup_orientation = _vector(
        spec.get('pickup_orientation', [1.0, 0.0, 0.0, 0.0]),
        size=4,
        name='pickup_orientation',
    )
    assembly_origin = _vector(
        spec.get('assembly_origin', [0.70, -0.18, 0.0125]),
        size=3,
        name='assembly_origin',
    )
    assembly_orientation = _vector(
        spec.get('assembly_orientation', [1.0, 0.0, 0.0, 0.0]),
        size=4,
        name='assembly_orientation',
    )
    board_origin = _vector(
        spec.get('board_origin', [0.47, -0.14, 0.0125]),
        size=3,
        name='board_origin',
    )
    workspace_offset = _vector(
        payload.get('workspace_offset', [0.0, 0.0, 0.0]),
        size=3,
        name='workspace_offset',
    )
    robots = payload.get('robots', [])
    if not isinstance(robots, list):
        raise ValueError('robots must be a list.')
    task = copy.deepcopy(task)
    assembly_step_order = spec.get('assembly_step_order')
    if assembly_step_order is not None:
        if not isinstance(assembly_step_order, (list, tuple)) or not assembly_step_order:
            raise ValueError('fabrica_canonical.assembly_step_order must be a non-empty list of move_part ids.')
        steps_by_part = {str(step['move_part']): step for step in task['assembly_steps']}
        ordered_steps = []
        for part_id in assembly_step_order:
            key = str(part_id)
            if key not in steps_by_part:
                raise ValueError(
                    f'fabrica_canonical.assembly_step_order refers to unknown move_part {key!r}; '
                    f'available: {sorted(steps_by_part)}.'
                )
            ordered_steps.append(steps_by_part.pop(key))
        if steps_by_part:
            raise ValueError(
                'fabrica_canonical.assembly_step_order must include every assembly move_part; '
                f'missing: {sorted(steps_by_part)}.'
            )
        task['assembly_steps'] = ordered_steps
    (
        pickup_origin,
        pickup_orientation,
        selected_base_grasp,
        selected_move_grasps,
        grasp_selection,
    ) = _resolve_pickup_layout_and_grasps(
        assembly=assembly,
        task=task,
        spec=spec,
        configured_pickup_origin=configured_pickup_origin,
        configured_pickup_orientation=configured_pickup_orientation,
        board_origin=board_origin,
        assembly_origin=assembly_origin,
        assembly_orientation=assembly_orientation,
        workspace_offset=workspace_offset,
        robots=robots,
    )
    task['base_grasp'] = selected_base_grasp
    for step in task['assembly_steps']:
        part_id = str(step['move_part'])
        step['move_grasp'] = copy.deepcopy(selected_move_grasps[part_id])

    if spec.get('coordinated_support_plan'):
        from roboassemblybench.core.beam_coordinated import select_grasps
        select_grasps(task, spec)
        selected_move_grasps = {str(step['move_part']): copy.deepcopy(step['move_grasp'])
                                for step in task['assembly_steps']}
        grasp_selection['coordinated_override'] = 'native_mesh_audit_2026_09_30'

    generated_objects = [
        _static_asset_object(
            name='optical_board',
            usd_path=task['optical_board']['usd_path'],
            position=board_origin,
            friction=0.5,
        ),
        _static_asset_object(
            name='fabrica_fixture',
            usd_path=task['fixture']['usd_path'],
            position=pickup_origin,
            orientation=pickup_orientation,
            friction=0.8,
        ),
    ]
    generated_objects.extend(
        _part_object(
            assembly,
            part,
            pickup_origin=pickup_origin,
            pickup_orientation=pickup_orientation,
        )
        for part in task['parts']
    )
    if bool(spec.get('official_bimanual_hold', False)):
        # Keep authored SDF (or force SDF) so holes remain collidable and seated
        # parts can physically support each other. Never change approximation
        # mid-episode — only CollisionEnabled is toggled, which is safe for PhysX.
        for entry in generated_objects:
            name = str(entry.get('name', ''))
            if name.startswith(f'fabrica_{assembly}_'):
                entry['collision_approximation'] = 'sdf'
                # Finger pads are already ~5. Grip friction is the average, so the
                # part itself stays near 0.8. 2.2 glued the beam to the tray and
                # the tray came up with it (v81–v82).
                entry['static_friction'] = 0.8
                entry['dynamic_friction'] = 0.6
                # Heavier damping so unlocked settle does not tumble/tunnel.
                entry['linear_damping'] = max(float(entry.get('linear_damping', 0.0) or 0.0), 4.0)
                entry['angular_damping'] = max(float(entry.get('angular_damping', 0.0) or 0.0), 16.0)
                # Sit slightly above the deck so SDF does not sink into it.
                entry['spawn_clearance'] = max(float(entry.get('spawn_clearance', 0.0) or 0.0), 0.004)
                # Lighter parts so finger friction can accelerate them (default mass=1kg).
                entry['mass'] = min(float(entry.get('mass') or 1.0), 0.25)
            elif name == 'fabrica_fixture':
                # Bolted nest. min combine keeps this low coefficient, and the
                # kinematic anchor stops the thin tray from being carried away.
                entry['static_friction'] = 0.20
                entry['tracked'] = True
                entry['dynamic_friction'] = 0.15
                entry['friction_combine_mode'] = 'min'
                entry['kinematic_anchor'] = True
            elif name == 'optical_board':
                entry['static_friction'] = max(float(entry.get('static_friction', 0.5) or 0.5), 1.5)
                entry['dynamic_friction'] = max(float(entry.get('dynamic_friction', 0.5) or 0.5), 1.2)
        generated_objects.append(
            _assembly_support_cube(
                board_origin=board_origin,
                board=task['optical_board'],
            )
        )
        part_entries = [
            entry
            for entry in generated_objects
            if str(entry.get('name', '')).startswith(f'fabrica_{assembly}_')
        ]
        part_positions = [list(entry['position']) for entry in part_entries]
        part_bottom_zs = []
        for entry in part_entries:
            bbox_min = entry.get('fabrica_bbox_min') or [0.0, 0.0, 0.0]
            part_bottom_zs.append(float(entry['position'][2]) + float(bbox_min[2]))
        generated_objects.append(
            _fixture_support_cube(
                pickup_origin=pickup_origin,
                part_positions=part_positions,
                part_bottom_zs=part_bottom_zs,
            )
        )

    (targets, phases, success, pickup_target_names, assembly_target_names,) = _compile_targets_and_phases(
        assembly=assembly,
        task=task,
        spec=spec,
        pickup_origin=pickup_origin,
        pickup_orientation=pickup_orientation,
        assembly_origin=assembly_origin,
        assembly_orientation=assembly_orientation,
        robots=robots,
    )
    if bool(spec.get('continuous_physics', False)):
        if assembly != 'beam' or not bool(spec.get('official_bimanual_hold', False)):
            raise ValueError('continuous_physics currently requires Beam official_bimanual_hold.')
        _apply_continuous_beam_physics(phases)
        from roboassemblybench.core.beam_coordinated import configure_beam_velocity_solver
        configure_beam_velocity_solver(generated_objects, spec.get('beam_solver_velocity_iterations', 4))
    if spec.get('coordinated_support_plan'):
        from roboassemblybench.core.beam_coordinated import coordinate_phases
        coordinate_phases(phases, task, spec, targets, assembly_target_names)
    from roboassemblybench.core.beam_staged_physical import apply_staged_contract
    staged_contract = apply_staged_contract(phases, success, robots=robots, spec=spec) if assembly == 'beam' else None
    if assembly == 'beam':
        _apply_part0_window_speedup(phases)
        _apply_fast_motion(phases)
        _apply_final_assembly_load(phases)
        _apply_part0_release_after_clear(phases)
        _apply_release_without_stack_window(phases)
        _apply_handover_unload_lift(phases)
    if assembly == 'beam' and bool(spec.get('continuous_physics', False)):
        # Coordination can insert new stages after the physical policy pass.
        # Apply only this idle switch to the final list, preserving the
        # coordinated grasp poses, support commands and contact parameters.
        for phase in phases:
            phase['beam_idle_hold_anchor'] = True
    part_names = [f'fabrica_{assembly}_{part["part_id"]}' for part in task['parts']]
    translation_constraints = _canonical_translation_constraints(
        assembly=assembly,
        task=task,
        spec=spec,
        generated_objects=generated_objects,
        targets=targets,
        pickup_target_names=pickup_target_names,
        assembly_target_names=assembly_target_names,
        workspace_offset=workspace_offset,
        robots=robots,
    )
    generated_randomization = _default_domain_randomization(
        spec=spec,
        assembly=assembly,
        part_names=part_names,
        pickup_target_names=pickup_target_names,
        assembly_target_names=assembly_target_names,
        translation_constraints=translation_constraints,
        include_fixture_support=any(
            entry.get('name') == 'fixture_support' for entry in generated_objects
        ),
    )

    resolved = copy.deepcopy(payload)
    resolved['objects'] = _merge_named_entries(generated_objects, resolved.get('objects', []))
    resolved['targets'] = _merge_named_entries(targets, resolved.get('targets', []))
    if assembly == 'beam':
        _apply_column3_transport_raise(resolved['targets'])
    resolved['phases'] = phases
    resolved['success'] = success
    if staged_contract is not None:
        resolved['beam_physical_contract'] = staged_contract
        from roboassemblybench.core.beam_staged_physical import validate_staged_skill_bindings
        validate_staged_skill_bindings(phases, resolved.get('metadata', {}), robots)
    resolved['domain_randomization'] = deep_merge(
        generated_randomization,
        resolved.get('domain_randomization', {}),
    )
    fixed_objects = {str(name) for name in resolved['domain_randomization'].get('fixed_objects', [])}
    fixed_objects.add('optical_board')
    if any(entry.get('name') == 'assembly_support' for entry in resolved['objects']):
        fixed_objects.add('assembly_support')
    # fixture_support must translate with start_parts — do not mark it fixed.
    fixed_objects.discard('fixture_support')
    resolved['domain_randomization']['fixed_objects'] = sorted(fixed_objects)
    for group_name, group in resolved['domain_randomization'].get('groups', {}).items():
        if 'optical_board' in (group.get('objects') or []):
            raise ValueError(f'Optical board is fixed and cannot belong to position group {group_name!r}.')

    resolved['max_steps'] = max(
        int(resolved.get('max_steps', 0)),
        22000,
        len(task['parts']) * 7000,
        len(phases) * 360,
    )
    if assembly == 'beam':
        from toolkits.factory_dual_franka_assembly.beam_exploration import (
            parse_exploration_environment, parse_exploration_continuation,
            continuation_step_budget)
        if staged_contract is not None or parse_exploration_continuation(os.environ, parse_exploration_environment(os.environ)):
            resolved['max_steps'] = continuation_step_budget(
                phases, resolved['max_steps'], int(resolved.get('phase_timeout_steps', 1200)))
    resolved['fabrica_canonical_resolved'] = {
        'assembly': assembly,
        'metadata_schema_version': metadata['schema_version'],
        'metadata_path': str(Path(metadata_path or CANONICAL_METADATA_PATH).expanduser().resolve()),
        'bundle_path': _asset_path(task['bundle_path']),
        'base_part': str(task['base_part']),
        'transport_tcp_height': _transport_tcp_height(
            spec,
            pickup_origin=pickup_origin,
            assembly_origin=assembly_origin,
        ),
        'transport_timeout_steps': int(spec.get('transport_timeout_steps', 4800)),
        'insertion_timeout_steps': int(spec.get('insertion_timeout_steps', 3600)),
        'base_place_timeout_steps': int(spec.get('base_place_timeout_steps', 4800)),
        'insertion_lateral_position_tolerance': float(spec.get('insertion_lateral_position_tolerance', 0.001)),
        'insertion_lateral_tolerance_object_extent_scale': float(
            spec.get('insertion_lateral_tolerance_object_extent_scale', 0.04)
        ),
        'intermediate_insertion_lateral_position_tolerance': float(
            spec.get('intermediate_insertion_lateral_position_tolerance', 0.002)
        ),
        'intermediate_insertion_lateral_alignment_cartesian_position_step': float(
            spec.get(
                'intermediate_insertion_lateral_alignment_cartesian_position_step',
                0.001,
            )
        ),
        'insertion_cartesian_position_step': float(spec.get('insertion_cartesian_position_step', 0.00025)),
        'insertion_lateral_alignment_cartesian_position_step': float(
            spec.get('insertion_lateral_alignment_cartesian_position_step', 0.00025)
        ),
        'insertion_lateral_alignment_entry_clearance': float(
            spec.get('insertion_lateral_alignment_entry_clearance', 0.01)
        ),
        'insertion_lateral_alignment_clearance_object_extent_scale': float(
            spec.get(
                'insertion_lateral_alignment_clearance_object_extent_scale',
                1.0,
            )
        ),
        'insertion_axial_recovery_cartesian_position_step': float(
            spec.get('insertion_axial_recovery_cartesian_position_step', 0.001)
        ),
        'insertion_axial_recovery_deadband': float(spec.get('insertion_axial_recovery_deadband', 0.0005)),
        'insertion_compliance_capture_max_linear_speed': float(
            spec.get('insertion_compliance_capture_max_linear_speed', 0.10)
        ),
        'insertion_compliance_capture_max_angular_speed': float(
            spec.get('insertion_compliance_capture_max_angular_speed', 2.0)
        ),
        'insertion_compliance_capture_stable_steps': int(spec.get('insertion_compliance_capture_stable_steps', 8)),
        'insertion_compliance_geometric_capture_after_steps': int(
            spec.get('insertion_compliance_geometric_capture_after_steps', 1200)
        ),
        'insertion_compliance_minimum_gravity_alignment': float(
            spec.get('insertion_compliance_minimum_gravity_alignment', 0.70)
        ),
        'insertion_compliant_alignment_retraction_limit': float(
            spec.get('insertion_compliant_alignment_retraction_limit', 0.006)
        ),
        'insertion_compliant_track_object_orientation': bool(
            spec.get('insertion_compliant_track_object_orientation', False)
        ),
        'base_support_release_position_tolerance': float(spec.get('base_support_release_position_tolerance', 0.012)),
        'base_support_lateral_position_tolerance': float(spec.get('base_support_lateral_position_tolerance', 0.015)),
        'base_support_lateral_alignment_enter_tolerance': float(
            spec.get('base_support_lateral_alignment_enter_tolerance', 0.002)
        ),
        'base_support_lateral_alignment_exit_tolerance': float(
            spec.get('base_support_lateral_alignment_exit_tolerance', 0.004)
        ),
        'base_support_lateral_alignment_cartesian_position_step': float(
            spec.get(
                'base_support_lateral_alignment_cartesian_position_step',
                0.002,
            )
        ),
        'release_retreat_distance': float(spec.get('release_retreat_distance', 0.06)),
        'post_release_park_distance': float(spec.get('post_release_park_distance', 0.35)),
        'post_release_park_vertical_offset': float(spec.get('post_release_park_vertical_offset', 0.02)),
        'post_release_park_minimum_planar_radius': float(spec.get('post_release_park_minimum_planar_radius', 0.28)),
        'assembly_order': [
            {
                'move_part': str(step['move_part']),
                'socket_part': str(step['socket_part']),
                'optimizer_hold_part': str(step['optimizer_hold_part']),
            }
            for step in task['assembly_steps']
        ],
        'stabilize_fixture_parts': bool(spec.get('stabilize_fixture_parts', True)),
        'fixture_release_after_steps': int(spec.get('fixture_release_after_steps', 8)),
        'configured_pickup_origin': configured_pickup_origin,
        'selected_pickup_origin': pickup_origin,
        'configured_pickup_orientation': configured_pickup_orientation,
        'selected_pickup_orientation': pickup_orientation,
        'selected_base_grasp': selected_base_grasp,
        'selected_move_grasps': selected_move_grasps,
        'move_grasp_selection': grasp_selection['move_grasp_selection'],
        'pickup_layout_selection': grasp_selection,
        'optical_board_position_randomized': False,
    }
    return resolved


def _apply_domain_randomization(
    recipe_spec: dict[str, Any],
    *,
    seed: int,
    enabled_override: bool | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Resolve one deterministic randomized episode from a recipe.

    Every member of a group receives the exact same sampled translation. This is
    required for assembly data: pickup parts and their pickup waypoints move as a
    rigid layout, while the assembly targets move as a second rigid layout.
    """

    from roboassemblybench.core.domain_randomization import (
        _derived_seed, _sample_translation, _sample_color,
        _apply_group_translation, _apply_group_color,
    )
    import random

    resolved = copy.deepcopy(recipe_spec)
    randomization_spec = copy.deepcopy(resolved.get('domain_randomization') or {})
    configured_enabled = bool(randomization_spec.get('enabled', False))
    enabled = configured_enabled if enabled_override is None else bool(enabled_override)
    namespace = str(randomization_spec.get('seed_namespace', resolved.get('task_name', 'task')))
    result: dict[str, Any] = {
        'enabled': enabled,
        'configured_enabled': configured_enabled,
        'seed': int(seed),
        'derived_seed': _derived_seed(seed, namespace),
        'seed_namespace': namespace,
        'groups': {},
        'appearance_groups': {},
    }
    if not enabled:
        resolved['resolved_domain_randomization'] = result
        return resolved, result

    groups = randomization_spec.get('groups') or {}
    appearance_groups = (randomization_spec.get('appearance') or {}).get('groups') or {}
    if not isinstance(groups, dict):
        raise ValueError('Domain-randomization groups must be a mapping.')
    if not isinstance(appearance_groups, dict):
        raise ValueError('Domain-randomization appearance groups must be a mapping.')
    if not groups and not appearance_groups:
        raise ValueError('Enabled domain randomization requires position or appearance groups.')

    rng = random.Random(result['derived_seed'])
    fixed_objects = {str(value) for value in (randomization_spec.get('fixed_objects') or [])}
    assigned_members: dict[tuple[str, str], str] = {}
    for group_name, raw_group_spec in groups.items():
        if not isinstance(raw_group_spec, dict):
            raise ValueError(f'Domain-randomization group {group_name!r} must be a mapping.')
        group_name = str(group_name)
        group_spec = copy.deepcopy(raw_group_spec)
        translation = _sample_translation(group_name, group_spec, rng)
        group_result = {
            'translation': translation,
            'objects': [],
            'targets': [],
        }
        for entry_kind, collection_key in (('object', 'objects'), ('target', 'targets')):
            member_names = [str(value) for value in (group_spec.get(collection_key) or [])]
            for member_name in member_names:
                if entry_kind == 'object' and member_name in fixed_objects:
                    raise ValueError(
                        f'Fixed object {member_name!r} cannot belong to position-randomization '
                        f'group {group_name!r}.'
                    )
                member_key = (entry_kind, member_name)
                previous_group = assigned_members.get(member_key)
                if previous_group is not None:
                    raise ValueError(
                        f'{entry_kind.title()} {member_name!r} belongs to both domain-randomization groups '
                        f'{previous_group!r} and {group_name!r}.'
                    )
                assigned_members[member_key] = group_name
            group_result[collection_key] = _apply_group_translation(
                resolved.get(collection_key, []),
                member_names=member_names,
                group_name=group_name,
                translation=translation,
                entry_kind=entry_kind,
            )
        result['groups'][group_name] = group_result

    assigned_appearance_members: dict[tuple[str, str], str] = {}
    for group_name, raw_group_spec in appearance_groups.items():
        if not isinstance(raw_group_spec, dict):
            raise ValueError(f'Domain-randomization appearance group {group_name!r} must be a mapping.')
        group_name = str(group_name)
        group_spec = copy.deepcopy(raw_group_spec)
        color = _sample_color(group_name, group_spec, rng)
        group_result = {'color': color, 'objects': [], 'lights': []}
        for entry_kind, collection_key in (('object', 'objects'), ('light', 'lights')):
            member_names = [str(value) for value in (group_spec.get(collection_key) or [])]
            for member_name in member_names:
                member_key = (entry_kind, member_name)
                previous_group = assigned_appearance_members.get(member_key)
                if previous_group is not None:
                    raise ValueError(
                        f'{entry_kind.title()} {member_name!r} belongs to both appearance groups '
                        f'{previous_group!r} and {group_name!r}.'
                    )
                assigned_appearance_members[member_key] = group_name
            entries_key = 'objects' if entry_kind == 'object' else 'scene_lights'
            group_result[collection_key] = _apply_group_color(
                resolved.get(entries_key, []),
                member_names=member_names,
                group_name=group_name,
                color=color,
                entry_kind=entry_kind,
            )
        result['appearance_groups'][group_name] = group_result

    resolved['resolved_domain_randomization'] = result
    return resolved, result

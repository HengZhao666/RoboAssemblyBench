"""Recorded v208 failure through production skill dispatch and final policy consumer.

No engine: measured joints/attachments are recorded inputs; the completion test
uses explicitly synthetic goal feedback and is not physical progress evidence.
"""
import copy
import json
import os
import unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
import numpy as np
from tests.toolkits.test_beam_idle_hold import Policy, Task
from roboassemblybench.core.beam_staged_physical import (
    _bind_empty_joint_skill, validate_staged_skill_bindings,
)
from toolkits.factory_dual_franka_assembly.local_skills import LocalSkillExecutor

FIXTURE = json.loads((Path(__file__).parents[1] / 'fixtures/beam_v208_joint_dispatch_failure.json').read_text())
ROBOT = 'franka_right'


def task_for(index=0, bind=True):
    task = Task()
    task.robots[ROBOT] = task.robots.pop('left')
    task.robots[ROBOT].config = NS(preserve_continuous_arm_joints=True)
    task.cfg.robot_names = [ROBOT]
    task.cfg.task_metadata = copy.deepcopy(FIXTURE['task_metadata'])
    task.spec = copy.deepcopy(FIXTURE['phase'])
    if bind:
        _bind_empty_joint_skill(task.spec['local_skill'])
    task.phase_specs = [task.spec]
    task.phase = task.spec['name']
    task.phase_index = 47
    task.phase_entry_step = 30738
    sample = FIXTURE['all_sampled_series'][index]
    task.step_counter = sample['step']
    task.phase_step_counter = task.step_counter - task.phase_entry_step
    task.subset.q = np.array(sample['actual_q'])
    task.tracking[ROBOT] = task.tracking.pop('left')
    # The original snapshot records the left arm's continuing ownership. The
    # right is unloaded; do not replace its ownership predicate with True.
    packet = FIXTURE['raw_selected_packets'][0]
    task._attachments = copy.deepcopy(packet['task_constraints']['attachments'])
    task._all_physical_grasps = lambda: list(task._attachments.items())
    task.completed = []
    task.mark_local_skill_complete = lambda **kwargs: task.completed.append(kwargs)
    return task


class JointDispatch(unittest.TestCase):
    def setUp(self):
        p = patch.dict(os.environ, {'BEAM_IDLE_HOLD_ANCHOR': '1'}, clear=True)
        p.start(); self.addCleanup(p.stop)

    def test_original_frozen_metadata_reproduces_unknown_dispatch(self):
        t = task_for(bind=False)
        ex = LocalSkillExecutor()
        action = ex.action_for(task=t, robot_name=ROBOT, phase_spec=t.spec,
                               tracked_robots=t.tracking, tracked_objects={})
        self.assertIsNone(action)
        self.assertEqual(ex.diagnostics[-1]['reason'],
                         'unknown_local_skill:move_arm_to_joint_positions')
        with self.assertRaisesRegex(ValueError, 'Unbound Beam local skill'):
            validate_staged_skill_bindings([t.spec], t.cfg.task_metadata, [ROBOT])

    def test_recorded_evolving_samples_reach_actual_policy_action(self):
        # Five real states independently replay dispatch; no simulated feedback
        # integration and no claim that the new path advanced native physics.
        for index in [0, 90, 180, 270, 374]:
            with self.subTest(index=index):
                t = task_for(index)
                policy = Policy()
                with patch.object(policy, '_compose_robot_action',
                                  side_effect=AssertionError('unexpected native fallback')):
                    out = policy.act(t)[ROBOT]
                q = np.array(out['arm_joint_controller'][0])
                goal = np.array(t.spec['local_skill']['joint_positions'])
                self.assertGreater(np.max(np.abs(q-t.subset.q)), 0)
                self.assertLessEqual(np.max(np.abs(q-t.subset.q)), .004+1e-12)
                self.assertLess(np.max(np.abs(goal-q)), np.max(np.abs(goal-t.subset.q)))
                self.assertEqual(out['gripper_controller'], [1.])
                self.assertFalse(t.failed)
                self.assertFalse(t.completed)
                self.assertEqual(policy.local_skill_diagnostics[-1]['reason'], 'adapter_action')

    def test_loaded_right_is_rejected_by_real_ownership_predicate(self):
        t = task_for()
        t._attachments['counterexample_right_owns_part'] = {'robot_name': ROBOT}
        p = Policy()
        p.act(t)
        self.assertTrue(t.failed)
        self.assertIn('joint_home_requires_empty_arm', t.terminal_reason)
        self.assertFalse(t.completed)

    def test_goal_feedback_requires_original_stable_window(self):
        t = task_for()
        t.subset.q = np.array(t.spec['local_skill']['joint_positions'])
        p = Policy()
        required = t.spec['local_skill']['joint_target_stable_steps']
        for step in range(required):
            t.step_counter += 1; t.phase_step_counter += 1
            p.act(t)
            self.assertEqual(bool(t.completed), step == required-1)
        self.assertEqual(t.completed[-1]['robot_name'], ROBOT)

    def test_binding_rejects_loaded_or_closed_joint_requests(self):
        for changes in [{'gripper_command': 'close'}, {'requires_held_object': True}]:
            s = copy.deepcopy(FIXTURE['phase']['local_skill']); s.update(changes)
            with self.assertRaises(ValueError): _bind_empty_joint_skill(s)

    def test_unknown_name_fails_before_engine_even_with_adapter(self):
        t = task_for(); t.spec['local_skill']['name'] = 'move_arm_to_joint_postions'
        with self.assertRaisesRegex(ValueError, 'Unbound Beam local skill'):
            validate_staged_skill_bindings([t.spec], t.cfg.task_metadata, [ROBOT])

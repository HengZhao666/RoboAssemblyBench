"""Repeated R53 release through real interaction/dispatch/policy branches.

No engine: ownership records and force/pose feedback are explicit test doubles.
This proves software routing and preservation, not a physical load transfer.
"""
import copy
import json
import os
from pathlib import Path
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

import numpy as np

from internutopia_extension.tasks.factory_dual_franka_assembly_task import FactoryDualFrankaAssemblyTask as NativeTask
from tests.toolkits.test_beam_idle_hold import Policy, Task as IdleTask
from toolkits.factory_dual_franka_assembly.beam_support_state import BeamSupportState

DATA=json.loads((Path(__file__).parents[1]/'fixtures/beam_v217_release_failure.json').read_text())
COMPILED_WORKER_CONFIG=Path(os.environ['BEAM_COMPILED_WORKER_CONFIG'])
OBJECT='fabrica_beam_3';LEFT='franka_left';RIGHT='franka_right'
scope={};exec(DATA['legacy_detach_source'],scope)
LEGACY=scope['_detach_object']


class ReplayTask(IdleTask, BeamSupportState):
    _process_phase_interactions=NativeTask._process_phase_interactions
    _detach_ready=NativeTask._detach_ready
    _detach_object=NativeTask._detach_object
    _clear_attachment_state=NativeTask._clear_attachment_state
    _sync_object_states=NativeTask._sync_object_states
    _invalidate_continuous_grasp=NativeTask._invalidate_continuous_grasp

    def __init__(self):
        super().__init__()
        self.robots[RIGHT]=self.robots.pop('left')
        self.robots[RIGHT].config=NS(gripper_open_position=0.,gripper_closed_position=.8,
                                    gripper_close_openness=.08,preserve_continuous_arm_joints=True)
        gripper=NS(get_obs=lambda:{'gripper_pos':[.72]})
        self.robots[RIGHT].controllers['gripper_controller']=gripper
        self.tracking[RIGHT]=self.tracking.pop('left')
        self.tracking[RIGHT]['gripper_opening']=.1
        self.cfg.robot_names=[RIGHT]
        self.cfg.task_metadata=copy.deepcopy(DATA['task_metadata'])
        self.spec=copy.deepcopy(DATA['phase']);self.phase_specs=[self.spec]
        self.phase=self.spec['name'];self.phase_index=53;self.phase_entry_step=29681
        self.step_counter=29693;self.phase_step_counter=12
        self.effects=[];self.hold_valid=True;self.force=8.
        self._locked_targets={};self._lock_pin_pose={};self._attachment_joints={}
        self._local_skill_completions={}
        self._record_object_pose_history=lambda:None
        self._check_object_state_sanity=lambda:None
        self._as_list=lambda v: [] if v is None else v if isinstance(v,list) else [v]
        self._extract_object_name=lambda v: v.get('object') if isinstance(v,dict) else v
        self._current_gripper_command=lambda ph,r:ph.get('gripper_commands',{}).get(r)
        # Physical readiness is a test input; the release timing/ownership
        # consumers themselves are the unchanged production methods.
        self._pure_physical_release_ready=lambda o,s: s['robot_name']==LEFT and self.phase_step_counter>=12
        self._physical_hold_valid=lambda *a,**kw:self.hold_valid
        self._remove_attachment_joint=lambda o:self.effects.append(('remove_joint',o))
        self._set_object_collision=lambda o,v:self.effects.append(('collision',o,v))
        self._zero_object_velocity=lambda o:self.effects.append(('zero_velocity',o))
        self._set_object_pose=lambda *a:self.effects.append(('set_pose',))
        self._set_object_kinematic_enabled=lambda *a:self.effects.append(('set_kinematic',))
        self._gripper_contact_metrics=lambda *a,**kw:{s:{'force_probe_valid':True,'force':self.force,
            'force_observation':{'physics_dt':1/240}} for s in ('left_finger','right_finger')}
        self.left=self.state(LEFT,15025);self.right=self.state(RIGHT,29610)
        self._store_physical_grasp(OBJECT,self.left);self._store_physical_grasp(OBJECT,self.right)
        self._ur5e_contact_hold_commands={RIGHT:{'object':OBJECT,'arm_q':self.subset.q.copy(),
            'pose':copy.deepcopy(self.tracking[RIGHT]),'gripper_openness':.1}}

    @staticmethod
    def state(robot,step):
        return {'robot_name':robot,'mode':'pure_physical_grasp','attach_step':step,
            'position':[.001,.002,.003],'orientation':[1.,0.,0.,0.],
            'grasp_reference':{'capture_step':step,'frozen_material_point':[.01,0.,0.]},
            'attach_spec':{'allow_shared_physical_grasp':True,'continuous_physics':True,
                'hold_force_regulation':True,'contact_force_threshold':.1,'close_force_limit':40.,
                'close_force_low':4.,'close_force_high':12.,'close_force_joint_rate':.025}}

    def get_tracked_object_states(self):
        state=self._attachments.get(OBJECT)
        return {OBJECT:{'attached_to':None if state is None else state['robot_name'],
                        'grasped_by':None if state is None else state['robot_name'],
                        'status':'free' if state is None else 'grasped_physical'}}

    def repeat_release(self,until=13):
        for step in range(12,until+1):
            self.phase_step_counter=step;self.step_counter=self.phase_entry_step+step
            self._process_phase_interactions(self.spec)


class SelectiveRelease(unittest.TestCase):
    def setUp(self):
        env=patch.dict(os.environ,{'BEAM_IDLE_HOLD_ANCHOR':'1'},clear=True)
        env.start();self.addCleanup(env.stop)

    def test_legacy_repeated_phase_release_reproduces_downstream_failure(self):
        t=ReplayTask();t._detach_object=LEGACY.__get__(t)
        t.repeat_release(12)
        self.assertIs(t._attachments[OBJECT],t.right)
        t.repeat_release(13)
        self.assertIsNone(t._attachment_for(OBJECT,RIGHT))
        Policy().act(t)
        self.assertTrue(t.failed)
        self.assertEqual(t.terminal_reason,DATA['failure']['reason'])

    def test_repeat_preserves_anchor_cache_and_reaches_real_policy_command(self):
        t=ReplayTask();before=copy.deepcopy(t.right);saved=t._ur5e_contact_hold_commands[RIGHT]
        original_arm=saved['arm_q'].copy();t.repeat_release(100)
        self.assertIs(t._attachments[OBJECT],t.right)
        self.assertEqual(t.right,before)
        self.assertIs(t._ur5e_contact_hold_commands[RIGHT],saved)
        p=Policy()
        with patch.object(p,'_compose_robot_action',side_effect=AssertionError('unexpected native fallback')):
            action=p.act(t)[RIGHT]
        self.assertFalse(t.failed)
        self.assertEqual(p.local_skill_diagnostics[-1]['reason'],'adapter_action')
        np.testing.assert_array_equal(action['arm_joint_controller'][0],original_arm)
        self.assertIn('gripper_controller',action)
        self.assertEqual(t.effects,[])

    def test_release_gate_still_waits_for_minimum_steps(self):
        t=ReplayTask();t.phase_step_counter=11;t._process_phase_interactions(t.spec)
        self.assertIs(t._attachment_for(OBJECT,LEFT),t.left)

    def test_secondary_repeated_release_keeps_primary(self):
        t=ReplayTask()
        for _ in range(3):t._detach_object(OBJECT,{'robot':RIGHT})
        self.assertIs(t._attachments[OBJECT],t.left)
        self.assertEqual(t.effects,[])

    def test_absent_or_unknown_named_hand_is_noop_for_all_modes(self):
        for mode in ['pure_physical_grasp','fixed_joint','physical_hold']:
            t=ReplayTask();t.left['mode']=mode
            before=copy.deepcopy((t._attachments,t._beam_shared_grasps))
            t._detach_object(OBJECT,{'robot':'unknown'})
            self.assertEqual((t._attachments,t._beam_shared_grasps),before)
            self.assertEqual(t.effects,[])

    def test_named_final_shared_holder_detaches_without_physical_writes(self):
        t=ReplayTask();t.repeat_release();t._detach_object(OBJECT,{'robot':RIGHT})
        t._detach_object(OBJECT,{'robot':RIGHT})
        self.assertEqual(t._attachments,{})
        self.assertEqual(t._beam_shared_grasps,{})
        self.assertEqual(t.effects,[])

    def test_single_holder_repeat_eliminates_legacy_zero_velocity_call(self):
        old=ReplayTask();old._beam_shared_grasps={};old._detach_object=LEGACY.__get__(old)
        old.repeat_release()
        self.assertIn(('zero_velocity',OBJECT),old.effects)
        new=ReplayTask();new._beam_shared_grasps={};new.repeat_release(100)
        self.assertEqual(new._attachments,{})
        self.assertEqual(new.effects,[])

    def test_all_eight_compiled_named_release_sites_preserve_only_survivor(self):
        self.assertEqual(len(DATA['all_detach_sites']),8)
        for site in DATA['all_detach_sites']:
            for survivor in (False,True):
                with self.subTest(phase=site['phase'],survivor=survivor):
                    t=ReplayTask();entry=site['detach'][0];obj=entry['object'];robot=entry['robot']
                    other=RIGHT if robot==LEFT else LEFT
                    primary=t.state(robot,10);secondary=t.state(other,20)
                    t._attachments={obj:primary};t._beam_shared_grasps={}
                    if survivor:t._beam_shared_grasps[(obj,other)]=secondary
                    t._pure_physical_release_ready=lambda *a:True
                    t._current_gripper_command=lambda *a:'open'
                    phase={'name':site['phase'],'detach':copy.deepcopy(site['detach'])}
                    for _ in range(3):t._process_phase_interactions(phase)
                    self.assertIs(t._attachments.get(obj),secondary if survivor else None)
                    self.assertEqual(t.effects,[])

    def test_unscoped_legacy_fixed_release_keeps_legacy_cleanup(self):
        t=ReplayTask();t._beam_shared_grasps={};t.left['mode']='fixed_joint'
        t.left['attach_spec']={};t._detach_object(OBJECT)
        self.assertIsNone(t._attachments.get(OBJECT))
        self.assertIn(('remove_joint',OBJECT),t.effects)
        self.assertIn(('zero_velocity',OBJECT),t.effects)

    def test_named_nonshared_release_still_clears_actual_holder(self):
        t=ReplayTask();t._beam_shared_grasps={};t.left['attach_spec']={'continuous_physics':True}
        t._detach_object(OBJECT,{'robot':LEFT})
        self.assertIsNone(t._attachments.get(OBJECT))
        self.assertNotIn(('zero_velocity',OBJECT),t.effects)

    def test_unrelated_object_is_untouched(self):
        t=ReplayTask();other=t.state(LEFT,7);t._attachments['other']=other
        t.repeat_release(100);self.assertIs(t._attachments['other'],other)

    def test_missing_survivor_is_not_invented_by_repeated_release(self):
        t=ReplayTask();t._beam_shared_grasps={};t.repeat_release()
        Policy().act(t);self.assertTrue(t.failed)
        self.assertEqual(t.terminal_reason,'local-skill-failure:held_object_not_grasped')

    def test_invalid_surviving_hold_is_still_rejected_by_actual_adapter(self):
        t=ReplayTask();t.repeat_release();t.hold_valid=False
        Policy().act(t);self.assertTrue(t.failed)
        self.assertEqual(t.terminal_reason,'local-skill-failure:held_object_not_grasped')

    def test_force_hard_limit_is_not_bypassed_by_surviving_ownership(self):
        t=ReplayTask();t.repeat_release();t.force=80.
        Policy().act(t);self.assertTrue(t.failed)
        self.assertEqual(t.terminal_reason,'local-skill-failure:loaded_gripper_force_limit')

    def test_state_sync_removes_invalid_survivor_and_cached_command(self):
        t=ReplayTask();t.repeat_release();t.hold_valid=False;t._sync_object_states()
        self.assertIsNone(t._attachment_for(OBJECT,RIGHT))
        self.assertNotIn(RIGHT,t._ur5e_contact_hold_commands)

    @staticmethod
    def compiled_phases():
        # This path is generated by the real worker/preflight in qualification;
        # the recorded fixture is deliberately not a replacement for it.
        return json.loads(COMPILED_WORKER_CONFIG.read_text())['phase_specs']

    def test_compiled_release_robots_match_actual_open_commands(self):
        sites=[p for p in self.compiled_phases() if p.get('detach')]
        self.assertEqual(len(sites),8)
        for phase in sites:
            for entry in phase['detach']:
                self.assertIsInstance(entry,dict)
                robot=entry.get('robot');self.assertIsNotNone(robot)
                self.assertEqual(phase['gripper_commands'][robot],'open')
                for other,command in phase['gripper_commands'].items():
                    if other!=robot:self.assertNotEqual(command,'open')

    def test_compiled_phases_exclude_unnamed_detach_and_clear_paths(self):
        attachments=[]
        for phase in self.compiled_phases():
            for key in ['lock','unlock_after_steps','handoff','transfer']:
                self.assertFalse(phase.get(key),(phase['name'],key))
            for entry in phase.get('detach',[]):
                self.assertIsInstance(entry,dict)
                self.assertIsNotNone(entry.get('robot'))
            attachments.extend(phase.get('attach',[]))
        self.assertTrue(attachments)
        for entry in attachments:
            self.assertTrue(entry.get('continuous_physics'))
            self.assertTrue(entry.get('allow_shared_physical_grasp'))

    def test_compiled_R45_single_right_release_has_no_repeated_writes(self):
        phase=next(p for p in self.compiled_phases() if p['name']=='hold_6_to_3_switch_release')
        entry=phase['detach'][0];self.assertEqual(entry['robot'],RIGHT)
        t=ReplayTask();t.spec=copy.deepcopy(phase)
        t._attachments={entry['object']:t.state(RIGHT,10)};t._beam_shared_grasps={}
        t._pure_physical_release_ready=lambda *args:True
        for step in range(12,113):
            t.phase_step_counter=step;t._process_phase_interactions(t.spec)
        self.assertEqual(t._attachments,{})
        self.assertEqual(t.effects,[])


if __name__=='__main__':unittest.main()

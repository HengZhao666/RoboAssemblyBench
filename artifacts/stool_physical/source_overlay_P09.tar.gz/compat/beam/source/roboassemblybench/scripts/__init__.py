"""Script entrypoints for RoboAssemblyBench."""

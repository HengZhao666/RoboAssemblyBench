"""Actual task methods on recorded native inputs; no new physical response claim."""
import copy
import json
import os
from pathlib import Path
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

import numpy as np

from internutopia_extension.tasks.factory_dual_franka_assembly_task import FactoryDualFrankaAssemblyTask as Task
from toolkits.factory_dual_franka_assembly.physical_grasp_reference import (
    capture_grasp_reference, measure_grasp_point_slip,
)
from toolkits.factory_dual_franka_assembly.planner_primitives import quat_rotate, quat_multiply
from toolkits.factory_dual_franka_assembly.plumbers_block_ur5e_skills import UR5eAssemblyAtomicSkillAdapter as Adapter

DATA = json.loads((Path(__file__).parent/'fixtures/beam_v201_v203_reference.json').read_text())


class FrozenPoint(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ, BEAM_CONTACT_TRACE_PATH='', BEAM_HOLD_TRACE_PATH='',
                              DUAL_FRANKA_ATTACH_DEBUG_PATH='')
        self.env.start()
        self.addCleanup(self.env.stop)
        self.row = copy.deepcopy(DATA['capture_record'])
        self.spec = dict(copy.deepcopy(DATA['attach_spec']), hold_position_slip_reference='grasp_point')
        self.object, self.robot = self.spec['object'], self.spec['robot']
        self.task = object.__new__(Task)
        task = self.task
        task._attachments, task._beam_shared_grasps = {}, {}
        task._locked_collision_states, task._locked_targets, task._frozen_lock_poses = {}, {}, {}
        task._object_metadata_map = {self.object:{'scale':self.spec['contact_box_scale']}}
        task.step_counter, task.phase = self.row['step'], self.row['phase']
        self.attach_debug=[]
        task._maybe_write_attach_debug=lambda payload:self.attach_debug.append(payload)
        config = NS(gripper_open_position=0., gripper_closed_position=.8)
        controller = NS(get_obs=lambda: {'gripper_pos':[self.row['gripper_q']]})
        task.robots = {self.robot:NS(config=config,controllers={'gripper_controller':controller})}
        target = self.row['contact_metrics']['left_finger']['force_observation']['other_body']
        body = NS(get_pose=lambda: (np.array(self.row['object_position']),np.array(self.row['object_orientation'])),
                  unwrap=lambda: NS(prim_path=target))
        task._resolve_object = lambda name: body
        task._get_robot_task_pose = lambda name: (np.array(self.row['tcp_position']),np.array(self.row['tcp_orientation']))
        task._gripper_contact_metrics = lambda *a,**kw: self.recorded_metrics()
        def forbidden(*args, **kwargs):
            raise AssertionError('Pure grasp registration wrote physical state or created a joint')
        task._set_object_pose = task._zero_object_velocity = task._set_object_collision = forbidden
        task._create_attachment_joint = forbidden

    def recorded_metrics(self):
        metrics=copy.deepcopy(self.row['contact_metrics'])
        # Native JSONL keeps the selected strict sample points but omits the
        # full per-finger sample array. Restore only those measured points and
        # recompute their geometry through the real production helper.
        pair=self.row['strict_contact'].get('strict_sample_pair')
        if pair:
            for side,key in [('left_finger','left_local_point'),('right_finger','right_local_point')]:
                local=self.task._local_surface_contact_metrics(np.array(pair[key]),
                    half_extents=np.array(metrics['contact_box_scale'])/2,
                    contact_distance=self.spec['finger_contact_distance'])
                metrics[side]['sample_contacts']=[{'local_contact':local}]
        return metrics

    def attach(self):
        self.task._attach_object(self.object,self.robot,phase_spec={'name':self.row['phase']},attach_spec=self.spec)
        return self.task._attachment_for(self.object,self.robot)

    def advance_to_failure(self):
        self.row = copy.deepcopy(DATA['failure_record'])
        self.task.step_counter,self.task.phase = self.row['step'],self.row['phase']

    def test_real_registration_preserves_transport_anchor_and_measures_one_fixed_point(self):
        state = self.attach()
        self.assertIsNotNone(state,self.attach_debug)
        np.testing.assert_allclose(state['position'],DATA['frozen_reference']['object_origin_in_tcp_at_attach'],atol=1e-12)
        self.assertIsNone(state['joint_path'])
        self.advance_to_failure()
        self.assertTrue(self.task._physical_hold_valid(self.object,state))
        record = state['last_hold_validation']
        self.assertAlmostEqual(record['position_slip'],.00007005719499429013,places=11)
        self.assertAlmostEqual(record['object_origin_position_slip'],.004183647547069569,places=11)
        self.assertEqual(record['grasp_reference_capture_step'],14942)

    def test_legacy_origin_contract_still_rejects_the_original_failure(self):
        self.spec.pop('hold_position_slip_reference')
        state = self.attach()
        self.advance_to_failure()
        self.assertFalse(self.task._physical_hold_valid(self.object,state))
        self.assertIn('position_slip',state['last_hold_validation']['reasons'])

    def test_real_translation_cannot_hide_behind_good_recorded_contact(self):
        state = self.attach()
        position,orientation = self.task._current_relative_pose(self.object,self.robot)
        self.task._current_relative_pose = lambda *a: (position+np.array([.005,0,0]),orientation)
        self.assertFalse(self.task._physical_hold_valid(self.object,state))
        self.assertIn('position_slip',state['last_hold_validation']['reasons'])

    def test_rotation_limit_remains_even_when_the_material_point_does_not_move(self):
        state = self.attach()
        reference = state['hold_grasp_reference']
        angle = .10
        orientation = quat_multiply(reference['object_orientation_in_tcp_at_attach'],
                                    [np.cos(angle/2),0,0,np.sin(angle/2)])
        position = np.array(reference['point_in_tcp_at_attach'])-quat_rotate(orientation,reference['point_in_object'])
        self.task._current_relative_pose = lambda *a: (position,orientation)
        self.assertFalse(self.task._physical_hold_valid(self.object,state))
        self.assertIn('orientation_slip',state['last_hold_validation']['reasons'])

    def test_repeated_registration_never_refreshes_reference_or_missing_reference(self):
        state = self.attach()
        original = copy.deepcopy(state)
        self.advance_to_failure()
        self.attach()
        self.assertEqual(state['hold_grasp_reference'],original['hold_grasp_reference'])
        self.assertEqual(state['position'],original['position'])
        state.pop('hold_grasp_reference')
        self.attach()
        self.assertNotIn('hold_grasp_reference',state)
        self.assertFalse(self.task._physical_hold_valid(self.object,state))
        self.assertIn('grasp_reference_invalid',state['last_hold_validation']['reasons'])

    def test_registration_rejects_missing_truncated_or_wrong_target_contacts(self):
        for change in [('details_valid',False),('details_at_capacity',True),('other_body','wrong'),('contacts',[])]:
            with self.subTest(change=change):
                self.row = copy.deepcopy(DATA['capture_record'])
                self.row['contact_metrics']['left_finger']['force_observation'][change[0]]=change[1]
                self.assertIsNone(self.attach())

    def test_current_contact_centroid_cannot_move_the_frozen_reference(self):
        state = self.attach()
        frozen = copy.deepcopy(state['hold_grasp_reference'])
        for side in ['left_finger','right_finger']:
            for contact in self.row['contact_metrics'][side]['force_observation']['contacts']:
                contact['point_world'][0]+=.001
        self.assertTrue(self.task._physical_hold_valid(self.object,state))
        self.assertEqual(state['hold_grasp_reference'],frozen)


class SingleContact(unittest.TestCase):
    def run_confirmation(self, full, left=0.,right=9.):
        recorded = DATA['v203_close_failure']
        spec = dict(recorded['phase_spec']['local_skill'],close_force_recenter_single_contact_full_step=full)
        metrics = copy.deepcopy(recorded['failure']['contact_detail']['contact_metrics'])
        for side,force in [('left_finger',left),('right_finger',right)]:
            metrics[side]['force']=force
        state = dict(close_tcp_position_world=np.array(recorded['recenter_lifecycle'][0]['motion_start_position_world']))
        result = None
        # Steady recorded contact-frame boundary: tests classification and
        # planned targets only; these four calls do not model engine motion.
        for tick in range(4):
            state['force_recenter_observation_step']=tick
            result=Adapter._update_force_recenter(state=state,metrics=metrics,spec=spec)
        return result,state,spec

    def test_true_single_contact_uses_published_200um_classification(self):
        old,_,_=self.run_confirmation(False)
        new,state,_=self.run_confirmation(True)
        self.assertEqual(old['motion_mode'],'force_margin')
        self.assertAlmostEqual(np.linalg.norm(old['motion_delta_world']),.000025)
        self.assertEqual(new['motion_mode'],'single_contact')
        self.assertAlmostEqual(np.linalg.norm(new['motion_delta_world']),.0002)
        self.assertEqual(state['force_recenter_pending']['lifecycle'],'planned')
        self.assertGreater(np.dot(old['motion_delta_world'],new['motion_delta_world']),0)

    def test_two_loaded_finger_balance_retains_25um_step(self):
        result,_,_=self.run_confirmation(True,left=1.,right=9.)
        self.assertEqual(result['motion_mode'],'force_margin')
        self.assertAlmostEqual(np.linalg.norm(result['motion_delta_world']),.000025)

    def test_soft_and_hard_peak_limits_never_issue_a_correction(self):
        for peak in [13.,40.,45.]:
            result,state,_=self.run_confirmation(True,right=peak)
            self.assertFalse(result['updated'])
            self.assertNotIn('force_recenter_pending',state)

    def test_unperformed_or_opposite_motion_cannot_acknowledge_a_200um_move(self):
        _,state,_=self.run_confirmation(True)
        pending=state['force_recenter_pending']
        pending['lifecycle']='final_action_issued'
        start=np.array(pending['motion_start_position_world']);delta=np.array(pending['motion_delta_world'])
        for current,expected in [(start,False),(start-delta,False),(start+delta,True)]:
            ready,_=Adapter._recenter_motion_ready(pending=pending,current_position=current,
                                                  overall_pose_ready=True,tolerance=.0001)
            self.assertEqual(ready,expected)


class GripperUnits(unittest.TestCase):
    def check(self,measured,opened=0.,closed=.8):
        task=object.__new__(Task)
        task.phase_step_counter=24
        task.robots={'right':NS(config=NS(gripper_open_position=opened,gripper_closed_position=closed),
                    controllers={'gripper_controller':NS(get_obs=lambda:{'gripper_pos':[measured]})})}
        return task._evaluate_advance_condition(phase_spec={},advance=dict(type='gripper_open',robot='right',minimum_openness=.95))

    def test_robotiq_open_and_recorded_closed_joint_positions_use_normalized_units(self):
        self.assertTrue(self.check(0.))
        self.assertFalse(self.check(DATA['v203_close_failure']['failure']['gripper_joint_position']))
        self.assertFalse(self.check(.8))

    def test_franka_opposite_joint_direction_is_normalized(self):
        self.assertTrue(self.check(.04,opened=.04,closed=0.))
        self.assertFalse(self.check(.02,opened=.04,closed=0.))

    def test_invalid_feedback_or_endpoints_cannot_pass(self):
        self.assertFalse(self.check(float('nan')))
        self.assertFalse(self.check(0.,opened=0.,closed=0.))


if __name__=='__main__':
    unittest.main()

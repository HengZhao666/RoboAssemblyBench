"""Synthetic production triangle checker regressions; never a worker/native proof."""
from pathlib import Path
from types import SimpleNamespace
import itertools,json
import numpy as np
import fcl
from stool_geometry_guard import StoolMeshGuard


def box_mesh(name,body,robot=None):
    p=np.array(list(itertools.product(*[[-.01,.01]]*3)),float)
    f=np.array([[0,1,3],[0,3,2],[4,6,7],[4,7,5],[0,4,5],[0,5,1],[2,3,7],[2,7,6],[0,2,6],[0,6,4],[1,5,7],[1,7,3]],np.int32)
    return dict(prim=body+'/mesh',body=body,robot=robot,object=name),p,f


def probe(a,b,*,distance=.1,phase=None,attached=None,initial=False,cad_pinch=False):
    checker=StoolMeshGuard.__new__(StoolMeshGuard);checker.fcl=fcl
    checker.meshes=[];checker.shapes=[];corners=[]
    checker.pairs=[(0,1)];checker.indices=np.array([[0,1]])
    checker.objects={'part_a','part_b','part_c'};checker.initial_support={}
    checker.support_object_names={'fabrica_fixture','optical_board','factory_tabletop_visual'}
    checker.contract={'assembly_contact_pairs':[['part_a','part_b']]}
    if cad_pinch:checker.contract['cad_pinch']={'schema':'stool_visible_pad_near_fit_v1'}
    checker.task=SimpleNamespace(get_current_phase_spec=lambda:phase or {},_attachments=attached or {})
    poses={}
    for index,args in enumerate((a,b)):
        mesh,p,f=box_mesh(*args);shape=fcl.BVHModel();shape.beginModel(len(f),len(p));shape.addSubModel(p,f);shape.endModel()
        checker.meshes.append(mesh);checker.shapes.append(fcl.CollisionObject(shape));corners.append(p)
        pose=np.eye(4);pose[0,3]=distance*index;poses[mesh['body']]=pose
    checker.corners=np.asarray(corners)
    return checker._check_scene(poses,initial=initial)


def main():
    cases=[]
    def expect(name,result,collision):
        observed=bool(result['collisions']);assert observed is collision,(name,result)
        cases.append(dict(name=name,expected_collision=collision,observed_collision=observed,allowed=result['allowed_contacts']))
    part=('part_a','/part_a',None)
    expect('separated_safe',probe(part,('part_c','/part_c',None)),False)
    expect('dangerous_part_overlap',probe(part,('part_c','/part_c',None),distance=.005),True)
    expect('unknown_background_overlap',probe(part,('warehouse','/obstacle',None),distance=.005,initial=True),True)
    expect('exact_initial_fixture_support',probe(part,('fabrica_fixture','/fixture',None),distance=.005,initial=True),False)
    expect('socket_pair_outside_insertion',probe(part,('part_b','/part_b',None),distance=.005),True)
    phase=dict(name='assemble_a_insert_00',local_skill=dict(object='part_a',robot='franka_left'))
    expect('exact_catalog_socket_in_insertion',probe(part,('part_b','/part_b',None),distance=.005,phase=phase),False)
    phase=dict(name='assemble_a_close_gripper',local_skill=dict(object='part_a',robot='franka_left'))
    expect('exact_inner_finger_contact',probe(part,(None,'/robot/left_inner_finger','franka_left'),distance=.005,phase=phase),False)
    expect('outer_link_not_a_contact_exemption',probe(part,(None,'/robot/left_outer_knuckle','franka_left'),distance=.005,phase=phase),True)
    expect('other_arm_not_exempted',probe(part,(None,'/robot/right_inner_finger','franka_right'),distance=.005,phase=phase),True)
    finger=(None,'/robot/left_inner_finger','franka_left')
    expect('CAD_close_finger_body_overlap_rejected',probe(part,finger,distance=.005,phase=phase,cad_pinch=True),True)
    expect('CAD_held_finger_body_overlap_rejected',probe(part,finger,distance=.005,
        attached={'part_a':{'robot_name':'franka_left'}},cad_pinch=True),True)
    expect('CAD_close_positive_near_gap',probe(part,finger,distance=.020125,phase=phase,cad_pinch=True),False)
    report=dict(passed=True,cases=cases,native_physics_executed=0,
        scope='synthetic box triangles through actual production FCL/checker; separate from actual worker/scene/native verification')
    print(json.dumps(report))

if __name__=='__main__':main()

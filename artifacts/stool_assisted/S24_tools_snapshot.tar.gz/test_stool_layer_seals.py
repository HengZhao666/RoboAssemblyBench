"""Mocked USD-layer retention tests; no simulator construction or physics."""
from pathlib import Path
import hashlib,json,tempfile
from types import SimpleNamespace
from stool_export_geometry import seal_composed_layers,LayerSealError

STAMP=dict(valid=True,epoch=0,index=12,time=.25,dt=1/48)


class Layer:
    def __init__(self,identifier,real_path='',text='#usda 1.0\n'):
        self.identifier=identifier;self.realPath=real_path;self.text=text;self.exports=0
    def ExportToString(self):self.exports+=1;return self.text


def main():
    checks=[]
    def check(name,predicate):assert predicate,name;checks.append(dict(name=name,passed=True))
    with tempfile.TemporaryDirectory(prefix='stool_layer_seal_test_') as temporary:
        root=Path(temporary);local=root/'original.usdc';payload=b'PXR-USDC\x00unchanged_local_original_bytes'
        local.write_bytes(payload)
        original=Layer(str(local),str(local),text='must_not_export_local_layer')
        anonymous=Layer('anon:0x123:runtime-session.usda',text='#usda 1.0\ndef Xform "Runtime" {}\n')
        remote=Layer('https://example.invalid/robot.usd',text='#usda 1.0\ndef Xform "Robot" {}\n')
        stage=SimpleNamespace(GetUsedLayers=lambda:[remote,original,anonymous])
        out=root/'run';receipt=seal_composed_layers(stage,out,lambda:dict(STAMP))
        rows={row['identifier']:row for row in receipt['layers']}
        check('all_three_actual_used_layers_sealed',receipt['passed'] and len(rows)==3 and all(row['sha256'] for row in rows.values()))
        row=rows[str(local)]
        check('local_original_sha_unchanged',row['sha256']==hashlib.sha256(payload).hexdigest() and local.read_bytes()==payload and original.exports==0)
        for layer,label in [(anonymous,'anonymous'),(remote,'remote')]:
            row=rows[layer.identifier];retained=Path(row['resolved_path'])
            check(label+'_retained_under_run_asset_layers',retained.parent==(out/'asset_layers').resolve() and retained.is_absolute())
            check(label+'_actual_exported_bytes_and_sha',retained.read_bytes()==layer.text.encode() and row['sha256']==hashlib.sha256(retained.read_bytes()).hexdigest())
            check(label+'_original_identifier_and_honest_scope',row['identifier']==layer.identifier and row['seal_status']=='captured_composed_layer_text' and 'not original remote/anonymous file bytes' in row['seal_scope'])
        check('read_only_clock_bound',receipt['physics_stamp_before']==receipt['physics_stamp_after']==STAMP and receipt['native_clock_unchanged'])
        second=seal_composed_layers(stage,out,lambda:dict(STAMP))
        check('identical_retention_reused_without_overwrite',second['layers']==receipt['layers'])
        retained_before={p:p.read_bytes() for p in (out/'asset_layers').iterdir()}
        remote.text+='# changed later\n'
        try:seal_composed_layers(stage,out,lambda:dict(STAMP));check('changed_retained_content_rejected',False)
        except LayerSealError as exc:check('changed_retained_content_rejected',not exc.report['passed'] and 'different content' in exc.report['error'])
        check('original_retained_evidence_preserved',all(p.read_bytes()==content for p,content in retained_before.items()))
        check('partial_failure_receipt_saved',not json.loads((out/'asset_layer_seal_receipt.json').read_text())['passed'])
        stamps=iter([dict(STAMP),dict(STAMP,index=13),dict(STAMP,index=13)])
        try:seal_composed_layers(stage,root/'changed_clock',lambda:next(stamps));check('native_clock_change_rejected',False)
        except LayerSealError as exc:check('native_clock_change_rejected',not exc.report['native_clock_unchanged'])
        broken=Layer('anon:empty',text='')
        try:seal_composed_layers(SimpleNamespace(GetUsedLayers=lambda:[broken]),root/'empty_export',lambda:dict(STAMP));check('empty_export_rejected',False)
        except LayerSealError as exc:check('empty_export_rejected','no canonical text' in exc.report['error'])
        try:seal_composed_layers(stage,root/'invalid_native',lambda:dict(STAMP,valid=False));check('invalid_native_clock_rejected',False)
        except LayerSealError as exc:check('invalid_native_clock_rejected','native clock unavailable' in exc.report['error'])
    print(json.dumps(dict(passed=True,count=len(checks),cases=checks,native_physics_executed=0,
        scope='mocked used-layer objects through production capture function; exact retained byte/hash and failure-preservation assertions')))

if __name__=='__main__':main()

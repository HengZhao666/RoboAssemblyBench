"""Undeployed exact-query cache candidate for offline stool CAD equivalence.

The live stool_geometry_guard.py is unchanged. Only deterministic FCL hit/depth
queries may be reused within one guard call. Every scene/sample/pair AABB check,
shape transform publication and phase/contact classification still executes.
"""
from __future__ import annotations
from contextlib import contextmanager
import numpy as np
from stool_geometry_guard import StoolMeshGuard


class ExactPairCacheStoolMeshGuard(StoolMeshGuard):
    @contextmanager
    def exact_pair_cache_scope(self):
        """A fresh exact cache for one action/support call; never across ticks."""
        previous=getattr(self,'_exact_pair_scope',None)
        scope=dict(cache={},hits=0,misses=0,selected_pair_queries=0,scene_samples=0)
        self._exact_pair_scope=scope
        try:yield scope
        finally:
            self.last_exact_pair_cache_stats={key:value for key,value in scope.items() if key!='cache'}
            self.last_exact_pair_cache_stats['stored_entries']=len(scope['cache'])
            self._exact_pair_scope=previous

    def __call__(self,actions):
        with self.exact_pair_cache_scope():return super().__call__(actions)

    def support_guard(self,name,position,orientation,stamp):
        with self.exact_pair_cache_scope():return super().support_guard(name,position,orientation,stamp)

    def _exact_hit_depth(self,index,i,j,transforms):
        scope=self._exact_pair_scope
        # Include complete input transforms, including the homogeneous row.
        # No rounding, pose tolerance, relative transform, or phase key is used.
        key=(int(index),int(i),int(j),transforms.dtype.str,transforms.shape[1:],
            transforms[i].tobytes(order='C'),transforms[j].tobytes(order='C'))
        scope['selected_pair_queries']+=1
        if key in scope['cache']:
            scope['hits']+=1;return scope['cache'][key]
        fcl=self.fcl;result=fcl.CollisionResult()
        hit=fcl.collide(self.shapes[i],self.shapes[j],
            fcl.CollisionRequest(num_max_contacts=8,enable_contact=True),result)
        depth=max((float(c.penetration_depth) for c in result.contacts),default=0.) if hit else 0.
        value=(int(hit),depth);scope['cache'][key]=value;scope['misses']+=1
        return value

    def _check_scene(self,poses,*,initial=False):
        if getattr(self,'_exact_pair_scope',None) is None:
            # Constructor/initial support discovery uses the unchanged method.
            return super()._check_scene(poses,initial=initial)
        self._exact_pair_scope['scene_samples']+=1
        fcl=self.fcl;transforms=np.asarray([poses[m['body']] for m in self.meshes])
        world=np.einsum('nkj,nij->nki',self.corners,transforms[:,:3,:3])+transforms[:,:3,3][:,None,:]
        lo=world.min(axis=1);hi=world.max(axis=1);ii,jj=self.indices.T
        gaps=np.maximum(np.maximum(lo[ii]-hi[jj],lo[jj]-hi[ii]),0.)
        selected=np.flatnonzero(np.sum(gaps*gaps,axis=1)<=1e-12)
        for obj,t in zip(self.shapes,transforms):obj.setTransform(fcl.Transform(t[:3,:3],t[:3,3]))
        collisions=[];contacts=[]
        for index in selected:
            i,j=self.pairs[index];a,b=self.meshes[i],self.meshes[j]
            hit,depth=self._exact_hit_depth(index,i,j,transforms)
            if not hit:continue
            # Deliberately re-read task phase/attachments and reclassify every hit.
            reason=self._contact_reason(a,b,initial,depth)
            row=dict(mesh_a=a['prim'],mesh_b=b['prim'],body_a=a['body'],body_b=b['body'],depth_m=depth,
                allowed_contact_reason=reason)
            if reason:contacts.append(row)
            elif depth>1e-6:collisions.append(row)
        lower=np.sqrt(np.sum(gaps*gaps,axis=1))
        return dict(collisions=collisions,allowed_contacts=contacts,checked_pair_count=len(self.pairs),
            exact_overlap_candidates=len(selected),minimum_AABB_clearance_m=float(lower.min()) if len(lower) else None)

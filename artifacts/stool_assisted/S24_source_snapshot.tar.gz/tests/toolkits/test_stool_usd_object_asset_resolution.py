"""Exercise the actual object resolver without constructing a scene or simulator."""
import os
from pathlib import Path
import sys
import tempfile
from types import ModuleType
import unittest
from unittest.mock import patch

from internutopia_extension.objects.usd_object import UsdObject


class UsdObjectAssetResolutionTests(unittest.TestCase):
    def test_direct_remote_urls_are_preserved(self):
        for scheme in ('http', 'https', 'omniverse'):
            path = scheme + '://assets.example.test/Isaac/Props/part.usd'
            with self.subTest(scheme=scheme):
                self.assertEqual(UsdObject._resolve_usd_path(path), path)

    def test_remote_roots_and_both_isaac_suffix_forms_do_not_become_local_paths(self):
        for scheme in ('http', 'https', 'omniverse'):
            for root in (scheme + '://assets.example.test/Assets/5.1',
                         scheme + '://assets.example.test/Assets/5.1/'):
                for path in ('${ISAAC_ASSETS_ROOT}/Isaac/Props/part.usd', '/Isaac/Props/part.usd'):
                    with self.subTest(root=root, path=path), patch.dict(os.environ, ISAAC_ASSETS_ROOT=root):
                        self.assertEqual(UsdObject._resolve_usd_path(path),
                            scheme + '://assets.example.test/Assets/5.1/Isaac/Props/part.usd')

    def test_local_absolute_and_relative_files_remain_valid(self):
        with tempfile.TemporaryDirectory() as directory:
            asset = Path(directory) / 'part.usd'
            asset.write_text('#usda 1.0\n')
            self.assertEqual(UsdObject._resolve_usd_path(str(asset)), str(asset.resolve()))
            self.assertEqual(UsdObject._resolve_usd_path(os.path.relpath(asset)), str(asset.resolve()))

    def test_local_asset_roots_validate_both_suffix_forms(self):
        with tempfile.TemporaryDirectory() as directory:
            asset = Path(directory) / 'Isaac' / 'Props' / 'part.usd'
            asset.parent.mkdir(parents=True)
            asset.write_text('#usda 1.0\n')
            with patch.dict(os.environ, ISAAC_ASSETS_ROOT=directory):
                for path in ('${ISAAC_ASSETS_ROOT}/Isaac/Props/part.usd', '/Isaac/Props/part.usd'):
                    self.assertEqual(UsdObject._resolve_usd_path(path), str(asset.resolve()))

    def test_real_tilde_expansion_for_file_and_root(self):
        with tempfile.TemporaryDirectory() as directory:
            asset = Path(directory) / 'Isaac' / 'Props' / 'part.usd'
            asset.parent.mkdir(parents=True)
            asset.write_text('#usda 1.0\n')
            # A relative traversal allows this real expanduser test to write
            # only in the system temporary folder, including sandboxed runs.
            home = os.path.expanduser('~')
            file_tilde = '~/' + os.path.relpath(asset, home)
            root_tilde = '~/' + os.path.relpath(directory, home)
            self.assertEqual(UsdObject._resolve_usd_path(file_tilde), str(asset.resolve()))
            with patch.dict(os.environ, ISAAC_ASSETS_ROOT=root_tilde):
                self.assertEqual(UsdObject._resolve_usd_path('/Isaac/Props/part.usd'), str(asset.resolve()))

    def test_missing_local_files_are_still_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            missing = str(Path(directory) / 'missing.usd')
            with self.assertRaisesRegex(FileNotFoundError, 'Object USD asset does not exist'):
                UsdObject._resolve_usd_path(missing)
            with patch.dict(os.environ, ISAAC_ASSETS_ROOT=directory):
                with self.assertRaisesRegex(FileNotFoundError, 'configured as /Isaac/Props/missing.usd'):
                    UsdObject._resolve_usd_path('/Isaac/Props/missing.usd')

    def test_environment_root_expansion_matches_scene_resolver(self):
        with patch.dict(os.environ, STOOL_TEST_ASSET_HOST='https://assets.example.test',
                        ISAAC_ASSETS_ROOT='$STOOL_TEST_ASSET_HOST/Assets/5.1'):
            self.assertEqual(UsdObject._resolve_usd_path('/Isaac/Props/part.usd'),
                'https://assets.example.test/Assets/5.1/Isaac/Props/part.usd')

    def test_provider_remote_root_uses_actual_resolver_without_simulation(self):
        # Only the external storage provider is substituted. The production
        # UsdObject method and all path/filesystem operations execute normally.
        provider = ModuleType('isaacsim.storage.native')
        provider.get_assets_root_path = lambda: 'omniverse://assets.example.test/Assets/5.1'
        with patch.dict(os.environ, ISAAC_ASSETS_ROOT=''), patch.dict(sys.modules,
                {'isaacsim.storage.native': provider}):
            self.assertEqual(UsdObject._resolve_usd_path('/Isaac/Props/part.usd'),
                'omniverse://assets.example.test/Assets/5.1/Isaac/Props/part.usd')


if __name__ == '__main__':
    unittest.main()

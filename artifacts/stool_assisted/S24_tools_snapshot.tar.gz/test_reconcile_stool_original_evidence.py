"""Synthetic retained-summary/coverage-index tests; no audit or native run."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile


def main():
    path=Path(__file__).with_name('reconcile_stool_original_evidence.py')
    spec=importlib.util.spec_from_file_location('reconcile',path);tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool)
    checks=[]
    def check(name,value):assert value,name;checks.append(name)
    with tempfile.TemporaryDirectory(prefix='stool_reconciliation_') as temp:
        run=Path(temp)/'S03';run.mkdir()
        def save(name,value):(run/name).write_text(json.dumps(value))
        def lines(values):(run/'entity_geometry_trace.jsonl').write_text(''.join(json.dumps(v)+'\n' for v in values))
        robots={'franka_left':'/World/robots/left','franka_right':'/World/robots/right'}
        links=['Gripper/Robotiq_2F_85/'+name for name in ('base_link','left_outer_knuckle','left_outer_finger',
            'left_inner_finger','left_inner_knuckle','right_outer_knuckle','right_outer_finger','right_inner_finger','right_inner_knuckle')]
        gaps=[dict(root='/World/objects/object'+str(i),reason='no_enabled_supported_colliders') for i in range(10)]
        events=[];rows=[]
        for step in range(8,1113,8):
            event=dict(step=step,entity_a='franka_right/Gripper/Robotiq_2F_85/right_inner_knuckle',
                entity_b='fabrica_stool_circular_5',collider_a='/World/a/mesh',collider_b='/World/b/mesh',
                distance=-step/1e8,classification='collision',native_pair_impulse_verified=False)
            events.append(event);rows.append(dict(step=step,phase='synthetic_phase',events=[event],
                closest_nonexempt_pair=event,body_poses={'/World/a':[[1]]},
                pose_source='live_exact_robot_wrappers; existing_object_rigid_wrappers; static_xform; no_hold_validation_getter'))
        summary=dict(sampled_checks=len(rows),events=events[-5:],events_dropped_from_summary=len(events)-5,
            pair_minima=[events[-1]],minimum_nonexempt_pair=events[-1],missing=copy.deepcopy(gaps),
            skipped=[dict(prim=gaps[i]['root']+'/mesh',reason='collision_disabled') for i in range(4)])
        metrics=dict(success=False,failed=True,steps=1113,terminal_reason='synthetic_failure',
            phase_history=['synthetic_phase','failed'],runtime_constraint_monitor=dict(observed_steps=1113,
                checks=len(rows),check_stride=8,registered_robots=robots,entity_geometry=summary),
            assembly_sequence_precheck=dict(enabled=True,feasible=True),stage_trajectory_precheck=dict(
                frame_coverage={name:dict(missing_model_frames=links,gripper_articulation_swept=False) for name in robots},
                entity_geometry_coverage=dict(missing=copy.deepcopy(gaps),skipped=summary['skipped'])))
        meshes=[dict(prim=root+'/'+link+'/mesh',body=root+'/'+link,rendered=True,enabled_collider=True)
                for root in robots.values() for link in links]
        meshes += [dict(prim=g['root']+'/mesh',body=g['root'],rendered=True,enabled_collider=False) for g in gaps]
        scene=dict(visible_meshes=meshes,colliders=[],roots=[[g['root']] for g in gaps],gaps=[],
                   collision_inventory_gaps=dict(missing=[],skipped=summary['skipped']))
        save('scene_geometry.json',scene);save('formal_closure.json',{'closed':True})
        save('collect_results.json',[metrics]);save('independent_audit.json',{'accepted_full_assembly':False});lines(rows)
        original_hashes={p.name:tool.sha(p) for p in run.iterdir()}
        result=tool.reconcile(run)
        check('complete_stream_reconciles_capped_summary',result['checks']['uncapped_original_events_reconcile_with_capped_summary']['passed'] is True)
        check('index_keeps18gripper10objects_unresolved',result['original_coverage_evidence_index']['gripper_frame_count']==18
            and result['original_coverage_evidence_index']['object_root_count']==10
            and all(r['coverage_resolved'] is None for r in result['original_coverage_evidence_index']['object_roots'])
            and result['coverage_resolved'] is None)
        check('mesh_presence_never_proves_gripper_sweep',all(r['scene_visible_mesh_members']
            and r['complete_command_gripper_sweep_verified'] is None for r in result['original_coverage_evidence_index']['gripper_frames']))
        check('empty_exported_collider_list_never_proves_actual_absence',all(
            r['original_USD_collider_absence_verified'] is None
            for r in result['original_coverage_evidence_index']['object_roots']))
        witness=result['step1112_pair_event_index']
        check('step1112_candidate_index_keeps_native_and_CAD_unknown',witness['expected_pair_present']
            and witness['physical_classification_resolved'] is None
            and witness['events'][0]['own_native_stamp_recorded'] is False)
        check('all_original_files_unchanged',original_hashes=={p.name:tool.sha(p) for p in run.iterdir()})
        changed=copy.deepcopy(metrics);changed['runtime_constraint_monitor']['entity_geometry']['events_dropped_from_summary']+=1
        save('collect_results.json',[changed]);check('incorrect_summary_drop_count_rejects',tool.reconcile(run)['checks']['uncapped_original_events_reconcile_with_capped_summary']['passed'] is False)
        changed=copy.deepcopy(metrics);changed['runtime_constraint_monitor']['entity_geometry']['events'][0]['distance']=999
        save('collect_results.json',[changed]);check('altered_summary_suffix_rejects',tool.reconcile(run)['checks']['uncapped_original_events_reconcile_with_capped_summary']['passed'] is False)
        changed=copy.deepcopy(metrics)
        changed['runtime_constraint_monitor']['entity_geometry']['pair_minima']=copy.deepcopy(summary['pair_minima'])
        changed['runtime_constraint_monitor']['entity_geometry']['pair_minima'][0]['distance']=999
        save('collect_results.json',[changed]);check('altered_pair_minimum_rejects',tool.reconcile(run)['checks']['uncapped_original_events_reconcile_with_capped_summary']['passed'] is False)
        save('collect_results.json',[metrics]);lines(rows[:-1]);check('missing_uncapped_row_rejects',tool.reconcile(run)['checks']['uncapped_original_events_reconcile_with_capped_summary']['passed'] is False)
        wrong=copy.deepcopy(rows);wrong[4]['step']=wrong[3]['step'];lines(wrong)
        check('duplicated_or_reordered_native_step_rejects',tool.reconcile(run)['checks']['uncapped_original_events_reconcile_with_capped_summary']['passed'] is False)
        (run/'entity_geometry_trace.jsonl').unlink();check('missing_stream_is_null',tool.reconcile(run)['checks']['uncapped_original_events_reconcile_with_capped_summary']['passed'] is None)
        lines(rows);changed=copy.deepcopy(metrics)
        changed['runtime_constraint_monitor']['entity_geometry']['missing'].append({'prim':'/World/unknown','reason':'unsupported_collider_type'})
        save('collect_results.json',[changed]);unknown=tool.reconcile(run)['original_coverage_evidence_index']['unindexed_original_gaps']
        check('unrecognized_original_gap_preserved_without_waiver',len(unknown)==1 and unknown[0]['coverage_resolved'] is None)
        save('formal_closure.json',{'closed':False})
        check('active_run_cannot_claim_completed_input',tool.reconcile(run)['checks']['completed_original_report_identity']['passed'] is False)
    print(json.dumps(dict(passed=True,count=len(checks),checks=checks,
        scope='synthetic reconciliation only; original physics/coverage/assembly never approved'),indent=2))


if __name__=='__main__':main()

"""Real UR5e SDK normalization methods on controlled buffers; no simulator.

This verifies the native command boundary and legacy compatibility behavior.
It does not instantiate UR5e, call native SDK apply_action or validate motion.
"""
from types import MethodType, SimpleNamespace
from pathlib import Path
import argparse
import copy
import json
import math
import tempfile
import numpy as np

from internutopia_extension.robots.ur5e import UR5eRobot, _UR5E_ARM_JOINT_NAMES


def probe(preserve, values):
    measured = np.asarray(values, dtype=float).copy()
    writes = []
    articulation = SimpleNamespace(
        get_dof_index=lambda name: _UR5E_ARM_JOINT_NAMES.index(name),
        get_joint_positions=lambda joint_indices=None: measured.copy() if joint_indices is None else measured[joint_indices].copy(),
        set_joint_positions=lambda values, joint_indices=None: writes.append(('q', np.asarray(values).copy())),
        set_joint_velocities=lambda values, joint_indices=None: writes.append(('qd', np.asarray(values).copy())),
    )
    instance = SimpleNamespace(config=SimpleNamespace(preserve_continuous_arm_joints=preserve),
                               articulation=articulation)
    instance._bounded_revolute_joint_values = UR5eRobot._bounded_revolute_joint_values
    instance._current_arm_joint_positions_for_normalization = MethodType(
        UR5eRobot._current_arm_joint_positions_for_normalization, instance)
    return instance, writes


def snapshot_first_batch(geometry_path, worker_path):
    """Offline real policy/adapter/guard path on recorded q and body poses.

    The S02 snapshot has no native limit readback. Its limit callback is an
    explicit controlled fixture and is reported as such; no native SDK or
    nonzero FK/native equivalence is claimed by this replay.
    """
    from toolkits.factory_dual_franka_assembly.beam_assisted_state import BeamAssistedState
    from toolkits.factory_dual_franka_assembly.demo_policy import DualFrankaAssemblyDemoPolicy
    from toolkits.factory_dual_franka_assembly.plumbers_block_ur5e_skills import _quat_from_axes
    from stool_geometry_guard import StoolMeshGuard

    data = json.loads(geometry_path.read_text())
    configs = json.loads(worker_path.read_text())
    cfg = configs[0] if isinstance(configs, list) else configs
    phase = cfg['phase_specs'][0]
    contract = phase['fabrica_assisted_contract']
    assert contract == data['task_contract'], 'recorded geometry and compiled stool contract differ'
    pose_buffers = {name:np.asarray(value,float) for name,value in data['body_rest'].items()}
    tracked_objects = {}
    for name, bodies in data['object_body_coverage'].items():
        pose = pose_buffers[bodies[0]]
        tracked_objects[name] = dict(position=pose[:3,3],
            orientation=_quat_from_axes(*[pose[:3,i] for i in range(3)]))

    class Task(BeamAssistedState):
        def _beam_physics_stamp(self):
            return copy.deepcopy(data['physics_stamp'])
        def get_current_phase_spec(self):
            return phase
        def get_tracked_robot_states(self, **kwargs):
            return {}
        def get_tracked_object_states(self):
            return copy.deepcopy(tracked_objects)
        def _assisted_arm_joint_limits(self, name):
            return np.array([[-2*math.pi, 2*math.pi]]*6)
        def _assisted_event(self, event, **detail):
            self.events.append(dict(event=event, **detail))
        def _set_terminal_state(self, *args, **kwargs):
            raise AssertionError('actual first policy action failed offline: ' + repr((args,kwargs)))

    task = Task()
    task.config = task.cfg = SimpleNamespace(**cfg)
    task._fabrica_assisted_contract = contract
    task.phase_index=0;task.phase_entry_step=0;task.phase_step_counter=0
    task.phase=phase['name'];task.step_counter=0;task.events=[]
    task._attachments={};task.robots={};task.failed=False;task.success=False
    config_by_name={robot['name']:robot for robot in cfg['robots']}
    for name,record in data['robots'].items():
        robot_cfg=config_by_name[name]
        assert robot_cfg['preserve_continuous_arm_joints'] is True
        q=np.asarray(record['joint_positions'],float)
        names=record['joint_names']
        arm_indices=[names.index(n) for n in _UR5E_ARM_JOINT_NAMES]
        subset=SimpleNamespace(get_joint_positions=lambda q=q,indices=arm_indices:q[indices].copy())
        controller=SimpleNamespace(joint_names=list(_UR5E_ARM_JOINT_NAMES),
            get_joint_subset=lambda subset=subset:subset)
        articulation=SimpleNamespace(dof_names=names,
            get_dof_index=lambda name,names=names:names.index(name),
            get_joint_positions=lambda joint_indices=None,q=q:q.copy() if joint_indices is None else q[joint_indices].copy())
        task.robots[name]=SimpleNamespace(articulation=articulation,
            controllers={'arm_joint_controller':controller},config=SimpleNamespace(**robot_cfg),
            _action_batch_sequence=0)
    monitor=SimpleNamespace(current_poses=lambda:{name:value.copy() for name,value in pose_buffers.items()})
    with tempfile.TemporaryDirectory(prefix='stool_first_batch_replay_') as temp:
        out=Path(temp)
        (out/'scene_geometry.json').symlink_to(geometry_path.resolve())
        guard=StoolMeshGuard(task,monitor,data,out)
        task._fabrica_production_action_guard=guard
        policy=DualFrankaAssemblyDemoPolicy()
        actions=policy.act(task)
        assert set(actions)=={'franka_left','franka_right'}
        assert all(set(value)=={'arm_joint_controller','gripper_controller'} for value in actions.values())
        assert all(value['gripper_controller']==[1.] for value in actions.values())
        reports=[json.loads(line) for line in (out/'stool_production_geometry.jsonl').read_text().splitlines()]
        assert len(reports)==1 and reports[0]['passed'] is True
        assert task.events[-1]['event']=='fabrica_final_published_batch'
        assert task.events[-1]['expected_sdk_batch_sequences']=={'franka_left':1,'franka_right':1}
        return dict(passed=True,phase=phase['name'],actions=actions,
            production_geometry=reports[0],policy_diagnostics=policy.local_skill_diagnostics,
            recorded_native_q_and_body_poses=True,
            limit_reader='controlled +/-2pi fixture; actual native get_dof_limits not present in S02 snapshot',
            native_sdk_apply_action_called=False,simulation_initialized=False,
            scope='actual policy/local-skill/adapter/idle/native-batch guard/FCL on S02 snapshot; no physical execution proof')


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--geometry-snapshot',type=Path)
    parser.add_argument('--worker-config',type=Path)
    args=parser.parse_args()
    checks = []
    cases = {
        'beyond_pi': [4., -4., 3.5, -3.5, 0., 1.],
        'near_native_limits': [2*math.pi-1e-4, -2*math.pi+1e-4, math.pi+.3, -math.pi-.3, .2, -.2],
        'initial_branch': [0., -math.pi/2, math.pi/2, -math.pi/2, -math.pi/2, 0.],
    }
    for label, values in cases.items():
        instance, writes = probe(True, values)
        action = [list(values)]
        returned = UR5eRobot._normalize_arm_joint_controller_action(instance, 'arm_joint_controller', action)
        assert returned is action and np.array_equal(returned[0], values), (label, returned)
        checks.append(label + '_native_action_exact')
        control = SimpleNamespace(joint_positions=np.asarray(values, dtype=float))
        original = control.joint_positions.copy()
        returned_control = UR5eRobot._normalize_arm_control(instance, 'arm_joint_controller', control)
        assert returned_control is control and np.array_equal(control.joint_positions, original)
        checks.append(label + '_native_control_exact')
        UR5eRobot._renormalize_arm_joint_state_if_needed(instance)
        assert not writes, (label, writes)
        checks.append(label + '_no_measured_q_or_velocity_rewrite')

    values = cases['beyond_pi']
    legacy, writes = probe(False, values)
    original = np.asarray(values)
    expected = (original + np.pi) % (2*np.pi) - np.pi
    expected = np.where(np.abs(original) > np.pi+.25, expected, original)
    normalized = UR5eRobot._normalize_arm_joint_controller_action(
        legacy, 'arm_joint_controller', [list(values)])
    assert np.allclose(normalized[0], expected, atol=1e-12) and not np.array_equal(normalized[0], values)
    checks.append('legacy_false_action_compatibility_unchanged')
    control = SimpleNamespace(joint_positions=np.asarray(values))
    UR5eRobot._normalize_arm_control(legacy, 'arm_joint_controller', control)
    assert np.allclose(control.joint_positions, expected, atol=1e-12)
    checks.append('legacy_false_control_compatibility_unchanged')
    UR5eRobot._renormalize_arm_joint_state_if_needed(legacy)
    assert [name for name, _ in writes] == ['q','qd']
    assert np.allclose(writes[0][1], expected, atol=1e-12)
    assert np.array_equal(writes[1][1], np.zeros(6))
    checks.append('legacy_false_state_rewrite_behavior_explicit')
    gripper = [[.5]]
    assert UR5eRobot._normalize_arm_joint_controller_action(legacy, 'gripper_controller', gripper) is gripper
    checks.append('nonarm_controller_unchanged')
    snapshot_result=None
    if args.geometry_snapshot or args.worker_config:
        assert args.geometry_snapshot and args.worker_config, 'both snapshot paths are required'
        snapshot_result=snapshot_first_batch(args.geometry_snapshot,args.worker_config)
        checks.append('actual_recorded_initial_policy_adapter_guard_FCL_batch')
    print(json.dumps(dict(passed=True, checks=checks, snapshot_first_batch=snapshot_result, simulation_initialized=False,
        native_sdk_apply_action_called=False,
        scope='actual UR5e normalization methods with controlled measured buffers; no native motion proof'), indent=2))


if __name__ == '__main__':
    main()

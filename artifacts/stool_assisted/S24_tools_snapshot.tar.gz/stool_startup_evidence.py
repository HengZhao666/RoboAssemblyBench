"""Early three-view startup evidence at one frozen native physics stamp.

Call before geometry/raw preflight. Reads native tensors and existing render
products; advances rendering only, never physics, task observations, or commands.
The optional startup wrist adapter changes only existing Camera orientation,
retaining its authored eye and intrinsics; no robot/object/collision setters are used.
"""
from __future__ import annotations
import copy
import hashlib
import json
from pathlib import Path
import numpy as np


class StartupEvidenceError(RuntimeError):
    def __init__(self, report):
        self.report=report
        super().__init__('stool startup evidence rejected: '+'; '.join(report.get('errors',[])))


def plain(value):
    if isinstance(value,dict):return {str(k):plain(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [plain(v) for v in value]
    if hasattr(value,'detach'):value=value.detach()
    if hasattr(value,'cpu'):value=value.cpu()
    if hasattr(value,'numpy'):value=value.numpy()
    if isinstance(value,np.ndarray):return plain(value.tolist())
    if isinstance(value,np.generic):return plain(value.item())
    if isinstance(value,float) and not np.isfinite(value):return repr(value)
    return value


def finite_array(value,shape=None):
    if hasattr(value,'detach'):value=value.detach()
    if hasattr(value,'cpu'):value=value.cpu()
    if hasattr(value,'numpy'):value=value.numpy()
    array=np.array(value,float,copy=True)
    if not np.all(np.isfinite(array)) or (shape is not None and array.shape!=shape):
        raise ValueError('native/camera buffer shape or finiteness rejected')
    return array


class NativeStartupReader:
    """Existing native wrappers, independent of geometry/raw preflight.

    New body wrappers, only when an exact full-path wrapper is absent, bind an
    existing live PhysX view without transform normalization or state setters.
    This is a read-only invariance snapshot, not independent raw certification.
    """
    def __init__(self,task):
        from isaacsim.core.simulation_manager import SimulationManager
        from isaacsim.core.utils.stage import get_current_stage
        from isaacsim.core.prims import SingleRigidPrim
        from pxr import Usd,UsdPhysics
        self.task=task;sim=SimulationManager.get_physics_sim_view()
        if sim is None:raise RuntimeError('startup has no initialized native simulation view')
        stage=get_current_stage();self.readers={};self.robot_views={};self.robot_names={};self.identities={}
        for name,robot in task.robots.items():
            root=str(robot.articulation._root_prim_path)
            if not root.startswith('/') or any(c in root for c in '*?[]'):
                raise RuntimeError('startup robot root is not exact')
            source=robot.articulation._articulation_view._physics_view
            native_paths=list(source.prim_paths)
            if len(native_paths)!=1 or not (native_paths[0]==root or str(native_paths[0]).startswith(root+'/')):
                raise RuntimeError('startup existing articulation path is missing/ambiguous')
            self.robot_views[name]=source;self.robot_names[name]=list(robot.articulation.dof_names)
            self.identities[name]=dict(configured_root=root,native_articulation_path=str(native_paths[0]),
                source_view_id=id(source),source='existing_native_wrapper; no independent raw claim')
            prim=stage.GetPrimAtPath(root)
            if not prim or not prim.IsValid():raise RuntimeError('startup robot USD root missing')
            cache=getattr(robot,'_rigid_body_map',{}) or {}
            for body in Usd.PrimRange(prim,Usd.TraverseInstanceProxies()):
                if not body.HasAPI(UsdPhysics.RigidBodyAPI):continue
                path=str(body.GetPath());wrapper=cache.get(path)
                if wrapper is not None:
                    native=wrapper.unwrap()
                else:
                    native=SingleRigidPrim(prim_path=path,name=path,reset_xform_properties=False)
                    native.initialize(physics_sim_view=sim)
                if str(native.prim_path)!=path:raise RuntimeError('startup body wrapper full-path alias')
                self.readers[path]=native
        self.object_paths={}
        for name in task._fabrica_assisted_contract['objects']:
            wrapper=(getattr(task,'_resolved_objects',{}) or {}).get(name)
            if wrapper is None:raise RuntimeError('startup existing object wrapper missing: '+name)
            native=wrapper.unwrap();path=str(native.prim_path)
            if path!=str(task._object_prims[name].GetPath()):raise RuntimeError('startup object full-path mismatch: '+name)
            self.object_paths[name]=path;self.readers[path]=native
        if len(self.robot_views)!=2 or len(self.object_paths)!=9:
            raise RuntimeError('startup needs two robots and nine existing stool objects')
        self.paths=sorted(self.readers)

    def snapshot(self):
        task=self.task;stamp=dict(task._beam_physics_stamp())
        if not stamp.get('valid'):raise RuntimeError('startup native clock is invalid')
        transforms={};velocities={}
        for path,native in self.readers.items():
            valid=getattr(getattr(native,'_rigid_prim_view',None),'is_physics_handle_valid',None)
            if not callable(valid) or not valid():raise RuntimeError('startup body native handle invalid: '+path)
            p,q=native.get_world_pose();p=finite_array(p,(3,));q=finite_array(q,(4,))
            # Standard SDK body quaternion is wxyz; raw tensor order is not reused.
            transforms[path]=[*p.tolist(),*q[[1,2,3,0]].tolist()]
            velocities[path]=[*finite_array(native.get_linear_velocity(),(3,)).tolist(),
                              *finite_array(native.get_angular_velocity(),(3,)).tolist()]
        robots={}
        for name,view in self.robot_views.items():
            names=self.robot_names[name];size=(1,len(names))
            robots[name]=dict(names=names,positions=finite_array(view.get_dof_positions(),size).tolist(),
                velocities=finite_array(view.get_dof_velocities(),size).tolist(),
                targets=finite_array(view.get_dof_position_targets(),size).tolist())
        result=dict(physics_stamp=stamp,robots=robots,body_paths=self.paths,
            transforms_xyzw=transforms,velocities=velocities,object_paths=self.object_paths,
            source='existing live native wrappers; read-only startup invariance; not independent raw sampler',
            counters={key:plain(copy.deepcopy(getattr(task,key,None))) for key in
                ('step_counter','phase_index','phase_entry_step','steps','success','failed','work')},
            phase_transition_history=plain(copy.deepcopy(getattr(task,'phase_transition_history',[]))))
        if dict(task._beam_physics_stamp())!=stamp:raise RuntimeError('native clock changed while reading startup snapshot')
        return result


def inspect_pixels(frame,resolution):
    raw=np.asarray(frame) if frame is not None else np.asarray([])
    report=dict(valid=False,shape=list(raw.shape),dtype=str(raw.dtype))
    if (raw.ndim!=3 or raw.shape[-1] not in (3,4) or not raw.size
            or list(raw.shape[:2])!=[int(resolution[1]),int(resolution[0])]):
        report['reason']='missing_or_wrong_resolution_RGB';return None,report
    if raw.dtype.kind not in 'uif' or not np.all(np.isfinite(raw)):
        report['reason']='nonfinite_or_invalid_pixel_buffer';return None,report
    if raw.shape[-1]==4 and not np.any(raw[...,3]>0):
        report['reason']='fully_transparent_pixels';return None,report
    rgb=raw[...,:3]
    if raw.dtype.kind=='f' and float(np.max(rgb))<=1.+1e-6:rgb=rgb*255.
    rgb=np.clip(rgb,0.,255.).astype(np.uint8)
    spatial_ranges=np.ptp(rgb.reshape(-1,3),axis=0)
    report.update(channel_ranges=spatial_ranges.astype(int).tolist(),
        channel_standard_deviation=np.std(rgb.reshape(-1,3),axis=0).tolist(),
        all_black_fraction=float(np.mean(np.all(rgb==0,axis=-1))),
        all_white_fraction=float(np.mean(np.all(rgb==255,axis=-1))),
        pixel_sha256=hashlib.sha256(rgb.tobytes()).hexdigest())
    if not np.any(spatial_ranges):report['reason']='spatially_uniform_blank_image';return rgb,report
    report['valid']=True;report['scope']='pixel availability/finiteness/nonuniformity; task visibility requires human image review'
    return rgb,report


def inspect_reference_clocks(rows,stamp):
    """Compare renderer ReferenceTime products without conflating clock epochs."""
    from fractions import Fraction
    from toolkits.factory_dual_franka_assembly.beam_video_clock import render_reference_time
    errors=[];clocks=[];rational=[]
    for row in rows:
        reference=render_reference_time(row.get('raw_reference_time'))
        clocks.append(dict(camera=row['camera'],reference=reference))
        if not reference['valid']:errors.append(row['camera']+': missing/invalid ReferenceTime')
        else:rational.append(Fraction(reference['numerator'],reference['denominator']))
    if len(rows)!=3 or len({row['camera'] for row in rows})!=3 or len(rational)!=3 or len(set(rational))!=1:
        errors.append('three render products do not share one valid render stamp')
    return dict(passed=not errors,errors=errors,cameras=clocks,
        clock_relation='render ReferenceTime and native physics time are distinct clocks; no absolute seconds equality asserted')


def reference_rows(entries,observations=None):
    result=[]
    for entry in entries:
        if observations is None:
            getter=getattr(entry['backend'],'get_render_reference_time',None)
            raw=getter() if callable(getter) else None
        else:
            raw=(((observations.get(entry['owner']) or {}).get('sensors') or {}).get(entry['name'],{}) or {}).get('render_reference_time')
        result.append(dict(camera=entry['name'],raw_reference_time=plain(raw)))
    return result


def inspect_render_sequence(before_rows,passes,stamp,expected_passes=8):
    """Require a fresh final shared render stamp across a frozen native batch.

    Renderer scheduling may repeat a ReferenceTime on an individual render()
    call. Preserve those repeats, reject backwards/mixed stamps, and require
    the final actual RGB stamp to be strictly newer than the pre-batch stamp.
    """
    from fractions import Fraction
    before=inspect_reference_clocks(before_rows,stamp);errors=list(before['errors'])
    initial={row['camera']:Fraction(row['reference']['numerator'],row['reference']['denominator'])
        for row in before['cameras'] if row['reference']['valid']}
    previous=dict(initial);checked=[];nondecreasing=True;native_frozen=True;shared=before['passed'];repeated=[]
    for index,row in enumerate(passes,1):
        checked_clock=inspect_reference_clocks(row['references'],stamp)
        shared=shared and checked_clock['passed'];errors.extend(checked_clock['errors'])
        valid_native=row.get('physics_stamp')==stamp and row.get('native_state_exactly_unchanged') is True
        native_frozen=native_frozen and valid_native
        if not valid_native:errors.append('render pass '+str(index)+': native state/stamp changed')
        this_new=True
        for item in checked_clock['cameras']:
            reference=item['reference'];name=item['camera']
            if not reference['valid']:
                nondecreasing=False;this_new=False;continue
            value=Fraction(reference['numerator'],reference['denominator'])
            if name not in previous or value<previous[name]:
                nondecreasing=False;errors.append(name+': render pass '+str(index)+' has a backwards or unbound render stamp')
            if name in previous and value==previous[name]:this_new=False
            previous[name]=value
        if not this_new:repeated.append(index)
        checked.append(dict(pass_index=index,physics_stamp=row.get('physics_stamp'),
            native_state_exactly_unchanged=row.get('native_state_exactly_unchanged'),
            render_stamp_newer_than_previous=bool(this_new),cameras=checked_clock['cameras']))
    final_fresh=len(initial)==len(previous)==3 and all(previous[name]>value for name,value in initial.items())
    if not final_fresh:errors.append('final three-camera render stamp is not strictly newer than before the render-only batch')
    if len(passes)!=expected_passes:errors.append('render pass count differs from required '+str(expected_passes))
    return dict(passed=not errors,errors=errors,before_render=before['cameras'],render_passes=checked,
        after_render=checked[-1]['cameras'] if checked else [],all_three_shared_each_pass=bool(shared),
        nondecreasing_shared_render_stamps=bool(nondecreasing and shared),
        final_render_stamp_newer_than_before=bool(final_fresh),repeated_render_passes=repeated,
        native_stamp_preserved_each_pass=bool(native_frozen),expected_render_passes=expected_passes,
        clock_relation='distinct render clock and native physics clock; paired capture',
        scope='eight render-only calls with nondecreasing shared camera stamps and strictly newer final RGB stamp while complete native state remains frozen')


def native_matrix(transform):
    from scipy.spatial.transform import Rotation
    value=finite_array(transform,(7,));result=np.eye(4)
    result[:3,:3]=Rotation.from_quat(value[3:]).as_matrix();result[:3,3]=value[:3];return result


USD_CONVERSION_METHOD='Gf.Matrix4d.SetRotate(Gf.Rotation(Gf.Quatd(raw_w,raw_xyz)))'
RAW_QUATERNION_SANITY_ATOL=float(64*np.finfo(np.float32).eps)
GF_AXIS_IDENTITY_EPSILON=1.e-10


def validated_native_pose(transform):
    value=finite_array(transform,(7,))
    with np.errstate(over='raise',invalid='raise'):
        single=value.astype(np.float32)
    if not np.array_equal(value,single.astype(np.float64)):
        raise ValueError('native pose is not losslessly float32 round-trippable')
    q=value[3:];norm=float(np.linalg.norm(q))
    if abs(norm-1.)>RAW_QUATERNION_SANITY_ATOL or abs(float(q[3]))>1.:
        raise ValueError('native raw quaternion norm or scalar domain rejected')
    return value,norm


def gf_rotation_matrix_math(transform):
    """Independent legal Gf.Rotation(raw quaternion) axis-angle calculation.

    Deliberately do not normalize raw w: this USD representation conversion is
    distinct from the normalized physical-native rotation retained below.
    """
    value,_=validated_native_pose(transform);q=value[3:];length=float(np.linalg.norm(q[:3]))
    result=np.eye(4);result[:3,3]=value[:3]
    if length<=GF_AXIS_IDENTITY_EPSILON:return result
    axis=q[:3]/length;angle=2.*float(np.arccos(q[3]));x,y,z=axis
    cross=np.array([[0.,-z,y],[z,0.,-x],[-y,x,0.]])
    result[:3,:3]=np.eye(3)+np.sin(angle)*cross+(1.-np.cos(angle))*(cross@cross)
    return result


def normalized_native_matrix_math(transform):
    value,norm=validated_native_pose(transform);x,y,z,w=value[3:]/norm
    result=np.eye(4);result[:3,3]=value[:3]
    result[:3,:3]=[[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],
                  [2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],
                  [2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]]
    return result


def expected_usd_matrix_gf(transform):
    """Run the installed SDK conversion, retaining a per-call numeric receipt."""
    from pxr import Gf
    value,norm=validated_native_pose(transform);q=value[3:]
    converted=Gf.Matrix4d(1.)
    converted.SetRotate(Gf.Rotation(Gf.Quatd(float(q[3]),Gf.Vec3d(*map(float,q[:3])))))
    converted.SetTranslateOnly(Gf.Vec3d(*map(float,value[:3])))
    expected=finite_array(converted,(4,4)).T
    difference=float(np.max(abs(expected-gf_rotation_matrix_math(value))))
    if difference>1.e-12:raise ValueError('installed Gf conversion differs from independently reproducible SDK math')
    receipt=dict(actual_sdk_called=True,sdk_module_path=str(Gf.__file__),method=USD_CONVERSION_METHOD,
        raw_dtype='float32',native_pose_float32_roundtrip=True,raw_quaternion_norm=norm,
        quaternion_norm_sanity_atol=RAW_QUATERNION_SANITY_ATOL,scalar_in_unit_interval=True,
        axis_identity_epsilon=GF_AXIS_IDENTITY_EPSILON,sdk_math_matrix_max_abs_error=difference)
    return expected,receipt


def validated_world_matrix(value,*,allow_scale=False):
    matrix=finite_array(value,(4,4))
    if not np.allclose(matrix[3],[0.,0.,0.,1.],atol=1.e-12,rtol=0):
        raise ValueError('USD/native world matrix is not affine')
    linear=matrix[:3,:3];scales=np.linalg.norm(linear,axis=0)
    if np.any(scales<=np.finfo(float).eps) or np.linalg.det(linear)<=0:
        raise ValueError('USD/native matrix has singular or reflected axes')
    unit=linear/scales
    if np.max(abs(unit.T@unit-np.eye(3)))>32*np.finfo(np.float32).eps:
        raise ValueError('USD/native world matrix is not a proper rotation with scale')
    if not allow_scale and np.max(abs(scales-1.))>32*np.finfo(np.float32).eps:
        raise ValueError('rigid world matrix contains unexpected scale')
    return matrix,scales


def compare_native_usd_row(path,transform,physical_native,observed_usd,expected_usd,receipt,*,raw_usd_matrix=None):
    value,norm=validated_native_pose(transform)
    if not isinstance(path,str) or not path.startswith('/') or any(x in path for x in ('..','*','?','[')):
        raise ValueError('invalid native body identity')
    expected,_=validated_world_matrix(physical_native)
    actual,_=validated_world_matrix(observed_usd)
    publication,_=validated_world_matrix(expected_usd)
    math_expected=gf_rotation_matrix_math(value)
    if np.max(abs(expected-normalized_native_matrix_math(value)))>1.e-12:
        raise ValueError('physical-native matrix does not match the raw native pose')
    if np.max(abs(publication-math_expected))>1.e-12:
        raise ValueError('SDK conversion matrix does not match the raw native pose')
    if not isinstance(receipt,dict) or receipt.get('actual_sdk_called') is not True or receipt.get('method')!=USD_CONVERSION_METHOD:
        raise ValueError('actual SDK conversion receipt is absent')
    error=float(np.max(abs(actual-expected)))
    tolerance=float(32*np.finfo(np.float32).eps*max(1.,float(np.max(abs(expected)))))
    angle=float(np.arccos(np.clip((np.trace(actual[:3,:3]@expected[:3,:3].T)-1)/2,-1.,1.)))
    publication_error=float(np.max(abs(actual-publication)))
    representation_angle=float(np.arccos(np.clip((np.trace(publication[:3,:3]@expected[:3,:3].T)-1)/2,-1.,1.)))
    row=dict(body=path,matrix_max_abs_error=error,tolerance=tolerance,
        position_error_m=float(np.linalg.norm(actual[:3,3]-expected[:3,3])),angle_error_rad=angle,
        native_world_matrix=expected.tolist(),usd_world_matrix=actual.tolist(),passed=error<=tolerance,
        publication_passed=publication_error<=tolerance,expected_usd_world_matrix=publication.tolist(),
        publication_matrix_max_abs_error=publication_error,raw_native_pose_xyzw=value.tolist(),
        raw_native_quaternion_xyzw=value[3:].tolist(),raw_native_dtype='float32',raw_quaternion_norm=norm,
        raw_quaternion_scalar_ulp=float(abs(np.spacing(np.float32(value[6])))),
        representation_delta_rad=representation_angle,representation_matrix_max_abs_error=float(np.max(abs(publication-expected))),
        conversion_method=USD_CONVERSION_METHOD,conversion_receipt=copy.deepcopy(receipt))
    if raw_usd_matrix is not None:
        raw,scales=validated_world_matrix(raw_usd_matrix,allow_scale=True)
        row.update(raw_usd_world_matrix=raw.tolist(),raw_usd_axis_scales=scales.tolist())
    return row


def compare_native_usd(stage,snapshot):
    from pxr import UsdGeom,Gf
    paths=snapshot['body_paths']
    if (not isinstance(paths,list) or not paths or len(set(paths))!=len(paths)
            or set(paths)!=set(snapshot['transforms_xyzw'])):
        raise ValueError('native body identity inventory is absent, duplicated, or mismatched')
    cache=UsdGeom.XformCache();rows=[]
    for path in paths:
        prim=stage.GetPrimAtPath(path)
        if not prim or not prim.IsValid():raise RuntimeError('native startup body is missing from USD: '+path)
        if str(prim.GetPath())!=path:raise RuntimeError('native/USD body identity mismatch: '+path)
        value,_=validated_native_pose(snapshot['transforms_xyzw'][path])
        raw=cache.GetLocalToWorldTransform(prim);rigid=Gf.Matrix4d(1)
        raw_matrix=finite_array(raw,(4,4)).T
        validated_world_matrix(raw_matrix,allow_scale=True)
        rigid.SetRotate(raw.ExtractRotationQuat());rigid.SetTranslateOnly(raw.ExtractTranslation())
        actual=finite_array(rigid,(4,4)).T;expected=native_matrix(snapshot['transforms_xyzw'][path])
        publication,receipt=expected_usd_matrix_gf(value)
        rows.append(compare_native_usd_row(path,value,expected,actual,publication,receipt,raw_usd_matrix=raw_matrix))
    return dict(schema_version='native_usd_dual_v1',passed=bool(rows) and all(row['publication_passed'] for row in rows),
        normalized_native_alignment_passed=bool(rows) and all(row['passed'] for row in rows),bodies=len(rows),
        body_paths=list(snapshot['body_paths']),rows=rows,
        precision_basis='32 float32 machine eps times normalized-native world-matrix magnitude; unchanged for both comparisons; representational alignment, not a physical success tolerance')


def align_native_publication(task,reader,stage,before):
    initial=compare_native_usd(stage,before)
    report=dict(passed=False,before_publication=initial,publication_api=None,args=None,native_unchanged=False)
    if not initial['passed']:
        import omni.physx
        report.update(publication_api='omni.physx.get_physx_interface().update_transformations',args=[False,True,False,False])
        omni.physx.get_physx_interface().update_transformations(False,True,False,False)
    after=reader.snapshot();report['native_unchanged']=before==after
    report['after_publication']=compare_native_usd(stage,after)
    report['passed']=bool(report['native_unchanged'] and report['after_publication']['passed'])
    if not report['passed']:raise RuntimeError('existing native-result publication did not align USD without changing native state: '+repr(report))
    return report


def grip_camera_matrix(eye,pad_centers):
    eye=finite_array(eye,(3,));pads=finite_array(pad_centers,(2,3));target=pads.mean(axis=0)
    forward=target-eye;distance=float(np.linalg.norm(forward))
    if distance<=1e-8:raise ValueError('wrist camera eye coincides with measured grip midpoint')
    forward/=distance;jaw=pads[1]-pads[0];right=jaw-forward*np.dot(jaw,forward)
    if np.linalg.norm(right)<=1e-8:raise ValueError('jaw direction is parallel to wrist camera optical axis')
    right/=np.linalg.norm(right);up=np.cross(right,forward);up/=np.linalg.norm(up)
    matrix=np.eye(4);matrix[:3,:3]=np.column_stack([right,up,-forward]);matrix[:3,3]=eye
    return matrix,target


def align_wrist_camera_orientation(task,stage,entries,snapshot):
    """Retain authored eye/intrinsics; aim at actual inner-finger CAD midpoint.

    Only the existing Camera prim's rotation is written. Its wrist attachment,
    mount position and all native robot/object states remain untouched.
    """
    from pxr import Usd,UsdGeom,Gf
    from scipy.spatial.transform import Rotation
    rows=[];cache=UsdGeom.XformCache()
    for entry in entries:
        if entry['spec'].get('view_type')!='wrist':continue
        robot=entry['spec'].get('robot') or entry['owner'];root=str(task.robots[robot].articulation._root_prim_path)
        sensor_path=str(entry['sensor'].camera_prim_path);camera=stage.GetPrimAtPath(sensor_path)
        original=finite_array(cache.GetLocalToWorldTransform(camera),(4,4)).T;centers=[];selected=[]
        for finger in ('left_inner_finger','right_inner_finger'):
            body=root+'/Gripper/Robotiq_2F_85/'+finger;prim=stage.GetPrimAtPath(body)
            if not prim or not prim.IsValid():raise RuntimeError('wrist camera lacks exact native inner-finger body')
            meshes=[]
            for child in Usd.PrimRange(prim,Usd.TraverseInstanceProxies()):
                if not child.IsA(UsdGeom.Mesh):continue
                if UsdGeom.Imageable(child).ComputeVisibility()=='invisible':continue
                mesh=UsdGeom.Mesh(child);points=mesh.GetPointsAttr().Get()
                if points is None or not len(points):continue
                world=cache.GetLocalToWorldTransform(child)
                values=np.asarray([list(world.Transform(Gf.Vec3d(*map(float,p)))) for p in points])
                meshes.append((str(child.GetPath()),values))
            pads=[item for item in meshes if 'fingertipsstep' in item[0].lower()]
            chosen=pads if len(pads)==1 else meshes
            if not chosen:raise RuntimeError('wrist camera has no visible inner-finger CAD geometry')
            centers.append(np.concatenate([item[1] for item in chosen]).mean(axis=0))
            selected.append(dict(body=body,mesh_paths=[item[0] for item in chosen],
                source='unique authored fingertip pad mesh' if len(pads)==1 else 'visible inner-finger CAD centroid fallback'))
        matrix,target=grip_camera_matrix(original[:3,3],centers)
        quat=Rotation.from_matrix(matrix[:3,:3]).as_quat()[[3,0,1,2]]
        # Camera-only SDK setter; no native body pose/target setter is used.
        entry['backend'].prim.set_world_pose(position=original[:3,3],orientation=quat)
        actual=finite_array(UsdGeom.XformCache().GetLocalToWorldTransform(camera),(4,4)).T
        if np.max(abs(actual-matrix))>1e-6:raise RuntimeError('wrist Camera orientation write/readback differs')
        rows.append(dict(camera=entry['name'],sensor_path=sensor_path,selected_pad_geometry=selected,
            original_world_matrix=original.tolist(),adapted_world_matrix=actual.tolist(),eye_unchanged=True,
            grip_midpoint_world=target.tolist(),pad_centers_world=np.asarray(centers).tolist(),
            policy='original wrist camera eye/intrinsics; USD -Z optical axis to actual CAD pad midpoint; projected jaw line horizontal',
            setter='existing Camera SingleXFormPrim.set_world_pose only; no robot/object setters'))
    if len(rows)!=2:raise RuntimeError('expected exactly two wrist camera orientations')
    return dict(passed=True,cameras=rows,native_physics_stamp=snapshot['physics_stamp'])


def camera_entries(task):
    import omni.replicator.core as rep
    entries=[]
    try:
        for spec in task.cfg.camera_metadata:
            owner=spec.get('owner') or spec.get('robot');name=spec['name']
            sensor=task.robots[owner].sensors[name];backend=sensor._camera
            if backend is None or backend.rp is None:raise RuntimeError('camera backend/render product unavailable: '+name)
            # A missing clock must reject acceptance after pixels are retained.
            # Never attach/recreate a ReferenceTime product here to backfill it.
            annotator=backend.rp_annotators.get('camera_params');temporary=annotator is None
            if temporary:
                annotator=rep.AnnotatorRegistry.get_annotator('camera_params');annotator.attach(backend.rp)
            entries.append(dict(spec=spec,owner=owner,name=name,sensor=sensor,backend=backend,
                product=backend.rp,product_path=str(getattr(backend.rp,'path',backend.rp)),
                params=annotator,temporary_params=temporary))
        if len(entries)!=3 or len({e['name'] for e in entries})!=3 or len({e['product_path'] for e in entries})!=3:
            raise RuntimeError('startup needs three unique camera names/render products')
        return entries
    except Exception:
        for entry in entries:
            if entry['temporary_params']:entry['params'].detach(entry['product'])
        raise


def inspect_camera_identity(stage,entry):
    from pxr import UsdGeom
    sensor_path=str(entry['sensor'].camera_prim_path)
    backend_path=str(entry['backend'].prim.prim_path)
    product=stage.GetPrimAtPath(entry['product_path'])
    targets=[str(p) for p in product.GetRelationship('camera').GetTargets()] if product and product.IsValid() else []
    report=dict(camera=entry['name'],sensor_path=sensor_path,backend_path=backend_path,
        render_product_path=entry['product_path'],render_product_camera_targets=targets,passed=False)
    try:
        if targets!=[sensor_path] or backend_path!=sensor_path:raise RuntimeError('RGB product/sensor/backend camera identity mismatch')
        prim=stage.GetPrimAtPath(sensor_path)
        if not prim or not prim.IsValid() or str(prim.GetTypeName())!='Camera':raise RuntimeError('existing camera prim is missing or not a Camera')
        params=entry['params'].get_data();report['camera_params']=plain(params)
        if list(params['renderProductResolution'])!=list(entry['spec']['resolution']):raise RuntimeError('renderer resolution differs from camera contract')
        world=finite_array(UsdGeom.XformCache().GetLocalToWorldTransform(prim),(4,4)).T
        view=finite_array(params['cameraViewTransform']).reshape(4,4).T
        error=float(np.max(abs(view-np.linalg.inv(world))))
        report.update(usd_camera_world_matrix=world.tolist(),renderer_world_to_camera_matrix=view.tolist(),matrix_max_abs_error=error)
        if error>1e-5:raise RuntimeError('renderer camera transform differs from USD Camera')
        report['passed']=True
    except Exception as exc:report['error']=type(exc).__name__+': '+str(exc)
    return report


class ReadonlyVideoTask:
    """Retain pixels without recorder's stateful public tracked-state getter."""
    def __init__(self,task,snapshot):self.task=task;self.snapshot=snapshot
    def __getattr__(self,name):return getattr(self.task,name)
    def get_tracked_object_states(self):
        return {name:dict(path=path,transform_xyzw=self.snapshot['transforms_xyzw'][path],
            velocity=self.snapshot['velocities'][path],source='read_only_startup_native_snapshot')
            for name,path in self.snapshot['object_paths'].items()}


def record_initial_video(recorder,task,observations,snapshot):
    if recorder is None:raise RuntimeError('startup live video recorder unavailable')
    before=dict(recorder._written_png_counts);stride=recorder.frame_stride
    try:
        recorder.frame_stride=1
        recorder.record(ReadonlyVideoTask(task,snapshot),observations,step_index=int(task.step_counter))
    finally:recorder.frame_stride=stride
    after=dict(recorder._written_png_counts)
    keys={row['video_key'] for row in recorder.camera_specs}
    increments={key:after.get(key,0)-before.get(key,0) for key in keys}
    report=dict(passed=len(keys)==3 and all(v==1 for v in increments.values()),
        increments=increments,physics_stamp=snapshot['physics_stamp'],frame_clock='video_frame_clock.jsonl',
        scope='initial frames retained in the ordinary live recorder before later preflight; tracked state uses immutable native snapshot')
    if not report['passed']:raise RuntimeError('startup live video recorder did not preserve all three frames: '+repr(report))
    return report


def capture_startup_evidence(task,env,out,record_callback,*,render_steps=8,prefix='startup',orient_wrist=True):
    """Return report or raise after retaining images/video/diagnostics.

    record_callback(observations, before_snapshot) should call record_initial_video
    with the current ACTIVE_VIDEO recorder. Call this before geometry/raw gates.
    """
    from internutopia.core.task import BaseTask
    from isaacsim.core.utils.stage import get_current_stage
    import cv2
    if prefix not in {'startup','terminal'}:raise ValueError('capture prefix must be startup or terminal')
    if int(render_steps)!=8:raise ValueError('paired capture requires exactly eight render-only passes')
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    report=dict(passed=False,errors=[],images=[],render_only_steps=int(render_steps),
        stage='early_startup_before_geometry_and_raw' if prefix=='startup' else 'terminal_before_cleanup',formal_physical_success=False)
    entries=[];reader=None;before=None
    def save():
        (out/(prefix+'_capture_diagnostics.json')).write_text(json.dumps(plain(report),allow_nan=False,indent=2)+'\n')
    try:
        try:
            reader=NativeStartupReader(task);before=reader.snapshot()
            report['native_reader_identities']=reader.identities
        except Exception as exc:
            report['errors'].append('complete native startup snapshot unavailable: '+repr(exc))
            reader=None
            try:stamp=dict(task._beam_physics_stamp())
            except Exception as secondary:stamp=dict(valid=False,error=repr(secondary))
            before=dict(physics_stamp=stamp,object_paths={},transforms_xyzw={},velocities={},
                counters={key:plain(getattr(task,key,None)) for key in ('step_counter','phase_index','phase_entry_step','steps')},
                source='incomplete fallback only to retain camera pixels; full native invariance rejected')
        report['before']=before
        entries=camera_entries(task)
        if reader is not None:
            try:report['stage_native_alignment']=align_native_publication(task,reader,get_current_stage(),before)
            except Exception as exc:report['errors'].append('native/USD startup publication rejected: '+repr(exc))
        else:report['errors'].append('full native/USD rendered-stage alignment unavailable')
        if prefix=='startup' and orient_wrist and reader is not None:
            try:report['wrist_camera_orientation_adapter']=align_wrist_camera_orientation(task,get_current_stage(),entries,before)
            except Exception as exc:report['errors'].append('wrist camera CAD orientation rejected: '+repr(exc))
        before_references=reference_rows(entries);render_passes=[];observations={}
        for render_pass in range(int(render_steps)):
            env.warm_up(steps=1,render=True,physics=False)
            observations=BaseTask.get_observations(task)
            same_state=reader is not None and reader.snapshot()==before
            render_passes.append(dict(references=reference_rows(entries,observations),
                physics_stamp=dict(task._beam_physics_stamp()),native_state_exactly_unchanged=bool(same_state)))
        if reader is not None:
            try:
                aligned=compare_native_usd(get_current_stage(),reader.snapshot())
                report.setdefault('stage_native_alignment',{})['after_render']=aligned
                if not aligned['passed']:report['errors'].append('rendered USD scene no longer matches frozen native bodies')
            except Exception as exc:report['errors'].append('after-render native/USD comparison failed: '+repr(exc))
        for entry in entries:
            spec=entry['spec'];sensor_obs=((observations.get(entry['owner']) or {}).get('sensors') or {}).get(entry['name'],{})
            rgb,pixels=inspect_pixels(sensor_obs.get('rgba'),spec['resolution'])
            row=dict(camera=entry['name'],owner=entry['owner'],video_key=spec.get('video_key'),pixels=pixels,
                raw_reference_time=plain(sensor_obs.get('render_reference_time')),physics_stamp=before['physics_stamp'])
            if rgb is not None:
                path=out/(prefix+'_'+entry['name']+'.png')
                if not cv2.imwrite(str(path),cv2.cvtColor(rgb,cv2.COLOR_RGB2BGR)):
                    report['errors'].append(entry['name']+': PNG write failed')
                else:row.update(path=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
            if not pixels['valid']:report['errors'].append(entry['name']+': '+pixels.get('reason','pixels invalid'))
            row['camera_identity']=inspect_camera_identity(get_current_stage(),entry)
            if not row['camera_identity']['passed']:report['errors'].append(entry['name']+': render product camera identity/matrix rejected')
            report['images'].append(row)
        # Preserve ordinary video originals before any geometry/raw failure.
        try:report['video_retention']=plain(record_callback(observations,before))
        except Exception as exc:report['errors'].append('startup video retention failed: '+repr(exc))
        clocks=inspect_render_sequence(before_references,render_passes,before['physics_stamp'],int(render_steps));report['clock_validation']=clocks
        report['errors'].extend(clocks['errors'])
        hashes=[row['pixels'].get('pixel_sha256') for row in report['images']]
        if len(hashes)!=3 or None in hashes or len(set(hashes))!=3:report['errors'].append('three camera pixel buffers missing or exactly duplicated')
        if reader is not None:
            after=reader.snapshot();report['after']=after
            report['native_state_exactly_unchanged']=before==after
            if before!=after:report['errors'].append('render-only startup changed native body/q/qd/targets/task counters/history')
        else:report['native_state_exactly_unchanged']=False
        report['passed']=not report['errors'];save()
        (out/(prefix+'_images_ready.json')).write_text(json.dumps(dict(passed=report['passed'],images=report['images'],
            physics_stamp=before['physics_stamp'],before_render_physics_stamp=before['physics_stamp'],
            diagnostics=prefix+'_capture_diagnostics.json',video_retention=report.get('video_retention'),
            scope='initial native state retained before later geometry/raw gates; human image review still required'),indent=2)+'\n')
    except Exception as exc:
        report['errors'].append(type(exc).__name__+': '+str(exc))
        if reader is not None and before is not None:
            try:report['after_failure']=reader.snapshot();report['native_state_exactly_unchanged']=before==report['after_failure']
            except Exception as secondary:report['state_after_failure_error']=repr(secondary)
        save()
    finally:
        for entry in entries:
            if entry['temporary_params']:
                try:entry['params'].detach(entry['product'])
                except Exception as exc:report.setdefault('cleanup_errors',[]).append(repr(exc))
    if not report['passed']:raise StartupEvidenceError(report)
    return report

"""Pure interface tests; no Isaac imports, scene creation, or native physics."""
from types import SimpleNamespace as NS
import unittest
import numpy as np

from stool_raw_evidence import (array, create_independent_articulation_reader,
    exact_view_paths, read_raw_body_buffers, read_raw_articulation_buffers)


ROOT = '/World/env_0/robots/ur5e_left'
ACTUAL = ROOT + '/ur5e/base_link'


class StateForbiddenView:
    def __init__(self, paths):
        self.prim_paths = paths

    def get_dof_positions(self):
        raise AssertionError('Identity discovery must not read wrapper or raw state')

    get_dof_velocities = get_dof_positions
    get_dof_position_targets = get_dof_positions


def robot(paths=(ACTUAL,), *, valid=True, wrapper_root=ROOT):
    source = StateForbiddenView(list(paths))
    wrapper_view = NS(_physics_view=source, is_physics_handle_valid=lambda: valid)
    return NS(articulation=NS(_root_prim_path=wrapper_root, _articulation_view=wrapper_view)), source


class Factory:
    def __init__(self, output=None):
        self.calls = []
        self.output = output

    def create_articulation_view(self, path):
        self.calls.append(path)
        return StateForbiddenView([path]) if self.output is None else self.output


class RawArticulationIdentityTests(unittest.TestCase):
    def test_nested_native_root_is_selected_instead_of_robot_container(self):
        item, source = robot()
        factory = Factory()
        independent, identity = create_independent_articulation_reader(factory, item, ROOT)
        self.assertEqual(factory.calls, [ACTUAL])
        self.assertEqual(independent.prim_paths, [ACTUAL])
        self.assertIsNot(independent, source)
        self.assertEqual(identity['configured_robot_root'], ROOT)
        self.assertEqual(identity['native_articulation_path'], ACTUAL)
        self.assertNotEqual(identity['existing_physics_view_id'], identity['independent_physics_view_id'])

    def test_container_equal_to_native_root_is_also_supported(self):
        item, _ = robot([ROOT])
        factory = Factory()
        _, identity = create_independent_articulation_reader(factory, item, ROOT + '/')
        self.assertEqual(factory.calls, [ROOT])
        self.assertEqual(identity['native_articulation_path'], ROOT)

    def test_missing_native_view_and_invalid_handle_reject_before_creation(self):
        missing = NS(articulation=NS(_root_prim_path=ROOT, _articulation_view=NS(_physics_view=None)))
        invalid, _ = robot(valid=False)
        for item in (missing, invalid):
            factory = Factory()
            with self.assertRaises(RuntimeError):
                create_independent_articulation_reader(factory, item, ROOT)
            self.assertEqual(factory.calls, [])

    def test_missing_duplicate_and_multiple_existing_paths_are_ambiguous(self):
        for paths in ([], [ACTUAL, ACTUAL], [ACTUAL, ACTUAL + '_other']):
            item, _ = robot(paths)
            factory = Factory()
            with self.assertRaisesRegex(RuntimeError, 'missing or ambiguous'):
                create_independent_articulation_reader(factory, item, ROOT)
            self.assertEqual(factory.calls, [])

    def test_other_robot_and_sibling_prefix_are_rejected(self):
        for actual in ('/World/env_0/robots/ur5e_right/base_link',
                       ROOT + '_other/base_link', ROOT + '/*'):
            item, _ = robot([actual])
            factory = Factory()
            with self.assertRaisesRegex(RuntimeError, 'outside the expected robot namespace'):
                create_independent_articulation_reader(factory, item, ROOT)
            self.assertEqual(factory.calls, [])

    def test_wrong_wrapper_namespace_is_rejected(self):
        item, _ = robot(wrapper_root=ROOT + '_other')
        factory = Factory()
        with self.assertRaisesRegex(RuntimeError, 'different configured root'):
            create_independent_articulation_reader(factory, item, ROOT)
        self.assertEqual(factory.calls, [])

    def test_new_reader_must_match_one_exact_native_path(self):
        for returned in (StateForbiddenView([]), StateForbiddenView([ACTUAL, ACTUAL]),
                         StateForbiddenView([ROOT]), StateForbiddenView([ROOT + '_other'])):
            item, _ = robot()
            with self.assertRaisesRegex(RuntimeError, 'differs from the exact existing path'):
                create_independent_articulation_reader(Factory(returned), item, ROOT)

    def test_source_reader_cannot_be_reused_as_independent_evidence(self):
        item, source = robot()
        with self.assertRaisesRegex(RuntimeError, 'Separate native articulation reader was not created'):
            create_independent_articulation_reader(Factory(source), item, ROOT)

    def test_invalid_new_backend_becomes_an_explicit_error(self):
        class BrokenBackend:
            @property
            def prim_paths(self):
                raise AttributeError('backend is None')
        item, _ = robot()
        with self.assertRaisesRegex(RuntimeError, 'no valid backend'):
            create_independent_articulation_reader(Factory(BrokenBackend()), item, ROOT)

    def test_namespace_wildcards_and_world_root_are_rejected(self):
        item, _ = robot()
        for root in ('', '/', 'relative/root', '/World/*'):
            with self.assertRaisesRegex(RuntimeError, 'exact absolute prim root'):
                create_independent_articulation_reader(Factory(), item, root)


class FakeWarpArray:
    """Warp's host conversion returns a borrowed ndarray in these tests."""
    def __init__(self, values):
        self.values = np.asarray(values, dtype=np.float32)

    def numpy(self):
        return self.values


class FakeTorchTensor(FakeWarpArray):
    def __init__(self, values):
        super().__init__(values)
        self.conversions = []

    def detach(self):
        self.conversions.append('detach')
        return self

    def cpu(self):
        self.conversions.append('cpu')
        return self

    def numpy(self):
        self.conversions.append('numpy')
        return self.values


class BodyView:
    def __init__(self):
        self.prim_paths = ['/body_b', '/body_a']
        self.count = 2
        self.transforms = FakeWarpArray([[2., 0., 0., 0., 0., .6, .8],
                                         [1., 0., 0., 0., 0., -.6, -.8]])
        self.velocities = FakeWarpArray([[20., 0., 0., 0., 0., 0.],
                                        [10., 0., 0., 0., 0., 0.]])
        self.mutate_prior = False
        self.change_order = False

    def get_transforms(self):
        return self.transforms

    def get_velocities(self):
        if self.mutate_prior:
            self.transforms.values[:, 0] = 99.
        if self.change_order:
            self.prim_paths.reverse()
        return self.velocities


DOFS = ['arm_' + str(i) for i in range(6)] + ['gripper_' + str(i) for i in range(6)]


class ArticulationView:
    def __init__(self):
        self.prim_paths = [ACTUAL]
        self.count, self.max_dofs = 1, 12
        self.shared_metatype = NS(dof_names=DOFS.copy())
        self.q = FakeWarpArray([list(range(12))])
        self.qd = FakeWarpArray([[100 + i for i in range(12)]])
        self.targets = FakeWarpArray([[200 + i for i in range(12)]])
        self.mutate_prior = False
        self.change_metadata = False

    def get_dof_positions(self):
        return self.q

    def get_dof_velocities(self):
        if self.mutate_prior:
            self.q.values[:] = -999.
        return self.qd

    def get_dof_position_targets(self):
        if self.mutate_prior:
            self.qd.values[:] = -888.
        if self.change_metadata:
            self.shared_metatype.dof_names.reverse()
        return self.targets


class RawBufferTests(unittest.TestCase):
    def test_numpy_warp_and_torch_buffers_are_detached_without_shape_changes(self):
        for source in (np.arange(12, dtype=np.float32).reshape(1, 12),
                       FakeWarpArray([list(range(12))]), FakeTorchTensor([list(range(12))])):
            result = array(source)
            borrowed = source if isinstance(source, np.ndarray) else source.values
            borrowed[:] = -50.
            np.testing.assert_array_equal(result, [list(range(12))])
            self.assertEqual(result.shape, (1, 12))
            self.assertFalse(np.shares_memory(result, borrowed))
            if isinstance(source, FakeTorchTensor):
                self.assertEqual(source.conversions, ['detach', 'cpu', 'numpy'])

    def test_nonfinite_frontend_data_is_rejected(self):
        for value in (np.array([np.nan]), FakeWarpArray([np.inf]), FakeTorchTensor([-np.inf])):
            with self.assertRaisesRegex(ValueError, 'Nonfinite'):
                array(value)

    def test_exact_membership_rejects_duplicates_missing_extra_and_bad_count(self):
        for view in (NS(prim_paths=['/body_a', '/body_a'], count=2),
                     NS(prim_paths=['/body_a'], count=1),
                     NS(prim_paths=['/body_a', '/other'], count=2),
                     NS(prim_paths=['/body_b', '/body_a'], count=3)):
            with self.assertRaisesRegex(ValueError, 'membership/count changed'):
                exact_view_paths(view, ['/body_a', '/body_b'], 'test')

    def test_bodies_follow_native_path_order_and_keep_raw_xyzw_values(self):
        view = BodyView()
        view.mutate_prior = True
        row = read_raw_body_buffers(view, ['/body_a', '/body_b'], {'part_a': '/body_a'})
        self.assertEqual(row['objects']['part_a']['transform'][0], 1.)
        np.testing.assert_allclose(row['bodies']['/body_b']['transform'][3:], [0., 0., .6, .8])
        np.testing.assert_allclose(row['objects']['part_a']['transform'][3:], [0., 0., -.6, -.8])
        self.assertEqual(row['objects']['part_a']['velocity'][0], 10.)
        self.assertEqual(row['body_buffer_metadata']['native_path_order'], ['/body_b', '/body_a'])
        self.assertEqual(row['body_buffer_metadata']['orientation_order'], 'xyzw')
        self.assertEqual(row['body_buffer_metadata']['transform_shape'], [2, 7])

    def test_nonunit_quaternion_and_wrong_body_shape_are_rejected(self):
        for replacement in (np.zeros((2, 7), dtype=np.float32),
                            np.ones((2, 7), dtype=np.float32),
                            np.zeros((2, 6), dtype=np.float32)):
            view = BodyView()
            view.transforms.values = replacement
            with self.assertRaises(ValueError):
                read_raw_body_buffers(view, view.prim_paths, {'part_a': '/body_a'})

    def test_object_aliases_and_body_order_change_are_rejected(self):
        view = BodyView()
        with self.assertRaisesRegex(ValueError, 'aliases or unbound'):
            read_raw_body_buffers(view, view.prim_paths, {'a': '/body_a', 'b': '/body_a'})
        view.change_order = True
        with self.assertRaisesRegex(ValueError, 'order changed'):
            read_raw_body_buffers(view, ['/body_a', '/body_b'], {'part_a': '/body_a'})

    def test_full_native_dof_rows_are_copied_before_subsequent_getters(self):
        view = ArticulationView()
        view.mutate_prior = True
        identity = {'native_articulation_path': ACTUAL, 'configured_robot_root': ROOT}
        row = read_raw_articulation_buffers(view, identity, DOFS)
        self.assertEqual(row['positions'], list(range(12)))
        self.assertEqual(row['velocities'], [100 + i for i in range(12)])
        self.assertEqual(row['position_targets'], [200 + i for i in range(12)])
        self.assertEqual(row['joint_names'], DOFS)
        self.assertEqual(row['path'], ACTUAL)
        self.assertEqual(row['configured_robot_root'], ROOT)
        self.assertEqual(row['dof_buffer_metadata']['native_dof_count'], 12)
        self.assertTrue(row['dof_buffer_metadata']['native_dof_order_verified'])

    def test_missing_reordered_or_duplicate_native_dof_metadata_is_rejected(self):
        for names in ([], DOFS[::-1], DOFS[:-1] + [DOFS[0]]):
            view = ArticulationView()
            view.shared_metatype.dof_names = names
            with self.assertRaisesRegex(ValueError, 'metadata/order differs'):
                read_raw_articulation_buffers(view,
                    {'native_articulation_path': ACTUAL, 'configured_robot_root': ROOT}, DOFS)

    def test_partial_padded_flat_or_multi_articulation_dof_buffers_are_rejected(self):
        for shape in ((1, 6), (1, 13), (12,), (2, 12)):
            for field in ('q', 'qd', 'targets'):
                view = ArticulationView()
                setattr(view, field, FakeWarpArray(np.zeros(shape)))
                with self.assertRaisesRegex(ValueError, 'complete native DOF names'):
                    read_raw_articulation_buffers(view,
                        {'native_articulation_path': ACTUAL, 'configured_robot_root': ROOT}, DOFS)

    def test_dof_count_and_metadata_changes_during_read_are_rejected(self):
        view = ArticulationView()
        view.max_dofs = 6
        with self.assertRaisesRegex(ValueError, 'maximum DOF count'):
            read_raw_articulation_buffers(view,
                {'native_articulation_path': ACTUAL, 'configured_robot_root': ROOT}, DOFS)
        view = ArticulationView()
        view.change_metadata = True
        with self.assertRaisesRegex(ValueError, 'metadata changed during'):
            read_raw_articulation_buffers(view,
                {'native_articulation_path': ACTUAL, 'configured_robot_root': ROOT}, DOFS)


if __name__ == '__main__':
    unittest.main()

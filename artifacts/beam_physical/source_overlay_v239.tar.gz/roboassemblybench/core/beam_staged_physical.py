"""Beam roles/geometry with Plumbers-style supported versus unloaded checks.

The opt-in contract was explicitly selected by the user on 2026-11-10.
No body state, force threshold, grasp anchor or collision setting is modified.
"""
import copy
import os

PROFILE = 'plumbers_staged_v1'
GRASP_POINT_PROFILE = 'plumbers_staged_v2'
EMPTY_RETREAT_MIN_TIMEOUT_STEPS = 6960
PREFIX_EXACT_CLOSE_PHASES = frozenset({
    'base_6_close_and_attach', 'assemble_00_part_3_close_and_attach',
})
EMPTY_CORRIDOR_RETREATS = {
    'hold_2_approach_clearance': 'fabrica_beam_3',
    'hold_2_final_retreat': 'fabrica_beam_2',
}


def _bind_empty_joint_skill(skill):
    if skill.get('name') not in {'move_arm_to_joint_positions', 'ur5e_move_arm_to_joint_positions'}:
        return False
    if skill.get('gripper_command') != 'open' or skill.get('requires_held_object'):
        raise ValueError('Beam staged joint clearance/home must be explicitly open and unloaded')
    from toolkits.factory_dual_franka_assembly.ur5e_skill_api import UR5E_ASSEMBLY_ADAPTER
    # The v169 recipe predates this atom's metadata registration. Bind every
    # generated occurrence explicitly, including partner homes and final holds.
    skill.setdefault('adapter', UR5E_ASSEMBLY_ADAPTER)
    # Reuse the adapter's bounded published-command cache instead of restarting
    # each small increment at the measured joints. Preserve existing empty-arm
    # handoffs, authored endpoints and publication/track caps.
    skill['reference_mode'] = 'command'
    skill.update(requires_held_object=False, requires_empty_arm=True,
                 require_success=True, fallback='fail')
    return True


def _apply_empty_joint_speed_profile(skill):
    if skill.get('name') not in {'move_arm_to_joint_positions', 'ur5e_move_arm_to_joint_positions'}:
        return False
    if not (skill.get('requires_empty_arm') and skill.get('gripper_command') == 'open'
            and skill.get('requires_held_object') is False):
        raise ValueError('Joint transit speed requires explicit open unloaded ownership')
    floor = .004 if int(skill.get('joint_target_stable_steps', 8)) >= 24 else .008
    for key in ('max_joint_step', 'max_command_joint_step', 'max_command_wrist_joint_step'):
        if key in skill:
            skill[key] = max(floor, float(skill[key]))
    skill['beam_fast_empty_joint'] = True
    return True


def validate_staged_skill_bindings(phases, task_metadata, robots):
    """Use the production normalization/default merge before any engine starts."""
    import importlib
    from types import SimpleNamespace
    from toolkits.factory_dual_franka_assembly.local_skills import (
        LocalSkillExecutor, normalize_local_skill_spec,
    )
    from toolkits.factory_dual_franka_assembly.ur5e_skill_api import UR5eAssemblySkillAPI
    known = {definition.runtime_name for definition in UR5eAssemblySkillAPI.definitions}
    known.add('ur5e_move_arm_to_joint_positions')
    executor = LocalSkillExecutor()
    task = SimpleNamespace(cfg=SimpleNamespace(task_metadata=task_metadata))
    checked = []
    for phase in phases:
        for robot in robots:
            robot = robot['name'] if isinstance(robot, dict) else robot
            spec = normalize_local_skill_spec(phase, robot)
            if spec is None:
                continue
            spec = executor._merge_task_defaults(task, spec)
            ref = spec.get('adapter') or spec.get('adapter_class')
            if spec['name'] not in known or not ref:
                raise ValueError(f"Unbound Beam local skill: {phase['name']}/{robot}/{spec['name']}")
            module, attribute = str(ref).split(':', 1)
            adapter = getattr(importlib.import_module(module), attribute)
            if not callable(getattr(adapter, 'act', None)):
                raise ValueError(f'Beam adapter has no action consumer: {ref}')
            checked.append(dict(phase=phase['name'], robot=robot, skill=spec['name'], adapter=ref))
    return checked


def _apply_empty_retreat_budget(phase, skill):
    # Follow Plumbers' motion-budget floor, using Beam's measured late pace.
    # No endpoint, convergence tolerance, command rate or physics gate changes.
    if (skill.get('name') == 'ur5e_retreat_vertical'
            and skill.get('empty_arm_phase_handoff')
            and skill.get('gripper_command') == 'open'
            and not skill.get('requires_held_object')):
        phase['timeout_steps'] = max(int(phase['timeout_steps']), EMPTY_RETREAT_MIN_TIMEOUT_STEPS)
        return True
    return False


def _apply_free_transit_profile(phase, skill):
    """Accelerate open unloaded travel, retaining authored goals/contact steps."""
    if (skill.get('name') not in {'ur5e_move_above_part', 'ur5e_retreat_vertical'}
            or skill.get('gripper_command') != 'open'
            or skill.get('requires_held_object')
            or skill.get('servo_target_object_pose') is True):
        return False
    # 36 showed negligible step gain but measurable CAD cost on already-fast
    # 8--15mm travel. Retain those original controllers and reuse their checks.
    if float(skill.get('cartesian_position_step', .01)) > .004:
        return False
    skill.update(beam_free_transit=True, require_success=True, fallback='fail', requires_held_object=False,
                 requires_empty_arm=True, empty_arm_phase_handoff=True,
                 use_arm_ik_controller=False,
                 cartesian_position_command_warm_start=True,
                 cartesian_position_command_lookahead=.02,
                 cartesian_position_command_accumulation_step=.004,
                 cartesian_position_command_slowdown_distance=.02,
                 cartesian_position_command_near_lookahead=.001,
                 cartesian_position_step=max(.004, float(skill.get('cartesian_position_step', .004))))
    # Raise only explicitly tiny publication limits to 1.92 rad/s at240Hz.
    # Preserve larger/default limits; actual tracking and
    # existing angular/force limits are independent and remain in force.
    for key in ('max_joint_step', 'max_command_joint_step'):
        if key in skill:
            skill[key] = max(.008, float(skill[key]))
    return True


def _apply_empty_descent_profile(phase, skill):
    # Retain the reached prefix exactly; repair later unloaded pregrasps
    # together. Per-command position increment remains the original 1mm.
    eligible = {'hold_3_descend', 'assemble_01_part_2_descend',
                'handover_left_2_descend', 'hold_2_descend'}
    if phase['name'] not in eligible or skill.get('name') != 'ur5e_descend_to_grasp':
        return False
    if (skill.get('requires_held_object')
            or skill.get('gripper_command') not in ('open', 1.0)
            or skill.get('servo_target_object_pose') is True):
        raise ValueError('Empty pregrasp requires original open unloaded descent: ' + repr((phase['name'], skill)))
    skill.update(beam_free_transit=True, beam_empty_pregrasp_local_ik=True,
                 require_success=True, fallback='fail',
                 requires_held_object=False, requires_empty_arm=True,
                 empty_arm_phase_handoff=True, gripper_command='open',
                 cartesian_position_command_warm_start=True,
                 cartesian_position_command_lookahead=.004,
                 cartesian_position_command_accumulation_step=.001,
                 cartesian_position_command_slowdown_distance=.02,
                 cartesian_position_command_near_lookahead=.001)
    return True


def selected_profile():
    value = os.environ.get('BEAM_PHYSICAL_ACCEPTANCE_PROFILE', 'legacy')
    if value not in ('legacy', PROFILE, GRASP_POINT_PROFILE):
        raise ValueError('Unknown Beam physical acceptance profile: ' + value)
    return value


def _apply_empty_corridor_retreat_profile(phase, skill):
    """Use the proven descent solver only on the two empty side retreats."""
    reference_object = EMPTY_CORRIDOR_RETREATS.get(phase['name'])
    if reference_object is None:
        return False
    if not (skill.get('name') == 'ur5e_retreat_vertical'
            and skill.get('robot') == 'franka_right'
            and skill.get('gripper_command') == 'open'
            and skill.get('requires_held_object') is False
            and all(skill.get(key) for key in (
                'requires_empty_arm', 'empty_arm_phase_handoff', 'beam_free_transit',
                'relative_to_current_tcp', 'lock_target_position', 'lock_target_orientation'))
            and skill.get('guard_ik_branch_jump') is True
            and skill.get('ik_branch_jump_limit') == .15
            and 'ik_branch_jump_tolerance_steps' not in skill
            and skill.get('offset_reference_object') == reference_object):
        raise ValueError('Local corridor retreat requires its original open unloaded contract: ' + phase['name'])
    skill.update(beam_empty_retreat_local_ik=True,
                 cartesian_position_command_lookahead=.004,
                 cartesian_position_command_accumulation_step=.001)
    return True


def apply_staged_contract(phases, success, *, robots, spec):
    retreat_flag = os.environ.get('BEAM_EMPTY_RETREAT_LOCAL_IK', '0')
    if retreat_flag not in {'0', '1'}:
        raise ValueError('BEAM_EMPTY_RETREAT_LOCAL_IK must be 0 or 1')
    retreat_matches = {name: 0 for name in EMPTY_CORRIDOR_RETREATS}
    active_profile = selected_profile()
    if active_profile == 'legacy':
        return None
    before = copy.deepcopy(success)
    # Follow Plumbers' real joint-home verification, after both clearance paths.
    from roboassemblybench.core.fabrica_canonical import _initial_arm_joint_positions
    from roboassemblybench.core.beam_physical_compiler import _skill_phase
    names = [spec.get('assembly_robot', 'franka_left'), spec.get('base_robot', 'franka_right')]
    authored = {robot['name']: robot for robot in robots}

    def home(robot):
        return _skill_phase(skill='move_arm_to_joint_positions', robot=robot,
            phase_name='home', timeout_steps=4800, parameters=dict(
                joint_positions=_initial_arm_joint_positions(authored[robot]),
                joint_position_tolerance=.025, joint_target_stable_steps=24,
                max_joint_step=.001, max_command_joint_step=.001,
                max_command_wrist_joint_step=.001, max_command_tracking_error=.06,
                max_wrist_command_tracking_error=.06, empty_arm_phase_handoff=True,
                gripper_command='open', requires_held_object=False,
                require_success=True, fallback='fail'))['local_skill']

    final = phases[-1]
    if final['name'] != 'beam_final_unloaded_verification':
        raise ValueError('Beam staged contract requires its original terminal verification')
    for robot in names:
        phase = dict(name='beam_terminal_home_' + robot, timeout_steps=4800,
                     robot_targets={}, local_skill=home(robot),
                     gripper_commands={name: 'open' for name in names},
                     beam_coordinated=True, beam_idle_hold_anchor=True,
                     beam_table_support_objects=copy.deepcopy(final['beam_table_support_objects']),
                     beam_installed_parts=copy.deepcopy(final['beam_installed_parts']),
                     beam_require_table_support=True,
                     advance=dict(type='all_of', min_steps=24, conditions=[
                         dict(type='local_skill_complete', robot=robot, skill='move_arm_to_joint_positions'),
                         dict(type='gripper_open', robot=robot, minimum_openness=.95)]))
        if robot == names[1]:
            phase['local_skills'] = {names[0]: home(names[0])}
            phase['advance']['conditions'].extend([
                dict(type='local_skill_complete', robot=names[0], skill='move_arm_to_joint_positions'),
                dict(type='gripper_open', robot=names[0], minimum_openness=.95),
            ])
        phases.insert(len(phases)-1, phase)
    final.setdefault('local_skills', {}).update({robot: home(robot) for robot in names})
    final['advance']['conditions'].extend(
        dict(type='gripper_open', robot=robot, minimum_openness=.95) for robot in names)
    for phase in phases:
        phase['beam_physical_acceptance_profile'] = active_profile
        if active_profile == GRASP_POINT_PROFILE:
            for attachment in phase.get('attach', []):
                if attachment.get('attachment_mode') in ('pure_physical_grasp', 'contact_pure_physical_grasp'):
                    attachment['hold_position_slip_reference'] = 'grasp_point'
        skills = [phase.get('local_skill') or {}, *phase.get('local_skills', {}).values()]
        for skill in skills:
            _bind_empty_joint_skill(skill)
            if active_profile == GRASP_POINT_PROFILE:
                _apply_empty_joint_speed_profile(skill)
            if skill.get('name') == 'ur5e_close_gripper' and skill.get('close_force_regulation'):
                skill.update(close_force_weak_side_preload=True,
                             close_force_require_clamp_band=True)
                if active_profile == GRASP_POINT_PROFILE:
                    skill.update(close_force_recenter_track_weak_side=True,
                                 close_force_recenter_consistent_target=True,
                                 close_force_recenter_feedback=True,
                                 close_recenter_feedback_lookahead=.0002,
                                 close_recenter_feedback_step=.000005,
                                 close_force_recenter_single_contact_full_step=True)
                    if phase['name'] not in PREFIX_EXACT_CLOSE_PHASES:
                        skill.update(close_recenter_feedback_command_space=True,
                                     close_recenter_feedback_max_tracking_offset=.001)
                    if phase['name'] != 'base_6_close_and_attach':
                        # Plumbers centers moving grasps inside their carrying
                        # band before capture. Beam keeps its original 4--12 N
                        # gate; target its midpoint instead of stopping at 2 N.
                        low = float(skill['close_force_low'])
                        high = float(skill['close_force_high'])
                        if not 0.0 < low < high:
                            raise ValueError('Moving grasp requires an ordered force band')
                        skill['close_force_recenter_compare_jaw_state'] = True
                        skill['close_force_min_stable'] = low
                        skill['close_force_balance_min'] = (low + high) / 2.0
            if (active_profile == GRASP_POINT_PROFILE
                    and phase['name'].endswith(('_retreat', '_park'))
                    and skill.get('gripper_command') == 'open'
                    and skill.get('requires_held_object') is False):
                skill['empty_arm_phase_handoff'] = True
            if active_profile == GRASP_POINT_PROFILE:
                _apply_empty_retreat_budget(phase, skill)
                # Preserve the original budget eligibility before adding the
                # new unloaded-travel markers to other Cartesian stages.
                _apply_free_transit_profile(phase, skill)
                _apply_empty_descent_profile(phase, skill)
                if retreat_flag == '1' and skill is phase.get('local_skill'):
                    if _apply_empty_corridor_retreat_profile(phase, skill):
                        retreat_matches[phase['name']] += 1
        advance = phase['advance']
        if phase['name'] == 'base_6_set_down':
            advance.update(verification_mode='active_support', position_drift_tolerance=.0005,
                           orientation_drift_tolerance=.008726646259971648)
        elif phase['name'] == 'beam_final_unloaded_verification':
            for condition in advance['conditions']:
                if condition['type'] == 'beam_table_supported':
                    condition.update(verification_mode='unloaded',
                                     linear_velocity_threshold=.01, angular_velocity_threshold=.1)
                elif condition['type'] == 'objects_static':
                    condition.update(type='beam_staged_objects_stable',
                                     linear_velocity_threshold=.01, angular_velocity_threshold=.1,
                                     position_drift_tolerance=.002, orientation_drift_tolerance=.03,
                                     require_unloaded=True)
        elif phase['name'].endswith('_release') and advance.get('type') == 'all_of':
            for condition in advance.get('conditions', []):
                if condition.get('type') == 'objects_static':
                    condition.update(type='beam_staged_objects_stable', require_unloaded=False,
                                     position_drift_tolerance=.0005,
                                     orientation_drift_tolerance=.008726646259971648)
            # As in Plumbers, qualify supported poses instead of raw unloaded
            # velocities. Release/interactions/target conditions still all apply.
            advance['physics_stable_steps'] = 30
    if active_profile == GRASP_POINT_PROFILE and retreat_flag == '1':
        if any(count != 1 for count in retreat_matches.values()):
            raise ValueError('Local corridor retreat phases must each occur exactly once: ' + repr(retreat_matches))
    for entry in success:
        entry.update(position_tolerance=.003, orientation_tolerance=.04,
                     linear_velocity_threshold=.01, angular_velocity_threshold=.1,
                     require_released=True, require_static=True)
    if os.environ.get('BEAM_COMMON_POSE_WINDOW', '0') == '1':
        for phase in phases:
            if phase.get('detach') and phase['name'].endswith('_release'):
                phase['beam_release_fixed_command'] = True
            for condition in phase.get('advance', {}).get('conditions', []):
                if condition.get('type') == 'beam_staged_objects_stable':
                    condition['common_pose_window'] = True
    metadata = dict(profile=active_profile, reference='baiyu858/RoboAssemblyBench@9497b839',
                supported_pose_drift_m=.0005, supported_pose_drift_rad=.008726646259971648,
                seating_steps=96, release_steps=30, terminal_steps=240,
                terminal_position_m=.003, terminal_orientation_rad=.04,
                terminal_linear_speed=.01, terminal_angular_speed=.1,
                legacy_terminal_linear_speed=.002, legacy_terminal_angular_speed=.02,
                legacy_success_criteria=before, exploration_bypass=False)
    if active_profile == GRASP_POINT_PROFILE:
        metadata.update(grasp_slip_reference='frozen_target_pair_force_patch_midpoint',
                        grasp_position_slip_m=.003, grasp_orientation_slip_rad=.0872664626,
                        single_contact_recenter_default_step_m=.0002,
                        two_loaded_finger_balance_step_m=.000025,
                        legacy_object_origin_diagnostic=True)
    if os.environ.get('BEAM_FINAL_POSE_ACCEPTANCE', '0') == '1':
        if os.environ.get('BEAM_COMMON_POSE_WINDOW', '0') != '1':
            raise ValueError('Final pose acceptance requires the common fixed-reference window')
        final = phases[-1]
        assert final['name'] == 'beam_final_unloaded_verification'
        assert final['advance']['physics_stable_steps'] == 240
        final['beam_final_pose_acceptance'] = True
        for condition in final['advance']['conditions']:
            if condition['type'] == 'beam_staged_objects_stable':
                condition['unloaded_pose_window_acceptance'] = True
            elif condition['type'] == 'beam_table_supported':
                condition['unloaded_pose_window_acceptance'] = True
        for criterion in success:
            criterion['static_acceptance'] = 'beam_common_pose_window'
        metadata.update(final_stability_mode='fixed_reference_pose_window',
                        final_raw_velocity_role='independent_diagnostic')
    return metadata

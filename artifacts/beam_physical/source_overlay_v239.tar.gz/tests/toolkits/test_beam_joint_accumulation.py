"""Production joint dispatch against recorded SDK state and explicit lag models.

Recorded sparse feedback checks publication arithmetic, not counterfactual
physics. The response model is calibrated only to the dominant recorded wrist;
its other joints are synthetic. Native geometry, loads and success remain open.
"""
import copy,json,os,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
from tests.toolkits.test_beam_joint_dispatch import task_for,Policy,ROBOT
from roboassemblybench.core.beam_staged_physical import _bind_empty_joint_skill

DATA=json.loads((Path(__file__).parents[1]/'fixtures/beam_v209_joint_progress.json').read_text())
STAGE=DATA['by_phase']['hold_3_high_joint_clearance']
SERIES=STAGE['all_sampled_series']


def setup(mode='command'):
    t=task_for();t.spec=copy.deepcopy(STAGE['phase_spec']);_bind_empty_joint_skill(t.spec['local_skill'])
    t.spec['local_skill']['reference_mode']=mode;t.phase_specs=[t.spec]
    t._attachments=copy.deepcopy(STAGE['raw_selected_packets'][0]['task_constraints']['attachments'])
    t.subset.q=np.array(SERIES[0]['actual_q']);t.step_counter=SERIES[0]['step'];t.phase_step_counter=t.step_counter-t.phase_entry_step
    p=Policy();a=p._local_skill_executor._load_adapter(t.spec['local_skill']['adapter'],t.spec['local_skill'])
    a._remember_arm_command(t,ROBOT,np.array(SERIES[0]['published_q']))
    return t,p


def action(t,p):
    result=p.act(t)[ROBOT]
    assert not t.failed
    return np.array(result['arm_joint_controller'][0])


class AccumulatedJointCommand(unittest.TestCase):
    def setUp(self):
        c=patch.dict(os.environ,{'BEAM_IDLE_HOLD_ANCHOR':'1'},clear=True);c.start();self.addCleanup(c.stop)

    def test_real_SDK_reference_accumulates_in_actual_policy(self):
        for packet,row in zip(STAGE['raw_selected_packets'],[SERIES[0],SERIES[94],SERIES[188],SERIES[282],SERIES[-1]]):
            # Each paired branch starts from the same genuine nonzero state and
            # accepted SDK target. No IK/qualification predicate is replaced.
            outputs=[]
            for mode in ['current','command']:
                t,p=setup(mode);t.subset.q=np.array(row['actual_q'])
                a=next(iter(p._local_skill_executor._adapter_cache.values()))
                a._remember_arm_command(t,ROBOT,np.array(row['published_q']))
                outputs.append(action(t,p))
            before=np.array(row['published_q'])
            self.assertGreater(outputs[1][-1]-before[-1],outputs[0][-1]-before[-1]+.002)
            self.assertLessEqual(np.max(np.abs(outputs[1]-before)),.004+1e-12)

    def test_sparse_recorded_feedback_retains_limits_without_claiming_convergence(self):
        t,p=setup();previous=np.array(SERIES[0]['published_q'])
        for row in SERIES:
            t.subset.q=np.array(row['actual_q']);t.step_counter=row['step'];t.phase_step_counter=t.step_counter-t.phase_entry_step
            published=action(t,p)
            self.assertLessEqual(np.max(np.abs(published-previous)),.004+2e-7)
            self.assertTrue(np.all(np.abs(published-t.subset.q)<=np.array([.18]*3+[.12]*3)+1e-9))
            previous=published
        self.assertFalse(t.completed)

    def test_unmoving_native_feedback_never_reports_goal_success(self):
        t,p=setup();q=t.subset.q.copy()
        for _ in range(1200):
            t.step_counter+=1;t.phase_step_counter+=1;published=action(t,p)
            self.assertTrue(np.all(np.abs(published-q)<=np.array([.18]*3+[.12]*3)+1e-9))
        self.assertFalse(t.completed)

    def test_same_lag_model_preserves_old_failure_and_allows_accumulation(self):
        # This identifies no full physical plant: only the dominant wrist's
        # observed mean response is used; all six model responses are assumed equal.
        alpha=(SERIES[-1]['actual_q'][-1]-SERIES[0]['actual_q'][-1])/(SERIES[-1]['physics_step_index']-SERIES[0]['physics_step_index'])/.004
        self.assertTrue(.05<alpha<.12)
        completed={};last_errors={}
        for mode in ['current','command']:
            t,p=setup(mode)
            for _ in range(t.spec['timeout_steps']):
                published=action(t,p);t.subset.q+=alpha*(published-t.subset.q)
                t.step_counter+=1;t.phase_step_counter+=1
                if t.completed:break
            completed[mode]=bool(t.completed);last_errors[mode]=float(np.max(np.abs(t.subset.q-np.array(t.spec['local_skill']['joint_positions']))))
        self.assertFalse(completed['current']);self.assertGreater(last_errors['current'],2.)
        self.assertTrue(completed['command']);self.assertLessEqual(last_errors['command'],.005)

    def test_recorded_loaded_right_ownership_is_still_rejected(self):
        t,p=setup();t._attachments['synthetic_loaded_right']={'robot_name':ROBOT};p.act(t)
        self.assertTrue(t.failed);self.assertIn('joint_home_requires_empty_arm',t.terminal_reason)


if __name__=='__main__':unittest.main()

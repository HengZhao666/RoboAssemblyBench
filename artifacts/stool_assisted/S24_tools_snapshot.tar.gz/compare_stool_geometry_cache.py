"""Offline measured-native/CAD comparison of an undeployed exact FCL cache.

Reads bounded immutable prefixes of a run's JSONL files. Creates only a new
review directory, never edits run/control files and never imports/starts Isaac.
Native after_action positions and SDK targets define interpolation fixtures;
this is geometry-query equivalence, not a replay of native physics or the full
controller. All scene checks, samples, exemptions and first-failure results are
compared exactly against the current unmodified production implementation.
"""
from __future__ import annotations
import argparse,collections,contextlib,hashlib,itertools,json,math,statistics,time
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import fcl
from stool_geometry_guard import StoolMeshGuard,ARM,MIMIC,_inverse
from stool_geometry_cache_candidate import ExactPairCacheStoolMeshGuard
from stool_sweep_model import SceneModel
from toolkits.constraint_checking.integration.entity_geometry import pose_matrix


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def snapshot_lines(path,keep):
    size=path.stat().st_size;digest=hashlib.sha256();rows=[];number=0;partial=0;errors=[]
    with path.open('rb') as stream:
        while stream.tell()<size:
            line=stream.readline(size-stream.tell());digest.update(line);number+=1
            if not line.endswith(b'\n'):
                partial=len(line);break
            if not line.strip():continue
            try:
                row=json.loads(line)
                if keep(row):rows.append(dict(source_line=number,source_line_sha256=hashlib.sha256(line).hexdigest(),row=row))
            except (TypeError,ValueError) as exc:errors.append(dict(line=number,error=repr(exc)))
    return rows,dict(path=str(path),prefix_bytes=size,prefix_sha256=digest.hexdigest(),complete_lines=number-bool(partial),
        ignored_incomplete_tail_bytes=partial,errors=errors,scope='exact file byte prefix at invocation; original growing file is unchanged')


def native_matrix(value):
    value=np.asarray(value,float)
    if value.shape!=(7,) or not np.all(np.isfinite(value)):raise ValueError('invalid measured native transform')
    return pose_matrix(value[:3],value[[6,3,4,5]])


def clock(row):
    stamp=row.get('physics_stamp',{})
    if not stamp.get('valid'):raise ValueError('fixture lacks valid native clock')
    return int(stamp['epoch']),int(stamp['index'])


def context_for(row,events,phases):
    name=row['phase']
    if name not in phases:raise ValueError('raw phase missing from actual task configuration: '+name)
    attachments={};used=[]
    for event in events:
        value=event['row'];kind=value.get('event');obj=value.get('object')
        if kind not in {'attach_measured_pose','support_measured_pose','detach_grasp'}:continue
        if not value.get('physics_stamp',{}).get('valid'):
            if kind=='attach_measured_pose':raise ValueError('captured attachment event has no valid native stamp')
            continue
        if clock(value)>clock(row):continue
        if kind=='attach_measured_pose':
            hand=pose_matrix(value['native_hand_position'],value['native_hand_orientation'])
            body=pose_matrix(value['position'],value['orientation'])
            attachments[obj]=dict(robot_name=value['robot'],frozen_hand_object=_inverse(hand)@body)
            used.append(event['source_line'])
        elif kind in {'support_measured_pose','detach_grasp'}:
            attachments.pop(obj,None);used.append(event['source_line'])
    task=SimpleNamespace(phase=name,_attachments=attachments)
    task.get_current_phase_spec=lambda:phases[name]
    return task,used


def select_native(rows,limit):
    grouped=collections.OrderedDict()
    for envelope in rows:
        row=envelope['row']
        if row.get('valid') is not True or row.get('boundary')!='after_action':continue
        grouped.setdefault(row['phase'],[]).append(envelope)
    selected=[]
    for group in grouped.values():
        indices=sorted(set([0,1,len(group)-2,len(group)-1]))
        selected.extend(group[i] for i in indices if 0<=i<len(group))
    selected.sort(key=lambda envelope:envelope['source_line'])
    if len(selected)>limit:
        selected=[selected[i] for i in sorted(set(np.linspace(0,len(selected)-1,limit,dtype=int).tolist()))]
    if not selected:raise ValueError('no complete valid after_action native snapshots to compare')
    return selected


def build_checker(cls,data,initial,model):
    checker=cls.__new__(cls);checker.fcl=fcl;checker.model=model;checker.data=data
    checker.meshes=data['visible_meshes'];checker.objects=set(data['task_objects']);checker.contract=data['task_contract']
    checker.support_object_names={'fabrica_fixture','optical_board','factory_tabletop_visual'}
    checker.initial_support={row['mesh_a']+' | '+row['mesh_b']:dict(row) for row in initial['baseline_support_pairs']}
    exemptions={frozenset((row['mesh_a'],row['mesh_b'])) for row in initial['exemptions']}
    checker.pairs=[];checker.shapes=[];corners=[]
    for mesh in checker.meshes:
        points=np.asarray(mesh['points'],float);faces=np.asarray(mesh['triangles'],np.int32)
        shape=fcl.BVHModel();shape.beginModel(len(faces),len(points));shape.addSubModel(points,faces);shape.endModel()
        checker.shapes.append(fcl.CollisionObject(shape))
        corners.append(list(itertools.product(*zip(points.min(axis=0),points.max(axis=0)))))
    checker.corners=np.asarray(corners,float)
    for i,j in itertools.combinations(range(len(checker.meshes)),2):
        a,b=checker.meshes[i],checker.meshes[j]
        if a['body']==b['body']:continue
        if not (a['robot'] or b['robot'] or a['object'] in checker.objects or b['object'] in checker.objects):continue
        if frozenset((a['prim'],b['prim'])) in exemptions:continue
        checker.pairs.append((i,j))
    checker.indices=np.asarray(checker.pairs,int).reshape(-1,2)
    if len(checker.pairs)!=initial['pairs']:raise ValueError('offline pair membership/count differs from frozen original report')
    return checker


def measured_scenes(envelope,events,phases,data,model):
    row=envelope['row'];task,used=context_for(row,events,phases)
    native={path:np.asarray(value,float) for path,value in data['body_rest'].items()}
    native.update({path:native_matrix(value['transform']) for path,value in row['bodies'].items()})
    actual={name:np.asarray(robot['positions'],float) for name,robot in row['robots'].items()}
    targets={name:np.asarray(robot['position_targets'],float) for name,robot in row['robots'].items()}
    if set(actual)!=set(data['robots']):raise ValueError('fixture lacks both native articulation snapshots')
    final={name:value.copy() for name,value in actual.items()}
    for name in actual:
        names=data['robots'][name]['joint_names'];arm=[names.index(joint) for joint in ARM]
        if row['robots'][name]['joint_names']!=names:raise ValueError('native and geometry joint name order differs')
        final[name][arm]=targets[name][arm]
        driver=names.index('finger_joint');delta=targets[name][driver]-actual[name][driver]
        for joint,sign in MIMIC.items():final[name][names.index(joint)]=actual[name][names.index(joint)]+sign*delta
    origin=model.poses(actual);robot_bodies={mesh['body'] for mesh in data['visible_meshes'] if mesh['robot']}
    if not robot_bodies <= set(row['bodies']):raise ValueError('measured native fixture lacks full robot/gripper bodies')
    corrections={body:native[body]@_inverse(origin[body]) for body in robot_bodies}
    object_bodies={name:data['object_body_coverage'][name][0] for name in data['task_objects']}
    if not set(object_bodies.values())<=set(row['bodies']):raise ValueError('measured native fixture lacks nine parts')
    maximum=max(float(np.max(abs(final[n]-actual[n]))) for n in actual)
    count=max(2,int(math.ceil(maximum/data['task_contract']['max_joint_step_rad']))+1)
    if count>512:raise ValueError('reconstructed native SDK target sweep exceeds original sample budget')
    scenes=[('native_actual',native)]
    for fraction in np.linspace(0.,1.,count):
        fk=model.poses({n:actual[n]+fraction*(final[n]-actual[n]) for n in actual});poses=dict(native)
        for body,correction in corrections.items():poses[body]=correction@fk[body]
        for name,state in task._attachments.items():
            hand=data['robots'][state['robot_name']]['root_path']+'/wrist_3_link'
            poses[object_bodies[name]]=poses[hand]@state['frozen_hand_object']
        scenes.append((float(fraction),poses))
    return task,scenes,dict(native_stamp=row['physics_stamp'],phase=row['phase'],task_step=row['task_step'],
        source_line=envelope['source_line'],source_line_sha256=envelope['source_line_sha256'],
        boundary=row['boundary'],requested_sweep_samples=count,attachment_event_lines=used,
        attached_objects=list(task._attachments),target_source='same native snapshot accepted SDK position targets; gripper mimic endpoints reconstructed using unchanged Robotiq mapping',
        payload_relation_source='same-tick native hand/object poses retained in actual attach_measured_pose events; matrix reconstruction for offline fixtures')


def evaluate(checker,scenes,cached):
    rows=[];first=None;started=time.perf_counter()
    scope=checker.exact_pair_cache_scope() if cached else contextlib.nullcontext()
    with scope:
        for label,poses in scenes:
            row=checker._check_scene(poses);rows.append(dict(sample=label,result=row))
            if row['collisions']:
                first=dict(sample=label,collision=row['collisions'][0]);break
    return rows,first,time.perf_counter()-started,dict(checker.last_exact_pair_cache_stats) if cached else None


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',type=Path,required=True)
    parser.add_argument('--output-dir',type=Path,required=True);parser.add_argument('--max-native-frames',type=int,default=24)
    parser.add_argument('--repetitions',type=int,default=3);args=parser.parse_args()
    run=args.run.resolve();out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=False)
    report=dict(passed=False,native_physics_executed=0,deployed=False,errors=[],frames=[],run=str(run))
    try:
        files={name:run/name for name in ('scene_geometry.json','stool_geometry_initial.json','task_config_snapshot.json')}
        report['static_input_sha256']={name:sha(path) for name,path in files.items()}
        data=json.loads(files['scene_geometry.json'].read_text());initial=json.loads(files['stool_geometry_initial.json'].read_text())
        config=json.loads(files['task_config_snapshot.json'].read_text());config=config[0] if isinstance(config,list) else config
        phases={phase['name']:phase for phase in config['phase_specs']};model=SceneModel(files['scene_geometry.json'])
        raw,raw_prefix=snapshot_lines(run/'independent_native_trace.jsonl',lambda row:row.get('valid') is True and row.get('boundary')=='after_action')
        events,event_prefix=snapshot_lines(run/'assisted_trace.jsonl',lambda row:row.get('event')!='fabrica_final_published_batch')
        if raw_prefix['errors'] or event_prefix['errors']:raise ValueError('source prefix contains malformed complete JSON rows')
        selected=select_native(raw,args.max_native_frames)
        report.update(raw_prefix=raw_prefix,events_prefix=event_prefix,geometry_mesh_count=len(data['visible_meshes']),
            original_pair_count=initial['pairs'],baseline_guard_sha256=sha(Path(__file__).with_name('stool_geometry_guard.py')),
            candidate_sha256=sha(Path(__file__).with_name('stool_geometry_cache_candidate.py')),
            selection='each observed phase first/last two complete valid after_action rows; deterministic evenly spread cap')
        for name,values in [('selected_native_fixtures.jsonl',selected),('nonbatch_event_fixtures.jsonl',events)]:
            with (out/name).open('x') as stream:
                for value in values:stream.write(json.dumps(value,separators=(',',':'))+'\n')
        baseline=build_checker(StoolMeshGuard,data,initial,model);candidate=build_checker(ExactPairCacheStoolMeshGuard,data,initial,model)
        all_old=[];all_new=[];query_old=0;query_new=0
        for index,envelope in enumerate(selected):
            task,scenes,binding=measured_scenes(envelope,events,phases,data,model)
            baseline.task=candidate.task=task
            old,old_first,_,_=evaluate(baseline,scenes,False);new,new_first,_,stats=evaluate(candidate,scenes,True)
            equal=old==new and old_first==new_first
            timings_old=[];timings_new=[]
            for repetition in range(args.repetitions):
                order=((baseline,False),(candidate,True)) if repetition%2==0 else ((candidate,True),(baseline,False))
                for checker,cached in order:
                    result,first,seconds,_=evaluate(checker,scenes,cached)
                    if result!=old or first!=old_first:raise ValueError('repeat changed exact geometry result')
                    (timings_new if cached else timings_old).append(seconds)
            old_median=statistics.median(timings_old);new_median=statistics.median(timings_new)
            all_old.append(old_median);all_new.append(new_median)
            old_queries=sum(row['result']['exact_overlap_candidates'] for row in old);query_old+=old_queries;query_new+=stats['misses']
            record=dict(binding,exact_equal=equal,first_failure_original=old_first,first_failure_candidate=new_first,
                evaluated_scene_samples=len(old),cache_stats=stats,original_fcl_queries=old_queries,
                original_scene_results=old,candidate_scene_results=new,original_median_seconds=old_median,
                candidate_median_seconds=new_median,speedup=old_median/new_median if new_median else None)
            report['frames'].append(record)
            if not equal:raise ValueError('candidate differs from original exact scene/policy/first-failure output')
            print(json.dumps(dict(frame=index+1,total=len(selected),phase=binding['phase'],exact_equal=equal,
                old_s=old_median,new_s=new_median,cache_hits=stats['hits'])),flush=True)
        report['static_inputs_unchanged']=all(sha(path)==report['static_input_sha256'][name] for name,path in files.items())
        report['baseline_control_unchanged']=sha(Path(__file__).with_name('stool_geometry_guard.py'))==report['baseline_guard_sha256']
        if not report['static_inputs_unchanged'] or not report['baseline_control_unchanged']:raise ValueError('frozen static input/baseline source changed during offline review')
        report.update(passed=True,original_cpu_seconds=sum(all_old),candidate_cpu_seconds=sum(all_new),
            aggregate_speedup=sum(all_old)/sum(all_new),original_fcl_queries=query_old,candidate_fcl_queries=query_new,
            unchanged_domains=['all full-scene AABB pairs','all native/interpolation samples','all shape transforms','per-sample policy classification',
                'collision threshold and max8 contacts','collision depths/exemptions/first-failure results'],
            scope='offline actual S03 measured-native/CAD fixtures and reconstructed native SDK-target sweeps; no physical replay, deployment, or full-controller equivalence claim')
    except Exception as exc:report['errors'].append(type(exc).__name__+': '+str(exc))
    (out/'geometry_cache_comparison.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({key:report.get(key) for key in ('passed','aggregate_speedup','original_fcl_queries','candidate_fcl_queries','errors')}))
    return 0 if report['passed'] else 1

if __name__=='__main__':raise SystemExit(main())

"""List or exclusively pack closed-run delivery; never decode or alter originals."""
from pathlib import Path
import argparse, hashlib, io, json, os, re, tarfile
CAMERAS = {'observation.images.front', 'observation.images.left_wrist', 'observation.images.right_wrist'}
REQUIRED = {'collect_results.json','independent_audit.json','formal_closure.json','media_verification.json',
    'source_binding.json','runtime_source_binding.json','task_config_snapshot.json','expected_runtime_config.json',
    'launch_receipt.json','launch_gate.json','worker_build_preflight.json','runtime_configuration_binding.json',
    'runtime_initialization_preflight.json','video_frame_clock.jsonl','finished_at','exit_code'}

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for b in iter(lambda: stream.read(1048576), b''): h.update(b)
    return h.hexdigest()

def require(condition, message):
    if not condition: raise ValueError(message)

def safe(root, relative):
    p = Path(relative)
    require(not p.is_absolute() and '..' not in p.parts and '\\' not in str(p), 'unsafe member path')
    target = root / p
    require(not target.is_symlink() and target.resolve().is_relative_to(root.resolve()), 'symlink or escaping member')
    return target

def plan(root, run_id, grant, output=None):
    require(re.fullmatch(r'S[0-9]{2,}', run_id) and re.fullmatch(r'G[0-9]{2,}', grant), 'invalid run/grant ID')
    root = root.resolve(); run = safe(root, 'runs/'+run_id)
    require(run.is_dir() and all(safe(run,n).is_file() for n in REQUIRED), 'required closed-run evidence absent')
    load = lambda name: json.loads(safe(run,name).read_text())
    closure, audit, media = load('formal_closure.json'), load('independent_audit.json'), load('media_verification.json')
    require(closure.get('id') == run_id and closure.get('grant') == grant and closure.get('closed') is True, 'run not closed under requested grant')
    require((run/'finished_at').read_text().strip() and re.fullmatch(r'-?[0-9]+', (run/'exit_code').read_text().strip()), 'worker completion markers invalid')
    require(audit.get('run_directory') == str(run) and closure.get('accepted_full_assembly') == audit.get('accepted_full_assembly')
        and closure.get('strict_independent_audit') == audit.get('strict_independent_audit_passed'), 'audit/closure identity or outcome differs')
    primary = load('collect_results.json')
    require(isinstance(primary,list) and len(primary) == 1 and 'success' in primary[0]
        and primary[0]['success'] == closure.get('main_task_success') == audit.get('original_main_report',{}).get('reported_success'), 'original main result disagrees with closure/audit')
    ledger = json.loads((root/'execution_ledger.json').read_text())
    attempts = [r for r in ledger['execution']['attempts'] if r.get('id') == run_id]
    require(len(attempts) == 1 and attempts[0].get('closed') is True and attempts[0].get('grant') == grant
        and attempts[0].get('output',str(run)) == str(run), 'ledger closure disagrees')
    binding, runtime, launch = load('source_binding.json'), load('runtime_source_binding.json'), load('launch_receipt.json')
    require(binding.get('run') == run_id and binding.get('mode') == 'formal' and binding.get('passed') is True
        and binding.get('run_directory') == str(run) and runtime.get('run_directory') == str(run) and runtime.get('passed') is True
        and launch.get('run') == run_id and launch.get('mode') == 'formal' and launch.get('output') == str(run), 'formal source/run identity differs')
    frozen = sha(run/'source_binding.json')
    require(all(row.get('grant',grant) == grant for row in (binding,runtime,launch)), 'source/runtime/launch grant differs')
    require(binding.get('configuration_signature') and runtime.get('launch_source_binding_sha256') == frozen == launch.get('source_binding_sha256')
        and runtime.get('configuration_signature') == binding.get('configuration_signature'), 'source/runtime/config binding differs')
    require(media.get('run') == str(run) and media.get('status') == 'passed' and media.get('all_three_original_videos_decoded') is True
        and media.get('sha256_verified') is True and media.get('original_membership_passed') is True
        and media.get('diagnostic_only') is False and not media.get('errors'), 'prior full media verification did not pass')
    rows = media.get('files', [])
    require(len(rows) == 3 and {r.get('camera') for r in rows} == CAMERAS, 'three unique original cameras required')
    videos = {}
    for row in rows:
        p = safe(run,row['path']); relative = str(p.relative_to(run))
        require(p.suffix == '.mp4' and p.is_file() and relative not in videos, 'missing/duplicate original MP4')
        current_sha = sha(p)
        require(row.get('decoded') is True and row.get('decode',{}).get('passed') is True and row.get('sha256_verified') is True
            and p.stat().st_size == row.get('size_bytes') and current_sha == row.get('sha256') == row.get('sha256_after') == row.get('sha256_before'), 'video changed after prior complete decode')
        videos[relative] = current_sha
    included, excluded = [], []
    for p in sorted(run.iterdir()):
        rel = p.name
        if p.is_symlink():
            excluded.append(dict(path=rel,bytes=p.lstat().st_size,reason='symlink retained on server; never followed',sha256=None)); continue
        if p.is_dir():
            if any(str(Path(v).parts[0]) == rel for v in videos):
                for q in sorted(p.rglob('*')):
                    name = str(q.relative_to(run))
                    if q.is_file() and name not in videos:
                        excluded.append(dict(path=name,bytes=q.lstat().st_size,sha256=None,reason='unselected video-directory original retained on server'))
                continue
            files = [q for q in p.rglob('*') if q.is_file() and not q.is_symlink()]
            excluded.append(dict(path=rel+'/',files=len(files),bytes=sum(q.stat().st_size for q in files),sha256=None,
                reason='per-frame/asset/log directory retained on server; excluded bytes not rehashed')); continue
        selected = (rel in REQUIRED or (p.suffix == '.json' and rel != 'scene_geometry.json')
                    or (p.suffix == '.png' and rel.startswith(('startup_','terminal_'))) or rel == 'runner.log')
        if selected: included.append(dict(path=rel,bytes=p.stat().st_size,sha256=sha(p)))
        else: excluded.append(dict(path=rel,bytes=p.stat().st_size,sha256=None,reason='large geometry/raw/full trace/source-tool snapshot or unselected original retained on server'))
    for v in sorted(videos):
        p = safe(run,v); included.append(dict(path=v,bytes=p.stat().st_size,sha256=videos[v]))
    cameras = [row['name'] for row in load('expected_runtime_config.json').get('camera_metadata',[])]
    require(len(cameras) == len(set(cameras)) == 3, 'frozen three-camera metadata absent/ambiguous')
    missing_terminal = False; terminal_receipt_verified = False
    for prefix in ('startup','terminal'):
        names = {r['path'] for r in included if r['path'].startswith(prefix+'_') and r['path'].endswith('.png')}
        expected = {prefix+'_'+name+'.png' for name in cameras}
        require(names <= expected, 'unexpected PNG identity; front is named third_person_front in current frozen config')
        if names != expected or not safe(run,prefix+'_images_ready.json').is_file():
            require(prefix == 'terminal' and safe(run,'terminal_media_failure.json').is_file()
                and load('terminal_media_failure.json').get('passed') is False, 'paired PNG evidence missing without explicit terminal failure')
            missing_terminal = names != expected; continue
        ready = load(prefix+'_images_ready.json'); images = ready.get('images',[])
        require(len(images) == 3 and {row.get('camera') for row in images} == set(cameras), 'PNG readiness identity differs')
        require(all(row.get('path') == prefix+'_'+row['camera']+'.png'
            and sha(safe(run,row['path'])) == row.get('sha256') for row in images), 'PNG bytes differ from original capture receipt')
        if prefix == 'terminal': terminal_receipt_verified = True
    destination = (Path(output) if output else root/'deliveries'/(grant+'_'+run_id+'_media.tar.gz')).resolve()
    require(destination.is_relative_to(root/'deliveries') and not destination.exists() and destination.name.endswith('.tar.gz'), 'destination escapes deliveries or already exists')
    require(not destination.with_suffix(destination.suffix+'.partial').exists(), 'partial archive already exists')
    return dict(schema='stool_media_delivery_v1',run=run_id,grant=grant,server_run=str(run),archive=str(destination),
        included=included,excluded=excluded,decode_reused=True,media_report_sha256=sha(run/'media_verification.json'),
        source_binding_sha256=frozen,missing_terminal_PNG_recorded=missing_terminal,terminal_PNG_capture_receipt_verified=terminal_receipt_verified,
        scope='Three original MP4s and necessary metadata only; raw/full traces, geometry, frame trees and source/tool snapshots remain on server. Not a full original runtime/environment download.')

def create(root, manifest):
    run = Path(manifest['server_run']); destination = Path(manifest['archive'])
    require(run == root.resolve()/'runs'/manifest['run'] and destination.resolve().is_relative_to(root.resolve()/'deliveries')
        and not destination.exists(), 'create destination/run identity differs from plan')
    destination.parent.mkdir(parents=True,exist_ok=True); partial = destination.with_suffix(destination.suffix+'.partial')
    prefix = manifest['grant']+'/'+manifest['run']
    with partial.open('xb') as stream, tarfile.open(fileobj=stream,mode='w:gz') as archive:
        for row in manifest['included']:
            p = safe(run,row['path'])
            require(p.is_file() and p.stat().st_size == row['bytes'], 'original size changed before packing')
            class Reader:
                def __init__(self,stream): self.stream=stream; self.hash=hashlib.sha256()
                def read(self,size):
                    payload=self.stream.read(size); self.hash.update(payload); return payload
            with p.open('rb') as source:
                reader=Reader(source); archive.addfile(archive.gettarinfo(p,arcname=prefix+'/'+row['path']),reader)
                require(reader.hash.hexdigest() == row['sha256'] and p.stat().st_size == row['bytes'], 'original changed while packing')
        payload = (json.dumps(manifest,indent=2)+'\n').encode(); info = tarfile.TarInfo(prefix+'/MANIFEST.json'); info.size=len(payload)
        archive.addfile(info,io.BytesIO(payload))
    os.link(partial,destination); partial.unlink()
    return dict(path=str(destination),bytes=destination.stat().st_size,sha256=sha(destination),
        download_instruction='Copy this archive once; verify size/SHA locally. Prior full decode is reused; no new decode requested.')

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',required=True);parser.add_argument('--grant',required=True)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);parser.add_argument('--output',type=Path)
    parser.add_argument('--create',action='store_true');args=parser.parse_args()
    manifest=plan(args.root,args.run,args.grant,args.output)
    print(json.dumps(dict(mode='created' if args.create else 'dry_listing',manifest=manifest,
        download=create(args.root,manifest) if args.create else None),indent=2))
if __name__=='__main__':main()

"""Passive precheck of commanded UR5e joint segments using Lula FK."""

from __future__ import annotations

import time
import re
from dataclasses import replace
from collections import Counter

import numpy as np

from .models import get_robot_collision_model, infer_task_robot_collision_model
from .runtime_monitor import RuntimeConstraintConfig, RuntimeConstraintMonitor, stool_capsule_proxy_witness


class _StaticXform:
    def __init__(self, position):
        self.position = np.asarray(position, dtype=float)

    def get_world_pose(self):
        return self.position, np.asarray([1.0, 0.0, 0.0, 0.0])


class StageTrajectoryPrechecker:
    """Check actual policy joint commands without changing or rejecting them."""

    def __init__(
        self,
        *,
        check_stride: int = 64,
        num_waypoints: int = 8,
        threshold: float | None = None,
        include_ground: bool = False,
        ignore_pairs=(),
        robot_model: str | None = None,
    ):
        self.check_stride = max(int(check_stride), 1)
        self.num_waypoints = max(int(num_waypoints), 2)
        self._threshold = threshold
        self._include_ground = bool(include_ground)
        self._requested_robot_model = robot_model
        self._model_selected = robot_model is not None
        self.model = None
        self.monitor = None
        self.detector = None
        self._observations = 0
        self._checks = 0
        self._segments = 0
        self._waypoints = 0
        self._violations = []
        self._classified_candidates = []
        self._stage_classification_mode = None
        self._errors = []
        self._reasons = Counter()
        self._total_seconds = 0.0
        self._ignore_pairs = list(ignore_pairs)
        self._frame_coverage = {}
        self._entity_segments = []
        self._entity_errors = []
        self._gripper_prediction = 'current_articulation_frozen_during_arm_segment; gripper action sweep not modeled'
        self._configure_model(get_robot_collision_model(robot_model))

    def observe(self, task, actions: dict) -> dict:
        step = int(getattr(task, 'step_counter', 0))
        self._observations += 1
        if step % self.check_stride:
            return {'checked': False, 'step': step, 'reason': 'stride_skip'}
        started = time.perf_counter()
        self._checks += 1
        try:
            self._select_task_model(task)
            if self.detector is None:
                return self._result(step, 'detector_unavailable')
            self.monitor.refresh_environment_from_task(task)
            paths = {}
            # Holding arms occupy space even when there is no new action.
            for robot_name in (getattr(task, 'robots', {}) or {}):
                robot_actions = (actions or {}).get(robot_name, {})
                path, reason = self._joint_path(task, str(robot_name), robot_actions)
                if path is None:
                    self._reasons[reason] += 1
                    continue
                paths[str(robot_name)] = path
                self._segments += 1
            if not paths:
                return self._result(step, 'no_joint_targets')

            self.monitor.initialize_entity_geometry(task)
            entity_monitor = self.monitor._entity_geometry
            current_entities = entity_monitor.current_poses() if entity_monitor is not None else None

            sample_count = max(len(path) for path in paths.values())
            calibrated = self._calibrated_scene_path(task, actions, sample_count)
            classify = (getattr(task, '_fabrica_assisted_contract', {}) or {}).get('adapter') == 'stool_circular_ur5e_v1'
            if self._stage_classification_mode is None:
                self._stage_classification_mode = classify
            elif self._stage_classification_mode != classify:
                raise ValueError('stage candidate classification task domain changed')
            snapshot = self.monitor._contact_policy.snapshot_from_task(task) if classify else None
            events = []
            for waypoint_index in range(sample_count):
                link_positions_by_robot = {}
                for robot_name, path in paths.items():
                    q = path[min(waypoint_index, len(path) - 1)]
                    positions = (calibrated[waypoint_index][1][robot_name] if calibrated is not None
                                 else self._forward_link_positions(task, robot_name, q))
                    if positions:
                        link_positions_by_robot[robot_name] = positions
                        events.extend(
                            self.detector.check_config(
                                positions,
                                step=step,
                                agent_name=f'{robot_name}@waypoint_{waypoint_index}',
                            )
                        )
                events.extend(self._check_inter_robot(link_positions_by_robot, step, waypoint_index))
                if current_entities is not None:
                    try:
                        poses = (calibrated[waypoint_index][0] if calibrated is not None
                                 else self._swept_entity_poses(task, paths, waypoint_index, current_entities))
                        entity_result = entity_monitor.checker.check(poses, step=step,
                            policy=self.monitor._contact_policy, task=task)
                        if len(self._entity_segments) < 5000:
                            self._entity_segments.append({'waypoint_index': waypoint_index, **entity_result})
                    except Exception as exc:
                        self._entity_errors.append(self._error('entity_segment', exc, step))
                self._waypoints += 1
            if classify:
                serialized = self._classify_stage_candidates(events, task, snapshot, sample_count)
                violations = [event for event in serialized if event['classification'] == 'collision']
                if violations:
                    if calibrated is None:
                        raise ValueError('Stool proxy witness lacks the original calibrated full graph')
                    for event in violations:
                        index = event['waypoint_index']
                        prediction = dict(self._stool_capsule_prediction,
                                          fraction=float(index) / float(sample_count - 1))
                        witness = stool_capsule_proxy_witness(task, event, calibrated[index][0],
                            domain='command_waypoint', prediction=prediction)
                        if witness is not None:
                            event['capsule_proxy_witness'] = witness

            else:
                serialized = [self.monitor._event_to_dict(event) for event in events]
                serialized = [
                    event
                    for event in serialized
                    if not any(rule.matches(event['entity_a'], event['entity_b']) for rule in self._ignore_pairs)
                ]
                violations = serialized
            self._violations.extend(violations)
            return {
                'checked': True,
                'step': step,
                'reason': 'ok',
                'segments': len(paths),
                'violations': violations,
                **({'candidates': serialized} if classify else {}),
            }
        except Exception as exc:
            error = self._error('observe', exc, step)
            self._record_error(error)
            return {'checked': True, 'step': step, 'reason': 'error', 'monitor_error': error}
        finally:
            self._total_seconds += max(time.perf_counter() - started, 0.0)

    def _classify_stage_candidates(self, events, task, snapshot, sample_count):
        """Keep raw candidates and classify verified canonical robot identities.

        Waypoint suffixes identify samples, not robots. Geometry, distances,
        thresholds and original policy rules are unchanged. Unknown identities
        or classifications retain the raw rows and fail the original error gate.
        """
        rows = [self.monitor._event_to_dict(event) for event in events]
        for row in rows:
            row['raw_candidate'] = dict(row)
        self._classified_candidates.extend(rows)
        robots = tuple(str(name) for name in (getattr(task, 'robots', {}) or {}))
        try:
            for event, row in zip(events, rows):
                canonical = []
                samples = set()
                for entity in (event.entity_a, event.entity_b):
                    entity = str(entity)
                    matches = [(name, re.match(re.escape(name) + r'@waypoint_([0-9]+)(?=/|$)', entity))
                               for name in robots]
                    matches = [(name, match) for name, match in matches if match is not None]
                    if matches:
                        if len(matches) != 1:
                            raise ValueError('ambiguous stage candidate robot identity')
                        name, match = matches[0]
                        samples.add(int(match.group(1)))
                        canonical.append(name + entity[match.end():])
                    else:
                        if '@waypoint_' in entity:
                            raise ValueError('unknown stage candidate robot/sample identity')
                        if any(entity == name or entity.startswith(name + '/') for name in robots):
                            raise ValueError('stage robot candidate lacks its waypoint identity')
                        canonical.append(entity)
                if any('@waypoint_' in entity for entity in canonical):
                    raise ValueError('nested stage candidate waypoint identity')
                if len(samples) != 1 or not (0 <= next(iter(samples)) < sample_count):
                    raise ValueError('stage candidate has missing/mismatched waypoint identity')
                if not np.isfinite(float(event.distance)) or not np.isfinite(float(event.threshold)):
                    raise ValueError('nonfinite stage candidate distance/threshold')
                classified_event = replace(event, entity_a=canonical[0], entity_b=canonical[1])
                decision = self.monitor._contact_policy.classify(classified_event, task, snapshot=snapshot)
                if decision.classification not in {'collision', 'proximity', 'allowed_contact'}:
                    raise ValueError('unresolved stage candidate classification')
                row.update(self.monitor._event_to_dict(event, decision))
                row.update(canonical_entity_a=canonical[0], canonical_entity_b=canonical[1],
                           waypoint_index=next(iter(samples)))
        except Exception as exc:
            row['classification_error'] = {'type': type(exc).__name__, 'message': str(exc)}
            raise
        return rows

    def finalize(self) -> dict:
        minimum_distance = min(
            (float(event['distance']) for event in self._violations),
            default=None,
        )
        return {
            'enabled': True,
            'mode': 'passive',
            'robot_model': self.model.name,
            'check_stride': self.check_stride,
            'num_waypoints': self.num_waypoints,
            'observed_steps': self._observations,
            'checks': self._checks,
            'segments_checked': self._segments,
            'waypoints_checked': self._waypoints,
            **({'candidate_total': len(self._classified_candidates),
                'candidate_classifications': dict(Counter(row['classification'] for row in self._classified_candidates)),
                'unresolved_candidate_total': sum(row['classification'] == 'candidate' for row in self._classified_candidates),
                'candidate_events': list(self._classified_candidates),
                'candidate_classification_scope': 'explicit Stool contract; unchanged runtime contact policy on verified canonical robot identity; raw waypoint candidates retained'}
               if self._stage_classification_mode else {}),
            'violation_total': len(self._violations),
            'violations_by_kind': dict(Counter(event['kind'] for event in self._violations)),
            'minimum_distance': minimum_distance,
            'events': list(self._violations),
            'skip_reasons': dict(self._reasons),
            'monitor_error': list(self._errors),
            'total_check_seconds': self._total_seconds,
            'frame_coverage': dict(self._frame_coverage),
            'geometry_mode': 'link_origin_capsules_only',
            'full_entity_sweep_verified': False,
            'entity_geometry_coverage': self.monitor._entity_geometry.finalize() if self.monitor._entity_geometry is not None else None,
            'entity_geometry_segments': list(self._entity_segments),
            'entity_geometry_errors': list(self._entity_errors),
            'entity_geometry_initialize_errors': list(self.monitor._monitor_errors),
            'gripper_prediction': self._gripper_prediction,
        }

    def _select_task_model(self, task) -> None:
        if self._model_selected:
            return
        self._configure_model(infer_task_robot_collision_model(task))
        self._model_selected = True

    def _configure_model(self, model) -> None:
        self.model = model
        self.monitor = RuntimeConstraintMonitor(
            RuntimeConstraintConfig(
                robot_model=model.name,
                threshold=self._threshold,
                include_ground=self._include_ground,
                ignore_pairs=list(self._ignore_pairs),
            )
        )
        self.detector = self.monitor.detector

    def _joint_path(self, task, robot_name: str, robot_actions):
        if not isinstance(robot_actions, dict):
            return None, 'invalid_robot_action'
        robot = (getattr(task, 'robots', {}) or {}).get(robot_name)
        if robot is None:
            return None, 'missing_robot'
        joint_controller = self._controller(robot, 'joint')
        ik_controller = self._controller(robot, 'ik')
        if joint_controller is None or ik_controller is None:
            return None, 'missing_controller'
        target = self._joint_target(robot_actions, joint_controller)
        subset = joint_controller.get_joint_subset()
        current = np.asarray(subset.get_joint_positions(), dtype=float).reshape(-1)
        if target is None:
            target = current
            self._reasons['holding_robot_current_joints'] += 1
        target = np.asarray(target, dtype=float).reshape(-1)
        if current.shape != target.shape or not np.all(np.isfinite(target)) or not np.all(np.isfinite(current)):
            return None, 'invalid_joint_target'
        return [current + (target - current) * fraction for fraction in np.linspace(0.0, 1.0, self.num_waypoints)], 'ok'

    @staticmethod
    def _controller(robot, kind: str):
        controllers = getattr(robot, 'controllers', {}) or {}
        try:
            from internutopia_extension.configs.robots.franka import (
                arm_ik_cfg,
                arm_joint_cfg,
            )

            configured_name = arm_joint_cfg.name if kind == 'joint' else arm_ik_cfg.name
            if configured_name in controllers:
                return controllers[configured_name]
        except Exception:
            pass
        for name, controller in controllers.items():
            lowered = str(name).lower()
            if kind == 'joint' and 'joint' in lowered and 'gripper' not in lowered:
                return controller
            if kind == 'ik' and ('ik' in lowered or 'inverse' in lowered):
                return controller
        return None

    @staticmethod
    def _joint_target(robot_actions: dict, joint_controller):
        configured_name = getattr(getattr(joint_controller, 'config', None), 'name', None)
        candidates = []
        if configured_name:
            candidates.append(configured_name)
        candidates.extend(name for name in robot_actions if 'joint' in str(name).lower())
        for name in candidates:
            value = robot_actions.get(name)
            if value is None:
                continue
            array = np.asarray(value, dtype=float)
            if array.ndim >= 2:
                array = array[0]
            return array
        return None

    def _calibrated_scene_path(self, task, actions, count):
        """Stool opt-in: full authored graph, calibrated per body at this native tick.

        This remains a passive finite sweep. It never calls the action guard,
        changes its targets, writes bodies, or counts missing Lula frames as read.
        """
        if not getattr(task, '_fabrica_assisted_contract', {}):
            return None
        guard = getattr(task, '_fabrica_production_action_guard', None)
        data = getattr(task, '_assisted_geometry_snapshot', None)
        if guard is None or data is None or guard.data is not data or guard.model.gaps:
            raise ValueError('stool original precheck lacks its initialized full geometry graph')
        stamp = task._beam_physics_stamp()
        if stamp.get('valid') is not True:
            raise ValueError('stool original precheck lacks native clock')
        model = guard.model
        native = guard.monitor.current_poses()
        current, targets, bindings = {}, {}, {}
        # These linkage coefficients define the supported Robotiq 2F85 robot,
        # not a task grasp, trajectory, tolerance or assistance parameter.
        mimic = {'finger_joint': 1., 'right_outer_knuckle_joint': 1.,
                 'left_inner_finger_joint': -1., 'right_inner_finger_joint': 1.,
                 'left_inner_finger_knuckle_joint': -1., 'right_inner_finger_knuckle_joint': -1.}
        arm = ('shoulder_pan_joint','shoulder_lift_joint','elbow_joint',
               'wrist_1_joint','wrist_2_joint','wrist_3_joint')
        for name, robot in task.robots.items():
            names = data['robots'][name]['joint_names']
            if names != model.data['robots'][name]['joint_names'] or set(mimic) - set(names):
                raise ValueError('stool original precheck joint identity is incomplete')
            q = np.asarray(robot.articulation.get_joint_positions(), float).copy()
            if q.shape != (len(names),) or not np.all(np.isfinite(q)):
                raise ValueError('stool original precheck full articulation read invalid')
            goal = q.copy(); command = (actions or {}).get(name) or {}
            if 'arm_ik_controller' in command:
                raise ValueError('stool original precheck requires final explicit joint outlet')
            indices = [names.index(j) for j in arm]
            request = np.asarray(command.get('arm_joint_controller', [q[indices]])[0], float)
            if request.shape != (6,) or not np.all(np.isfinite(request)):
                raise ValueError('stool original precheck final arm target invalid')
            goal[indices] = request.astype(np.float32).astype(float)
            if 'gripper_controller' in command:
                value = np.asarray(command['gripper_controller'], float)
                if value.shape != (1,) or not np.all(np.isfinite(value)) or not 0 <= value[0] <= 1:
                    raise ValueError('stool original precheck gripper command invalid')
                opening = float(value[0])
                # Match GripperController._normalize_action/_continuous_forward.
                opening = 0. if opening <= 1e-6 else 1. if opening >= 1-1e-6 else opening
                opening = float(np.clip(opening, max(float(getattr(robot.config, 'gripper_close_openness', 0.) or 0.), 0.), 1.))
                controller = robot.controllers['gripper_controller']
                opened = np.asarray(controller._gripper.joint_opened_positions, float)
                closed = np.asarray(controller._gripper.joint_closed_positions, float)
                if opened.shape != (1,) or closed.shape != (1,) or robot.config.gripper_dof_name != 'finger_joint':
                    raise ValueError('stool original precheck unsupported gripper SDK interface')
                driver_goal = float(np.asarray(closed + opening * (opened-closed), dtype=np.float32)[0])
                change = driver_goal-q[names.index('finger_joint')]
                for joint, coefficient in mimic.items():
                    goal[names.index(joint)] = q[names.index(joint)] + coefficient*change
            current[name], targets[name] = q, goal
            root = data['robots'][name]['root_path']
            mapping = {}
            for link in self.model.link_names:
                candidates = self.model.prim_paths_for_link(root, link)
                matches = [path for path in candidates if path in native and path in model.rest]
                if len(matches) != 1:
                    raise ValueError('stool original precheck lacks unique native graph body: '+name+'/'+link)
                mapping[link] = matches[0]
            bindings[name] = mapping
        self._stool_capsule_prediction = dict(physics_stamp=dict(stamp),
            current_q_by_robot={name:q.tolist() for name,q in current.items()},
            target_q_by_robot={name:q.tolist() for name,q in targets.items()},
            native_body_world_matrices={data['robots'][name]['root_path']+'/'+link:
                native[data['robots'][name]['root_path']+'/'+link].tolist()
                for name in current for link in ('wrist_1_link','wrist_2_link','wrist_3_link','Gripper/Robotiq_2F_85/base_link')})
        nominal = model.poses(current)
        robot_bodies = {m['body'] for m in data['visible_meshes'] if m.get('robot')}
        corrections = {body: native[body] @ np.linalg.inv(nominal[body]) for body in robot_bodies}
        held = {}
        for name, state in (getattr(task, '_attachments', {}) or {}).items():
            from .entity_geometry import pose_matrix
            owner = state['robot_name']; hand = data['robots'][owner]['root_path']+'/wrist_3_link'
            body = data['object_body_coverage'][name][0]
            frozen = pose_matrix(state['hand_object_position'], state['hand_object_orientation'])
            expected = native[hand] @ frozen
            error = float(np.linalg.norm(expected[:3,3]-native[body][:3,3]))
            angle = float(np.arccos(np.clip((np.trace(expected[:3,:3].T@native[body][:3,:3])-1)/2,-1,1)))
            limits = state['attach_spec']
            if error > float(limits['position_tolerance']) or angle > float(limits['orientation_tolerance']):
                raise ValueError('stool passive payload frozen/native residual exceeds original envelope')
            from scipy.spatial.transform import Rotation, Slerp
            measured = np.linalg.inv(native[hand]) @ native[body]
            rotations = Slerp([0.,1.], Rotation.from_matrix(np.stack([measured[:3,:3], frozen[:3,:3]])))
            held[name] = body, hand, frozen, measured, rotations
        result = []
        for fraction in np.linspace(0.,1.,count):
            predicted = model.poses({name: q+(targets[name]-q)*fraction for name,q in current.items()})
            poses = {body: value.copy() for body,value in native.items()}
            for body in robot_bodies:
                poses[body] = native[body].copy() if fraction == 0 else corrections[body] @ predicted[body]
            for body, hand, frozen, measured, rotations in held.values():
                if fraction == 0:
                    poses[body] = native[body].copy()
                elif fraction == 1:
                    poses[body] = poses[hand] @ frozen
                else:
                    relative = np.eye(4); relative[:3,3] = (1-fraction)*measured[:3,3]+fraction*frozen[:3,3]
                    relative[:3,:3] = rotations([fraction]).as_matrix()[0]
                    poses[body] = poses[hand] @ relative
            links = {name: {link: poses[body][:3,3].copy() for link,body in mapping.items()}
                     for name,mapping in bindings.items()}
            result.append((poses, links))
        if task._beam_physics_stamp() != stamp:
            raise ValueError('native clock changed during passive full graph prediction')
        for name, mapping in bindings.items():
            self._frame_coverage[name] = dict(source='same_clock_native_calibrated_full_authored_joint_graph',
                unique_mapping=mapping, missing_model_frames=[], gripper_articulation_swept=True,
                native_physics_stamp=stamp, full_joint_names=data['robots'][name]['joint_names'])
        self._gripper_prediction = 'full_authored_12DOF_graph; actual_final_gripper_SDK_clamp_and_mimics; native_per_body_calibration; frozen_payload_bridge'
        return result

    def _forward_link_positions(self, task, robot_name: str, q: np.ndarray) -> dict:
        robot = task.robots[robot_name]
        controller = self._controller(robot, 'ik')
        solver = getattr(controller, '_kinematics_solver')
        lula_solver = getattr(solver, '_kinematics', solver)
        base_pose = controller.get_ik_base_world_pose()
        solver.set_robot_base_pose(
            robot_position=np.asarray(base_pose[0], dtype=float) / controller._robot_scale,
            robot_orientation=np.asarray(base_pose[1], dtype=float),
        )
        available = set(lula_solver.get_all_frame_names())
        result = {}
        mapping = {}
        missing = []
        for link_name in self.model.link_names:
            # Mounted gripper base_link must never alias the arm base_link.
            # Mounted frames require exact full-path names from the solver.
            frame_name = link_name
            if frame_name not in available:
                missing.append(link_name)
                continue
            position, _ = lula_solver.compute_forward_kinematics(frame_name, joint_positions=q)
            result[link_name] = np.asarray(position, dtype=float) * np.asarray(controller._robot_scale, dtype=float)
            mapping[link_name] = frame_name
        self._frame_coverage[robot_name] = {
            'available_solver_frames': sorted(available),
            'unique_mapping': mapping,
            'missing_model_frames': missing,
            'gripper_articulation_swept': not any('Gripper/' in name for name in missing),
        }
        return result

    def _swept_entity_poses(self, task, paths, index, current_entities):
        poses = dict(current_entities)
        mount_deltas = {}
        for robot_name, path in paths.items():
            robot = task.robots[robot_name]
            controller = self._controller(robot, 'ik')
            solver = controller._kinematics_solver
            lula = getattr(solver, '_kinematics', solver)
            available = set(lula.get_all_frame_names())
            current_q = np.asarray(self._controller(robot, 'joint').get_joint_subset().get_joint_positions(), dtype=float).reshape(-1)
            predicted_q = path[min(index, len(path)-1)]
            def frame_matrix(name, q):
                position, rotation = lula.compute_forward_kinematics(name, joint_positions=q)
                matrix = np.eye(4); matrix[:3,:3] = rotation
                matrix[:3,3] = np.asarray(position) * np.asarray(controller._robot_scale, dtype=float)
                return matrix
            mount = 'wrist_3_link' if self.model.name == 'ur5e_robotiq_2f85' else 'panda_hand'
            if mount not in available: raise ValueError(f'Missing mount frame {robot_name}/{mount}')
            delta = frame_matrix(mount, predicted_q) @ np.linalg.inv(frame_matrix(mount, current_q))
            mount_deltas[robot_name] = delta
            for body, (owner, link) in self.monitor._entity_geometry.body_robot_links.items():
                if owner != robot_name: continue
                if link in available:
                    link_delta = frame_matrix(link, predicted_q) @ np.linalg.inv(frame_matrix(link, current_q))
                elif link.startswith('Gripper/'):
                    link_delta = delta
                else:
                    raise ValueError(f'Missing unique body frame {robot_name}/{link}')
                poses[body] = link_delta @ current_entities[body]
        holders = dict(self.monitor._contact_policy.holder_pairs_from_task(task))
        for name, prim in (getattr(task, '_object_prims', {}) or {}).items():
            holder = holders.get(name)
            if isinstance(holder, str) and holder in mount_deltas:
                body = str(prim.GetPath())
                poses[body] = mount_deltas[holder] @ current_entities[body]
        return poses

    def _check_inter_robot(self, positions_by_robot, step, waypoint_index):
        if len(positions_by_robot) < 2:
            return []
        self.detector._agents.clear()
        for robot_name, positions in positions_by_robot.items():
            self.detector.add_agent(
                f'{robot_name}@waypoint_{waypoint_index}',
                {name: _StaticXform(position) for name, position in positions.items()},
            )
        return self.detector.check_inter_agent(step=step)

    def _result(self, step, reason):
        self._reasons[reason] += 1
        return {'checked': True, 'step': step, 'reason': reason, 'violations': []}

    def _record_error(self, error: dict) -> None:
        key = (error['stage'], error['type'], error['message'])
        for existing in self._errors:
            existing_key = (existing['stage'], existing['type'], existing['message'])
            if existing_key == key:
                existing['last_step'] = error['step']
                existing['occurrences'] = int(existing.get('occurrences', 1)) + 1
                return
        error['last_step'] = error['step']
        error['occurrences'] = 1
        self._errors.append(error)

    @staticmethod
    def _error(stage, exc, step):
        return {
            'stage': stage,
            'step': int(step),
            'type': type(exc).__name__,
            'message': str(exc),
        }

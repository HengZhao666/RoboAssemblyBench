"""Run the real stool collect worker with task-specific build and geometry gates."""
from pathlib import Path
import copy
import hashlib
import json
import os
import time
import types
from datetime import datetime, timezone

import numpy as np

from toolkits.factory_dual_franka_assembly import generate_demos as demo
from toolkits.factory_dual_franka_assembly.fabrica_assisted_preflight import (
    assert_fabrica_assisted_configuration as assert_stool_configuration,
)

OUT = Path(os.environ['STOOL_RUN_DIR'])
ENV = None
EXPECTED = None
original_build = demo._build_env
original_act = demo.DualFrankaAssemblyDemoPolicy.act
original_video_init = demo.LiveRolloutVideoRecorder.__init__
ACTIVE_VIDEO = None
PROCESS_START = time.monotonic()
TIMING = dict(process_started_at_utc=datetime.now(timezone.utc).isoformat(),
    phases=[], policy_compute_seconds=0., policy_calls=0,
    instrumentation_origin='Worker module after imports; full launch-to-exit wall time is recorded separately by launch_receipt/finished_at.',
    interpretation='Instrumented wall time includes native stepping, rendering and evidence overhead; policy compute excludes outer failure retention, includes separately recorded synchronous first-local-failure capture, and overlaps phase wall time. Native stamp elapsed time is simulated time, not engine wall time.')


def phase_timing(task):
    now = time.monotonic()
    stamp = copy.deepcopy(task._beam_physics_stamp())
    rows = TIMING['phases']
    key = (int(task.phase_index), str(task.phase))
    if not rows or (rows[-1]['phase_index'], rows[-1]['phase']) != key:
        if rows:
            rows[-1]['ended_after_process_seconds'] = now-PROCESS_START
        rows.append(dict(phase_index=key[0], phase=key[1],
            started_after_process_seconds=now-PROCESS_START,
            first_native_stamp=stamp, policy_calls=0, policy_compute_seconds=0.))
    rows[-1]['last_native_stamp'] = stamp
    rows[-1]['last_observed_after_process_seconds'] = now-PROCESS_START
    return rows[-1]


def save(name, value):
    demo._write_json(OUT / name, value)


def retain_worker_result_status(boundary):
    """Keep timing before SimulationApp.close(), which need not return."""
    path = OUT / 'worker_result_status.json'
    try:
        if path.exists():
            return False
        result_path = OUT / 'collect_results.json'
        results, read_error = None, None
        if result_path.exists():
            try:
                results = json.loads(result_path.read_text())
            except Exception as exc:
                read_error = repr(exc)
        payload = dict(original_results_present=result_path.exists(),
            episode_count=len(results) if isinstance(results, list) else None,
            results_read_error=read_error, process_exit_alone_is_success=False,
            status_capture_boundary=boundary,
            process_completion_source='launch_receipt.json / finished_at / exit_code; this is not process closure',
            timing=dict(TIMING, instrumented_wall_seconds=time.monotonic()-PROCESS_START,
                status_recorded_at_utc=datetime.now(timezone.utc).isoformat(),
                instrumented_wall_scope=('module import to immediately before env.close; engine shutdown excluded'
                    if boundary == 'pre_env_close' else
                    'module import to worker finally; engine shutdown completion is not guaranteed')))
        if boundary == 'worker_finally_fallback':
            # Preserve the old fallback key as a labelled compatibility alias.
            payload['timing']['process_finished_at_utc'] = payload['timing']['status_recorded_at_utc']
            payload['timing']['process_finished_at_utc_semantics'] = 'legacy status-save timestamp; not verified process completion'
        encoded = json.dumps(demo._to_jsonable(payload), indent=2, allow_nan=False) + '\n'
        with path.open('x', encoding='utf-8') as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        return True
    except FileExistsError:
        return False
    except Exception as exc:
        # Evidence I/O must not prevent or replace the original shutdown.
        try:
            print('[stool-worker-status] retention failed: ' + repr(exc), flush=True)
        except Exception:
            pass
        return False


def install_pre_close_status(env):
    if getattr(env, '_stool_pre_close_status_installed', False):
        return
    original_close = env.close

    def close(_self, *args, **kwargs):
        retain_worker_result_status('pre_env_close')
        return original_close(*args, **kwargs)

    env.close = types.MethodType(close, env)
    env._stool_pre_close_status_installed = True



def _observation_service_snapshot(task):
    """Read existing native buffers only; never create a reader or step physics."""
    def finite(value):
        for attr in ('detach', 'cpu', 'numpy'):
            method = getattr(value, attr, None)
            if callable(method):
                value = method()
        result = np.array(value, dtype=float, copy=True)
        if not np.all(np.isfinite(result)):
            raise RuntimeError('Observation warmup snapshot contains a nonfinite native buffer')
        return result.tolist()
    from isaacsim.core.api import SimulationContext
    context = SimulationContext.instance()
    physics_context = context.get_physics_context() if context is not None else None
    if physics_context is None or not callable(getattr(physics_context, 'is_stablization_enabled', None)):
        raise RuntimeError('Observation warmup lacks actual solver stabilization readback')
    stabilization_enabled = bool(physics_context.is_stablization_enabled())
    stamp = copy.deepcopy(task._beam_physics_stamp())
    if stamp.get('valid') is not True:
        raise RuntimeError('Observation warmup has no valid native clock')
    robots, objects = {}, {}
    for name, robot in task.robots.items():
        view = robot.articulation._articulation_view._physics_view
        robots[name] = dict(native_view_id=id(view), positions=finite(view.get_dof_positions()),
            velocities=finite(view.get_dof_velocities()), targets=finite(view.get_dof_position_targets()),
            sdk_batch_sequence=getattr(robot, '_action_batch_sequence', 0))
    for name in task._fabrica_assisted_contract['objects']:
        wrapper = (getattr(task, '_resolved_objects', {}) or {}).get(name)
        if wrapper is None:
            raise RuntimeError('Observation warmup lacks an existing native object: ' + name)
        native = wrapper.unwrap()
        view = getattr(native, '_rigid_prim_view', None)
        if (not callable(getattr(view, 'is_physics_handle_valid', None))
                or not view.is_physics_handle_valid()
                or str(native.prim_path) != str(task._object_prims[name].GetPath())):
            raise RuntimeError('Observation warmup object identity/handle invalid: ' + name)
        position, orientation = native.get_world_pose()
        objects[name] = dict(path=str(native.prim_path), native_view_id=id(view),
            position=finite(position), orientation_wxyz=finite(orientation),
            linear_velocity=finite(native.get_linear_velocity()), angular_velocity=finite(native.get_angular_velocity()))
    if task._beam_physics_stamp() != stamp:
        raise RuntimeError('Native clock changed during observation warmup snapshot')
    return dict(physics_stamp=stamp, robots=robots, objects=objects,
        solver_stabilization_enabled=stabilization_enabled, physics_context_id=id(physics_context))


def _warm_observation_service_seal(task, before):
    """Warm original services before startup evidence, then forbid lazy writers.

    Original Isaac constructors/initialize may author USD or flush PhysX. This
    startup preparation is deliberately reported as potentially state-changing.
    No policy action, SDK publication, rendering, or physics step is requested.
    """
    if getattr(task, '_stool_observation_service_seal', None) is not None:
        check_observation_service_seal(task)
        return task._stool_observation_service_seal
    contract = task._fabrica_assisted_contract
    roles = (contract.get('cad_pinch') or {}).get('objects') or {}
    if (contract.get('adapter') != 'stool_circular_ur5e_v1'
            or (contract.get('base_support') or {}).get('schema') != 'stool_continuous_base_support_v3'
            or len(contract.get('objects', [])) != 9 or set(roles) != set(contract['objects'])
            or len(task.robots) != 2):
        raise RuntimeError('Observation service warmup requires exact Stool nine-object continuous-support contract')
    from isaacsim.core.simulation_manager import SimulationManager
    simulation_view = SimulationManager.get_physics_sim_view()
    epoch = before['physics_stamp'].get('epoch')
    if simulation_view is None or epoch is None:
        raise RuntimeError('Observation warmup has no native runtime view/epoch')
    original_probe, original_sensor = task._get_contact_probe, task._get_contact_sensor
    probes, sensors, pair_rows, sensor_rows, force_rows = {}, {}, [], [], []
    def view_identity(value):
        result = {key: id(getattr(value, key)) for key in
            ('_physics_view', '_contact_view', '_prim_view', '_contact_sensor_interface', '_sensor_interface')
            if getattr(value, key, None) is not None}
        contact_physics = getattr(getattr(value, '_contact_view', None), '_physics_view', None)
        if contact_physics is not None:
            result['_contact_view._physics_view'] = id(contact_physics)
        return result
    def valid(value, probe):
        try:
            if value is None or not callable(getattr(value, 'is_valid', None)) or not value.is_valid():
                return False
            return not probe or (callable(getattr(value, 'is_physics_handle_valid', None))
                and bool(value.is_physics_handle_valid()))
        except Exception:
            return False
    for name in contract['objects']:
        robot_name = roles[name]['robot']
        if robot_name not in task.robots:
            raise RuntimeError('Observation service role names an unknown robot: ' + robot_name)
        object_path = str(task._resolved_objects[name].unwrap().prim_path)
        fingers = task._get_robot_finger_rigid_bodies(robot_name)
        if set(fingers) != {'left', 'right'}:
            raise RuntimeError('Observation warmup needs both authored finger bodies')
        for side, body in fingers.items():
            if body is None:
                raise RuntimeError('Observation warmup missing finger: ' + robot_name + '/' + side)
            finger_path = str(body.unwrap().prim_path)
            root = str(task.robots[robot_name].articulation._root_prim_path)
            if not finger_path.startswith(root + '/') or object_path != str(task._object_prims[name].GetPath()):
                raise RuntimeError('Observation warmup robot/object full-path mismatch')
            key = (finger_path, object_path)
            value = original_probe(*key)
            if not valid(value, True):
                raise RuntimeError('Observation warmup filtered probe invalid: ' + repr(key))
            probes[key] = (value, view_identity(value))
            pair_rows.append(dict(robot=robot_name, object=name, side=side, body=finger_path,
                filter_body=object_path, service_id=id(value), runtime_view_ids=view_identity(value)))
            sensor_path = finger_path + '/assembly_contact_sensor'
            if sensor_path not in sensors:
                sensor = original_sensor(finger_path)
                if not valid(sensor, False) or not callable(getattr(sensor, 'get_current_frame', None)):
                    raise RuntimeError('Observation warmup finger sensor invalid: ' + sensor_path)
                sensor.get_current_frame()  # Original API, no altered force interpretation.
                sensors[sensor_path] = (sensor, view_identity(sensor))
                sensor_rows.append(dict(robot=robot_name, side=side, body=finger_path,
                    path=sensor_path, service_id=id(sensor), runtime_view_ids=view_identity(sensor),
                    sensor_prim_path=str(sensor.prim_path), body_prim_path=str(sensor._body_prim_path),
                    validity_scope='USD prim validity only; force frame validity retains original API semantics'))
            force_rows.append(dict(body=finger_path, filter_body=object_path,
                observation=task._contact_observation_between(finger_path, object_path)))
    if len(probes) != 18 or len(sensors) != 4 or len(pair_rows) != 18:
        raise RuntimeError('Observation warmup must bind exactly 18 distinct filtered pairs and four sensors')
    after = _observation_service_snapshot(task)
    if (after['physics_stamp'] != before['physics_stamp']
            or {k: v['sdk_batch_sequence'] for k, v in after['robots'].items()}
            != {k: v['sdk_batch_sequence'] for k, v in before['robots'].items()}):
        raise RuntimeError('Observation warmup unexpectedly stepped physics or published an SDK batch')
    def violation(reason):
        if getattr(task, '_stool_observation_service_violation', None) is None:
            task._stool_observation_service_violation = dict(reason=reason,
                physics_stamp=copy.deepcopy(task._beam_physics_stamp()),
                phase=str(getattr(task, 'phase', '')), step=int(getattr(task, 'step_counter', 0)))
        raise RuntimeError('Sealed Stool observation service rejected: ' + reason)
    def check_runtime():
        try:
            current_stamp = task._beam_physics_stamp()
            same = (SimulationManager.get_physics_sim_view() is simulation_view
                and current_stamp.get('valid') is True and current_stamp.get('epoch') == epoch)
        except Exception as exc:
            violation('native runtime identity unavailable: ' + repr(exc))
        if not same:
            violation('native runtime simulation view/epoch changed')
    def check_entry(key, entries, cache, probe):
        check_runtime()
        entry = entries.get(key)
        if not isinstance(cache, dict) or entry is None or cache.get(key) is not entry[0]:
            violation('missing/replaced cache entry: ' + repr(key))
        try:
            identity_matches = view_identity(entry[0]) == entry[1]
            if not probe:
                identity_matches = (identity_matches and str(entry[0].prim_path) == key
                    and str(entry[0]._body_prim_path) == key.rsplit('/', 1)[0])
        except Exception as exc:
            violation('cached service identity unavailable: ' + repr(exc))
        if not valid(entry[0], probe) or not identity_matches:
            violation('invalid/rebound cached service: ' + repr(key))
        return entry[0]
    def sealed_probe(_self, prim_path, filter_prim_path):
        return check_entry((prim_path, filter_prim_path), probes, getattr(task, '_contact_probes', None), True)
    def sealed_sensor(_self, prim_path):
        return check_entry(prim_path + '/assembly_contact_sensor', sensors, getattr(task, '_contact_sensors', None), False)
    def blocked_initialize(*args, **kwargs):
        violation('runtime service initialize is forbidden')
    for value, _ in list(probes.values()) + list(sensors.values()):
        value.initialize = blocked_initialize
    task._get_contact_probe = types.MethodType(sealed_probe, task)
    task._get_contact_sensor = types.MethodType(sealed_sensor, task)
    def check():
        check_runtime()
        if getattr(task, '_stool_observation_service_violation', None) is not None:
            violation('a prior observation service violation was caught by another caller')
        if (getattr(task._get_contact_probe, '__func__', None) is not sealed_probe
                or getattr(task._get_contact_sensor, '__func__', None) is not sealed_sensor):
            violation('sealed observation getter was replaced')
        for key in probes:
            check_entry(key, probes, getattr(task, '_contact_probes', None), True)
        for key in sensors:
            check_entry(key, sensors, getattr(task, '_contact_sensors', None), False)
    task._stool_check_observation_service_seal = check
    report = dict(schema='stool_observation_service_startup_seal_v1', passed=True,
        pairs=pair_rows, sensors=sensor_rows, force_observations=force_rows,
        startup_stamp=before['physics_stamp'], runtime_simulation_view_id=id(simulation_view),
        before=before, after=after,
        physical_state_unchanged=(before == after),
        changed_sections=[key for key in before if before[key] != after[key]],
        startup_preparation_may_author_usd_or_flush_physics=True,
        startup_and_full_scene_evidence_scope='after observer warmup; no prewarm-state invariance claim',
        solver_stabilization_final=after['solver_stabilization_enabled'],
        solver_configuration_restored=False,
        sdk_publications=0, requested_physics_steps=0,
        runtime_policy='exact cached identity and valid handles only; initialize/cold construction forbidden')
    task._stool_observation_service_seal = report
    check()
    save('observation_service_startup_seal.json', report)
    return report


def install_observation_service_seal(task):
    if getattr(task, '_stool_observation_service_seal', None) is not None:
        check_observation_service_seal(task)
        return task._stool_observation_service_seal
    before = _observation_service_snapshot(task)
    try:
        return _warm_observation_service_seal(task, before)
    except Exception as exc:
        failure = dict(passed=False, before=before, error=repr(exc),
            startup_preparation_may_author_usd_or_flush_physics=True)
        try:
            failure['after'] = _observation_service_snapshot(task)
            failure['physical_state_unchanged'] = failure['after'] == before
        except Exception as snapshot_error:
            failure['after_snapshot_error'] = repr(snapshot_error)
        save('observation_service_startup_failure.json', failure)
        raise


def check_observation_service_seal(task):
    check = getattr(task, '_stool_check_observation_service_seal', None)
    if not callable(check):
        raise RuntimeError('Stool observation services were not sealed before action computation')
    check()


def startup_dry_action(policy, task, *args, **kwargs):
    from stool_startup_evidence import NativeStartupReader
    reader = NativeStartupReader(task)
    before = reader.snapshot()
    sdk_before = {name: getattr(robot, '_action_batch_sequence', 0) for name, robot in task.robots.items()}
    limits = {name: np.asarray(task._assisted_arm_joint_limits(name), float).tolist() for name in task.robots}
    # Exercise the real policy/adapter/final-guard outlet without submitting it.
    dry_actions = original_act(policy, task, *args, **kwargs)
    check_observation_service_seal(task)
    after = reader.snapshot()
    if after != before:
        raise RuntimeError('Startup dry action changed full native q/qd/targets/body/task state')
    sdk_after = {name: getattr(robot, '_action_batch_sequence', 0) for name, robot in task.robots.items()}
    if sdk_before != sdk_after:
        raise RuntimeError('Startup dry action unexpectedly submitted an SDK batch')
    return dict(actions=dry_actions, actual_native_arm_limits=limits,
        native_state_unchanged=True, native_before=before, native_after=after,
        sdk_before=sdk_before, sdk_after=sdk_after, action_computed=True, action_submitted=False,
        scope='complete native q/qd/targets/body poses/velocities and task counters/history frozen; no env.step/apply_action',
        allowed_side_effects='Python policy/local-skill/control computation caches and candidate-command trace may change; no restore-equivalence claim')


def build(*args, **kwargs):
    global ENV, EXPECTED
    TIMING['worker_build_started_after_process_seconds'] = time.monotonic()-PROCESS_START
    configs = kwargs.get('task_configs', args[0] if args else [])
    if len(configs) != 1:
        raise RuntimeError('Stool acceptance requires exactly one reviewed episode')
    report = assert_stool_configuration(configs[0])
    reviewed = json.loads((OUT / 'launch_gate.json').read_text())
    if report['configuration_signature'] != reviewed['configuration_signature']:
        raise RuntimeError('Actual stool worker configuration differs from offline review')
    from internutopia.core.task_config_manager.base import setup_offset_for_assets
    EXPECTED = copy.deepcopy(configs[0])
    setup_offset_for_assets(EXPECTED, 0, [0., 0., 0.])
    save('worker_build_preflight.json', dict(passed=True, report=report))
    save('task_config_snapshot.json', [configs[0].model_dump(mode='python', serialize_as_any=True)])
    save('expected_runtime_config.json', EXPECTED.model_dump(mode='python', serialize_as_any=True))
    ENV = original_build(*args, **kwargs)
    install_pre_close_status(ENV)
    TIMING['environment_built_after_process_seconds'] = time.monotonic()-PROCESS_START
    return ENV


class StartupPreflightComplete(Exception):
    """Expected stop after initialization; no robot action has been submitted."""


def capture_initial_images(task):
    from stool_startup_evidence import capture_startup_evidence, record_initial_video
    report = capture_startup_evidence(task, ENV, OUT,
        lambda obs, snapshot: record_initial_video(ACTIVE_VIDEO, task, obs, snapshot))
    rows = report['images']
    stamp = task._beam_physics_stamp()
    deadline = time.monotonic() + 600
    while not (OUT/'startup_image_review.json').exists():
        if time.monotonic() >= deadline:
            raise RuntimeError('Startup image review timed out before first action')
        time.sleep(.25)
    review = json.loads((OUT/'startup_image_review.json').read_text())
    if (review.get('accepted') is not True
            or review.get('image_sha256') != {r['camera']: r['sha256'] for r in rows}
            or task._beam_physics_stamp() != stamp):
        raise RuntimeError('Startup image review failed or native clock changed')
    return report


def video_init(self, *args, **kwargs):
    global ACTIVE_VIDEO
    original_video_init(self, *args, **kwargs)
    ACTIVE_VIDEO = self


def install_first_local_failure_capture(task):
    """Observe the first local failure transition before fallback/SDK/step.

    This stamp belongs to the terminal-transition observation. The caught
    adapter/CAD exception did not supply an independent native stamp.
    """
    if getattr(task, '_stool_first_local_failure_hook_installed', False):
        return
    if (getattr(task, '_fabrica_assisted_contract', {}) or {}).get('adapter') != 'stool_circular_ur5e_v1':
        return
    original_terminal = task._set_terminal_state

    def terminal(_self, terminal_phase, *args, **kwargs):
        reason = kwargs.get('reason')
        if (terminal_phase == 'failed' and kwargs.get('status') == 'failed'
                and isinstance(reason, str) and reason.startswith('local-skill-failure:')
                and not getattr(task, '_stool_first_local_failure_capture_attempted', False)):
            # Set before any read/I/O so duplicate calls and failed retention
            # cannot cause a second native query or replace the first record.
            task._stool_first_local_failure_capture_attempted = True
            started = time.monotonic()
            observed = dict(schema='stool_first_local_failure_transition_v1',
                passed=False, capture_boundary='before_original_terminal_transition',
                clock_scope='terminal-transition observation; original exception has no independent native stamp',
                phase=task.phase, phase_index=task.phase_index,
                step=int(task.step_counter), original_reason=reason,
                original_terminal_phase=terminal_phase,
                original_status=kwargs.get('status'))
            task._stool_first_local_failure_observation = observed
            try:
                observed['original_detail'] = copy.deepcopy(kwargs.get('detail'))
                observed['original_terminal_args'] = copy.deepcopy(args)
                observed['original_terminal_kwargs'] = copy.deepcopy(kwargs)
                stamp = copy.deepcopy(task._beam_physics_stamp())
                before = {name: getattr(robot, '_action_batch_sequence', 0)
                          for name, robot in task.robots.items()}
                observed.update(physics_stamp=stamp, sdk_before=before)
                raw = task._fabrica_independent_raw_sampler('control_failure')
                observed['independent_raw'] = raw
                after = {name: getattr(robot, '_action_batch_sequence', 0)
                         for name, robot in task.robots.items()}
                observed.update(sdk_after=after, no_new_sdk_batch=before == after,
                    native_stamp_unchanged=task._beam_physics_stamp() == stamp)
                observed['passed'] = bool(stamp.get('valid') is True
                    and isinstance(raw, dict) and raw.get('valid') is True
                    and raw.get('physics_stamp') == stamp
                    and observed['native_stamp_unchanged'] and observed['no_new_sdk_batch'])
            except Exception as exc:
                observed.update(passed=False, capture_error=repr(exc))
            observed['capture_wall_seconds'] = time.monotonic() - started
            try:
                serialized = json.dumps(demo._to_jsonable(observed), indent=2, allow_nan=False) + '\n'
                with (OUT / 'first_local_failure_observation.json').open('x', encoding='utf-8') as stream:
                    stream.write(serialized)
                    stream.flush()
                    os.fsync(stream.fileno())
            except Exception as exc:
                # Collection failures never replace the original reason or
                # alter the original bound terminal call/return/exception.
                observed.update(passed=False, retention_error=repr(exc))
        return original_terminal(terminal_phase, *args, **kwargs)

    task._set_terminal_state = types.MethodType(terminal, task)
    task._stool_first_local_failure_hook_installed = True


def install_base_support_sampler(task, initial):
    """Force only qualified support ticks through the existing independent views."""
    contract = task._fabrica_assisted_contract
    settings = contract.get('base_support')
    if not settings:
        return
    expected_paths = tuple(initial.get('body_paths') or [])
    expected_objects = dict(initial.get('objects') or {})
    identities = initial.get('articulation_identities') or {}
    if (initial.get('valid') is not True or len(expected_paths) != 41
            or len(set(expected_paths)) != 41 or set(expected_objects) != set(contract['objects'])
            or set(identities) != set(task.robots)):
        raise ValueError('Stool support raw binding lacks exact full initial body/object/articulation coverage')
    cache = {}; primary = {}; last_native = [None]
    def sample(stage):
        phase = task.get_current_phase_spec() or {}
        role = phase.get('fabrica_base_support') or {}
        cycles = [c for c in settings['cycles'] if c['cycle_id']==role.get('cycle_id')]
        continuous = settings.get('schema') == 'stool_continuous_base_support_v3'
        hold_phase = bool(continuous and stage == 'hold' and len(cycles) == 1
            and ((role.get('stage') == 'hold' and phase.get('name') in cycles[0]['hold_phase_names'])
                 or (role.get('stage') == 'open' and phase.get('name') == cycles[0]['open_phase_name']
                     and not (getattr(task, '_fabrica_base_support', None) or {}).get('opening_started'))))
        entry_phase = bool(continuous and stage == 'enter' and len(cycles) == 1
            and role.get('stage') == 'enter' and cycles[0].get('enter_phase_names')
            and phase.get('name') == cycles[0]['enter_phase_names'][-1])
        gate_phase = bool(stage in {'acquire','open'} and len(cycles) == 1
            and phase.get('name') == cycles[0].get(stage+'_phase_name') and role.get('stage') == stage)
        if (len(cycles)!=1 or not (hold_phase or gate_phase or entry_phase)
                or role.get('moving_object')!=cycles[0].get('moving_object')
                or role != dict({k:settings[k] for k in ('schema','role','robot','object')},
                    cycle_id=cycles[0]['cycle_id'],moving_object=cycles[0]['moving_object'],stage=role.get('stage'))):
            raise ValueError('Stool support independent raw role/phase mismatch')
        stamp = task._beam_physics_stamp()
        if continuous:
            native = (stamp.get('epoch'), stamp.get('index'))
            if stamp.get('valid') is not True or any(type(v) is not int for v in native):
                raise ValueError('Stool continuous evidence lacks a valid native clock')
            if last_native[0] is not None and native < last_native[0]:
                raise ValueError('Stool continuous evidence native clock regressed')
            if native != last_native[0]:
                cache.clear(); primary.clear(); last_native[0] = native
        key = (task.phase_index, task.phase_entry_step, role['cycle_id'], stage, stamp.get('epoch'), stamp.get('index'))
        if key in cache:
            if cache[key]['physics_stamp'] != stamp:
                raise ValueError('Stool support independent duplicate index has a different clock')
            return copy.deepcopy(cache[key])
        error = None
        try:
            raw = task._fabrica_independent_raw_sampler('base_support_' + stage)
        except Exception as exc:
            raw = None; error = repr(exc)
        passed = bool(isinstance(raw, dict) and raw.get('valid') is True
            and raw.get('physics_stamp') == stamp and task._beam_physics_stamp() == stamp
            and tuple(raw.get('body_paths') or []) == expected_paths
            and raw.get('objects') == expected_objects
            and raw.get('articulation_identities') == identities
            and raw.get('source') == 'separate_exact_path_PhysX_tensor_views')
        result = dict(passed=passed, physics_stamp=stamp, independent_raw=raw, error=error,
            cycle_id=role['cycle_id'],moving_object=role['moving_object'],
            source='existing separate exact-path native views; full 41 bodies, nine objects and both complete12DOF articulations')
        cache[key] = copy.deepcopy(result)
        return result
    task._fabrica_base_support_independent_sample = sample

    if settings.get('schema') == 'stool_continuous_base_support_v3':
        # The controller has already computed exact CAD once for this native
        # tick. Retain that result, including failures, with existing raw views.
        def record_primary(stage, value):
            phase = task.get_current_phase_spec() or {}
            role = phase.get('fabrica_base_support') or {}
            stamp = task._beam_physics_stamp()
            if stage != 'hold' or not isinstance(value, dict) or value.get('physics_stamp') != stamp:
                raise ValueError('Stool continuous primary sample is missing or stale')
            fingerprint = json.dumps(value, sort_keys=True, allow_nan=False,
                default=lambda item: item.tolist())
            key = (task.phase_index, task.phase_entry_step, stamp.get('epoch'), stamp.get('index'))
            if key in primary:
                if primary[key][0] != fingerprint:
                    raise ValueError('Stool continuous primary changed within the same native tick')
                return copy.deepcopy(primary[key][1])
            independent = sample('hold')
            task._assisted_event('fabrica_base_support_continuous_sample',
                cycle_id=role['cycle_id'], moving_object=role['moving_object'],
                support_stage=role['stage'], sample=copy.deepcopy(value),
                independent_raw=copy.deepcopy(independent), force_support_claimed=False,
                evidence_scope='existing primary CAD result; separate exact-path native buffers; no additional CAD query')
            primary[key] = (fingerprint, copy.deepcopy(independent))
            return independent
        task._fabrica_base_support_primary_record = record_primary


def install_terminal_capture(task):
    original_metrics = task.calculate_metrics

    def retain_once(name, payload):
        # Terminal originals belong to this run and must survive later metric
        # queries, failed capture, or a reused output directory unchanged.
        with (OUT / name).open('x', encoding='utf-8') as stream:
            json.dump(demo._to_jsonable(payload), stream, indent=2, allow_nan=False)
            stream.write('\n')

    def metrics(_self):
        result = original_metrics()
        # Non-policy is_done() also terminates at the global step cap without
        # setting success/failed. Read that same threshold; calling is_done()
        # here would itself consume bookkeeping. Preserve the original result.
        at_global_cap = bool(not (task.success or task.failed)
            and getattr(task, 'policy_evaluation_mode', None) is False
            and type(getattr(task, 'step_counter', None)) is int
            and type(getattr(task, 'max_steps', None)) is int
            and task.step_counter >= task.max_steps)
        trigger = ({'capture_trigger': 'nonpolicy_global_max_steps',
                    'step_counter': task.step_counter, 'max_steps': task.max_steps,
                    'original_terminal_flags_unchanged': True} if at_global_cap else {})
        if (task.success or task.failed or at_global_cap) and not getattr(task, '_stool_terminal_media_capture_attempted', False):
            task._stool_terminal_media_capture_attempted = True
            try:
                retain_once('terminal_original_metrics.json', copy.deepcopy(result))
                from stool_startup_evidence import capture_startup_evidence, record_initial_video
                report = capture_startup_evidence(task, ENV, OUT,
                    lambda obs, snapshot: record_initial_video(ACTIVE_VIDEO, task, obs, snapshot),
                    prefix='terminal', orient_wrist=False)
                raw = task._fabrica_independent_raw_sampler('terminal')
                if (report.get('passed') is not True or not isinstance(raw, dict)
                        or raw.get('valid') is not True
                        or raw.get('physics_stamp') != report['before']['physics_stamp']):
                    raise RuntimeError('Terminal media/raw qualification is invalid or from a different native tick')
                retain_once('terminal_media_capture.json', dict(passed=True,
                    physics_stamp=report['before']['physics_stamp'],
                    task_counters=report['before']['counters'], render_only_steps=8,
                    independent_raw=raw, paired_capture='terminal_capture_diagnostics.json',
                    cameras=[c['name'] for c in task.cfg.camera_metadata],
                    video_clock='video_frame_clock.jsonl', original_metrics_preserved=True,
                    original_metrics='terminal_original_metrics.json', **trigger))
                task._stool_terminal_media_captured = True
            except Exception as exc:
                failure = dict(passed=False, exception_type=type(exc).__name__, message=str(exc),
                    original_metrics='terminal_original_metrics.json',
                    original_metrics_present=(OUT / 'terminal_original_metrics.json').exists(),
                    paired_capture='terminal_capture_diagnostics.json',
                    strict_media_qualified=False, capture_attempted_once=True,
                    original_task_result_returned=True, **trigger)
                task._stool_terminal_media_failure = failure
                try:
                    retain_once('terminal_media_failure.json', failure)
                except Exception as retention_error:
                    # Evidence failure may invalidate independent acceptance;
                    # it must not suppress the original task result either.
                    failure['failure_record_retention_error'] = repr(retention_error)
        return result
    task.calculate_metrics = types.MethodType(metrics, task)


def review_first_production_action(task, actions, sdk_before, guard, guard_sequence_before, reader, native_before):
    """Review the one real first policy result; never recompute or submit it."""
    if getattr(task, '_stool_first_production_action_review_attempted', False):
        raise RuntimeError('First production command review cannot be retried')
    task._stool_first_production_action_review_attempted = True
    stamp = copy.deepcopy(task._beam_physics_stamp())
    current_sdk = lambda: {name: getattr(robot, '_action_batch_sequence', 0)
        for name, robot in task.robots.items()}
    if (stamp.get('valid') is not True or current_sdk() != sdk_before
            or set(sdk_before) != set(task.robots) or any(value != 0 for value in sdk_before.values())
            or guard is not getattr(task, '_fabrica_production_action_guard', None)
            or type(guard_sequence_before) is not int
            or getattr(guard, '_rejection_evidence_sequence', None) != guard_sequence_before + 1
            or not isinstance(actions, dict) or set(actions) != set(task.robots)):
        raise RuntimeError('First production batch lacks exact one-call full-guard/zero-SDK identity')
    native_after_calculation = reader.snapshot()
    native_fields = lambda row: {key: value for key, value in row.items()
        if key not in {'counters', 'phase_transition_history'}}
    if (native_fields(native_after_calculation) != native_fields(native_before)
            or native_before.get('physics_stamp') != stamp
            or getattr(task, 'failed', False) or getattr(task, 'success', False)):
        raise RuntimeError('First production calculation changed physical native state/clock or terminated the task')
    commands = getattr(task, '_fabrica_final_gripper_commands', {})
    if set(commands) != set(task.robots):
        raise RuntimeError('First production batch lacks both actual final command receipts')
    published = getattr(task, '_assisted_published_q', {})
    for name, action in actions.items():
        q = np.asarray(action.get('arm_joint_controller'), float)
        opening = np.asarray(action.get('gripper_controller'), float)
        receipt = commands.get(name) or {}
        if (q.shape != (1, 6) or not np.all(np.isfinite(q))
                or opening.shape != (1,) or not np.all(np.isfinite(opening))
                or not 0. <= opening[0] <= 1. or 'arm_ik_controller' in action
                or not np.array_equal(q[0], published.get(name))
                or receipt.get('physics_stamp') != stamp
                or receipt.get('expected_sdk_batch_sequence') != sdk_before[name] + 1
                or receipt.get('gripper_openness') != float(opening[0])):
            raise RuntimeError('First production batch differs from actual final guarded command: ' + name)
    encoded = json.dumps(demo._to_jsonable(actions), sort_keys=True, allow_nan=False)
    before = reader.snapshot()
    save('startup_first_production_action.json', dict(passed=True, actions=json.loads(encoded),
        expected_sdk_batch_sequences={name: row['expected_sdk_batch_sequence'] for name, row in commands.items()},
        physics_stamp=stamp, sdk_before=sdk_before, sdk_after=current_sdk(),
        source_binding_sha256=hashlib.sha256((OUT/'source_binding.json').read_bytes()).hexdigest(),
        runtime_source_binding_sha256=hashlib.sha256((OUT/'runtime_source_binding.json').read_bytes()).hexdigest(),
        runtime_initialization_preflight_sha256=hashlib.sha256((OUT/'runtime_initialization_preflight.json').read_bytes()).hexdigest(),
        actual_policy_calls_for_this_batch=1, production_guard_calls_for_this_batch=1,
        action_computed=True, action_submitted=False,
        initialization_complete_before_image_review=True, native_before_calculation=native_before,
        native_after_calculation=before, native_state_unchanged=True,
        native_calculation_comparison_scope='All physical native fields; one original policy call may update task counters/history and Python caches, recorded without restoration.',
        task_logic_before={key: native_before.get(key) for key in ('counters', 'phase_transition_history')},
        task_logic_after={key: before.get(key) for key in ('counters', 'phase_transition_history')},
        scope='The actual first normal policy action and original full production guard; not a dry action or SDK execution proof.'))
    capture_start = time.monotonic()
    report = capture_initial_images(task)
    after = reader.snapshot()
    check_observation_service_seal(task)
    if ((OUT / 'stop_request.json').exists() or before != after or current_sdk() != sdk_before or task._beam_physics_stamp() != stamp
            or report.get('before') != before
            or encoded != json.dumps(demo._to_jsonable(actions), sort_keys=True, allow_nan=False)):
        raise RuntimeError('Startup review changed native state, first action, or actual SDK counters')
    save('startup_first_production_action_review.json', dict(passed=True,
        physics_stamp=stamp, sdk_before=sdk_before, sdk_after=current_sdk(),
        native_before=before, native_after=after, native_state_unchanged=True,
        actual_policy_calls_for_this_batch=1, same_actions_returned_after_review=True,
        image_review='startup_image_review.json', action_evidence='startup_first_production_action.json',
        image_review_wall_seconds=time.monotonic()-capture_start,
        action_submitted=False, submission_owner='Original runner env.step after this worker returns the unchanged actions.'))
    task._stool_first_production_action_review_pending = False


def act(self, task, *args, **kwargs):
    if not getattr(task, '_stool_worker_ready', False):
        runtime_report = assert_stool_configuration(task)
        from internutopia.core.scene.isaacsim.scene import IsaacsimScene
        from toolkits.factory_dual_franka_assembly.beam_assisted_preflight import configuration_signature
        expected = copy.deepcopy(EXPECTED)
        scene = IsaacsimScene._resolve_scene_asset_path(expected)
        fallback = getattr(expected, 'scene_asset_fallback_path', None)
        preference = IsaacsimScene._scene_asset_preference(expected)
        resolved_fallback = IsaacsimScene._resolve_isaac_asset_path(fallback) if fallback else None
        using_fallback = bool(resolved_fallback and scene == resolved_fallback)
        expected.scene_asset_source = 'fallback' if using_fallback else 'primary'
        expected.scene_asset_selection_policy = preference or 'primary_first'
        expected.scene_asset_selection_reason = ('fallback_preferred_by_scene_profile'
            if using_fallback and preference in {'fallback', 'fallback_first'} else 'first_existing_asset')
        expected.resolved_scene_family = str((getattr(expected, 'scene_profile_metadata', {}) or {}).get(
            'fallback_scene_family' if using_fallback else 'scene_family', ''))
        expected.scene_asset_path = scene
        actual_roots = sorted(str(r.articulation._root_prim_path) for r in task.robots.values())
        expected_roots = sorted(str(r.prim_path) for r in expected.robots)
        binding = dict(expected_configuration_signature=configuration_signature(expected),
            actual_configuration_signature=runtime_report['configuration_signature'],
            expected_roots=expected_roots, actual_roots=actual_roots,
            env_id=getattr(task, 'env_id', None), env_offset=getattr(task, 'env_offset', None),
            task_count=len(ENV.runner.current_tasks))
        binding['passed'] = bool(binding['expected_configuration_signature'] == binding['actual_configuration_signature']
            and expected_roots == actual_roots and binding['env_id'] == 0
            and list(binding['env_offset'] or []) == [0., 0., 0.] and binding['task_count'] == 1)
        save('runtime_configuration_binding.json', binding)
        if not binding['passed']:
            raise RuntimeError('Actual initialized stool config/roots differ from exact framework/scene mapping')
        observation_services = install_observation_service_seal(task)
        from stool_raw_evidence import install_raw_sampler
        raw = install_raw_sampler(task, OUT)
        install_base_support_sampler(task, raw)
        from stool_geometry_guard import initialize_geometry_guard
        geometry = initialize_geometry_guard(task, OUT)
        from toolkits.factory_dual_franka_assembly.beam_assisted_visual_grasp import validate_stool_geometry
        cad_pinch = validate_stool_geometry(task)
        if cad_pinch.get('passed') is not True:
            raise RuntimeError('Stool actual pad/native-reader initialization did not pass')
        geometry['cad_pinch_initialization'] = cad_pinch
        frozen = json.loads((OUT / 'source_binding.json').read_text())
        scene_data = json.loads((OUT / 'scene_geometry.json').read_text())
        layer_seals = scene_data['composed_layer_asset_seals']
        frozen.update(asset_manifest_sha256=hashlib.sha256(json.dumps(layer_seals, sort_keys=True).encode()).hexdigest(),
            asset_manifest=layer_seals, launch_source_binding_sha256=hashlib.sha256((OUT/'source_binding.json').read_bytes()).hexdigest(),
            runtime_configuration_signature=runtime_report['configuration_signature'],
            asset_unhashed_layers=[x for x in layer_seals if not x.get('sha256')])
        save('runtime_source_binding.json', frozen)
        save('runtime_initialization_preflight.json', dict(
            passed=True, configuration=runtime_report, geometry=geometry, independent_raw=raw,
            physics_stamp=task._beam_physics_stamp(), observation_services=observation_services))
        install_terminal_capture(task)
        install_first_local_failure_capture(task)
        task._stool_worker_ready = True
        TIMING['native_evidence_ready_after_process_seconds'] = time.monotonic()-PROCESS_START
        if os.environ.get('STOOL_STARTUP_ONLY') == '1':
            save('startup_dry_action.json', startup_dry_action(self, task, *args, **kwargs))
            initial_images = capture_initial_images(task)
            gate = json.loads((OUT/'launch_gate.json').read_text())
            save('startup_preflight_passed.json', dict(passed=True, robot_sdk_submissions=0,
                configuration_signature=gate['configuration_signature'],
                control_source_signature=gate['control_source_signature'],
                control_tools_signature=gate['control_tools_signature'],
                actual_native_raw=raw, initial_three_views=True, image_review='startup_image_review.json',
                geometry=geometry, first_action_interface='startup_dry_action.json',
                assembly_success_claimed=False))
            raise StartupPreflightComplete('startup collector/three-view/first-command interface complete; no SDK submission')
        task._stool_first_production_action_review_pending = True
    if (OUT / 'stop_request.json').exists():
        task._set_terminal_state('failed', reason='stool-evidence-stop', status='failed',
            detail=json.loads((OUT / 'stop_request.json').read_text()))
        return {}
    phase_row = phase_timing(task)
    call_start = time.monotonic()
    policy_elapsed = None
    sdk_before = {name: getattr(robot, '_action_batch_sequence', 0) for name, robot in task.robots.items()}
    evidence_guard = getattr(task, '_fabrica_production_action_guard', None)
    evidence_sequence_before = getattr(evidence_guard, '_rejection_evidence_sequence', 0)
    try:
        check_observation_service_seal(task)
        first_reader, first_native_before = None, None
        if getattr(task, '_stool_first_production_action_review_pending', False):
            from stool_startup_evidence import NativeStartupReader
            first_reader = NativeStartupReader(task)
            first_native_before = first_reader.snapshot()
        actions = original_act(self, task, *args, **kwargs)
        check_observation_service_seal(task)
        policy_elapsed = time.monotonic()-call_start
        if getattr(task, '_stool_first_production_action_review_pending', False):
            review_first_production_action(task, actions, sdk_before, evidence_guard, evidence_sequence_before, first_reader, first_native_before)
        return actions
    except (ValueError, RuntimeError) as exc:
        violation = getattr(task, '_stool_observation_service_violation', None)
        policy_elapsed = time.monotonic()-call_start
        failure_stamp = copy.deepcopy(task._beam_physics_stamp())
        sdk_after = {name: getattr(robot, '_action_batch_sequence', 0) for name, robot in task.robots.items()}
        detail = dict(error=repr(exc), phase=task.phase, step=int(task.step_counter),
                      physics_stamp=failure_stamp, sdk_before=sdk_before,
                      sdk_after=sdk_after, no_new_sdk_batch=(sdk_before == sdk_after),
                      original_error=repr(exc), observation_service_violation=copy.deepcopy(violation))
        # Only this actual guard invocation may own a rejected command. An error
        # before the guard (including held-fit failure) cannot borrow old data.
        detail['rejected_command_evidence'] = None
        try:
            evidence = getattr(evidence_guard, 'last_rejection_evidence', None)
            if (evidence_guard is getattr(task, '_fabrica_production_action_guard', None)
                    and isinstance(evidence, dict)
                    and type(evidence_sequence_before) is int
                    and evidence.get('invocation_sequence') == evidence_sequence_before + 1
                    and evidence.get('physics_stamp') == failure_stamp
                    and evidence.get('task_step') == detail['step']
                    and evidence.get('phase') == detail['phase']
                    and evidence.get('original_error') == detail['error']):
                detail['rejected_command_evidence'] = json.loads(json.dumps(evidence, allow_nan=False))
            else:
                detail['rejected_command_evidence_missing'] = 'no fresh same-call guard evidence at original phase/task/native stamp and error'
        except Exception as evidence_error:
            detail['rejected_command_evidence_missing'] = 'guard evidence retention error: ' + repr(evidence_error)
        # Save the rejected command's actual clock before a subsequent env.step
        # or terminal capture. A neighbouring stride/terminal row cannot fill it.
        try:
            local_failure = getattr(task, '_stool_first_local_failure_observation', None) or {}
            if local_failure.get('physics_stamp') == failure_stamp:
                # A subsequent guard rejection at the same native clock must
                # reuse the first transition sample, even when it was invalid.
                raw = local_failure.get('independent_raw')
                detail['raw_reused_from_first_local_failure_observation'] = True
            else:
                raw = task._fabrica_independent_raw_sampler('control_failure')
            detail['independent_raw'] = raw
            detail['failure_clock_raw_complete'] = bool(isinstance(raw, dict)
                and raw.get('valid') is True and raw.get('physics_stamp') == failure_stamp
                and task._beam_physics_stamp() == failure_stamp)
        except Exception as retention_error:
            detail.update(failure_clock_raw_complete=False,
                raw_retention_error=repr(retention_error))
        save('production_control_failure.json', detail)
        task._set_terminal_state('failed', reason='stool-production-control-stop',
                                 status='failed', detail=detail)
        return {}
    finally:
        elapsed = policy_elapsed if policy_elapsed is not None else time.monotonic()-call_start
        TIMING['policy_calls'] += 1
        TIMING['policy_compute_seconds'] += elapsed
        phase_row['policy_calls'] += 1
        phase_row['policy_compute_seconds'] += elapsed


demo._build_env = build
demo.DualFrankaAssemblyDemoPolicy.act = act
demo.LiveRolloutVideoRecorder.__init__ = video_init
if __name__ == '__main__':
    try:
        demo.main()
    except StartupPreflightComplete:
        save('startup_only_complete.json', dict(completed=True, robot_sdk_submissions=0, assembly_success_claimed=False))
    except BaseException as exc:
        save('worker_exception.json', dict(exception_type=type(exc).__name__, message=str(exc),
            original_results_present=(OUT/'collect_results.json').exists(),
            native_initialization_passed=(OUT/'runtime_initialization_preflight.json').exists()))
        raise
    finally:
        retain_worker_result_status('worker_finally_fallback')

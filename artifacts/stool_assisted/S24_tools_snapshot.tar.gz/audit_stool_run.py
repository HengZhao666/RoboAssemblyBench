"""Read-only stool acceptance audit; missing evidence never becomes success.

All source reports remain untouched. This tool writes JSON only to stdout (or
to a new --output file). Raw buffers, wrapper qualification, SDK submissions,
images, geometry and provenance are separate evidence domains.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import tarfile
import re
import struct
from collections import deque
from fractions import Fraction
from pathlib import Path


OBJECTS = {'fabrica_stool_circular_' + str(i) for i in range(9)}
ROBOTS = {'franka_left', 'franka_right'}
ARM = ('shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint',
       'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint')
CAMERAS = {'observation.images.front', 'observation.images.left_wrist',
           'observation.images.right_wrist'}


def production_video_key(spec):
    """Mirror the documented export_lerobot._normalize_camera_spec alias."""
    key = spec.get('video_key')
    if key in {'observation.images.isaac_3d', 'observation.images.third_person'}:
        return 'observation.images.front'
    if key:
        return key
    owner = str(spec.get('robot') or spec.get('owner') or '').lower()
    view = str(spec.get('view_type') or '').lower()
    if not view:
        view = 'wrist' if 'wrist' in str(spec.get('name') or '') or owner in ROBOTS else 'front'
    if view == 'wrist':
        return 'observation.images.right_wrist' if owner == 'franka_right' else 'observation.images.left_wrist'
    return 'observation.images.front'


def matrix4(value):
    if not isinstance(value, list) or len(value) != 4:
        raise ValueError('4x4 evidence matrix missing')
    return [vector(row, 4) for row in value]


def transform_matrix(transform):
    x, y, z, qx, qy, qz, qw = vector(transform, 7)
    length = norm([qx, qy, qz, qw])
    if length <= 0 or abs(length-1.) > .001:
        raise ValueError('native snapshot quaternion is invalid')
    qx, qy, qz, qw = [q/length for q in (qx, qy, qz, qw)]
    return [[1-2*(qy*qy+qz*qz),2*(qx*qy-qz*qw),2*(qx*qz+qy*qw),x],
            [2*(qx*qy+qz*qw),1-2*(qx*qx+qz*qz),2*(qy*qz-qx*qw),y],
            [2*(qx*qz-qy*qw),2*(qy*qz+qx*qw),1-2*(qx*qx+qy*qy),z],
            [0.,0.,0.,1.]]


def matrix_difference(a, b):
    a, b = matrix4(a), matrix4(b)
    return max(abs(a[i][j]-b[i][j]) for i in range(4) for j in range(4))


def sdk_usd_matrix(transform, dtype):
    """Recompute Gf.Rotation(Quatd(raw float32)) without importing USD.

    Gf uses the raw real component for angle and normalizes the imaginary
    axis. This intentionally differs from normalizing all four components.
    The physical normalized quaternion residual is checked separately.
    """
    x, y, z, qx, qy, qz, qw = vector(transform, 7)
    require(dtype == 'float32', 'SDK/native quaternion dtype is not the frozen float32 domain')
    q = [qx, qy, qz, qw]
    require(all(struct.unpack('<f', struct.pack('<f', v))[0] == v for v in transform),
            'SDK/native pose values do not round-trip exactly through float32')
    require(abs(norm(q)-1.) <= 64 * 2**-23 and -1. <= qw <= 1.,
            'SDK/native raw quaternion is outside the validated unit/real-component domain')
    size = norm([qx, qy, qz])
    if size <= 1e-10:
        rotation = [[float(i == j) for j in range(3)] for i in range(3)]
    else:
        axis = [qx/size, qy/size, qz/size]
        radians = 2*math.acos(qw)
        cosine, sine = math.cos(radians), math.sin(radians)
        skew = [[0., -axis[2], axis[1]], [axis[2], 0., -axis[0]], [-axis[1], axis[0], 0.]]
        rotation = [[cosine*(i == j) + (1-cosine)*axis[i]*axis[j] + sine*skew[i][j]
                     for j in range(3)] for i in range(3)]
    return [row+[p] for row, p in zip(rotation, [x, y, z])] + [[0., 0., 0., 1.]]


def rigid_matrix(value):
    matrix = matrix4(value)
    require(max(abs(matrix[3][j] - float(j == 3)) for j in range(4)) <= 1e-12,
            'evidence transform is not homogeneous')
    rotation = [row[:3] for row in matrix[:3]]
    require(max(abs(sum(rotation[k][i]*rotation[k][j] for k in range(3)) - float(i == j))
                for i in range(3) for j in range(3)) <= 1e-10,
            'evidence transform rotation is not orthonormal')
    determinant = sum(rotation[0][j]*(rotation[1][(j+1)%3]*rotation[2][(j+2)%3]
                      - rotation[1][(j+2)%3]*rotation[2][(j+1)%3]) for j in range(3))
    require(abs(determinant-1.) <= 1e-10, 'evidence transform rotation is reflected or invalid')
    return matrix


def rotation_distance(a, b):
    a, b = rigid_matrix(a), rigid_matrix(b)
    cosine = (sum(a[i][j]*b[i][j] for i in range(3) for j in range(3))-1.)/2.
    return math.acos(max(-1., min(1., cosine)))


def native_usd_dual_row(row, transform):
    """Validate both recorded domains, retaining the old physical residual."""
    normalized = transform_matrix(transform)
    native, usd = rigid_matrix(row.get('native_world_matrix')), rigid_matrix(row.get('usd_world_matrix'))
    require(matrix_difference(native, normalized) <= 1e-9,
            'stage/native comparison is not bound to the frozen captured native body')
    require(vector(row.get('raw_native_quaternion_xyzw'), 4) == vector(transform, 7)[3:],
            'publication conversion raw quaternion differs from captured native values')
    require(vector(row.get('raw_native_pose_xyzw'), 7) == transform,
            'publication conversion raw pose differs from captured native values')
    expected = sdk_usd_matrix(transform, row.get('raw_native_dtype'))
    require(matrix_difference(row.get('expected_usd_world_matrix'), expected) <= 1e-12,
            'recorded SDK/USD conversion differs from independent raw-quaternion axis-angle recomputation')
    require(row.get('conversion_method') == 'Gf.Matrix4d.SetRotate(Gf.Rotation(Gf.Quatd(raw_w,raw_xyz)))',
            'SDK/USD conversion method is not the frozen actual Gf path')
    receipt = row.get('conversion_receipt') or {}
    sdk_math_error = receipt.get('sdk_math_matrix_max_abs_error')
    require(receipt.get('actual_sdk_called') is True and isinstance(receipt.get('sdk_module_path'), str)
            and bool(receipt['sdk_module_path']) and receipt.get('method') == row['conversion_method']
            and receipt.get('raw_dtype') == 'float32' and receipt.get('native_pose_float32_roundtrip') is True
            and receipt.get('quaternion_norm_sanity_atol') == 64 * 2**-23
            and receipt.get('scalar_in_unit_interval') is True and receipt.get('axis_identity_epsilon') == 1e-10
            and isinstance(sdk_math_error, (int, float)) and not isinstance(sdk_math_error, bool)
            and math.isfinite(sdk_math_error) and 0. <= sdk_math_error <= 1e-12,
            'actual SDK/Gf conversion receipt is missing or outside the frozen conversion domain')
    raw_norm = norm(transform[3:])
    require(isinstance(row.get('raw_quaternion_norm'), (int, float))
            and abs(row['raw_quaternion_norm']-raw_norm) <= 1e-12
            and isinstance(receipt.get('raw_quaternion_norm'), (int, float))
            and abs(receipt['raw_quaternion_norm']-raw_norm) <= 1e-12,
            'recorded raw quaternion norm differs')
    scalar = abs(transform[6]); bits = struct.unpack('<I', struct.pack('<f', scalar))[0]
    scalar_ulp = struct.unpack('<f', struct.pack('<I', bits+1))[0]-scalar
    require(row.get('raw_quaternion_scalar_ulp') == scalar_ulp, 'raw quaternion scalar float32 ULP differs')
    tolerance = row.get('tolerance')
    expected_tolerance = 32 * 2**-23 * max(1., max(abs(v) for r in native for v in r))
    require(isinstance(tolerance, (int, float)) and not isinstance(tolerance, bool)
            and math.isfinite(tolerance) and tolerance > 0.
            and abs(tolerance-expected_tolerance) <= 1e-12 * max(1., expected_tolerance),
            'stage/native tolerance differs from frozen float32 representation formula')
    normalized_error = matrix_difference(native, usd)
    position_error = distance([native[i][3] for i in range(3)], [usd[i][3] for i in range(3)])
    normalized_angle = rotation_distance(native, usd)
    representation_delta = rotation_distance(native, expected)
    for key, value, precision in (('matrix_max_abs_error', normalized_error, 1e-12),
                                  ('position_error_m', position_error, 1e-12),
                                  ('angle_error_rad', normalized_angle, 1e-7),
                                  ('representation_delta_rad', representation_delta, 1e-7),
                                  ('representation_matrix_max_abs_error', matrix_difference(native, expected), 1e-12)):
        reported = row.get(key)
        require(isinstance(reported, (int, float)) and not isinstance(reported, bool)
                and math.isfinite(reported) and abs(reported-value) <= precision,
                'original/dual numeric residual is missing or altered: '+key)
    normalized_passed = normalized_error <= tolerance
    require(row.get('passed') is normalized_passed, 'original normalized-native pass/fail was rewritten')
    publication_error = matrix_difference(expected, usd)
    require(isinstance(row.get('publication_matrix_max_abs_error'), (int, float))
            and abs(row['publication_matrix_max_abs_error']-publication_error) <= 1e-12,
            'SDK publication residual is missing or differs')
    require(row.get('publication_passed') is True and publication_error <= tolerance
            and position_error <= tolerance and rotation_distance(expected, usd) <= tolerance,
            'renderer/USD body differs from actual SDK conversion of the frozen native pose')
    return dict(body=row.get('body'), normalized_native_alignment_passed=normalized_passed,
        normalized_native_matrix_max_abs_error=normalized_error,
        normalized_native_position_error_m=position_error, normalized_native_angle_error_rad=normalized_angle,
        sdk_representation_delta_rad=representation_delta,
        publication_matrix_max_abs_error=publication_error, original_tolerance=tolerance)


def reference_fraction(reference, *, raw=False):
    if not isinstance(reference, dict) or reference.get('error'):
        raise ValueError('render-product ReferenceTime is missing or invalid')
    if not raw and reference.get('valid') is not True:
        raise ValueError('render-product normalized ReferenceTime is invalid')
    numerator = reference.get('referenceTimeNumerator' if raw else 'numerator')
    denominator = reference.get('referenceTimeDenominator' if raw else 'denominator')
    if type(numerator) is not int or type(denominator) is not int or numerator < 0 or denominator <= 0:
        raise ValueError('render-product rational ReferenceTime is invalid')
    return Fraction(numerator, denominator)


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def vector(value, length):
    if (not isinstance(value, list) or len(value) != length
            or any(isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x) for x in value)):
        raise ValueError('missing, nonfinite or incorrectly shaped numeric vector')
    return value


def norm(value):
    return math.sqrt(sum(x*x for x in value))


def distance(a, b):
    return norm([x-y for x, y in zip(a, b)])


def angle(a, b):
    a, b = vector(a, 4), vector(b, 4)
    na, nb = norm(a), norm(b)
    if abs(na-1) > .001 or abs(nb-1) > .001:
        raise ValueError('raw quaternion is not normalized')
    return 2 * math.acos(min(1., abs(sum(x*y for x, y in zip(a, b))/(na*nb))))


def stamp_key(stamp):
    if (not isinstance(stamp, dict) or stamp.get('valid') is not True
            or type(stamp.get('epoch')) is not int or type(stamp.get('index')) is not int
            or not math.isfinite(float(stamp.get('time', float('nan'))))
            or not math.isfinite(float(stamp.get('dt', float('nan')))) or stamp['dt'] <= 0):
        raise ValueError('valid native epoch/index/time/dt is unavailable')
    return stamp['epoch'], stamp['index']


def original_geometry_inventory(coverage, scene):
    """Verify typed physical absence against complete visible/collider inventory.

    This explains explicit nonphysical roots; it never exempts unsupported or
    unexported geometry, nor claims PhysX cooked/SDF or force qualification.
    """
    if coverage.get('physical_inventory_schema') != 'usd_collider_inventory_v1':
        return set()
    roots = coverage.get('root_collider_inventory')
    require(isinstance(roots, list) and roots, 'typed original collider inventory absent')
    require(not scene.get('gaps') and scene.get('visible_meshes'), 'complete visible scene inventory absent')
    require(len({r.get('root') for r in roots}) == len(roots), 'duplicate physical inventory roots')
    disabled = set()
    for root in roots:
        path, rows = root.get('root'), root.get('prims')
        require(isinstance(path, str) and rows and root.get('primitive_count') == len(rows), 'incomplete original root traversal')
        require(root.get('traversal') == 'Usd.PrimRange(root, Usd.TraverseInstanceProxies())', 'instance-proxy traversal missing')
        require(len({r.get('prim') for r in rows}) == len(rows)
                and any(r.get('prim') == path for r in rows), 'typed root prim identity missing/duplicated')
        require(all(isinstance(r.get('collision_api'), bool) and isinstance(r.get('supported_type'), bool)
                    and (r['prim'] == path or r['prim'].startswith(path+'/'))
                    and r['supported_type'] == (r.get('type') in {'Mesh','Cube'}) for r in rows),
                'typed collider inventory contains invalid prim identity/type')
        declared = [r for r in rows if r['collision_api']]
        require(all(isinstance(r.get('enabled'), bool) for r in declared)
                and all(r.get('enabled') is None for r in rows if not r['collision_api']), 'collider enable declaration invalid')
        enabled = [r for r in declared if r['enabled']]
        require(not any(not r['supported_type'] for r in enabled), 'unsupported enabled collider remains uncovered')
        require(root.get('enabled_supported_count') == len(enabled), 'enabled collider count differs from traversal')
        actual = {r['prim'] for r in scene.get('colliders', []) if r['prim'] == path or r['prim'].startswith(path+'/')}
        require(actual == {r['prim'] for r in enabled}, 'original enabled collider inventory differs from scene export')
        expected = ('no_collision_api_declared' if not declared else
                    'all_declared_colliders_disabled' if not enabled else 'enabled_supported_colliders')
        require(root.get('status') == expected, 'typed root status contradicts actual declarations')
        if not enabled:
            visible = [m for m in scene['visible_meshes'] if m['prim'] == path or m['prim'].startswith(path+'/')]
            require(visible and all(m.get('enabled_collider') is False for m in visible),
                    'nonphysical root lacks complete visible guard geometry')
            require({m['prim'] for m in visible} <= {r['prim'] for r in rows}, 'visible prim absent from original traversal')
        disabled.update(r['prim'] for r in declared if r['enabled'] is False)
    skipped = coverage.get('skipped', [])
    require(isinstance(skipped, list) and all(row.get('reason') == 'collision_disabled'
            and row.get('prim') in disabled for row in skipped), 'unresolved typed skip reason or identity')
    require({r['prim'] for r in skipped} == disabled, 'disabled collider declarations not fully retained as original skips')
    return disabled


def original_uncapped_trace(coverage, path):
    receipt = coverage.get('uncapped_trace_receipt') or {}
    require(receipt.get('schema') == 'entity_geometry_uncapped_trace_v1'
            and receipt.get('start_offset') == 0 and receipt.get('summary_is_exact_suffix') is True,
            'original uncapped trace receipt missing or nonexclusive')
    hasher = hashlib.sha256(); records = events = size = 0; suffix = deque(maxlen=5000)
    previous = None
    with path.open('rb') as stream:
        for payload in stream:
            hasher.update(payload); size += len(payload)
            row = json.loads(payload)
            require(isinstance(row.get('events'), list) and isinstance(row.get('body_poses'), dict)
                    and row['body_poses'], 'original uncapped trace row missing full poses/events')
            step = row.get('step')
            require(type(step) is int and (previous is None or step > previous), 'original trace steps not strictly increasing')
            previous = step; records += 1; events += len(row['events']); suffix.extend(row['events'])
    require(receipt.get('bytes') == size and receipt.get('sha256') == hasher.hexdigest(), 'uncapped trace bytes/SHA differ')
    require(receipt.get('records') == records == coverage.get('sampled_checks')
            and receipt.get('events') == events, 'uncapped trace record/event counts differ')
    summary = coverage.get('events'); dropped = coverage.get('events_dropped_from_summary')
    require(isinstance(summary, list) and summary == list(suffix), 'original summary is not exact full-trace suffix')
    require(receipt.get('summary_events') == len(summary)
            and receipt.get('summary_omitted_events') == dropped == events-len(summary),
            'uncapped trace/retained/omitted event conservation failed')
    return {'records': records, 'events': events, 'sha256': hasher.hexdigest(), 'summary_omitted_events': dropped}


"""Pure join of support qualification to completed original SDK boundary rows."""


def verify_support_sdk_windows(support, events, selected, boundary_rows):
    wanted = {}; sequence_publications = {}
    for (stage, key), raw in selected.items():
        event = events[stage][key]
        owned = event['sample']['SDK'] if stage in {'acquire','hold'} else event['actual_final_SDK']
        receipt = owned['receipt']; publication = receipt['physics_stamp']
        require(publication['epoch'] == key[0]
                and key[1] - publication['index'] in (0, 1), 'support publication is not causal to its native sample')
        sequence = receipt['expected_sdk_batch_sequence']
        require(type(sequence) is int and sequence > 0, 'support actual SDK sequence must be a positive integer')
        pub_identity = (publication['epoch'], publication['index'], publication['time'], publication['dt'])
        require(sequence not in sequence_publications or sequence_publications[sequence] == pub_identity,
                'support actual SDK sequence belongs to multiple publication clocks')
        sequence_publications[sequence] = pub_identity
        identity = (publication['index'], sequence)
        wanted.setdefault(identity, []).append((stage, key, raw, owned, publication))
    matched = {}; joined = set(); peak_error = 0.
    for row in boundary_rows:
        # The SDK call completes before the existing world.step.  Its clock is
        # the publication clock, usually one native tick before qualification.
        if row.get('kind') != 'boundary' or row.get('boundary') != 'after_action':
            continue
        robot = row.get('robots', {}).get(support['robot']) or {}
        sdk = robot.get('sdk_submission') or {}
        identity = (row.get('physics_step_index'), sdk.get('batch_sequence'))
        if identity not in wanted:
            continue
        require(type(row.get('physics_step_index')) is int and type(sdk.get('batch_sequence')) is int
                and row.get('clock_valid') is True and robot.get('valid') is True,
                'support completed SDK row/native articulation clock is invalid')
        require(sdk.get('scope') == 'completed_apply_action_calls_not_physical_tracking'
                and not sdk.get('skipped'), 'support SDK call was missing or skipped')
        controllers, actions = sdk.get('controllers'), sdk.get('actions')
        require(isinstance(controllers, list) and isinstance(actions, list)
                and len(controllers) == len(actions) == 2
                and set(controllers) == {'arm_joint_controller', 'gripper_controller'},
                'support completed SDK row lacks exactly the two explicit controllers')
        controls = dict(zip(controllers, actions))
        for stage, key, raw, owned, publication in wanted[identity]:
            expected_phase = owned['receipt'].get('phase') if stage == 'hold' else support[stage+'_phase_name']
            require(isinstance(expected_phase, str) and expected_phase and
                    (row.get('phase') == expected_phase or row.get('cycle_phase') == expected_phase)
                    and math.isclose(float(row['physics_time']), float(publication['time']), rel_tol=0., abs_tol=1e-9)
                    and math.isclose(float(row['physics_dt']), float(publication['dt']), rel_tol=1e-9, abs_tol=1e-12),
                    'support completed SDK row does not share its exact publication clock/phase')
            current = raw['physics_stamp']
            require(math.isclose(float(current['dt']), float(publication['dt']), rel_tol=1e-9, abs_tol=1e-12)
                    and math.isclose(float(current['time']) - float(publication['time']),
                        (current['index']-publication['index'])*float(current['dt']),
                        rel_tol=1e-6, abs_tol=max(1e-10, float(current['dt'])*1e-6)),
                    'support publication and independent backend have no valid native-tick causal relation')
            native = raw['robots'][support['robot']]; names = native['joint_names']
            require(robot.get('joint_names') == names, 'support SDK/native DOF order differs')
            def accepted(control):
                require(isinstance(control, dict), 'support accepted control is not an action object')
                positions = control.get('joint_positions'); indices = control.get('joint_indices')
                require(isinstance(positions, list) and positions, 'support accepted control lacks positions')
                if indices is None: indices = list(range(len(positions)))
                require(isinstance(indices, list) and len(indices) == len(positions)
                        and len(set(indices)) == len(indices)
                        and all(type(i) is int and 0 <= i < len(names) for i in indices),
                        'support accepted control has ambiguous/invalid native DOF indices')
                require(all(v is None or (isinstance(v, (int, float)) and not isinstance(v, bool)
                        and math.isfinite(v)) for v in positions), 'support accepted control has nonfinite values')
                return dict(zip(indices, positions))
            arm = accepted(controls['arm_joint_controller'])
            gripper = accepted(controls['gripper_controller'])
            request = vector(owned['arm_q'], 6)
            expected = {names.index(n): request[j] for j, n in enumerate(ARM)}
            row_spec = support['cad_row']; opening = owned['gripper_openness']
            expected_driver = row_spec['driver_closed_rad'] + opening*(row_spec['driver_open_rad']-row_spec['driver_closed_rad'])
            driver = names.index('finger_joint')
            require(all(i in arm and arm[i] is not None and abs(arm[i]-v) <= 2e-5
                        for i, v in expected.items()), 'support SDK accepted arm differs from owned final6q')
            require(driver in gripper and gripper[driver] is not None
                    and abs(gripper[driver]-expected_driver) <= 2e-5,
                    'support SDK accepted driver differs from owned normalized aperture')
            # Only the driver is actuated by this authored Robotiq controller.
            # Both complete12DOF backend buffers remain required by the caller.
            errors = [abs(arm[i]-native['position_targets'][i]) for i in expected]
            errors.append(abs(gripper[driver]-native['position_targets'][driver]))
            require(max(errors) <= 2e-5, 'support SDK accepted targets differ from independent native backend')
            peak_error = max(peak_error, max(errors))
            joined.add((stage, key))
        projection = dict(physics_time=row['physics_time'], physics_dt=row['physics_dt'],
            joint_names=robot['joint_names'], sdk_submission=sdk)
        require(identity not in matched or matched[identity] == projection,
                'support SDK submission changed at the same publication clock and sequence')
        matched[identity] = projection
    require(joined == set(selected), 'support window lacks a completed after_action SDK row for every required publication/sequence')
    return dict(ticks_joined=len(joined), completed_submission_identities=len(matched),
        completed_batch_sequence_min=min(key[1] for key in matched),
        completed_batch_sequence_max=max(key[1] for key in matched),
        robot=support['robot'], peak_accepted_backend_difference_rad=peak_error,
        accepted_backend_tolerance_rad=2e-5,
        publication_to_native_tick_offsets=sorted({raw['physics_stamp']['index']-owned['receipt']['physics_stamp']['index']
            for group in wanted.values() for _, _, raw, owned, _ in group}),
        wrapper_epoch=None, wrapper_clock_fields=['physics_step_index','physics_time','physics_dt'],
        epoch_scope='primary qualification and independent native buffers share exact epoch; original SDK wrapper has no epoch field',
        gripper_scope='accepted driver joint only; original controller actuates one DOF, complete six native gripper states/targets remain separately checked')


def verify_continuous_base_support(contract, trace_rows, raw_rows, boundary_rows):
    """One continuous support role: original12+12 gates and every native hold tick.

    CAD is the already-computed primary exact-mesh result, not an independent
    CAD rerun. Native buffers and completed SDK calls are independently joined.
    Base motion/drift is reported; no new long-duration drift threshold is added.
    """
    support = contract['base_support']; cycles = support.get('cycles') or []
    require(contract.get('adapter') == 'stool_circular_ur5e_v1'
        and support.get('schema') == 'stool_continuous_base_support_v3'
        and support.get('role') == 'base_2_support' and support.get('robot') == 'franka_right'
        and support.get('object') == contract.get('base_object') == 'fabrica_stool_circular_2'
        and support.get('stable_native_ticks') == 12 and support.get('force_support_claimed') is False
        and len(cycles) == 1, 'continuous support role/contract differs from explicit single-cycle schema')
    cycle = cycles[0]
    require(cycle.get('cycle_id') == 'base_support_continuous' and cycle.get('moving_object') is None
        and cycle.get('moving_objects') == contract['assembly_order'][1:]
        and isinstance(cycle.get('hold_phase_names'), list) and cycle['hold_phase_names']
        and len(set(cycle['hold_phase_names'])) == len(cycle['hold_phase_names']),
        'continuous support moving objects/hold phase list is invalid')
    stages = {cycle['acquire_phase_name']:'acquire', cycle['open_phase_name']:'open'}
    stages.update({name:'hold' for name in cycle['hold_phase_names']})
    traces = list(trace_rows); raws = list(raw_rows); boundaries = list(boundary_rows)
    for event in traces:
        if event.get('event') in {'fabrica_base_support_acquire','fabrica_base_support_open',
                'fabrica_base_support_continuous_sample'}:
            require(event.get('cycle_id') == cycle['cycle_id'] and event.get('moving_object') is None
                and event.get('phase') in stages, 'continuous support primary cycle/phase identity differs')
    local = dict(support, acquire_phase_name=cycle['acquire_phase_name'], open_phase_name=cycle['open_phase_name'])
    windows = verify_support_cycle_windows(dict(contract, base_support=local), traces, raws, boundaries)
    acquisition = tuple(windows['acquisition_end']); release = tuple(windows['release_end'])
    acquire_event = next(e for e in traces if e.get('event') == 'fabrica_base_support_acquire'
        and stamp_key(e.get('physics_stamp')) == acquisition and e.get('qualified') is True)
    frozen = acquire_event['sample']; frozen_q = vector(frozen['SDK']['arm_q'], 6)
    frozen_open = frozen['SDK']['gripper_openness']; frozen_identity = frozen['identity']
    reference = vector(frozen['native_object']['position'], 3)
    reference_q = vector(frozen['native_object']['orientation'], 4)
    raw_by_sequence = {}
    for row in raws:
        sequence = row.get('sequence')
        require(type(sequence) is int and sequence not in raw_by_sequence,
            'independent raw sequence missing or duplicated')
        raw_by_sequence[sequence] = row
    events = {'hold':{}}; selected = {}; observed_phases = []; opened = []
    max_tracking = max_translation = max_angle = max_linear = max_angular = 0.
    acquired_summary = (acquire_event.get('independent_raw') or {}).get('independent_raw') or {}
    acquired_raw = raw_by_sequence.get(acquired_summary.get('sequence')) or {}
    require(acquired_raw.get('valid') is True, 'continuous acquired raw reference is missing')
    view_scope = (acquired_raw.get('body_view_id'), tuple(sorted(acquired_raw.get('bodies', {}))))
    previous_clock = None
    for event in traces:
        if event.get('event') != 'fabrica_base_support_continuous_sample': continue
        phase = event['phase']; stage = event.get('support_stage'); key = stamp_key(event.get('physics_stamp'))
        require(stage == stages[phase] and stage in {'hold','open'}
            and event.get('force_support_claimed') is False,
            'continuous primary sample has wrong role/stage or force claim')
        sample = event.get('sample') or {}; cad = sample.get('CAD') or {}; sdk = sample.get('SDK') or {}
        require(sample.get('physics_stamp') == event['physics_stamp'] and sample.get('ready') is True
            and sample.get('identity') == frozen_identity and sample.get('force_support_claimed') is False
            and cad.get('ready') is True and cad.get('physics_stamp') == event['physics_stamp']
            and cad.get('qualification') == 'dual_native_visible_pad_CAD_near_fit',
            'continuous primary sample lost current native CAD/identity qualification')
        gaps = cad.get('gaps') or []
        require(len(gaps) == 2 and all(g.get('intersect') is False
            and 0 < g.get('gap', 0) <= contract['cad_pinch']['max_gap_m']
            and g.get('point_on_actual_inner_face') is True
            and g.get('separation_along_inward_normal') is True for g in gaps),
            'continuous primary dual-pad CAD predicates failed')
        require(vector(sdk.get('arm_q'), 6) == frozen_q and sdk.get('gripper_openness') == frozen_open,
            'continuous support changed acquired full arm/aperture drive')
        require((sdk.get('receipt') or {}).get('phase') in stages,
            'continuous actual SDK publication is outside the support phase graph')
        independent = event.get('independent_raw') or {}; summary = independent.get('independent_raw') or {}
        require(independent.get('passed') is True and independent.get('physics_stamp') == event['physics_stamp']
            and summary.get('valid') is True and summary.get('physics_stamp') == event['physics_stamp'],
            'continuous primary lacks separate same-clock native sample')
        raw = raw_by_sequence.get(summary.get('sequence')) or {}
        require(raw.get('valid') is True and raw.get('boundary') == 'base_support_hold'
            and raw.get('phase') == phase and raw.get('physics_stamp') == event['physics_stamp']
            and raw.get('source') == 'separate_exact_path_PhysX_tensor_views'
            and raw.get('orientation_order') == 'xyzw' and raw.get('pose_frame') == 'world'
            and raw.get('velocity_reference') == 'center_of_mass'
            and set(raw.get('objects', {})) == OBJECTS and set(raw.get('robots', {})) == ROBOTS
            and len(raw.get('bodies', {})) == 41,
            'continuous independent native scene/clock/sequence coverage is incomplete')
        scope = (raw.get('body_view_id'), tuple(sorted(raw['bodies'])))
        require(scope[0] is not None and (view_scope is None or scope == view_scope),
            'continuous independent body/view identity changed')
        require(tuple(sorted(summary.get('body_paths') or [])) == scope[1]
            and summary.get('objects') == {name:body.get('path') for name,body in raw['objects'].items()},
            'continuous independent raw summary aliases native body/object identities')
        view_scope = scope
        for body in raw['bodies'].values(): vector(body.get('transform'), 7); vector(body.get('velocity'), 6)
        for robot in raw['robots'].values():
            names = robot.get('joint_names') or []
            require(len(names) == 12 and len(set(names)) == 12 and set(ARM) <= set(names),
                'continuous full native12DOF order missing')
            vector(robot.get('positions'), 12); vector(robot.get('velocities'), 12); vector(robot.get('position_targets'), 12)
        robot = raw['robots'][support['robot']]; names = robot['joint_names']
        track = max(abs(robot['positions'][names.index(n)]-frozen_q[i]) for i,n in enumerate(ARM))
        require(track <= contract['max_tracking_error_rad'], 'continuous actual right arm exceeds original tracking bound')
        max_tracking = max(max_tracking, track)
        base = raw['objects'][support['object']]; primary = sample['native_object']; transform = vector(base.get('transform'), 7)
        require(base.get('path') == primary.get('body_path') and base['path'] in raw['bodies']
            and base['transform'] == raw['bodies'][base['path']]['transform']
            and base['velocity'] == raw['bodies'][base['path']]['velocity'],
            'continuous base raw path/buffer identity differs')
        native_matrix = transform_matrix(transform)
        primary_transform = vector(primary.get('position'),3) + vector(primary.get('orientation'),4)[1:] + [primary['orientation'][0]]
        require(matrix_difference(native_matrix, transform_matrix(primary_transform)) <= 2e-5,
            'continuous base primary pose differs from independent native buffer')
        translation = norm([transform[i]-reference[i] for i in range(3)])
        angle = rotation_distance(native_matrix, transform_matrix(reference + reference_q[1:] + [reference_q[0]]))
        velocity = vector(base['velocity'],6)
        max_translation=max(max_translation,translation); max_angle=max(max_angle,angle)
        max_linear=max(max_linear,norm(velocity[:3])); max_angular=max(max_angular,norm(velocity[3:]))
        if key in events['hold']:
            require(events['hold'][key] == event, 'continuous primary repeated native tick differs')
        events['hold'][key] = event; selected[('hold',key)] = raw
        if stage == 'hold' and (not observed_phases or observed_phases[-1] != phase): observed_phases.append(phase)
        if stage == 'open': opened.append(key)
        clock = event['physics_stamp']
        if previous_clock is not None:
            delta = clock['index']-previous_clock['index']
            require(delta == 1 and clock['epoch'] == previous_clock['epoch']
                and math.isclose(clock['dt'], previous_clock['dt'], rel_tol=1e-9, abs_tol=1e-12)
                and math.isclose(clock['time']-previous_clock['time'], clock['dt'], rel_tol=1e-6,
                    abs_tol=max(1e-10,clock['dt']*1e-6)), 'continuous native primary/raw tick coverage has a gap or changed epoch')
        previous_clock = clock
    require(selected and observed_phases == cycle['hold_phase_names'] and len(opened) == 1,
        'continuous support lacks all original left phases or the first opening boundary')
    keys = sorted(key for _,key in selected)
    require(keys[0][0] == acquisition[0] == keys[-1][0] == release[0]
        and keys[0][1]-acquisition[1] in (0,1) and keys[-1] == opened[0]
        and keys[-1] < release, 'continuous support interval does not connect original acquisition and release')
    sdk_join = verify_support_sdk_windows(local, events, selected, boundaries)
    return dict(passed=True,schema=support['schema'],completed_cycles=1,qualification_windows=2,
        ticks_per_window=12,windows=windows,continuous_native_ticks=len(selected),
        continuous_start=list(keys[0]),continuous_end=list(keys[-1]),hold_phases=len(observed_phases),
        sdk_execution_join=sdk_join,force_support_claimed=False,
        measured_base_drift_from_acquisition=dict(maximum_translation_m=max_translation,maximum_rotation_rad=max_angle,
            maximum_linear_speed_m_s=max_linear,maximum_angular_speed_rad_s=max_angular,
            qualification='diagnostic measurements; original installed-base criteria remain the control gate'),
        maximum_right_arm_tracking_error_rad=max_tracking,
        primary_CAD_scope='existing same-tick controller result, not independently recomputed CAD',
        final72_scope='original final common window is unchanged and checked separately')


def verify_base_support_windows(contract, trace_rows, raw_rows, boundary_rows):
    if contract.get('base_support', {}).get('schema') == 'stool_continuous_base_support_v3':
        return verify_continuous_base_support(contract, trace_rows, raw_rows, boundary_rows)
    """Eight explicit installation support cycles; original final72 is separate."""
    support = contract.get('base_support') or {}
    require(support.get('schema') == 'stool_install_cycle_support_v2'
            and support.get('role') == 'base_2_support'
            and support.get('robot') == 'franka_right'
            and support.get('stable_native_ticks') == 12 and support.get('force_support_claimed') is False
            and support.get('object') == contract.get('base_object') == 'fabrica_stool_circular_2',
            'explicit installation-cycle support contract absent')
    cycles = support.get('cycles') or []
    require(len(cycles) == 8 and len({c['cycle_id'] for c in cycles}) == 8
            and [c['moving_object'] for c in cycles] == contract['assembly_order'][1:],
            'support cycles must cover the eight original moving parts in order')
    phase_map = {}; grouped = {}
    for cycle in cycles:
        cid = cycle['cycle_id']; grouped[cid] = []
        for stage in ('acquire', 'open'):
            phase = cycle[stage+'_phase_name']
            require(isinstance(phase, str) and phase and phase not in phase_map,
                    'support acquisition/open phase names are ambiguous')
            phase_map[phase] = (cycle, stage)
    for row in trace_rows:
        event = row.get('event')
        if event not in {'fabrica_base_support_acquire', 'fabrica_base_support_open'}:
            continue
        require(row.get('phase') in phase_map, 'support event lies outside its exact contract phase map')
        cycle, stage = phase_map[row['phase']]
        require(event == 'fabrica_base_support_'+stage
                and row.get('cycle_id') == cycle['cycle_id']
                and row.get('moving_object') == cycle['moving_object'],
                'support event cycle/moving-object/phase identity differs from contract')
        grouped[cycle['cycle_id']].append(row)
    wanted = {}; publications = set()
    for cycle in cycles:
        events = grouped[cycle['cycle_id']]
        for stage in ('acquire','open'):
            candidates = [r for r in events if r.get('event') == 'fabrica_base_support_'+stage
                          and r.get('ready') is True and r.get('qualified') is True]
            require(candidates, 'cycle '+cycle['cycle_id']+' '+stage+' native window did not complete')
            end = min(stamp_key(r.get('physics_stamp')) for r in candidates)
            keys = {(end[0], i) for i in range(end[1]-support['stable_native_ticks']+1, end[1]+1)}
            phase = cycle[stage+'_phase_name']
            for key in keys: wanted[(phase,key)] = cycle['cycle_id']
            for row in events:
                if row.get('phase') != phase or row.get('ready') is not True:
                    continue
                key = stamp_key(row.get('physics_stamp'))
                if key not in keys: continue
                owned = row['sample']['SDK'] if stage == 'acquire' else row['actual_final_SDK']
                receipt = owned['receipt']; publication = receipt['physics_stamp']
                publications.add((publication['index'], receipt['expected_sdk_batch_sequence']))
    selected_raw = {c['cycle_id']:[] for c in cycles}
    for row in raw_rows:
        if row.get('boundary') not in ('base_support_acquire','base_support_open'): continue
        phase = row.get('phase')
        if phase not in phase_map: continue
        cycle, stage = phase_map[phase]
        require(row.get('boundary') == 'base_support_'+stage, 'support raw boundary has wrong role stage')
        key = stamp_key(row.get('physics_stamp'))
        if (phase,key) in wanted: selected_raw[cycle['cycle_id']].append(row)
    selected_boundaries = []
    for row in boundary_rows:
        if row.get('kind') != 'boundary' or row.get('boundary') != 'after_action':continue
        sdk = (row.get('robots',{}).get(support['robot']) or {}).get('sdk_submission') or {}
        if (row.get('physics_step_index'), sdk.get('batch_sequence')) in publications:
            selected_boundaries.append(row)
    results = []; previous = None; previous_sequence = None; native_scope = None
    for cycle in cycles:
        cid = cycle['cycle_id']; local_support = dict(support,
            acquire_phase_name=cycle['acquire_phase_name'], open_phase_name=cycle['open_phase_name'])
        local_contract = dict(contract, base_support=local_support)
        result = verify_support_cycle_windows(local_contract, grouped[cid], selected_raw[cid], selected_boundaries)
        start = (result['acquisition_end'][0], result['acquisition_end'][1]-support['stable_native_ticks']+1)
        if previous is not None:
            require(previous[0] == start[0] and previous < start,
                    'installation support cycles overlap or change native epoch')
        previous = tuple(result['release_end'])
        sequence_min = result['sdk_execution_join']['completed_batch_sequence_min']
        sequence_max = result['sdk_execution_join']['completed_batch_sequence_max']
        require(previous_sequence is None or sequence_min > previous_sequence,
                'support actual SDK sequence regressed or was reused between installation cycles')
        previous_sequence = sequence_max
        raw_scope = {(r.get('body_view_id'), tuple(sorted(r.get('bodies',{})))) for r in selected_raw[cid]}
        require(len(raw_scope)==1, 'cycle independent native body scope changed')
        scope = next(iter(raw_scope))
        require(native_scope is None or scope == native_scope,
                'independent native body/view identity changed between support cycles')
        native_scope = scope
        results.append(dict(cycle_id=cid, moving_object=cycle['moving_object'], **result))
    return dict(passed=True, schema=support['schema'], cycles=results, completed_cycles=len(results),
        ticks_per_window=support['stable_native_ticks'], qualification_windows=16,
        ticks_with_SDK_backend_native_join=sum(r['sdk_execution_join']['ticks_joined'] for r in results),
        force_support_claimed=False, final72_scope='original final common window is unchanged and checked separately')


def verify_support_cycle_windows(contract, trace_rows, raw_rows, boundary_rows):
    """Join the two explicit12-tick primary support gates to independent buffers.

    CAD distances remain primary exact-mesh predicates. Independent views prove
    native full-state/target/clock coverage; this does not manufacture force data.
    """
    support = contract['base_support']; required = support['stable_native_ticks']
    require(required == 12 and support['force_support_claimed'] is False,
            'base support must retain original12 ticks and no force-bearing claim')
    events = {'acquire':{}, 'open':{}}
    for row in trace_rows:
        for stage in events:
            if row.get('event') == 'fabrica_base_support_'+stage and row.get('ready') is True:
                key = stamp_key(row.get('physics_stamp'))
                require(row.get('phase') == support[stage+'_phase_name'], 'support event phase identity changed')
                if key in events[stage]:
                    require(events[stage][key] == row, 'support primary predicates changed within one native tick')
                events[stage][key] = row
    selected = {}; ends = {}
    for stage, rows in events.items():
        completed = [(key,row) for key,row in rows.items() if row.get('qualified') is True]
        require(completed, 'support '+stage+' did not complete its original native window')
        key,end = min(completed)
        wanted = {(key[0],i) for i in range(key[1]-required+1,key[1]+1)}
        require(wanted <= set(rows), 'support '+stage+' primary native window has missing ticks')
        for k in wanted:
            row = rows[k]
            raw = (row.get('independent_raw') or {})
            require(raw.get('passed') is True and stamp_key(raw.get('physics_stamp')) == k,
                    'support primary tick lacks independent same-clock sampling')
            require(row.get('force_support_claimed') is False, 'support cannot claim force contact')
            if stage == 'acquire':
                sample = row.get('sample') or {}; cad = sample.get('CAD') or {}
                require(sample.get('ready') is True and cad.get('ready') is True
                        and cad.get('qualification') == 'dual_native_visible_pad_CAD_near_fit',
                        'support CAD qualification absent')
                gaps = cad.get('gaps') or []
                require(len(gaps)==2 and all(g.get('intersect') is False
                        and 0 < g.get('gap',0) <= contract['cad_pinch']['max_gap_m']
                        and g.get('point_on_actual_inner_face') is True
                        and g.get('separation_along_inward_normal') is True for g in gaps),
                        'support primary native pads failed original CAD predicates')
            selected[(stage,k)] = None
        ends[stage] = key
    for row in raw_rows:
        boundary = row.get('boundary')
        if boundary not in ('base_support_acquire','base_support_open'):continue
        stage = boundary.removeprefix('base_support_'); key = stamp_key(row.get('physics_stamp'))
        pair = (stage,key)
        if pair not in selected:continue
        require(selected[pair] is None, 'support independent native sample duplicated')
        require(row.get('valid') is True and row.get('source') == 'separate_exact_path_PhysX_tensor_views'
                and row.get('phase') == support[stage+'_phase_name'], 'support independent sample identity invalid')
        require(set(row.get('objects',{})) == OBJECTS and set(row.get('robots',{})) == ROBOTS
                and len(row.get('bodies',{})) == 41, 'support independent full scene coverage incomplete')
        require(row.get('orientation_order') == 'xyzw' and row.get('pose_frame') == 'world'
                and row.get('velocity_reference') == 'center_of_mass', 'support raw native frame/order unverified')
        for body in row['bodies'].values():
            vector(body.get('transform'),7);vector(body.get('velocity'),6)
        event = events[stage][key]
        require(row.get('physics_stamp') == event.get('physics_stamp'), 'support clocks differ beyond index')
        sdk = (event.get('sample') or {}).get('SDK') if stage=='acquire' else event.get('actual_final_SDK')
        require(isinstance(sdk,dict), 'support actual final SDK receipt missing')
        q = vector(sdk.get('arm_q'),6)
        published = sdk.get('receipt') or {}; pubstamp = stamp_key(published.get('physics_stamp'))
        require(pubstamp[0]==key[0] and key[1]-pubstamp[1] in (0,1)
                and type(published.get('expected_sdk_batch_sequence')) is int,
                'support actual SDK ownership clock/sequence absent')
        for robot in row['robots'].values():
            names = robot.get('joint_names') or []
            require(len(names)==12 and len(set(names))==12 and set(ARM)<=set(names), 'support full12DOF native state missing')
            vector(robot.get('positions'),12);vector(robot.get('velocities'),12);vector(robot.get('position_targets'),12)
        robot = row['robots'][support['robot']]; names=robot['joint_names']
        require(max(abs(robot['position_targets'][names.index(n)]-q[i]) for i,n in enumerate(ARM)) <= 2e-5,
                'support independent backend arm targets differ from owned final SDK drive')
        row_spec = support['cad_row']
        opening = sdk.get('gripper_openness')
        require(isinstance(opening,(int,float)) and 0 <= opening <= 1, 'support actual SDK aperture invalid')
        driver_target = row_spec['driver_closed_rad'] + opening*(row_spec['driver_open_rad']-row_spec['driver_closed_rad'])
        require('finger_joint' in names and abs(robot['position_targets'][names.index('finger_joint')]-driver_target) <= 2e-5,
                'support independent backend driver target differs from owned SDK aperture')
        if stage=='open':
            require(sdk.get('gripper_openness')==1. and published.get('gripper_openness')==1., 'support release SDK aperture is not fully open')
            require(max(abs(v) for n,v in zip(names,robot['positions']) if n not in ARM)
                    <= contract['gripper_open_joint_tolerance_rad'], 'support native gripper is not actually open')
        selected[pair]=row
    require(all(row is not None for row in selected.values()), 'support independent raw has missing qualification ticks')
    for stage in events:
        rows=[r for (st,_),r in selected.items() if st==stage]
        require(len({r.get('body_view_id') for r in rows})==1 and rows[0].get('body_view_id') is not None,
                'support separate native body-view identity changed')
        ordered = sorted(rows,key=lambda r:stamp_key(r['physics_stamp']))
        for previous,current in zip(ordered,ordered[1:]):
            a,b=previous['physics_stamp'],current['physics_stamp']
            require(math.isclose(a['dt'],b['dt'],rel_tol=1e-9,abs_tol=1e-12)
                    and math.isclose(b['time']-a['time'],b['dt'],rel_tol=1e-6,abs_tol=max(1e-10,b['dt']*1e-6)),
                    'support native window is not consecutive in physical time')
    all_rows=list(selected.values())
    require(len({r['body_view_id'] for r in all_rows})==1
            and all(set(r['bodies'])==set(all_rows[0]['bodies']) for r in all_rows),
            'support native body/view scope changed between acquisition and release')
    require(ends['acquire'][0] == ends['open'][0] and ends['acquire'] < ends['open'],
            'support release does not follow acquisition in the same native epoch')
    sdk_execution_join = verify_support_sdk_windows(support, events, selected, boundary_rows)
    return dict(passed=True, sdk_execution_join=sdk_execution_join, acquisition_end=list(ends['acquire']), release_end=list(ends['open']),
                ticks_per_window=required, full_bodies=41, objects=9, robots=2,
                continuous_primary_scope='strict CAD native check each production hold batch; usual independent raw stride between acquisition and release',
                force_support_claimed=False)


def _proxy_multiply(a,b):
    return [[sum(a[i][k]*b[k][j] for k in range(4)) for j in range(4)] for i in range(4)]

def _proxy_inverse(a):
    a=rigid_matrix(a)
    return [[a[j][i] for j in range(3)]+[-sum(a[k][i]*a[k][3] for k in range(3))]
            for i in range(3)]+[[0.,0.,0.,1.]]

class StoolProxyGeometryReview:
    """Separate observed capsule candidates using complete scene vertex bounds.

    Original events/distances/totals remain untouched. Runtime matrices join
    independent raw. Original calibrated waypoint matrices are independently
    reconstructed from their full joint graph. A positive separating plane
    proves separation of all visible/authored endpoint meshes and the board;
    it is not native cooked/SDF/contact-force equivalence.
    """
    supported={
        'franka_right/wrist_3_link->Gripper/Robotiq_2F_85/base_link',
        'franka_left/wrist_3_link->Gripper/Robotiq_2F_85/base_link',
        'franka_left/wrist_1_link->wrist_2_link',
        'franka_left/wrist_2_link->wrist_3_link',
    }
    def __init__(self,scene):
        require((scene.get('task_contract')or{}).get('adapter')=='stool_circular_ur5e_v1',
                'proxy review is outside the explicit Stool adapter')
        self.scene=scene;self.robots=scene['robots'];self.robot=self.robots['franka_right']
        require(set(self.robots)==ROBOTS,'proxy review lacks both original robot identities')
        links=('wrist_1_link','wrist_2_link','wrist_3_link','Gripper/Robotiq_2F_85/base_link')
        self.all_endpoints=tuple(self.robots[n]['root_path']+'/'+link for n in sorted(ROBOTS) for link in links)
        root=self.robot['root_path'];self.endpoints=(root+'/wrist_3_link',root+'/Gripper/Robotiq_2F_85/base_link')
        boards={m['body']for m in scene['visible_meshes']if m.get('object')=='optical_board'}
        require(len(boards)==1,'proxy review board identity is ambiguous');self.board=next(iter(boards))
        self.rest={name:matrix4(value)for name,value in scene['body_rest'].items()}
        for m in scene['visible_meshes']:self.rest.setdefault(m['body'],matrix4(m['body_rest']))
        self.points={}
        for body in set(self.all_endpoints)|{self.board}:
            visible=[m for m in scene['visible_meshes']if m['body']==body and m.get('rendered')]
            colliders=[m for m in scene['colliders']if m['body']==body]
            require(visible and colliders,'proxy endpoint lacks visible/enabled authored collider coverage')
            meshes=[m for m in scene['visible_meshes']if m['body']==body]+colliders
            self.points[body]=[vector(p,3)for m in meshes for p in m['points']]
            require(self.points[body],'empty proxy endpoint vertex domain')
        self.entries={}
        for name,robot in self.robots.items():
            names=robot['joint_names'];root=robot['root_path'];entries=[]
            require(len(names)==len(set(names))==12,'proxy full articulation names are incomplete')
            for j in scene['joints']:
                if j['robot']!=name or not j['enabled']:continue
                if j['path']==root+'/root_joint':
                    require(j['type']=='PhysicsFixedJoint'and j['parent']==[]and j['child']==[root+'/base_link']
                            and root+'/base_link'in self.rest,'sealed articulation world boundary differs')
                    continue
                require(len(j['parent'])==len(j['child'])==1,'ambiguous proxy joint endpoints')
                parent,child=j['parent'][0],j['child'][0]
                require(parent in self.rest and child in self.rest,'missing proxy native rest body')
                require(j['type']in('PhysicsFixedJoint','PhysicsRevoluteJoint'),'unsupported proxy joint type')
                index=names.index(j['path'].rsplit('/',1)[-1])if j['type']=='PhysicsRevoluteJoint'else None
                anchor=transform_matrix(j['pos0']+j['rot0'])
                entries.append((parent,child,index,j.get('axis'),anchor,_proxy_inverse(anchor),
                                _proxy_multiply(_proxy_inverse(self.rest[parent]),self.rest[child])))
            self.entries[name]=entries
        self.fk_cache={};self.bounds_cache={}

    def fk(self,q,robot='franka_right'):
        q=tuple(vector(q,12));key=robot,q
        if key in self.fk_cache:return self.fk_cache[key]
        result=dict(self.rest);entries=self.entries[robot]
        initial=vector(self.robots[robot]['joint_positions'],12)
        done=set(self.rest)-{e[1]for e in entries};pending=list(entries)
        while pending:
            progress=False
            for e in pending[:]:
                parent,child,index,axis,anchor,inverse,relative=e
                if parent not in done:continue
                rotation=[[float(i==j)for j in range(4)]for i in range(4)]
                if index is not None:
                    require(axis in('X','Y','Z'),'unsupported proxy joint axis')
                    theta=q[index]-initial[index];i='XYZ'.index(axis);j=(i+1)%3;k=(i+2)%3
                    rotation[j][j]=rotation[k][k]=math.cos(theta)
                    rotation[j][k]=-math.sin(theta);rotation[k][j]=math.sin(theta)
                result[child]=_proxy_multiply(_proxy_multiply(_proxy_multiply(
                    _proxy_multiply(result[parent],anchor),rotation),inverse),relative)
                done.add(child);pending.remove(e);progress=True
            require(progress,'proxy joint graph is unresolved')
        self.fk_cache[key]=result;return result

    def bounds(self,body,pose,axis):
        pose=rigid_matrix(pose);key=body,axis,tuple(pose[axis])
        if key not in self.bounds_cache:
            values=[sum(pose[axis][j]*p[j]for j in range(3))+pose[axis][3]for p in self.points[body]]
            self.bounds_cache[key]=min(values),max(values)
        return self.bounds_cache[key]

    def separation(self,body,pose,board_pose):
        for axis in (2,0,1):
            low,high=self.bounds(body,pose,axis);blow,bhigh=self.bounds(self.board,board_pose,axis)
            gap=max(low-bhigh,blow-high)
            if gap>64*2**-52*max(1.,abs(low),abs(high),abs(blow),abs(bhigh)):
                return dict(axis=axis,gap_m=gap)
        raise ValueError('endpoint complete visible/authored vertex bounds lack a positive separating plane')

    def verify(self,section,report,raw_by_stamp):
        events=report.get('events')
        require(isinstance(events,list)and len(events)==report['violation_total']>0,
                'original proxy events are capped or disagree with the original total')
        require(report.get('events_dropped',0)==0,'original proxy events were dropped')
        gaps=[];pairs={}
        for event in events:
            a=event.get('canonical_entity_a',event.get('entity_a'));b=event.get('canonical_entity_b',event.get('entity_b'))
            require(a in self.supported and b=='static:optical_board:1'and event.get('classification')=='collision'
                    and event.get('kind')=='agent_env'and event.get('classification_reason')=='capsule_surface_overlap'
                    and math.isfinite(event['distance'])and event['distance']<0,'unresolved original proxy pair/type')
            robot,edge=a.split('/',1);root=self.robots[robot]['root_path']
            endpoints=tuple(root+'/'+link for link in edge.split('->'))
            witness=event.get('capsule_proxy_witness')or{}
            require(witness.get('schema')=='stool_capsule_proxy_witness_v1'and witness.get('task_step')==event['step'],
                    'original proxy witness is absent or bound to another step')
            key=stamp_key(witness.get('physics_stamp'));native=raw_by_stamp.get(key)
            require(native is not None and all(witness['physics_stamp'][k]==native['physics_stamp'][k]
                    for k in('epoch','index','time','dt')),'proxy witness lacks same-clock independent raw')
            poses=witness.get('body_world_matrices')or{}
            require(set(poses)==set(endpoints)|{self.board},'proxy witness body identities are incomplete')
            require(matrix_difference(poses[self.board],self.rest[self.board])<=1e-10,'static board differs from sealed rest')
            if section=='runtime_constraint_monitor':
                require(witness.get('domain')=='native_current','runtime proxy pose is not native')
                expected=native['body_world_matrices']
            else:
                require(section=='stage_trajectory_precheck'and witness.get('domain')=='command_waypoint',
                        'unknown proxy witness domain')
                prediction=witness.get('prediction')or{}
                require(prediction.get('physics_stamp')==witness['physics_stamp']and prediction.get('robot')==robot,
                        'stale or wrong-robot original graph calibration')
                current=vector(prediction.get('current_q'),12);target=vector(prediction.get('target_q'),12)
                require(current==native['q_by_robot'][robot],'graph current full articulation differs from independent raw')
                fraction=prediction.get('fraction')
                require(report['num_waypoints']>=2 and type(event.get('waypoint_index'))is int
                        and 0<=event['waypoint_index']<report['num_waypoints']
                        and fraction==event['waypoint_index']/(report['num_waypoints']-1),'original waypoint fraction differs')
                base=self.fk(current,robot);sample=self.fk([q+(t-q)*fraction for q,t in zip(current,target)],robot)
                measured=prediction.get('native_body_world_matrices')or{}
                require(set(measured)==set(endpoints),'native graph calibration body identities are incomplete')
                for body in endpoints:
                    require(matrix_difference(measured[body],native['body_world_matrices'][body])<=1e-10,
                            'graph calibration differs from same-clock native body')
                expected={body:_proxy_multiply(_proxy_multiply(measured[body],_proxy_inverse(base[body])),sample[body])
                          for body in endpoints}
            for body in endpoints:
                require(matrix_difference(poses[body],expected[body])<=1e-10,
                        'proxy pose differs from native or independently reconstructed original graph')
                gaps.append(self.separation(body,poses[body],poses[self.board])['gap_m'])
            pairs[a]=pairs.get(a,0)+1
        return dict(schema='stool_capsule_proxy_resolution_v1',original_violation_total=report['violation_total'],
                    all_original_events_retained=True,resolved_events=len(events),original_pairs=pairs,
                    minimum_verified_separating_plane_gap_m=min(gaps),native_raw_join=True,
                    waypoint_graph_recomputed=section=='stage_trajectory_precheck',
                    original_capsule_classifications_and_distances_preserved=True,
                    thresholds_changed=False,native_cooked_or_contact_force_claimed=False)

def collect_stool_proxy_raw(audit,sections,scene,reviewer):
    wanted=set()
    for name in('runtime_constraint_monitor','stage_trajectory_precheck'):
        report=sections.get(name)or{}
        if not report.get('violation_total'):continue
        events=report.get('events')or[]
        require(len(events)==report['violation_total']and report.get('events_dropped',0)==0,
                'original proxy event stream is incomplete')
        for e in events:
            w=e.get('capsule_proxy_witness')or{}
            require(w.get('schema')=='stool_capsule_proxy_witness_v1','original violation lacks a new geometry witness')
            wanted.add(stamp_key(w.get('physics_stamp')))
    result={}
    for row in audit.lines('independent_native_trace.jsonl'):
        stamp=row.get('physics_stamp')
        if not stamp or stamp.get('valid')is not True or stamp_key(stamp)not in wanted:continue
        require(row.get('valid')is True,'proxy raw is invalid');q={}
        for name,robot in reviewer.robots.items():
            r=row['robots'][name];names=robot['joint_names']
            require(len(r['joint_names'])==12 and set(r['joint_names'])==set(names),'proxy independent joint names differ')
            q[name]=[r['positions'][r['joint_names'].index(n)]for n in names]
        value=dict(physics_stamp=stamp,q_by_robot=q,body_world_matrices={
            body:transform_matrix(row['bodies'][body]['transform'])for body in reviewer.all_endpoints})
        key=stamp_key(stamp)
        if key in result:require(result[key]==value,'independent proxy body/q values change within one native clock')
        result[key]=value
    require(set(result)==wanted,'proxy independent raw clocks are missing')
    return result


class Audit:
    def __init__(self, run):
        self.run = run.resolve()
        self.inputs = {}
        self.checks = {}
        self.read_errors = []
        self.metric_sources = {}

    def path(self, name):
        direct = self.run / name
        paths = [direct] if direct.is_file() else sorted(self.run.rglob(name))
        if len(paths) != 1:
            raise FileNotFoundError('expected one ' + name + '; found ' + str(len(paths)))
        self.inputs[str(paths[0].relative_to(self.run))] = digest(paths[0])
        return paths[0]

    def json(self, name):
        return json.loads(self.path(name).read_text())

    def lines(self, name):
        path = self.path(name)
        with path.open() as stream:
            for number, line in enumerate(stream, 1):
                if line.strip():
                    try:
                        yield json.loads(line)
                    except Exception as exc:
                        raise ValueError(str(path) + ':' + str(number) + ': ' + str(exc))

    def check(self, name, function):
        try:
            detail = function()
            self.checks[name] = {'passed': True, 'detail': detail}
            return detail
        except FileNotFoundError as exc:
            self.checks[name] = {'passed': None, 'missing': str(exc)}
        except Exception as exc:
            self.checks[name] = {'passed': False, 'error': type(exc).__name__ + ': ' + str(exc)}
        return None


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def read_metrics(audit):
    candidates = []
    for name in ('collect_results.json', 'episode_0000.json'):
        try:
            value = audit.json(name)
        except FileNotFoundError:
            audit.metric_sources[name] = {'present': False, 'usable': None, 'reason': 'report_absent'}
            continue
        if isinstance(value, list):
            if not value:
                audit.metric_sources[name] = {'present': True, 'usable': False,
                                              'episode_count': 0, 'reason': 'empty_primary_results_array'}
                continue
            require(len(value) == 1, 'acceptance audit requires exactly one episode report')
            value = value[0]
        if isinstance(value, dict) and 'metrics' in value:
            value = value['metrics']
        require(isinstance(value, dict), 'metrics report is not an object')
        audit.metric_sources[name] = {'present': True, 'usable': True}
        candidates.append((name, value))
    if not candidates:
        raise FileNotFoundError('collect_results.json and episode_0000.json metrics are absent')
    # The dedicated final results report is authoritative. The episode report
    # remains separately SHA-bound and is never overwritten or repaired here.
    audit.metric_sources[candidates[0][0]]['selected_original_outcome'] = True
    return candidates[0][1]


def run_audit(run, source_binding=None, media_report=None):
    audit = Audit(run)
    metrics = audit.check('original_report_readable', lambda: read_metrics(audit)) or {}
    if audit.checks['original_report_readable'].get('passed') is True:
        audit.checks['original_report_readable']['detail'] = {
            'original_report_preserved': True,
            'keys': sorted(metrics), 'phase_history_entries': len(metrics.get('phase_history', []))}

    def primary_report_complete():
        if audit.metric_sources.get('collect_results.json', {}).get('usable') is not True:
            raise FileNotFoundError('primary collect_results episode report absent/empty; fallback metrics remain preserved')
        return {'primary_episode_report_complete': True}
    audit.check('primary_collect_results_complete', primary_report_complete)
    qualification = metrics.get('fabrica_assisted_qualification') or {}
    final_qualification = metrics.get('assisted_final_qualification') or {}
    certificate = final_qualification.get('certificate') or {}
    contract_holder = {}

    def config_check():
        snapshot = audit.json('task_config_snapshot.json')
        require(isinstance(snapshot, list) and len(snapshot) == 1, 'worker snapshot is not one episode')
        cfg = snapshot[0]
        contract = (cfg.get('benchmark_metadata') or {}).get('fabrica_assisted_contract') or {}
        require(contract.get('adapter') == 'stool_circular_ur5e_v1', 'explicit stool runtime contract absent')
        require(set(contract.get('objects', [])) == OBJECTS and len(contract['objects']) == 9,
                'runtime contract does not identify exactly nine stool objects')
        require(cfg.get('success_criteria') == contract.get('original_success_criteria'),
                'original success criteria changed after contract compilation')
        require(all(p.get('fabrica_assisted_contract') == contract for p in cfg.get('phase_specs', [])),
                'phase and benchmark contracts differ')
        require(contract.get('final_stable_physics_steps') == 72, 'frozen stool native window differs from 72')
        contract_holder.update(contract=contract, cfg=cfg)
        return {'recipe': cfg.get('recipe'), 'seed': cfg.get('seed'), 'layout_seed': cfg.get('layout_seed'),
                'phases': len(cfg['phase_specs']), 'original_criteria': cfg['success_criteria']}
    audit.check('worker_contract', config_check)
    contract = contract_holder.get('contract', {})
    if contract.get('base_support'):
        audit.check('base_support_independent_native_windows', lambda: verify_base_support_windows(
            contract, audit.lines('assisted_trace.jsonl'), audit.lines('independent_native_trace.jsonl'),
            audit.lines('physics_boundary_trace.jsonl')))

    def configuration_binding():
        launch = audit.json('launch_gate.json')
        worker = audit.json('worker_build_preflight.json')
        runtime = audit.json('runtime_initialization_preflight.json')
        binding = audit.json('runtime_configuration_binding.json')
        launch_sig = launch.get('configuration_signature')
        runtime_sig = runtime.get('configuration', {}).get('configuration_signature')
        require(launch_sig and launch_sig == worker.get('report', {}).get('configuration_signature'),
                'launch/worker prebuild configuration signatures differ')
        require(runtime_sig and binding.get('passed') is True
                and runtime_sig == binding.get('expected_configuration_signature')
                == binding.get('actual_configuration_signature'),
                'actual framework/scene runtime configuration does not match the explicit expected mapping')
        require(binding.get('actual_roots') == binding.get('expected_roots')
                and binding.get('env_id') == 0 and binding.get('env_offset') == [0., 0., 0.]
                and binding.get('task_count') == 1, 'runtime roots/environment/task membership differs from review')
        require(worker.get('passed') is True and runtime.get('passed') is True, 'worker/runtime preflight did not pass')
        return {'configuration_signature': launch_sig, 'runtime_configuration_signature': runtime_sig,
                'framework_mapping_passed': True}
    audit.check('configuration_source_binding', configuration_binding)

    def provenance():
        if source_binding is None:
            raise FileNotFoundError('explicit --source-binding receipt was not supplied')
        value = json.loads(source_binding.read_text())
        require(value.get('passed') is True and Path(value.get('run_directory', '')).resolve() == audit.run,
                'source receipt does not explicitly pass and bind this run directory')
        required = ('source_manifest_sha256', 'tool_manifest_sha256', 'asset_manifest_sha256',
                    'configuration_signature')
        if not value.get('asset_manifest_sha256'):
            raise FileNotFoundError('composed asset freeze absent; initialization may have failed before stage export')
        require(all(isinstance(value.get(k), str) and value[k] for k in required),
                'source/tool/asset/configuration identity is incomplete in source receipt')
        require(value['configuration_signature'] == audit.checks['configuration_source_binding'].get(
            'detail', {}).get('configuration_signature'), 'source receipt config differs from worker')
        require(value.get('runtime_configuration_signature') == audit.checks['configuration_source_binding'].get(
            'detail', {}).get('runtime_configuration_signature'), 'source receipt runtime mapping differs from native task')
        launch_binding = audit.path('source_binding.json')
        require(value.get('launch_source_binding_sha256') == digest(launch_binding),
                'runtime source receipt does not bind the original launch freeze')
        counts = {}
        for domain, manifest_key, hash_key, archive_name, archive_hash in (
            ('source', 'source_manifest', 'source_manifest_sha256', 'source_snapshot.tar.gz', 'source_archive_sha256'),
            ('tools', 'tools_manifest', 'tool_manifest_sha256', 'tools_snapshot.tar.gz', 'tools_archive_sha256')):
            manifest = value.get(manifest_key)
            require(isinstance(manifest, dict) and manifest, domain + ' manifest missing')
            require(hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest() == value[hash_key],
                    domain + ' manifest canonical hash differs from freeze')
            archive_path = audit.path(archive_name)
            require(digest(archive_path) == value.get(archive_hash), domain + ' frozen archive SHA differs')
            with tarfile.open(archive_path, 'r:gz') as archive:
                members = archive.getmembers()
                require({m.name for m in members} == set(manifest) and len(members) == len(manifest),
                        domain + ' snapshot membership differs from manifest')
                for member in members:
                    require(member.isfile(), domain + ' snapshot contains non-file entry')
                    stream = archive.extractfile(member)
                    h = hashlib.sha256()
                    for block in iter(lambda: stream.read(1024*1024), b''):
                        h.update(block)
                    require(h.hexdigest() == manifest[member.name], domain + ' frozen member SHA differs: ' + member.name)
            counts[domain] = len(manifest)
        assets = value.get('asset_manifest')
        require(isinstance(assets, list) and assets, 'composed asset manifest absent')
        require(hashlib.sha256(json.dumps(assets, sort_keys=True).encode()).hexdigest() == value['asset_manifest_sha256'],
                'composed asset manifest hash differs')
        unsealed = []
        for asset in assets:
            if not asset.get('sha256'):
                unsealed.append(asset.get('identifier'))
                continue
            path = Path(asset['resolved_path'])
            if not path.is_file():
                raise FileNotFoundError('named composed layer unavailable for SHA verification: ' + str(path))
            require(digest(path) == asset['sha256'], 'named composed layer changed after run freeze: ' + str(path))
        if unsealed:
            raise FileNotFoundError('unhashed anonymous/nonlocal composed layers: ' + repr(unsealed))
        return {'path': str(source_binding), 'sha256': digest(source_binding),
                'identities': {k: value[k] for k in required},
                'frozen_file_counts': counts, 'verified_named_asset_layers': len(assets),
                'scope': 'launch/runtime binding, canonical manifests, every archived source/tool member and named composed asset SHA'}
    audit.check('source_tools_assets_launch_binding', provenance)

    def runtime_terminal():
        require(qualification.get('adapter') == 'stool_circular_ur5e_v1', 'terminal stool qualification missing')
        require(qualification.get('phase_sequence_completed') is True, 'full phase sequence did not complete')
        require(qualification.get('final_native_qualified') is True, 'runtime final native gate did not pass')
        require(final_qualification.get('current_native_recheck', {}).get('ready') is True,
                'terminal runtime native recheck absent or rejected')
        terminal = qualification.get('terminal_evidence') or {}
        require(terminal.get('same_clock') is True and terminal.get('wrapper_sample_valid') is True,
                'terminal exact-wrapper evidence missing or stale')
        require(terminal.get('independent_raw', {}).get('valid') is True,
                'terminal independent raw sample missing or invalid')
        require(stamp_key(terminal['physics_stamp']) == stamp_key(certificate.get('physics_stamp')),
                'terminal sample and native certificate differ in clock')
        require(set(certificate.get('native_poses', {})) == OBJECTS,
                'native certificate does not include all nine exact objects')
        require(certificate.get('required_stable_physics_steps') == 72
                and certificate.get('stable_physics_steps', 0) >= 72, 'runtime 72-tick certificate missing')
        require(set(qualification.get('retained_world_supports', {})) == OBJECTS,
                'retained installation supports are not reported for all nine objects')
        return {'physics_stamp': certificate['physics_stamp'], 'supports_retained': qualification['retained_world_supports']}
    audit.check('runtime_terminal_qualification', runtime_terminal)

    selected_raw = {}
    selected_wrappers = {}
    end_key = None
    try:
        end_key = stamp_key(certificate.get('physics_stamp'))
    except Exception:
        pass
    window = set(range(end_key[1]-71, end_key[1]+1)) if end_key else set()

    def raw_window():
        require(end_key is not None and contract, 'native certificate/contract missing; no final window can be inferred')
        identity = json.loads(certificate['identity']['configuration'])
        targets = identity['targets']
        criteria = {c['object']: c for c in identity['criteria']}
        require(set(criteria) == OBJECTS and identity['criteria'] == contract['original_success_criteria'],
                'certificate original criteria differ from frozen worker contract')
        observed = {}
        for row in audit.lines('independent_native_trace.jsonl'):
            stamp = row.get('physics_stamp') or {}
            if stamp.get('epoch') != end_key[0] or stamp.get('index') not in window:
                continue
            require(row.get('valid') is True and row.get('source') == 'separate_exact_path_PhysX_tensor_views',
                    'raw final window includes invalid/non-independent samples')
            require(row.get('orientation_order') == 'xyzw' and row.get('pose_frame') == 'world'
                    and row.get('velocity_reference') == 'center_of_mass', 'raw frame/order/reference is unverified')
            require(set(row.get('objects', {})) == OBJECTS and set(row.get('robots', {})) == ROBOTS,
                    'raw final sample omits a stool object or robot')
            index = stamp_key(stamp)[1]
            if index in observed:
                require(observed[index]['objects'] == row['objects'], 'raw object buffers changed within one native tick')
            observed[index] = row
            if row.get('boundary') in ('after_physics', 'after_observation', 'terminal'):
                selected_raw[index] = row
        require(set(selected_raw) == window, 'independent raw has missing final native ticks: ' + str(sorted(window-set(selected_raw))))
        anchors = {}
        paths = {}
        view_id = None
        peak = {'position_error_m': 0., 'orientation_error_rad': 0.,
                'linear_speed_m_s': 0., 'angular_speed_rad_s': 0.}
        for index in sorted(window):
            row = selected_raw[index]
            if view_id is None:
                view_id = row.get('body_view_id')
            require(view_id is not None and row.get('body_view_id') == view_id, 'independent body-view identity changed')
            for name in sorted(OBJECTS):
                body = row['objects'][name]
                transform, velocity = vector(body.get('transform'), 7), vector(body.get('velocity'), 6)
                pose = transform[:3], [transform[6], *transform[3:6]]
                require(body.get('path') and body['path'] in row.get('bodies', {}), 'raw object body path missing')
                if name not in anchors:
                    anchors[name], paths[name] = pose, body['path']
                require(paths[name] == body['path'], 'raw object body identity changed')
                criterion = criteria[name]
                target = targets[criterion['target']]
                dp, dq = distance(pose[0], target['position']), angle(pose[1], target['orientation'])
                require(dp <= criterion['position_tolerance'] and dq <= criterion['orientation_tolerance'],
                        name + ' independent raw pose is outside its original target gate')
                require(distance(pose[0], anchors[name][0]) <= contract['stable_position_drift_m']
                        and angle(pose[1], anchors[name][1]) <= contract['stable_orientation_drift_rad'],
                        name + ' independent raw drift exceeds the native-window contract')
                linear, angular = norm(velocity[:3]), norm(velocity[3:])
                require(linear <= criterion['linear_velocity_threshold'] and angular <= criterion['angular_velocity_threshold'],
                        name + ' independent raw native velocity exceeds original static gate')
                for key, value in zip(peak, (dp, dq, linear, angular)):
                    peak[key] = max(peak[key], value)
            for robot in row['robots'].values():
                names = robot.get('joint_names', [])
                q = vector(robot.get('positions'), len(names))
                vector(robot.get('velocities'), len(names))
                vector(robot.get('position_targets'), len(names))
                require(len(names) == 12 and len(set(names)) == 12 and set(ARM).issubset(names),
                        'raw native UR5e/Robotiq joint membership is incomplete')
                require(max(abs(q[i]) for i, n in enumerate(names) if n not in ARM)
                        <= contract['gripper_open_joint_tolerance_rad'], 'native gripper is not fully open throughout final window')
        return {'ticks': len(window), 'start_index': min(window), 'end_index': max(window),
                'epoch': end_key[0], 'objects': len(OBJECTS), 'body_paths': paths, 'peak': peak,
                'raw_velocity_gate': 'actual native COM velocities; no history override substituted'}
    audit.check('independent_raw_native_window', raw_window)

    def exact_wrapper_window():
        require(selected_raw and set(selected_raw) == window, 'complete independent raw window is unavailable')
        for row in audit.lines('physics_boundary_trace.jsonl'):
            index = row.get('physics_step_index')
            if index in window and row.get('boundary') in ('after_physics', 'after_observation', 'terminal'):
                selected_wrappers[index] = row
        require(set(selected_wrappers) == window, 'exact-wrapper final native ticks are missing')
        max_dp, max_dq = 0., 0.
        for index, row in selected_wrappers.items():
            require(row.get('clock_valid') is True, 'wrapper native clock is invalid')
            raw = selected_raw[index]
            require(abs(row['physics_time']-raw['physics_stamp']['time']) <= 1e-9,
                    'exact-wrapper and raw physical times differ')
            bodies = {b.get('name'): b for b in row.get('bodies', [])}
            require(OBJECTS.issubset(bodies), 'exact-wrapper final sample omits stool objects')
            require(not row.get('task_constraints', {}).get('attachments'), 'an installed object remains robot-attached')
            for name in OBJECTS:
                body = bodies[name]
                require(body.get('valid') is True and body.get('orientation_order') == 'wxyz'
                        and body.get('path') == raw['objects'][name]['path'], 'exact-wrapper body/view/path invalid')
                p = vector(body['positions'][0], 3)
                q = vector(body['orientations'][0], 4)
                transform = raw['objects'][name]['transform']
                dp, dq = distance(p, transform[:3]), angle(q, [transform[6], *transform[3:6]])
                require(dp <= 2e-5 and dq <= 2e-4, 'independent raw/exact-wrapper same-tick pose mismatch')
                max_dp, max_dq = max(max_dp, dp), max(max_dq, dq)
        return {'ticks': len(selected_wrappers), 'max_raw_wrapper_position_difference_m': max_dp,
                'max_raw_wrapper_orientation_difference_rad': max_dq,
                'comparison_tolerances': '20 um / 0.2 mrad float-buffer cross-reader comparison, not assembly gates'}
    audit.check('exact_wrapper_raw_same_clock', exact_wrapper_window)

    def sdk_tracking():
        require(selected_raw and selected_wrappers, 'native raw/wrapper final window missing')
        publications = {}
        for row in audit.lines('assisted_trace.jsonl'):
            if row.get('event') == 'fabrica_final_published_batch':
                key = stamp_key(row.get('physics_stamp') or row.get('native_stamp'))
                if key[0] == end_key[0] and key[1] <= end_key[1]:
                    sequences = row.get('expected_sdk_batch_sequences') or {}
                    require(set(sequences) == ROBOTS and all(type(x) is int for x in sequences.values()),
                            'publication lacks explicit expected SDK sequence identity')
                    identity = tuple((name, sequences[name]) for name in sorted(ROBOTS))
                    require(identity not in publications, 'SDK sequence belongs to duplicate publication events')
                    publications[identity] = row
        require(publications, 'final published dual-arm batches absent')
        peak_tracking, covered = 0., 0
        for index in sorted(window):
            wrapper = selected_wrappers[index]
            raw = selected_raw[index]
            submissions = {name: wrapper.get('robots', {}).get(name, {}).get('sdk_submission') or {}
                           for name in ROBOTS}
            identity = tuple((name, submissions[name].get('batch_sequence')) for name in sorted(ROBOTS))
            publication = publications.get(identity)
            require(publication is not None, 'completed SDK sequence lacks its exact final publication event')
            publication_stamp = publication.get('physics_stamp') or publication.get('native_stamp')
            require(stamp_key(publication_stamp)[1] <= index,
                    'SDK publication is newer than the native execution sample')
            actions = publication.get('actions') or {}
            require(set(actions) == ROBOTS, 'published batch omits an arm')
            for name in ROBOTS:
                action = actions[name]
                request = vector((action.get('arm_joint_controller') or [None])[0], 6)
                require(action.get('gripper_controller') == [1.] and 'arm_ik_controller' not in action,
                        'final published batch does not explicitly open and command native joints')
                actual = raw['robots'][name]
                names = actual['joint_names']
                q, targets = actual['positions'], actual['position_targets']
                indices = [names.index(n) for n in ARM]
                require(max(abs(targets[i]-request[j]) for j, i in enumerate(indices)) <= 2e-5,
                        'published arm target differs from independently read SDK/backend target')
                tracking = max(abs(targets[i]-q[i]) for i in indices)
                require(tracking <= contract['max_tracking_error_rad'], 'actual native arm tracking exceeds frozen guard envelope')
                peak_tracking = max(peak_tracking, tracking)
                sdk = submissions[name]
                require(sdk.get('batch_sequence') is not None and not sdk.get('skipped')
                        and {'arm_joint_controller', 'gripper_controller'}.issubset(sdk.get('controllers', [])),
                        'SDK completed submission evidence is incomplete or skipped')
                controls = dict(zip(sdk['controllers'], sdk.get('actions', [])))
                control = controls.get('arm_joint_controller') or {}
                sdk_q, sdk_indices = control.get('joint_positions'), control.get('joint_indices')
                require(isinstance(sdk_q, list), 'SDK arm positions are absent')
                if sdk_indices is None:
                    sdk_indices = list(range(len(sdk_q)))
                submitted = dict(zip(sdk_indices, sdk_q))
                require(all(i in submitted and submitted[i] is not None and abs(submitted[i]-request[j]) <= 2e-5
                            for j, i in enumerate(indices)), 'SDK accepted arm target differs from final published batch')
            covered += 1
        return {'ticks_with_published_sdk_backend_and_actual_join': covered,
                'peak_actual_arm_tracking_rad': peak_tracking,
                'held_command_semantics': 'exact SDK batch sequence binds published/accepted/backend; actual buffers read each required tick'}
    audit.check('published_sdk_backend_actual_execution', sdk_tracking)

    def cameras():
        require(end_key is not None, 'native terminal certificate clock missing')
        cfg = contract_holder.get('cfg', {})
        expected_specs = [s for s in cfg.get('camera_metadata', []) if isinstance(s, dict)]
        expected_names = {s['name'] for s in expected_specs}
        name_to_video = {s['name']: production_video_key(s) for s in expected_specs}
        require(len(expected_specs) == 3 and len(expected_names) == 3
                and len(set(name_to_video.values())) == 3 and set(name_to_video.values()) == CAMERAS,
                'frozen camera metadata does not map to three unique production video keys')
        proof = audit.json('terminal_capture_diagnostics.json')
        require(proof.get('passed') is True and not proof.get('errors'), 'terminal paired-capture diagnostics rejected')
        before, after = proof.get('before'), proof.get('after')
        require(isinstance(before, dict) and before == after
                and proof.get('native_state_exactly_unchanged') is True,
                'full native state/counters/history changed during terminal render-only capture')
        require(isinstance(before.get('counters'), dict)
                and set(before['counters']) >= {'step_counter', 'phase_index', 'phase_entry_step', 'steps',
                                               'success', 'failed', 'work'}
                and isinstance(before.get('phase_transition_history'), list),
                'paired terminal capture omits original task counters or transition history')
        terminal_stamp = certificate['physics_stamp']
        require(before.get('physics_stamp') == terminal_stamp and stamp_key(terminal_stamp) == end_key,
                'paired terminal capture and current native certificate do not share the exact native stamp')
        paths = before.get('body_paths')
        require(isinstance(paths, list) and len(paths) == len(set(paths)) and paths
                and set(before.get('transforms_xyzw', {})) == set(paths)
                and set(before.get('velocities', {})) == set(paths)
                and set(before.get('object_paths', {})) == OBJECTS
                and set(before.get('robots', {})) == ROBOTS,
                'paired terminal native snapshot is incomplete')
        media_capture = audit.json('terminal_media_capture.json')
        raw_summary = media_capture.get('independent_raw') or {}
        require(media_capture.get('physics_stamp') == terminal_stamp and raw_summary.get('valid') is True
                and raw_summary.get('physics_stamp') == terminal_stamp
                and type(raw_summary.get('sequence')) is int
                and media_capture.get('paired_capture') == 'terminal_capture_diagnostics.json'
                and media_capture.get('render_only_steps') == 8,
                'terminal render capture lacks a same-stamp independent raw summary')
        terminal_rows = [r for r in audit.lines('independent_native_trace.jsonl')
                         if r.get('sequence') == raw_summary.get('sequence')
                         and r.get('boundary') == 'terminal']
        require(len(terminal_rows) == 1, 'terminal raw summary does not identify one original terminal tensor sample')
        raw = terminal_rows[0]
        require(raw.get('valid') is True and raw.get('physics_stamp') == terminal_stamp
                and raw.get('source') == 'separate_exact_path_PhysX_tensor_views'
                and set(raw.get('bodies', {})) == set(paths),
                'terminal paired native/raw body membership or clock differs')
        for path in paths:
            captured = vector(before['transforms_xyzw'][path], 7)
            observed = vector(raw['bodies'][path].get('transform'), 7)
            require(distance(captured[:3], observed[:3]) <= 2e-5
                    and angle([captured[6], *captured[3:6]], [observed[6], *observed[3:6]]) <= 2e-4,
                    'terminal read-only native snapshot differs from independent raw: ' + path)
            require(max(abs(x-y) for x, y in zip(vector(before['velocities'][path], 6),
                    vector(raw['bodies'][path].get('velocity'), 6))) <= 1e-7,
                    'terminal read-only native/raw velocity buffers differ: ' + path)
        for name, path in before['object_paths'].items():
            require(raw.get('objects', {}).get(name, {}).get('path') == path,
                    'terminal object identity differs between paired capture and independent raw')
        for name in ROBOTS:
            captured, observed = before['robots'][name], raw.get('robots', {}).get(name, {})
            require(captured.get('names') == observed.get('joint_names'), 'terminal native/raw DOF identities differ')
            for source, destination in (('positions', 'positions'), ('velocities', 'velocities'), ('targets', 'position_targets')):
                rows = captured.get(source)
                require(isinstance(rows, list) and len(rows) == 1
                        and max(abs(x-y) for x, y in zip(vector(rows[0], 12),
                            vector(observed.get(destination), 12))) <= 1e-7,
                        'terminal native/raw articulation buffers differ: ' + name + '/' + source)
        alignment = proof.get('stage_native_alignment') or {}
        require(alignment.get('passed') is True and alignment.get('native_unchanged') is True,
                'terminal renderer/USD body publication lacks native-invariance proof')
        dual_diagnostics = {}
        for stage in ('after_publication', 'after_render'):
            comparison = alignment.get(stage) or {}
            rows = comparison.get('rows')
            require(comparison.get('passed') is True and set(comparison.get('body_paths', [])) == set(paths)
                    and comparison.get('bodies') == len(paths) and isinstance(rows, list)
                    and len(rows) == len(paths) and {r.get('body') for r in rows} == set(paths),
                    'terminal stage/native matrix comparison misses body coverage: ' + stage)
            require(comparison.get('schema_version') == 'native_usd_dual_v1',
                    'terminal numerical comparison lacks the explicit native/SDK dual domain')
            checked = [native_usd_dual_row(row, before['transforms_xyzw'][row['body']]) for row in rows]
            physical_passed = all(r['normalized_native_alignment_passed'] for r in checked)
            require(comparison.get('normalized_native_alignment_passed') is physical_passed,
                    'original normalized-native summary pass/fail was not preserved')
            dual_diagnostics[stage] = dict(normalized_native_alignment_passed=physical_passed,
                publication_alignment_passed=True, rows=checked,
                scope='same 32eps bound in actual SDK publication domain; original normalized-native residuals preserved')
        clocks = proof.get('clock_validation') or {}
        require(clocks.get('passed') is True and not clocks.get('errors')
                and clocks.get('all_three_shared_each_pass') is True
                and clocks.get('nondecreasing_shared_render_stamps') is True
                and clocks.get('final_render_stamp_newer_than_before') is True
                and clocks.get('native_stamp_preserved_each_pass') is True,
                'paired capture does not prove fresh shared rendering over frozen physics')

        def reference_map(entries):
            require(isinstance(entries, list) and len(entries) == 3
                    and {r.get('camera') for r in entries} == expected_names,
                    'paired render stamp collection omits or duplicates a camera')
            return {r['camera']: reference_fraction(r.get('reference')) for r in entries}

        initial_references = reference_map(clocks.get('before_render'))
        require(len(set(initial_references.values())) == 1, 'initial render-product clocks are not shared')
        previous = initial_references
        passes = clocks.get('render_passes')
        require(isinstance(passes, list) and len(passes) == 8, 'eight render-only pass records are required')
        indices = [entry.get('pass_index') for entry in passes]
        require(all(type(i) is int for i in indices) and indices == list(range(indices[0], indices[0]+8)),
                'render-only pass indices are missing, repeated or reordered')
        for entry in passes:
            require(entry.get('physics_stamp') == terminal_stamp
                    and entry.get('native_state_exactly_unchanged') is True,
                    'native state or clock advanced during paired render-only passes')
            current = reference_map(entry.get('cameras'))
            require(len(set(current.values())) == 1 and all(current[name] >= previous[name] for name in expected_names),
                    'render products move backwards or are not shared at one capture pass')
            previous = current
        final_references = reference_map(clocks.get('after_render'))
        require(final_references == previous, 'final image render stamps differ from the last paired render pass')
        require(all(final_references[name] > initial_references[name] for name in expected_names),
                'final render products are stale relative to the paired capture beginning')
        proof_images = proof.get('images')
        require(isinstance(proof_images, list) and len(proof_images) == 3
                and {r.get('camera') for r in proof_images} == expected_names,
                'terminal capture proof does not contain all three camera images')
        images_by_key = {}
        rp_paths, sensor_paths = set(), set()
        for image in proof_images:
            name = image['camera']
            require(production_video_key(image) == name_to_video[name] and image.get('physics_stamp') == terminal_stamp
                    and reference_fraction(image.get('raw_reference_time'), raw=True) == final_references[name],
                    'terminal image identity/native stamp/render stamp differs from paired capture')
            identity = image.get('camera_identity') or {}
            require(identity.get('passed') is True and identity.get('sensor_path')
                    and identity.get('sensor_path') == identity.get('backend_path')
                    and identity.get('render_product_camera_targets') == [identity['sensor_path']]
                    and identity.get('render_product_path'), 'terminal RGB/sensor/backend camera identity differs')
            rp_paths.add(identity['render_product_path']);sensor_paths.add(identity['sensor_path'])
            world, view = matrix4(identity.get('usd_camera_world_matrix')), matrix4(identity.get('renderer_world_to_camera_matrix'))
            product = [[sum(view[i][k]*world[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
            require(matrix_difference(product, [[float(i==j) for j in range(4)] for i in range(4)]) <= 1e-5,
                    'terminal render-product camera matrix does not match its USD Camera')
            path = audit.run / image.get('path', '')
            require(path.resolve().is_relative_to(audit.run) and path.is_file()
                    and digest(path) == image.get('sha256'), 'terminal proof image is absent or changed')
            images_by_key[name_to_video[name]] = image
        require(len(rp_paths) == 3 and len(sensor_paths) == 3, 'terminal camera/render-product identities are duplicated')
        rows = []
        for row in audit.lines('video_frame_clock.jsonl'):
            stamp = row.get('physics_stamp') or {}
            if stamp.get('epoch') == end_key[0] and stamp.get('index') == end_key[1]:
                rows.append(row)
        selected = {}
        for row in rows:
            key = row.get('camera')
            if key not in images_by_key:
                continue
            image = images_by_key[key]
            try:
                matching = reference_fraction(row.get('render_reference_time')) == final_references[image['camera']]
            except ValueError:
                matching = False
            if matching:
                require(key not in selected, 'terminal video proof matches duplicate camera/frame rows')
                selected[key] = row
        require(set(selected) == CAMERAS, 'three terminal camera frames at certificate native tick are missing')
        references, images = [], {}
        for camera, row in selected.items():
            stamp = row['physics_stamp']
            stamp_key(stamp)
            reference = row.get('render_reference_time') or {}
            require(reference.get('valid') is True and reference.get('source') == 'same_render_product.ReferenceTime',
                    camera + ' render-product clock is missing')
            value = float(reference_fraction(reference))
            references.append(value)
            path = audit.run / row.get('image_path', '')
            require(stamp == terminal_stamp and path.resolve().is_relative_to(audit.run) and path.is_file()
                    and digest(path) == images_by_key[camera]['sha256'],
                    camera + ' retained video frame does not match paired-capture pixels/native stamp')
            images[camera] = {'frame_index': row.get('frame_index'), 'path': str(path.relative_to(audit.run)),
                              'sha256': digest(path), 'render_time_s': value}
        require(max(references)-min(references) <= 1e-9, 'terminal three-camera render clocks differ')
        return {'physics_stamp': certificate['physics_stamp'], 'images': images,
                'clock_relation': 'distinct render and native clocks joined by frozen-state paired capture',
                'paired_render_passes': len(passes), 'native_body_paths': len(paths),
                'native_usd_dual_diagnostics': dual_diagnostics,
                'production_camera_key_alias': 'export_lerobot maps isaac_3d/third_person to front',
                'scope': 'three final video frames match paired fresh shared RP stamp, camera matrices and frozen native/raw state; full decode separate'}
    audit.check('terminal_three_view_clock_join', cameras)

    def geometry():
        initial = audit.json('stool_geometry_initial.json')
        require(initial.get('passed') is True and initial.get('full_stage_export') is True,
                'complete initial geometry export/check missing or rejected')
        total = 0
        for row in audit.lines('stool_production_geometry.jsonl'):
            total += 1
            require(row.get('passed') is True and row.get('first_failure') is None,
                    'production whole-scene finite sweep rejected a final command')
        require(total > 0, 'no actual production geometry sweeps were recorded')
        return {'production_batches': total, 'meshes': initial.get('meshes'),
                'pairs': initial.get('pairs'), 'scope': 'finite visible/authored mesh samples; no continuous CCD or cooked-SDF proof'}
    audit.check('original_geometry_reports', geometry)

    def media():
        if media_report is None:
            raise FileNotFoundError('separate full-video decode/SHA receipt was not supplied')
        value = json.loads(media_report.read_text())
        require(value.get('all_three_original_videos_decoded') is True and value.get('sha256_verified') is True,
                'full original three-video decode/SHA receipt did not pass')
        return {'path': str(media_report), 'sha256': digest(media_report), 'original_report': value}
    audit.check('full_original_media_delivery', media)

    process = {'exit_code': None, 'log_exception': None, 'log_tail': None,
               'exit_code_is_success_evidence': False}
    try:
        process['exit_code'] = int(audit.path('exit_code').read_text().strip())
    except (FileNotFoundError, ValueError):
        pass
    try:
        with audit.path('runner.log').open(errors='replace') as stream:
            tail = list(deque(stream, maxlen=100))
        process['log_tail'] = ''.join(tail)
        exception_pattern = re.compile(r'\b(?:FileNotFoundError|RuntimeError|ValueError|TypeError|AttributeError|'
                                       r'ImportError|ModuleNotFoundError|AssertionError|OSError|KeyError):[^\r\n]*')
        exceptions = [match.group(0) for line in tail for match in [exception_pattern.search(line)] if match]
        process['log_exception'] = exceptions[-1] if exceptions else None
        process['traceback_in_retained_tail'] = any('Traceback (most recent call last)' in line for line in tail)
    except FileNotFoundError:
        pass

    def original_sections():
        result = {}
        diagnostics = ('error', 'missing', 'skip', 'dropped', 'warning')
        def fields(value, prefix=''):
            found = {}
            if isinstance(value, dict):
                for key, child in value.items():
                    path = prefix + '.' + key if prefix else key
                    if any(token in key.lower() for token in diagnostics):
                        found[path] = child
                    found.update(fields(child, path))
            elif isinstance(value, list):
                for index, child in enumerate(value):
                    found.update(fields(child, prefix+'['+str(index)+']'))
            return found
        for name in ('runtime_constraint_monitor', 'assembly_sequence_precheck',
                     'stage_trajectory_precheck', 'runtime_robochecker'):
            value = metrics.get(name)
            result[name] = {'present': value is not None, 'diagnostics': fields(value),
                            'original_value': value}
        return result
    report_sections = original_sections()

    def original_report_coverage():
        required = ('runtime_constraint_monitor', 'assembly_sequence_precheck', 'stage_trajectory_precheck')
        missing, errors, ambiguous_skips = [], [], []
        benign_skips = {'holding_robot_current_joints', 'stride_skip'}
        preserved_skips = {}
        resolved_geometry = {}; resolved_traces = {}

        def active(value):
            if isinstance(value, dict):
                return any(active(child) for child in value.values())
            if isinstance(value, list):
                return any(active(child) for child in value)
            return bool(value)

        def scan(value, path):
            if not isinstance(value, dict):
                return
            for key, child in value.items():
                label = path + '.' + key
                lower = key.lower()
                # A warning's content remains preserved, but its prose is not
                # reclassified as an unhandled exception by substring matching.
                if 'warning' in lower:
                    continue
                if lower == 'skipped' and id(value) in resolved_geometry:
                    preserved_skips[label] = child
                    continue
                if lower == 'skip_reasons' or 'skipped' in lower or 'skip_reason' in lower:
                    preserved_skips[label] = child
                    if isinstance(child, dict):
                        for reason, count in child.items():
                            if active(count) and reason not in benign_skips:
                                ambiguous_skips.append(label + '.' + str(reason))
                    elif active(child):
                        ambiguous_skips.append(label)
                    continue
                if lower == 'events_dropped_from_summary' and id(value) in resolved_traces:
                    continue
                if 'dropped' in lower and active(child):
                    missing.append(label + ': recorded evidence was dropped')
                if 'missing' in lower and active(child):
                    missing.append(label + ': required coverage is absent')
                if ((lower in {'error', 'errors', 'monitor_error'} or lower.endswith(('_error', '_errors')))
                        and active(child)):
                    errors.append(label)
                if isinstance(child, dict):
                    scan(child, label)
                elif isinstance(child, list):
                    for index, item in enumerate(child):
                        if isinstance(item, dict):
                            scan(item, label + '[' + str(index) + ']')

        sections = {}
        for name in required:
            value = metrics.get(name)
            if not isinstance(value, dict):
                missing.append(name + ': required original report section absent')
                continue
            sections[name] = value
            for geometry_key in ('entity_geometry', 'entity_geometry_coverage'):
                geometry = value.get(geometry_key)
                if not isinstance(geometry, dict):
                    continue
                if geometry.get('physical_inventory_schema') == 'usd_collider_inventory_v1':
                    resolved_geometry[id(geometry)] = original_geometry_inventory(geometry, audit.json('scene_geometry.json'))
                if geometry.get('uncapped_trace_receipt'):
                    receipt = geometry['uncapped_trace_receipt']
                    recorded = Path(receipt.get('path', ''))
                    require(recorded.is_absolute() and recorded.parent.resolve() == audit.run,
                            'uncapped original trace is not bound to this run directory')
                    resolved_traces[id(geometry)] = original_uncapped_trace(geometry, audit.path(recorded.name))
            if value.get('enabled') is not True:
                missing.append(name + ': required original checker was not enabled')
            scan(value, name)

        resolved_proxy = {}
        if any(sections.get(name, {}).get('violation_total', 0)
               for name in ('runtime_constraint_monitor','stage_trajectory_precheck')):
            try:
                scene = audit.json('scene_geometry.json')
                reviewer = StoolProxyGeometryReview(scene)
                proxy_raw = collect_stool_proxy_raw(audit, sections, scene, reviewer)
                for name in ('runtime_constraint_monitor','stage_trajectory_precheck'):
                    if sections.get(name, {}).get('violation_total', 0):
                        resolved_proxy[name] = reviewer.verify(name, sections[name], proxy_raw)
            except (ValueError, FileNotFoundError, KeyError, TypeError) as exc:
                errors.append('original capsule violations unresolved: '+str(exc))
        sequence = sections.get('assembly_sequence_precheck', {})
        if sequence:
            if sequence.get('feasible') is not True:
                errors.append('assembly_sequence_precheck.feasible: original sequence did not pass')
            expected_count = len(contract_holder.get('cfg', {}).get('phase_specs', []))
            if not expected_count or sequence.get('phase_count') != expected_count:
                missing.append('assembly_sequence_precheck.phase_count: whole compiled phase graph not covered')
        for name in ('runtime_constraint_monitor', 'stage_trajectory_precheck'):
            value = sections.get(name, {})
            if value and (not value.get('checks') or not value.get('observed_steps')):
                missing.append(name + ': no actual observations/checks recorded')
        runtime = sections.get('runtime_constraint_monitor', {})
        if runtime and set(runtime.get('registered_robots', {})) != ROBOTS:
            missing.append('runtime_constraint_monitor.registered_robots: both arms not registered')
        stage = sections.get('stage_trajectory_precheck', {})
        if stage:
            if not stage.get('segments_checked') or not stage.get('waypoints_checked'):
                missing.append('stage_trajectory_precheck: actual command segments/waypoints not checked')
            if set(stage.get('frame_coverage', {})) != ROBOTS:
                missing.append('stage_trajectory_precheck.frame_coverage: both arms not covered')
        if errors:
            raise ValueError('Unhandled original report errors: ' + '; '.join(errors)
                             + ('; coverage gaps: ' + '; '.join(missing) if missing else '')
                             + ('; ambiguous skips: ' + '; '.join(ambiguous_skips) if ambiguous_skips else ''))
        if missing or ambiguous_skips:
            raise FileNotFoundError('Original report coverage requires review: '
                + '; '.join(missing + [item + ': skip scope is ambiguous' for item in ambiguous_skips]))
        return {'required_sections': list(required), 'whole_sequence_phases': sequence['phase_count'],
                'preserved_skip_reasons': preserved_skips, 'benign_skip_policy': sorted(benign_skips),
                'warnings_preserved_without_automatic_failure': True,
                'geometrically_resolved_original_capsule_reports': resolved_proxy,
                'typed_geometry_sections_verified': len(resolved_geometry),
                'uncapped_trace_receipts_verified': list(resolved_traces.values())}

    audit.check('required_original_passive_report_coverage', original_report_coverage)
    accepted = bool(metrics.get('success') is True and qualification.get('phase_sequence_completed') is True
                    and all(c.get('passed') is True for c in audit.checks.values()))
    report = {
        'schema': 'stool_independent_audit/v1', 'run_directory': str(audit.run),
        'original_main_report': {
            'reported_success': metrics.get('success'),
            'original_report_success': qualification.get('original_report_success'),
            'original_criteria_passed': qualification.get('original_criteria_passed'),
            'failed': metrics.get('failed'), 'terminal_reason': metrics.get('terminal_reason')},
        'original_report_sources': audit.metric_sources,
        'process_observation': process,
        'evidence_presence': {
            'original_report_present': bool(metrics),
            'retained_images': sum(1 for _ in audit.run.rglob('frame_*.png')),
            'retained_video_files': sum(1 for _ in audit.run.rglob('*.mp4')),
            'raw_trace_present': any(audit.run.rglob('independent_native_trace.jsonl')),
            'failure_tail_report': metrics.get('post_failure_recording'),
        },
        'full_motion_completed': qualification.get('phase_sequence_completed'),
        'runtime_native_qualified': qualification.get('final_native_qualified'),
        'original_passive_reports': report_sections,
        'strict_independent_audit_passed': all(c.get('passed') is True for name, c in audit.checks.items()
                                             if name != 'full_original_media_delivery'),
        'accepted_full_assembly': accepted,
        'checks': audit.checks, 'input_sha256': audit.inputs,
        'missing_checks': [k for k, v in audit.checks.items() if v.get('passed') is None],
        'failed_checks': [k for k, v in audit.checks.items() if v.get('passed') is False],
        'support_claim': 'retained measured world constraints; no support-removal or friction-only stability claim',
        'limits': ['audit never advances physics or repairs reports',
                   'raw and wrapper readers observe the same PhysX scene through distinct handles',
                   'missing/skipped/invalid original evidence is preserved and fails acceptance'],
    }
    report['auditor_sha256'] = digest(Path(__file__).resolve())
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('run_directory', type=Path)
    parser.add_argument('--source-binding', type=Path)
    parser.add_argument('--media-report', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    report = run_audit(args.run_directory, args.source_binding, args.media_report)
    encoded = json.dumps(report, indent=2, allow_nan=False) + '\n'
    if args.output:
        with args.output.open('x') as stream:
            stream.write(encoded)
    print(encoded, end='')
    return 0 if report['accepted_full_assembly'] else 2


if __name__ == '__main__':
    raise SystemExit(main())

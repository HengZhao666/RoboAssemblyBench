"""Plan derived-PNG cleanup; execute only an explicitly reviewed manifest SHA.
Never decodes video. Run only after download/archive review; that review remains
root's responsibility. No source/raw/report/video/startup/terminal file is deleted.
"""
import argparse, hashlib, json, math, re, shutil
from datetime import datetime, timezone
from pathlib import Path
CAMERAS = ('front', 'left_wrist', 'right_wrist')
PATTERN = r'episode_0000_live_frames/observation_images_(front|left_wrist|right_wrist)/frame_[0-9]{5,}\.png'

def require(value, message):
    if not value: raise ValueError(message)

def safe(run, relative):
    p = Path(relative); require(not p.is_absolute() and '..' not in p.parts, 'unsafe relative path')
    q = run
    for part in p.parts:
        q = q / part; require(not q.is_symlink(), 'symlink rejected: ' + str(q))
    require(q.is_file(), 'missing regular file: ' + str(q)); return q

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''): h.update(block)
    return h.hexdigest()

def record(run, relative):
    p = safe(run, relative); return dict(path=relative, bytes=p.stat().st_size, sha256=digest(p))

def read(run, relative): return json.loads(safe(run, relative).read_text())

def json_lines(run, relative):
    with safe(run, relative).open() as f:
        for line in f: yield json.loads(line)

def stamp(value):
    require(isinstance(value, dict) and value.get('valid') is True, 'missing valid native stamp')
    require(all(type(value.get(k)) is int and value[k]>=0 for k in ('epoch', 'index')) and type(value.get('time')) in (int,float) and math.isfinite(value['time']), 'invalid native stamp')
    return value['epoch'], value['index'], value['time']

def eligibility(run):
    require(run.is_absolute() and run == run.resolve(), 'run path must be canonical without symlinks')
    require(re.fullmatch(r'S[0-9]{2,}', run.name) and run.parent.name == 'runs', 'formal run only')
    closure = read(run, 'formal_closure.json'); safe(run, 'finished_at')
    require(closure.get('closed') is True and closure.get('id') == run.name, 'run not formally closed')
    media = read(run, 'media_verification.json')
    require(media.get('status') == 'passed' and media.get('all_three_original_videos_decoded') is True
            and media.get('sha256_verified') is True and len(media.get('files', [])) == 3, 'three original decodes required')
    require({p.name for p in (run/'episode_0000_live_videos').glob('*.mp4')} == {'observation_images_'+n+'.mp4' for n in CAMERAS}, 'original MP4 membership differs')
    videos = []
    for name in CAMERAS:
        rows = [x for x in media['files'] if x.get('camera') == 'observation.images.' + name]
        require(len(rows) == 1, 'duplicate/missing camera'); row = rows[0]
        relative = 'episode_0000_live_videos/observation_images_' + name + '.mp4'
        require(row.get('path') == relative and row.get('decoded') is True and row.get('sha256_verified') is True
                and row.get('decode', {}).get('passed') is True and row['decode'].get('exit_code') == 0, 'incomplete original decode')
        rec = record(run, relative)
        require(all(row.get(k) == rec['sha256'] for k in ('sha256', 'sha256_before', 'sha256_after')), 'original video SHA changed')
        videos.append(rec)
    return media, videos, closure

def first_local_failure_event(run, episode):
    """Admit the original first local terminal observation, never invent a guard error."""
    name = 'first_local_failure_observation.json'; observed = read(run, name)
    native = stamp(observed.get('physics_stamp')); detail = observed.get('original_detail')
    require(observed.get('schema') == 'stool_first_local_failure_transition_v1'
            and observed.get('passed') is True and observed.get('native_stamp_unchanged') is True
            and observed.get('no_new_sdk_batch') is True
            and observed.get('sdk_before') == observed.get('sdk_after')
            and set(observed.get('sdk_before', {})) == {'franka_left','franka_right'}
            and not observed.get('capture_error')
            and not observed.get('retention_error'), 'first local-failure collection invalid/incomplete')
    reason = observed.get('original_reason'); metrics = episode.get('metrics', {})
    require(isinstance(reason, str) and reason.startswith('local-skill-failure:')
            and observed.get('original_terminal_phase') == 'failed' and observed.get('original_status') == 'failed'
            and metrics.get('failed') is True and isinstance(detail, dict), 'not an original failed local-skill event')
    transitions = [row for row in metrics.get('phase_transition_history', [])
        if row.get('reason') == reason and row.get('status') == 'failed'
        and row.get('from_phase') == observed.get('phase') and row.get('step_counter') == observed.get('step')]
    require(len(transitions) == 1 and all(transitions[0].get(k) == v for k,v in detail.items()),
            'first local-failure reason/detail/phase/task differs from original report')
    launch = read(run, 'source_binding.json'); runtime = read(run, 'runtime_source_binding.json')
    require(launch.get('passed') is True and runtime.get('passed') is True
            and launch.get('run') == runtime.get('run') == run.name
            and launch.get('run_directory') == runtime.get('run_directory') == str(run)
            and runtime.get('launch_source_binding_sha256') == digest(safe(run, 'source_binding.json')),
            'first local-failure source/run binding differs')
    for key, seal in [('source_manifest','source_manifest_sha256'),('tools_manifest','tool_manifest_sha256')]:
        manifest = launch.get(key)
        require(isinstance(manifest, dict) and manifest and runtime.get(key) == manifest
                and launch.get(seal) == runtime.get(seal) == hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest(),
                'first local-failure source/tool manifest seal differs')
    require(re.fullmatch(r'[0-9a-f]{64}', str(launch['tools_manifest'].get('stool_worker.py',''))),
            'first local-failure producer worker identity absent')
    init = read(run, 'runtime_initialization_preflight.json'); initial = init.get('independent_raw') or {}
    raw = observed.get('independent_raw') or {}
    require(init.get('passed') is True and raw.get('valid') is True and initial.get('valid') is True
            and raw.get('physics_stamp') == observed.get('physics_stamp')
            and raw.get('source') == initial.get('source') == 'separate_exact_path_PhysX_tensor_views'
            and raw.get('path') == initial.get('path') == 'independent_native_trace.jsonl'
            and raw.get('body_paths') == initial.get('body_paths') and raw.get('body_paths')
            and len(raw['body_paths']) == len(set(raw['body_paths']))
            and raw.get('objects') == initial.get('objects') and len(raw.get('objects', {})) == 9
            and set(raw['objects'].values()) <= set(raw['body_paths'])
            and raw.get('articulation_identities') == initial.get('articulation_identities')
            and set(raw.get('articulation_identities',{})) == {'franka_left','franka_right'},
            'first local-failure raw clock/full native identity differs')
    found = []
    with safe(run, raw['path']).open('rb') as stream:
        for line in stream:
            row = json.loads(line)
            if row.get('sequence') == raw.get('sequence'): found.append((row, hashlib.sha256(line).hexdigest()))
    require(len(found) == 1, 'first local-failure exact independent raw sequence absent/duplicated')
    row, line_sha = found[0]
    require(row.get('kind') == 'independent_raw' and row.get('source') == raw['source']
            and row.get('valid') is True and row.get('boundary') == 'control_failure'
            and row.get('physics_stamp') == raw['physics_stamp'] and row.get('phase') == observed.get('phase')
            and row.get('task_step') == observed.get('step') and set(row.get('bodies', {})) == set(raw['body_paths'])
            and set(row.get('objects',{})) == set(raw['objects']) and set(row.get('robots',{})) == set(raw['articulation_identities'])
            and all(row['objects'][k].get('path') == p for k,p in raw['objects'].items())
            and all(row['robots'][k].get('identity') == v for k,v in raw['articulation_identities'].items()),
            'first local-failure exact raw row is incomplete or from another clock')
    return dict(kind='first_failure', source=name, stamp=native,
                raw_sequence=raw['sequence'], raw_line_sha256=line_sha)

def plan(run, download_note=None):
    media, videos, closure = eligibility(run)
    inputs = ['finished_at', 'formal_closure.json', 'media_verification.json', 'video_frame_clock.jsonl', 'assisted_trace.jsonl', 'episode_0000.json']
    require(media.get('raw_clock',{}).get('passed') is True and media['raw_clock'].get('raw_clock_sha256') == digest(safe(run,'video_frame_clock.jsonl')), 'media/clock SHA differs')
    clock = list(json_lines(run,'video_frame_clock.jsonl')); events = []; phases = []; previous = None
    for x in json_lines(run,'assisted_trace.jsonl'):
        phase = x.get('phase')
        if phase != previous:
            events.append(dict(kind='observed_phase_boundary', phase=phase, stamp=stamp(x.get('physics_stamp')))); phases.append(phase); previous = phase
        if x.get('event') == 'attach_measured_pose': events.append(dict(kind='attach', object=x.get('object'), stamp=stamp(x.get('physics_stamp'))))
    episode = read(run, 'episode_0000.json')
    require(set(episode['metrics']['phase_history']) & set(episode['phase_blueprint']) <= set(phases), 'phase boundary evidence missing')
    if (run / 'production_control_failure.json').exists():
        inputs.append('production_control_failure.json'); x = read(run, inputs[-1]); events.append(dict(kind='first_failure', stamp=stamp(x.get('physics_stamp'))))
    if (run / 'first_local_failure_observation.json').exists():
        events.append(first_local_failure_event(run, episode))
        inputs.extend(['first_local_failure_observation.json', 'source_binding.json', 'runtime_source_binding.json',
                       'runtime_initialization_preflight.json', 'independent_native_trace.jsonl'])
    require(closure.get('main_task_success') is True or any(x['kind']=='first_failure' for x in events), 'failed/unknown outcome lacks first-failure native stamp; retain PNGs for review')
    keep = set(); mappings = []
    require({x['camera'] for x in clock} == {'observation.images.' + n for n in CAMERAS}, 'clock camera membership differs')
    for name in CAMERAS:
        rows = [x for x in clock if x['camera'] == 'observation.images.' + name]
        require([x['frame_index'] for x in rows] == list(range(len(rows))) and rows, 'frame ordinals incomplete')
        report = next(x for x in media['files'] if x['camera'] == rows[0]['camera'])
        require(report['decode']['frame_count'] == len(rows), 'decode/clock frame counts differ')
        stamps = [stamp(x['physics_stamp']) for x in rows]; require(stamps == sorted(stamps), 'nonmonotonic native frame clocks')
        for x in rows:
            require(re.fullmatch(PATTERN, x['image_path']) and Path(x['image_path']).parent.name == 'observation_images_' + name, 'frame path mismatch')
            require(int(Path(x['image_path']).stem[6:]) == x['frame_index'], 'frame filename/ordinal mismatch'); safe(run, x['image_path'])
        keep.update([rows[0]['image_path'], rows[-1]['image_path']])
        for event in events:
            s = tuple(event['stamp']); before = [i for i,t in enumerate(stamps) if t[0] == s[0] and t <= s]; after = [i for i,t in enumerate(stamps) if t[0] == s[0] and t >= s]
            require(before or after, 'event epoch missing from camera clock'); anchors = ([before[-1]] if before else []) + ([after[0]] if after else [])
            indices = sorted({j for i in anchors for j in range(max(0,i-2), min(len(rows),i+3))})
            keep.update(rows[i]['image_path'] for i in indices)
            mappings.append(dict(camera=name, event=event, frames=[dict(path=rows[i]['image_path'], stamp=stamps[i]) for i in indices], exact_event_clock_available=s in stamps, interpretation='nearest retained frames; exact event-clock claim only when epoch/index/time all match'))
    paths = {x['image_path'] for x in clock}; observed = set()
    for camera in CAMERAS:
        directory = run / 'episode_0000_live_frames' / ('observation_images_' + camera)
        require(not directory.is_symlink() and not directory.parent.is_symlink(), 'frame directory symlink')
        observed.update(str(p.relative_to(run)) for p in directory.glob('frame_*.png'))
    require(observed == paths, 'unclocked/missing frame files; preserve and inspect')
    targets = [record(run, x) for x in sorted(paths-keep)]
    return dict(schema='stool_frame_cleanup/v1', run=str(run), evidence=[record(run,n) for n in inputs]+videos,
        delete=targets, logical_delete_bytes=sum(x['bytes'] for x in targets), keep=sorted(keep), event_frame_mappings=mappings,
        download_proof_note=download_note,
        download_archive_review='Required before root approves this manifest; not independently proved by this tool')

def execute(run, path, approved_sha, receipt):
    require(path.absolute() == path.resolve(), 'manifest symlink/noncanonical path')
    require(digest(path) == approved_sha, 'approved manifest SHA mismatch'); m = json.loads(path.read_text())
    require(m.get('schema') == 'stool_frame_cleanup/v1' and m.get('run') == str(run), 'manifest identity mismatch')
    require(not receipt.exists() and not receipt.is_symlink() and receipt.parent.is_dir() and receipt.parent.absolute() == receipt.parent.resolve(), 'receipt exists, parent missing or symlink')
    require(run/'episode_0000_live_frames' not in receipt.absolute().parents, 'receipt cannot be written into frame directories')
    result = dict(manifest_sha256=approved_sha, run=str(run), started_utc=datetime.now(timezone.utc).isoformat(), disk_before=shutil.disk_usage(run)._asdict(), deleted=[], passed=False)
    with receipt.open('x') as f:
        try:
            current = plan(run, m.get('download_proof_note'))
            require(json.dumps(current,sort_keys=True) == json.dumps(m,sort_keys=True), 'current evidence/target SHA or retention plan changed')
            targets = m['delete']; require(len({x['path'] for x in targets}) == len(targets), 'duplicate deletion paths')
            identities = {}
            for row in targets:
                require(re.fullmatch(PATTERN,row['path']) and row['path'] not in m['keep'], 'non-PNG/protected deletion')
                identities[row['path']] = safe(run,row['path']).stat()
            for row in targets:
                target = safe(run,row['path']); require(target.stat() == identities[row['path']], 'target changed after precheck')
                target.unlink(); result['deleted'].append(row)
            result['passed'] = True
        except Exception as exc: result['error'] = type(exc).__name__ + ': ' + str(exc)
        result.update(logical_deleted_bytes=sum(x['bytes'] for x in result['deleted']), disk_after=shutil.disk_usage(run)._asdict(), finished_utc=datetime.now(timezone.utc).isoformat(), disk_note='Logical unlink bytes differ from physical free-space change; hardlinks, snapshots and concurrent writers may affect disk usage')
        json.dump(result,f,indent=2)
    return result

def main():
    p = argparse.ArgumentParser(description=__doc__); p.add_argument('run',type=Path); p.add_argument('--manifest',required=True,type=Path); p.add_argument('--execute',action='store_true'); p.add_argument('--approved-manifest-sha'); p.add_argument('--receipt',type=Path); p.add_argument('--download-proof-note'); a = p.parse_args()
    run = a.run.absolute(); require(run == run.resolve() and run.is_dir(), 'run path symlink/noncanonical/missing')
    if a.execute:
        require(a.approved_manifest_sha and a.receipt, 'execute requires reviewed SHA and new receipt path'); result = execute(run,a.manifest,a.approved_manifest_sha,a.receipt); print(json.dumps(result)); return 0 if result['passed'] else 1
    value = plan(run,a.download_proof_note)
    with a.manifest.open('x') as f: json.dump(value,f,indent=2)
    print(json.dumps(dict(manifest=str(a.manifest),sha256=digest(a.manifest)))); return 0

if __name__ == '__main__': raise SystemExit(main())

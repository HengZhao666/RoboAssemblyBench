"""Production act with nonzero tracking error; toy feedback is not physics proof."""
import copy
import json
from pathlib import Path
import unittest
import numpy as np
from test_beam_weak_side_recenter import FinalActionRecenterSafety
from toolkits.factory_dual_franka_assembly.plumbers_block_ur5e_skills import UR5eAssemblyAtomicSkillAdapter as Adapter


class ConsistentReference(unittest.TestCase):
    def test_actual_recorded_reference_mismatch_is_removed_without_anchor_recapture(self):
        data=json.loads((Path(__file__).parent/'fixtures/beam_v201_v203_reference.json').read_text())['v203_close_failure']
        record=data['recenter_lifecycle'][0]
        current=np.array(record['motion_start_position_world'])
        delta=np.array(record['motion_delta_world'])
        nominal=np.array(data['close_gates'][-1]['command_target_position'])
        anchor=nominal-delta
        state={'recenter_anchor_position_world':anchor.copy(),
               'force_recenter_pending':{'lifecycle':'planned','motion_delta_world':delta.copy()}}
        self.assertGreater(np.linalg.norm(nominal-current-delta),.0002)
        target=Adapter._consistent_recenter_target(state=state,nominal_target=nominal,current_position=current,max_offset=.002)
        np.testing.assert_allclose(target,current+delta,atol=1e-14)
        np.testing.assert_array_equal(state['recenter_anchor_position_world'],anchor)
        later=Adapter._consistent_recenter_target(state=state,nominal_target=nominal,current_position=current+.0001,max_offset=.002)
        np.testing.assert_array_equal(later,target)

    def test_full_act_keeps_one_goal_and_finishes_with_evolving_lag(self):
        adapter,task,native,state,act=FinalActionRecenterSafety().fixture(initial=.000204,consistent=True)
        anchor=copy.deepcopy(state['contact_arm_anchor'])
        first=act()
        # Native lag persists between planning and actual issuance.
        native['q'][0]=.00015
        task.step_counter=task.phase_step_counter=101
        action=act()
        pending=state['force_recenter_pending']
        target=pending['motion_target_position_world'].copy()
        self.assertAlmostEqual(target[1],.000125)
        self.assertAlmostEqual(pending['issued_command_tcp_position_world'][1],target[1])
        self.assertAlmostEqual(pending['motion_start_position_world'][1],.00015)
        for tick in range(102,145):
            native['q'] += .5*(np.array(action['arm_joint_controller'][0])-native['q'])
            task.step_counter=task.phase_step_counter=tick
            action=act()
            self.assertNotIn('__local_skill_failure__',action)
            if 'force_recenter_pending' not in state:break
            np.testing.assert_array_equal(state['force_recenter_pending']['motion_target_position_world'],target)
        self.assertNotIn('force_recenter_pending',state)
        np.testing.assert_array_equal(state['contact_arm_anchor']['position'],anchor['position'])
        self.assertAlmostEqual(state['force_recenter_travel'],.000025)
        # Completion cannot return the command to the older contact anchor.
        self.assertAlmostEqual(action['arm_joint_controller'][0][0],target[1])

    def test_no_motion_and_opposite_motion_do_not_acknowledge(self):
        for actual in [np.zeros(3),np.array([0.,.000025,0.])]:
            ready,_=Adapter._recenter_motion_ready(pending={'lifecycle':'final_action_issued',
                'adaptive_progress':True,'motion_delta_world':np.array([0.,-.000025,0.]),
                'motion_target_position_world':np.array([0.,-.000025,0.])},
                current_position=actual,overall_pose_ready=True,tolerance=.0001)
            self.assertFalse(ready)

    def test_reference_correction_cannot_escape_existing_travel_envelope(self):
        state={'recenter_anchor_position_world':np.zeros(3),'force_recenter_pending':{
            'lifecycle':'planned','motion_delta_world':np.array([0.,.0002,0.])}}
        with self.assertRaises(ValueError):
            Adapter._consistent_recenter_target(state=state,nominal_target=np.zeros(3),
                current_position=np.array([0.,.0019,0.]),max_offset=.002)
        self.assertNotIn('recenter_servo_bias_world',state)


if __name__=='__main__':unittest.main()

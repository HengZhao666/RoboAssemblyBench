"""Read-only full-stage geometry inventory for the explicit stool contract.

Includes the loaded background scene, fixtures, full robots/grippers and nine parts.
No simulator advance, pose setter, velocity setter or collision change is made.
"""
from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
import json, hashlib, copy
import numpy as np


class LayerSealError(RuntimeError):
    def __init__(self,report):
        self.report=report
        super().__init__('startup composed-layer seal rejected: '+str(report.get('error')))


def seal_composed_layers(stage,out,stamp_getter):
    """Seal local original bytes and retain nonlocal/anonymous layer text.

    ExportToString reads the already loaded layer. It neither fetches a new
    source nor mutates the stage. Captured USDA is explicitly distinct from
    original source file bytes; every dependency returned by GetUsedLayers is
    represented in the manifest.
    """
    out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True)
    report=dict(passed=False,layers=[],native_physics_executed=0,
        scope='actual used USD layers at startup; local original bytes or retained canonical layer text')
    before=copy.deepcopy(dict(stamp_getter()));report['physics_stamp_before']=before
    try:
        if before.get('valid') is not True:raise RuntimeError('native clock unavailable before layer sealing')
        layers=sorted(stage.GetUsedLayers(),key=lambda layer:(str(layer.identifier),str(layer.realPath or '')))
        for index,layer in enumerate(layers):
            identifier=str(layer.identifier);original_resolved=str(layer.realPath or identifier)
            source=Path(original_resolved)
            if source.is_file():
                payload=source.read_bytes()
                row=dict(identifier=identifier,resolved_path=str(source.resolve()),
                    sha256=hashlib.sha256(payload).hexdigest(),bytes=len(payload),
                    seal_status='hashed_local_composed_layer',seal_scope='original local USD layer file bytes')
            else:
                text=layer.ExportToString()
                if not isinstance(text,str) or not text.strip():raise RuntimeError('nonlocal/anonymous used layer exported no canonical text: '+identifier)
                payload=text.encode('utf-8');retained=out/'asset_layers'/('layer_'+str(index).zfill(4)+'.usda')
                retained.parent.mkdir(parents=True,exist_ok=True)
                if retained.exists():
                    if retained.read_bytes()!=payload:raise RuntimeError('retained startup layer already exists with different content: '+str(retained))
                else:
                    with retained.open('xb') as stream:stream.write(payload)
                row=dict(identifier=identifier,original_resolved_path=original_resolved,
                    resolved_path=str(retained.resolve()),sha256=hashlib.sha256(payload).hexdigest(),bytes=len(payload),
                    seal_status='captured_composed_layer_text',
                    seal_scope='canonical USD text of the actual composed layer captured at startup; not original remote/anonymous file bytes; dependency layers sealed separately')
            report['layers'].append(row)
        after=copy.deepcopy(dict(stamp_getter()));report['physics_stamp_after']=after
        report['native_clock_unchanged']=before==after
        if before!=after:raise RuntimeError('native clock changed during read-only composed-layer capture')
        report['passed']=True
    except Exception as exc:
        report['error']=type(exc).__name__+': '+str(exc)
        try:
            report['physics_stamp_after']=copy.deepcopy(dict(stamp_getter()))
            report['native_clock_unchanged']=before==report['physics_stamp_after']
        except Exception as secondary:report['clock_after_failure_error']=repr(secondary)
    (out/'asset_layer_seal_receipt.json').write_text(json.dumps(report,indent=2)+'\n')
    if not report['passed']:raise LayerSealError(report)
    return report


def export_geometry(monitor, out):
    from pxr import Usd, UsdGeom, UsdPhysics, Gf
    from toolkits.constraint_checking.integration.entity_geometry import enumerate_usd_colliders
    task, stage = monitor.task, monitor.stage
    contract = dict(getattr(task, '_fabrica_assisted_contract', {}) or {})
    if contract.get('adapter') != 'stool_circular_ur5e_v1':
        raise ValueError('geometry export requires the explicit stool contract')
    roots = list(monitor.roots)
    roots.sort(key=lambda row: len(row[0]), reverse=True)
    cache = UsdGeom.XformCache(); meshes = []; joints = []; gaps = []; excluded = []
    joint_paths = set(); all_bodies = {}; rigid_bodies = set(); body_robots = {}
    def ownership(path):
        for root, group, robot, name in roots:
            if path == root or path.startswith(root + '/'):
                return stage.GetPrimAtPath(root), group, robot, name
        return stage.GetPseudoRoot(), 'static:loaded_environment', None, 'loaded_environment'
    for prim in Usd.PrimRange(stage.GetPseudoRoot(), Usd.TraverseInstanceProxies()):
        path = str(prim.GetPath()); root, group, robot, object_name = ownership(path)
        if prim.IsA(UsdPhysics.Joint):
            j = UsdPhysics.Joint(prim)
            def vec(attr, default):
                v = attr.Get(); return list(v) if v is not None else default
            def quat(attr):
                q = attr.Get(); return [*map(float, q.GetImaginary()), float(q.GetReal())] if q else [0.,0.,0.,1.]
            joints.append(dict(path=path, robot=robot, type=str(prim.GetTypeName()),
                parent=[str(x) for x in j.GetBody0Rel().GetTargets()],
                child=[str(x) for x in j.GetBody1Rel().GetTargets()],
                pos0=vec(j.GetLocalPos0Attr(),[0.,0.,0.]), rot0=quat(j.GetLocalRot0Attr()),
                pos1=vec(j.GetLocalPos1Attr(),[0.,0.,0.]), rot1=quat(j.GetLocalRot1Attr()),
                axis=prim.GetAttribute('physics:axis').Get(), enabled=j.GetJointEnabledAttr().Get() is not False))
            joint_paths.add(path)
        if not prim.IsA(UsdGeom.Gprim): continue
        image = UsdGeom.Imageable(prim)
        visible = image.ComputeVisibility() != 'invisible' and str(image.ComputePurpose()) in ('default','render')
        collider = prim.HasAPI(UsdPhysics.CollisionAPI) and UsdPhysics.CollisionAPI(prim).GetCollisionEnabledAttr().Get() is not False
        if not visible and not collider:
            excluded.append(dict(prim=path, reason='neither_rendered_nor_enabled_collider')); continue
        if prim.IsA(UsdGeom.Mesh):
            mesh = UsdGeom.Mesh(prim); points = np.asarray(mesh.GetPointsAttr().Get(),float)
            counts = mesh.GetFaceVertexCountsAttr().Get(); indices = mesh.GetFaceVertexIndicesAttr().Get()
            faces = []; offset = 0
            for count in counts:
                face = list(indices[offset:offset+count]); offset += count
                for i in range(1,count-1): faces.append([face[0],face[i],face[i+1]])
        elif prim.IsA(UsdGeom.Cube):
            h = float(UsdGeom.Cube(prim).GetSizeAttr().Get())/2
            points=np.array([[x,y,z] for x in [-h,h] for y in [-h,h] for z in [-h,h]])
            faces=[[0,1,3],[0,3,2],[4,6,7],[4,7,5],[0,4,5],[0,5,1],[2,3,7],[2,7,6],[0,2,6],[0,6,4],[1,5,7],[1,7,3]]
        else:
            gaps.append(dict(prim=path,reason='unsupported_rendered_or_collision_gprim',
                type=str(prim.GetTypeName()),visible=visible,collider=collider)); continue
        if points.ndim != 2 or points.shape[1] != 3 or not len(points) or not faces or not np.all(np.isfinite(points)):
            gaps.append(dict(prim=path,reason='invalid_empty_mesh')); continue
        owner = prim
        while owner and owner.IsValid() and not owner.HasAPI(UsdPhysics.RigidBodyAPI):
            if owner == root or owner.IsPseudoRoot(): break
            owner = owner.GetParent()
        if not owner or not owner.IsValid() or owner.IsPseudoRoot(): owner = prim
        body = str(owner.GetPath()); world = cache.GetLocalToWorldTransform(owner)
        rigid = Gf.Matrix4d(1); rigid.SetRotate(world.ExtractRotationQuat()); rigid.SetTranslateOnly(world.ExtractTranslation())
        transform = cache.GetLocalToWorldTransform(prim) * rigid.GetInverse()
        local = np.asarray([list(transform.Transform(Gf.Vec3d(*map(float,p)))) for p in points])
        is_rigid = owner.HasAPI(UsdPhysics.RigidBodyAPI)
        if is_rigid: rigid_bodies.add(body)
        if robot: body_robots[body] = robot
        all_bodies[body] = np.asarray(rigid).T
        meshes.append(dict(prim=path,body=body,group=group,robot=robot,object=object_name,
            points=local.tolist(),triangles=faces,body_rest=np.asarray(rigid).T.tolist(),
            rendered=visible,enabled_collider=collider,rigid_body=is_rigid,
            geometry_domain='rendered_and_authored_collision' if visible and collider else 'rendered' if visible else 'authored_collision'))
    # Read all authored environment collider inventories, independent of task roots.
    scene_colliders, collision_gaps = enumerate_usd_colliders(stage,[('/', 'loaded_scene',None,'loaded_environment')])
    # Existing monitor uses full-path native wrappers; add every noncolliding robot shell too.
    from toolkits.constraint_checking.integration.runtime_monitor import _load_xform_reader_cls
    reader_cls = _load_xform_reader_cls()
    for body in all_bodies:
        if body not in monitor.readers:
            monitor.readers[body] = reader_cls(prim_path=body,reset_xform_properties=False)
        if body in body_robots:
            monitor.body_robot_links[body] = (body_robots[body],body)
    native = monitor.current_poses()
    for body in rigid_bodies:
        if body in body_robots or any(body == str(p.GetPath()) for p in getattr(task,'_object_prims',{}).values()): continue
        # Unknown dynamic background bodies may move; never freeze them as static xforms.
        api = UsdPhysics.RigidBodyAPI(stage.GetPrimAtPath(body))
        if api.GetRigidBodyEnabledAttr().Get() is not False and api.GetKinematicEnabledAttr().Get() is not True:
            gaps.append(dict(body=body,reason='unbound_dynamic_environment_body'))
    rest = {body: np.asarray(native.get(body,matrix),float).tolist() for body,matrix in all_bodies.items()}
    for j in joints:
        for body in j['parent'] + j['child']:
            if body and body not in rest:
                p = stage.GetPrimAtPath(body)
                if p and p.IsValid():
                    matrix=cache.GetLocalToWorldTransform(p); rigid=Gf.Matrix4d(1)
                    rigid.SetRotate(matrix.ExtractRotationQuat()); rigid.SetTranslateOnly(matrix.ExtractTranslation())
                    if j['robot']:
                        reader=monitor._native_body(j['robot'],body); pos,quat=reader.get_pose()
                        from toolkits.constraint_checking.integration.entity_geometry import pose_matrix
                        rest[body]=pose_matrix(pos,quat).tolist()
                        monitor.body_robot_links[body]=(j['robot'],body)
                        monitor.readers.setdefault(body,reader_cls(prim_path=body,reset_xform_properties=False))
                    else: rest[body]=np.asarray(rigid).T.tolist()
    robots={name:dict(joint_names=list(robot.articulation.dof_names),
        joint_positions=np.asarray(robot.articulation.get_joint_positions()).tolist(),
        root_path=str(robot.articulation._root_prim_path)) for name,robot in task.robots.items()}
    object_coverage={name:sorted({m['body'] for m in meshes if m['object']==name}) for name in contract['objects']}
    for name,bodies in object_coverage.items():
        if len(bodies) != 1: gaps.append(dict(object=name,reason='expected_one_native_part_body',bodies=bodies))
    if len(robots) != 2: gaps.append(dict(reason='expected_two_native_robots'))
    layer_receipt=seal_composed_layers(stage,out,task._beam_physics_stamp)
    composed_layers=layer_receipt['layers']
    report=dict(composed_layer_asset_seals=composed_layers,composed_layer_seal_receipt='asset_layer_seal_receipt.json',
        composed_layer_seal_physics_stamp=layer_receipt['physics_stamp_before'],schema='stool_full_stage_geometry/v1',scope='entire loaded USD stage, instance proxies, rendered and enabled authored collision gprims',
        task_contract=contract,task_objects=list(contract['objects']),roots=roots,
        colliders=[asdict(c) for c in scene_colliders],collision_inventory_gaps=collision_gaps,
        body_rest=rest,visible_meshes=meshes,joints=joints,robots=robots,gaps=gaps,
        excluded_nonrendered_noncolliding=excluded,object_body_coverage=object_coverage,
        scene_background_root_not_exported=False,physics_stamp=task._beam_physics_stamp(),
        resolved_scene_asset=getattr(task.cfg,'scene_asset_path',None),
        limits=['triangulation is authored geometry; PhysX cooked/SDF shape differs',
                'finite native/FK sample sweeps do not prove between-sample CCD'])
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    (out/'scene_geometry.json').write_text(json.dumps(report,default=lambda value:value.tolist())+'\n')
    return report

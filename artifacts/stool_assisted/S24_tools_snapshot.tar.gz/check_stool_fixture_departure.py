"""Offline real-CAD regressions for the narrow initial-fixture departure rule.

Uses immutable S03 measured native snapshots and captured commands. Counter-
examples change only offline fixture/configuration values, never simulator state.
The production __call__ is exercised with read-only snapshot facades; no SDK is
created and no command is published. This is not a native episode replay.
"""
from __future__ import annotations
import argparse,copy,hashlib,json
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from scipy.spatial.transform import Rotation
from stool_geometry_guard import StoolMeshGuard,ARM,_inverse
from stool_sweep_model import SceneModel
from compare_stool_geometry_cache import build_checker,native_matrix
from toolkits.constraint_checking.integration.entity_geometry import pose_matrix


def load(path):return json.loads(path.read_text())
def rows(path):return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',type=Path,required=True);parser.add_argument('--output-dir',type=Path,required=True)
    args=parser.parse_args();run=args.run.resolve();out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=False)
    report=dict(passed=False,native_physics_executed=0,sdk_commands_published=0,cases=[],errors=[])
    files={name:run/name for name in ('scene_geometry.json','stool_geometry_initial.json','task_config_snapshot.json',
        'stool_production_geometry.jsonl','independent_native_trace.jsonl','assisted_trace.jsonl','motion_trace.jsonl')}
    report['input_sha256']={name:sha(path) for name,path in files.items()}
    report['production_guard_sha256']=sha(Path(__file__).with_name('stool_geometry_guard.py'))
    try:
        data=load(files['scene_geometry.json']);initial=load(files['stool_geometry_initial.json'])
        config=load(files['task_config_snapshot.json']);config=config[0] if isinstance(config,list) else config
        phases={value['name']:value for value in config['phase_specs']}
        failure=[row for row in rows(files['stool_production_geometry.jsonl']) if not row['passed']][0]
        stamp=failure['physics_stamp'];raw=[row for row in rows(files['independent_native_trace.jsonl']) if row.get('valid') and row['physics_stamp']==stamp][-1]
        events=rows(files['assisted_trace.jsonl']);part='fabrica_stool_circular_3'
        attach=[row for row in events if row.get('event')=='attach_measured_pose' and row.get('object')==part and row['physics_stamp']['index']<=stamp['index']][-1]
        batch=[row for row in events if row.get('event')=='fabrica_final_published_batch' and row['physics_stamp']['index']<stamp['index']][-1]
        limits={row['robot']:np.asarray(row['limits_rad'],float) for row in events if row.get('event')=='native_arm_joint_limits'}
        phase=copy.deepcopy(phases[failure['phase']]);holder=attach['robot']
        actual_q={name:np.asarray(value['positions'],float) for name,value in raw['robots'].items()}
        native={name:np.asarray(value,float) for name,value in data['body_rest'].items()}
        native.update({name:native_matrix(value['transform']) for name,value in raw['bodies'].items()})
        hand=data['robots'][holder]['root_path']+'/wrist_3_link';body=data['object_body_coverage'][part][0]
        frozen=_inverse(pose_matrix(attach['native_hand_position'],attach['native_hand_orientation']))@pose_matrix(attach['position'],attach['orientation'])
        quaternion=Rotation.from_matrix(frozen[:3,:3]).as_quat()[[3,0,1,2]].tolist()
        attach_spec=next(item for item in phases[attach['phase']]['attach'] if item['object']==part)
        state=dict(robot_name=holder,hand_object_position=frozen[:3,3].tolist(),hand_object_orientation=quaternion,
            capture_physics_stamp=attach['physics_stamp'],attach_spec=attach_spec)
        model=SceneModel(files['scene_geometry.json']);checker=build_checker(StoolMeshGuard,data,initial,model)
        checker.robot_bodies={mesh['body'] for mesh in data['visible_meshes'] if mesh['robot']}
        checker.object_bodies={name:data['object_body_coverage'][name][0] for name in data['task_objects']}
        actions=copy.deepcopy(batch['actions'])
        motion=[row for row in rows(files['motion_trace.jsonl']) if row['step']==failure['step'] and row['robot']==holder][-1]
        actions[holder]['arm_joint_controller']=[np.asarray(motion['command_q'],np.float32).astype(float).tolist()]
        configs={value['name']:value for value in config['robots']}
        original_meshes=checker.meshes;original_support=copy.deepcopy(checker.initial_support)
        case_native=copy.deepcopy(native);case_phase=copy.deepcopy(phase);case_state=copy.deepcopy(state)
        def make_task():
            robots={name:SimpleNamespace(config=SimpleNamespace(**configs[name]),
                articulation=SimpleNamespace(get_joint_positions=lambda n=name:actual_q[n].copy())) for name in actual_q}
            task=SimpleNamespace(robots=robots,_attachments={part:copy.deepcopy(case_state)},phase=failure['phase'],step_counter=failure['step'],
                _assisted_published_q={name:value['arm_joint_controller'][0] for name,value in batch['actions'].items()})
            task.get_current_phase_spec=lambda:case_phase
            task._beam_physics_stamp=lambda:copy.deepcopy(stamp)
            task._assisted_arm_joint_limits=lambda name:limits[name].copy()
            return task
        def execute(name,expected,mutation=None,commands=None):
            nonlocal case_native,case_phase,case_state
            case_native=copy.deepcopy(native);case_phase=copy.deepcopy(phase);case_state=copy.deepcopy(state)
            checker.meshes=original_meshes;checker.initial_support=copy.deepcopy(original_support)
            if mutation:mutation()
            checker.task=make_task();checker.monitor=SimpleNamespace(current_poses=lambda:copy.deepcopy(case_native))
            checker.out=out/name;checker.out.mkdir();checker.calls=0;checker.samples=0
            captured_before=copy.deepcopy(checker.task._attachments)
            before=json.dumps(dict(native={key:value.tolist() for key,value in case_native.items()},
                q={key:value.tolist() for key,value in actual_q.items()},phase=case_phase,state=case_state),sort_keys=True)
            error=None;result=None
            try:result=checker(copy.deepcopy(actions if commands is None else commands));passed=True
            except (RuntimeError,ValueError) as exc:error=repr(exc);passed=False
            after=json.dumps(dict(native={key:value.tolist() for key,value in case_native.items()},
                q={key:value.tolist() for key,value in actual_q.items()},phase=case_phase,state=case_state),sort_keys=True)
            path=checker.out/'stool_production_geometry.jsonl';evidence=rows(path)[-1] if path.exists() else None
            record=dict(name=name,expected_accept=expected,accepted=passed,expectation_met=passed==expected,
                input_snapshot_unchanged=before==after,error=error,sampled_scene_count=checker.samples,
                frozen_attachment_state_unchanged=captured_before==checker.task._attachments,
                evidence=evidence,returned_actions=result,
                fixture_class='actual same-clock S03 native/CAD' if name=='actual_S03_departure' else 'offline counterfactual on the same real CAD/native fixture')
            report['cases'].append(record)
            if passed!=expected or before!=after or captured_before!=checker.task._attachments:raise ValueError('regression failed: '+name)
            return record
        positive=execute('actual_S03_departure',True)
        if (len(positive['evidence']['qualified_fixture_departures'])!=1 or checker.samples!=failure['requested_sample_count'] or
            positive['evidence']['pair_count']!=failure['pair_count'] or positive['evidence']['meshes']!=failure['meshes']):
            raise ValueError('positive changed original full-scene/sample coverage')
        if positive['returned_actions']!=actions:raise ValueError('positive changed the already bounded captured float32 targets')
        execute('downward_phase_offset',False,lambda:case_phase['local_skill'].update(offset=[0.,0.,-.1]))
        execute('non_world_offset',False,lambda:case_phase['local_skill'].update(offset_frame='tcp'))
        execute('not_a_held_vertical_retreat',False,lambda:case_phase['local_skill'].update(requires_held_object=False))
        execute('unregistered_initial_pair',False,lambda:checker.initial_support.clear())
        key=next(key for key,value in original_support.items() if value['part']==part and value['environment']=='fabrica_fixture')
        execute('over_existing_initial_depth_cap',False,
            lambda:checker.initial_support[key].update(initial_depth_m=failure['first_failure']['collision']['depth_m']-1.001e-6))
        def not_fixture():
            checker.meshes=[dict(mesh,object='optical_board') if mesh['prim']==failure['first_failure']['collision']['mesh_a'] else mesh for mesh in original_meshes]
        execute('non_fixture_environment_pair',False,not_fixture)
        def native_overlap():case_native[body]=case_native[hand]@frozen
        execute('native_pair_has_real_mesh_hit',False,native_overlap)
        hold=copy.deepcopy(actions);names=data['robots'][holder]['joint_names'];arm=[names.index(value) for value in ARM]
        hold[holder]['arm_joint_controller']=[actual_q[holder][arm].tolist()]
        later=execute('subsequent_fraction_still_overlapping',False,commands=hold)
        if not later['evidence'] or later['evidence']['first_failure']['fraction']<=0.:
            raise ValueError('later-overlap negative did not reach a later original sample')
        down=copy.deepcopy(actions);goal=np.asarray(actions[holder]['arm_joint_controller'][0],float)
        down[holder]['arm_joint_controller']=[(2*actual_q[holder][arm]-goal).tolist()]
        downward=execute('real_FK_command_moves_down',False,commands=down)
        if not any(not segment['passed'] for review in downward['evidence']['fixture_departure_reviews']
            for segment in review['per_segment_all_cad_vertex_z_deltas']):
            raise ValueError('downward FK negative did not exercise CAD-vertex ascent gate')
        def drift():case_state['hand_object_position'][0]+=.008
        execute('frozen_relation_drift_envelope_exceeded',False,drift)
        def other_object_overlap():case_native[checker.object_bodies['fabrica_stool_circular_5']]=case_native[body].copy()
        execute('another_part_collision_not_exempted',False,other_object_overlap)
        # Pure geometric rotation counterexample: centroid rises, but some actual
        # CAD vertices descend. This is a classifier fixture, not native motion.
        checker.meshes=original_meshes
        start=native[hand]@frozen;rotated=start.copy();rotated[:3,:3]=Rotation.from_rotvec([.02,0.,0.]).as_matrix()@start[:3,:3]
        rotated[2,3]+=5e-5
        review=dict(object=part,per_segment_all_cad_vertex_z_deltas=[],subsequent_checked_fractions=[])
        rise=checker._fixture_departure_ascent(review,{body:start},{body:rotated},1.)
        report['cases'].append(dict(name='rotated_part_some_vertices_descend_despite_centroid_rise',accepted=rise,
            expected_accept=False,expectation_met=not rise,input_snapshot_unchanged=True,evidence=review,
            fixture_class='rigid CAD rotation counterexample; no claim of a native/FK trajectory'))
        if rise:raise ValueError('rotation counterexample passed the all-CAD-vertex gate')
        report.update(inputs_unchanged=all(sha(path)==report['input_sha256'][name] for name,path in files.items()),
            frozen_relation_and_targets_unchanged=True,collision_threshold_m=1e-6,initial_support_additive_cap_m=1e-6,
            production_control_scope='one guard file; no cache, no new production dependency, no payload reanchor or new targets')
        report['passed']=report['inputs_unchanged'] and all(row['expectation_met'] for row in report['cases'])
    except Exception as exc:report['errors'].append(type(exc).__name__+': '+str(exc))
    (out/'fixture_departure_regression.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({key:report.get(key) for key in ('passed','inputs_unchanged','errors')},ensure_ascii=False))
    return 0 if report['passed'] else 1

if __name__=='__main__':raise SystemExit(main())

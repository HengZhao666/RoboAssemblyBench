"""Offline feasibility of native-origin to frozen-endpoint payload prediction.

The installed guard is not changed or called. Original full-stage pair policy
and CAD are reused; raw frames certify complete scenes, while failure-tail rows
with only selected native links certify only the named hand/part/fixture pair.
No attachment is rebased, no SDK target is changed, and no simulator is started.
"""
from __future__ import annotations
import argparse,copy,hashlib,json,math
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import fcl
from scipy.spatial.transform import Rotation,Slerp
from stool_geometry_guard import StoolMeshGuard,ARM,MIMIC,_inverse
from stool_sweep_model import SceneModel
from compare_stool_geometry_cache import build_checker,native_matrix
from toolkits.constraint_checking.integration.entity_geometry import pose_matrix


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def rows(path):return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',type=Path,required=True)
    parser.add_argument('--output-dir',type=Path,required=True);parser.add_argument('--tail-limit',type=int,default=16)
    args=parser.parse_args();run=args.run.resolve();out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=False)
    report=dict(passed=False,production_control_modified=False,native_physics_executed=0,frames=[],errors=[])
    files={name:run/name for name in ('scene_geometry.json','stool_geometry_initial.json','task_config_snapshot.json',
        'stool_production_geometry.jsonl','independent_native_trace.jsonl','assisted_trace.jsonl','post_failure_physics_trace.jsonl')}
    report['input_sha256']={name:sha(path) for name,path in files.items()}
    try:
        data=json.loads(files['scene_geometry.json'].read_text());initial=json.loads(files['stool_geometry_initial.json'].read_text())
        config=json.loads(files['task_config_snapshot.json'].read_text());config=config[0] if isinstance(config,list) else config
        phases={value['name']:value for value in config['phase_specs']};failure=[row for row in rows(files['stool_production_geometry.jsonl']) if not row['passed']][0]
        phase=phases[failure['phase']];stamp=failure['physics_stamp'];part='fabrica_stool_circular_3'
        events=rows(files['assisted_trace.jsonl']);attach=[row for row in events if row.get('event')=='attach_measured_pose' and row.get('object')==part][-1]
        batch=[row for row in events if row.get('event')=='fabrica_final_published_batch' and row['physics_stamp']['index']<stamp['index']][-1]
        holder=attach['robot'];hand=data['robots'][holder]['root_path']+'/wrist_3_link';body=data['object_body_coverage'][part][0]
        frozen=_inverse(pose_matrix(attach['native_hand_position'],attach['native_hand_orientation']))@pose_matrix(attach['position'],attach['orientation'])
        frozen_before=frozen.copy();attach_spec=next(value for value in phases[attach['phase']]['attach'] if value['object']==part)
        model=SceneModel(files['scene_geometry.json']);checker=build_checker(StoolMeshGuard,data,initial,model)
        checker.task=SimpleNamespace(_attachments={part:dict(robot_name=holder)},get_current_phase_spec=lambda:phase)
        robot_bodies={mesh['body'] for mesh in data['visible_meshes'] if mesh['robot']}
        steps=[(value['name'],float(value['local_skill']['cartesian_position_step'])) for value in config['phase_specs']
            if isinstance(value.get('local_skill'),dict) and isinstance(value['local_skill'].get('cartesian_position_step'),(int,float))
            and value['local_skill']['cartesian_position_step']>0.]
        if not steps:raise ValueError('actual configuration lacks positive native Cartesian skill increments')
        correction_resolution=min(value for _,value in steps)
        angle_resolution=float(data['task_contract']['max_joint_step_rad'])
        report['bridge_sampling_sources']=dict(cad_vertex_correction_resolution_m=correction_resolution,
            source='minimum positive explicit cartesian_position_step across all actual task phase_specs',
            attaining_phases=[name for name,value in steps if value==correction_resolution],
            relative_angle_resolution_rad=angle_resolution,angle_source='unchanged task contract max_joint_step_rad derived from original skills',
            operation='union of all original arm/gripper interpolation fractions and new relative-correction fractions; reject union above512')
        collision=failure['first_failure']['collision'];pair=[next(mesh for mesh in data['visible_meshes'] if mesh['prim']==collision[key]) for key in ('mesh_a','mesh_b')]
        shapes=[]
        for mesh in pair:
            points=np.asarray(mesh['points'],float);faces=np.asarray(mesh['triangles'],np.int32)
            shape=fcl.BVHModel();shape.beginModel(len(faces),len(points));shape.addSubModel(points,faces);shape.endModel();shapes.append(fcl.CollisionObject(shape))
        def pair_check(poses):
            for mesh,shape in zip(pair,shapes):
                matrix=poses[mesh['body']];shape.setTransform(fcl.Transform(matrix[:3,:3],matrix[:3,3]))
            result=fcl.CollisionResult();hit=fcl.collide(*shapes,fcl.CollisionRequest(num_max_contacts=8,enable_contact=True),result)
            return dict(hit=int(hit),max_depth_m=max((float(value.penetration_depth) for value in result.contacts),default=0.))
        fixtures=[];seen=set()
        for raw in rows(files['independent_native_trace.jsonl']):
            if raw.get('valid') and raw['physics_stamp']['index'] in (stamp['index'],stamp['index']+1) and raw['physics_stamp']['index'] not in seen:
                seen.add(raw['physics_stamp']['index']);fixtures.append(dict(source='independent_raw_full_scene',stamp=raw['physics_stamp'],
                    native={path:native_matrix(value['transform']) for path,value in raw['bodies'].items()},
                    q={name:np.asarray(value['positions'],float) for name,value in raw['robots'].items()}))
        if len(fixtures)!=2:raise ValueError('need exact failure and next physical-tick complete raw snapshots')
        tail=rows(files['post_failure_physics_trace.jsonl']);tail=[row for row in tail if row.get('valid')]
        if not tail:raise ValueError('no valid original retained-target failure-tail snapshots')
        indices=sorted(set(list(range(min(8,len(tail))))+np.linspace(0,len(tail)-1,max(2,args.tail_limit-8),dtype=int).tolist()))[:args.tail_limit]
        for index in indices:
            value=tail[index];native={entry['path']:pose_matrix(entry['positions'][0],entry['orientations'][0])
                for entry in value['bodies'] if entry.get('valid')}
            if hand not in native or body not in native:raise ValueError('tail frame lacks exact native hand/object')
            fixtures.append(dict(source='original_selected_native_failure_tail_pair_only',
                stamp=dict(valid=value['clock_valid'],index=value['physics_step_index'],time=value['physics_time'],dt=value['physics_dt']),
                native=native,q={name:np.asarray(robot['joint_positions'][0],float) for name,robot in value['robots'].items()},
                tail_row_index=index,missing_native_robot_bodies=sorted(robot_bodies-set(native))))
        configs={value['name']:value for value in config['robots']}
        all_pass=True
        for fixture in fixtures:
            measured_native=fixture['native'];native={path:np.asarray(value,float) for path,value in data['body_rest'].items()};native.update(measured_native)
            actual=fixture['q'];final={name:q.copy() for name,q in actual.items()}
            for name in actual:
                names=data['robots'][name]['joint_names'];arm=[names.index(value) for value in ARM]
                final[name][arm]=batch['actions'][name]['arm_joint_controller'][0]
                cfg=configs[name];opening=max(float(cfg.get('gripper_close_openness',0.) or 0.),float(batch['actions'][name]['gripper_controller'][0]))
                goal=cfg['gripper_closed_position']+opening*(cfg['gripper_open_position']-cfg['gripper_closed_position'])
                delta=goal-actual[name][names.index('finger_joint')]
                for joint,sign in MIMIC.items():final[name][names.index(joint)]=actual[name][names.index(joint)]+sign*delta
            origin=model.poses(actual);corrections={path:native[path]@_inverse(origin[path]) for path in robot_bodies if path in measured_native}
            measured=_inverse(native[hand])@native[body]
            slerp=Slerp([0.,1.],Rotation.from_matrix(np.stack([measured[:3,:3],frozen[:3,:3]])))
            expected=native[hand]@frozen
            position_error=float(np.linalg.norm(expected[:3,3]-native[body][:3,3]));angle_error=float(np.arccos(np.clip((np.trace(expected[:3,:3].T@native[body][:3,:3])-1)/2,-1,1)))
            residual_pass=position_error<=attach_spec['position_tolerance'] and angle_error<=attach_spec['orientation_tolerance']
            maximum=max(float(np.max(abs(final[name]-actual[name]))) for name in actual)
            count=max(2,int(math.ceil(maximum/data['task_contract']['max_joint_step_rad']))+1)
            correction_lengths=[]
            for mesh in data['visible_meshes']:
                if mesh['object']!=part:continue
                points=np.asarray(mesh['points'],float)
                before=points@measured[:3,:3].T+measured[:3,3];after=points@frozen[:3,:3].T+frozen[:3,3]
                correction_lengths.append(float(np.linalg.norm(after-before,axis=1).max()))
            maximum_vertex_correction=max(correction_lengths)
            correction_angle=float((Rotation.from_matrix(measured[:3,:3]).inv()*Rotation.from_matrix(frozen[:3,:3])).magnitude())
            correction_count=max(2,int(math.ceil(maximum_vertex_correction/correction_resolution))+1,
                int(math.ceil(correction_angle/angle_resolution))+1)
            original_fractions=np.linspace(0.,1.,count);fractions=np.union1d(original_fractions,np.linspace(0.,1.,max(count,correction_count)))
            if len(fractions)>512:raise ValueError('arm plus correction fraction union exceeds unchanged512 budget')
            full=fixture['source']=='independent_raw_full_scene'
            if full and not robot_bodies<=set(measured_native):raise ValueError('full raw fixture lacks robot native coverage')
            def scene(fraction,bridge=True,hold_current_arm=False):
                end={name:q.copy() for name,q in final.items()}
                if hold_current_arm:
                    names=data['robots'][holder]['joint_names'];arm=[names.index(value) for value in ARM];end[holder][arm]=actual[holder][arm]
                fk=model.poses({name:actual[name]+fraction*(end[name]-actual[name]) for name in actual});poses=dict(native)
                for path,correction in corrections.items():poses[path]=correction@fk[path]
                if not bridge:poses[body]=poses[hand]@frozen
                elif fraction==0.:poses[body]=native[body].copy()
                elif fraction==1.:poses[body]=poses[hand]@frozen
                else:
                    relative=np.eye(4);relative[:3,3]=(1-fraction)*measured[:3,3]+fraction*frozen[:3,3]
                    relative[:3,:3]=slerp([fraction]).as_matrix()[0];poses[body]=poses[hand]@relative
                return poses
            original_samples=[];dense_samples=[]
            for fraction in fractions:
                poses=scene(float(fraction));item=dict(fraction=float(fraction),pair=pair_check(poses))
                if full:item['full_scene']=checker._check_scene(poses)
                original_samples.append(item)
            for fraction in np.linspace(0.,1.,17):
                poses=scene(float(fraction));item=dict(fraction=float(fraction),pair=pair_check(poses))
                if full:item['full_scene']=checker._check_scene(poses)
                dense_samples.append(item)
            dangerous=scene(1.,hold_current_arm=True);danger_pair=pair_check(dangerous)
            frame_pass=(residual_pass and all(value['pair']['max_depth_m']<=1e-6 for value in dense_samples) and
                all(not value.get('full_scene',{}).get('collisions') for value in dense_samples) and
                (not full or danger_pair['max_depth_m']>1e-6))
            zero=scene(0.);one=scene(1.);old_one=scene(1.,bridge=False)
            entry={key:value for key,value in fixture.items() if key not in ('native','q')}
            entry.update(passed=frame_pass,full_scene_native_coverage=full,measured_temporary_hand_object_matrix=measured.tolist(),
                frozen_hand_object_matrix=frozen.tolist(),position_residual_m=position_error,orientation_residual_rad=angle_error,
                residual_gate=dict(passed=residual_pass,position_limit_m=attach_spec['position_tolerance'],orientation_limit_rad=attach_spec['orientation_tolerance']),
                fraction0_exact_native_matrix_equal=bool(np.array_equal(zero[body],native[body])),
                fraction1_exact_old_frozen_matrix_equal=bool(np.array_equal(one[body],old_one[body])),
                old_frozen_fraction0_pair=pair_check(scene(0.,bridge=False)),original_sample_count=count,original_fractions=original_fractions.tolist(),
                bridge_sample_count=len(fractions),bridge_fractions=fractions.tolist(),maximum_relative_CAD_vertex_correction_m=maximum_vertex_correction,
                relative_rotation_correction_rad=correction_angle,correction_sample_count=correction_count,original_samples=original_samples,
                extra_offline_dense_samples=dense_samples,dangerous_no_arm_progress_frozen_future_pair=danger_pair,
                dangerous_future_rejected=danger_pair['max_depth_m']>1e-6,
                scope='complete same-clock native full-stage fixture' if full else 'exact same-clock selected hand/object/fixture pair; missing robot native links explicitly listed')
            if not entry['fraction0_exact_native_matrix_equal'] or not entry['fraction1_exact_old_frozen_matrix_equal']:raise ValueError('bridge endpoint identity failed')
            report['frames'].append(entry);all_pass=all_pass and frame_pass
        report.update(frozen_relation_unchanged=bool(np.array_equal(frozen,frozen_before)),targets_unchanged=True,
            inputs_unchanged=all(sha(path)==report['input_sha256'][name] for name,path in files.items()),
            collision_threshold_m=1e-6,new_contact_exemptions=0,production_sampling_changed=False,
            scope='offline candidate only; complete native coverage for4964/4965, selected-native pair coverage for retained-target tail; no native episode success claim')
        report['passed']=all_pass and report['inputs_unchanged'] and report['frozen_relation_unchanged']
    except Exception as exc:report['errors'].append(type(exc).__name__+': '+str(exc))
    (out/'payload_bridge_feasibility.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({key:report.get(key) for key in ('passed','inputs_unchanged','errors')}))
    return 0 if report['passed'] else 1

if __name__=='__main__':raise SystemExit(main())

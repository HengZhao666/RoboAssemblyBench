"""Fail-closed authorization/interface checks for the narrow S04 domain review."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec=importlib.util.spec_from_file_location('stool_launcher_test',Path(__file__).with_name('launch_stool.py'))
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)

class ReviewTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);module.ROOT=self.root
  self.prior=self.root/'P05';self.prior.mkdir();self.receipt=self.prior/'startup_preflight_passed.json'
  self.proof=dict(passed=True,robot_sdk_submissions=0,configuration_signature='cfg',control_source_signature='src')
  self.receipt.write_text(json.dumps(self.proof));self.baseline={n:'old-'+n for n in module.CONTROL_TOOLS};(self.prior/'source_binding.json').write_text(json.dumps(dict(tools_manifest=self.baseline)))
  self.tools=dict(self.baseline);self.tools['stool_geometry_guard.py']='new-guard';self.tools['stool_startup_evidence.py']='new-render';self.identity=dict(control_source_signature='src',control_tools_signature='new-tool-sig')
  self.offline=self.root/'offline.json';self.offline.write_text(json.dumps(dict(passed=True,configuration_signature='cfg',tested_control_tools={n:self.tools[n] for n in ['stool_geometry_guard.py','stool_startup_evidence.py']})))
  self.review=dict(for_formal_run='S04',status='reviewed_for_unchanged_domain_reuse',original_startup_receipt_sha256=module.sha(self.receipt),candidate_control_identity=self.identity,changed_control_tools={n:dict(before=self.baseline[n],after=self.tools[n]) for n in ['stool_geometry_guard.py','stool_startup_evidence.py']},offline_preflight=dict(path=str(self.offline),sha256=module.sha(self.offline)))
  self.path=self.root/'review.json'
 def tearDown(self):self.tmp.cleanup()
 def call(self,run='S04',review=None,identity=None,tools=None):
  self.path.write_text(json.dumps(review or self.review));return module.reviewed_startup_reuse(self.path,self.receipt,self.proof,identity or self.identity,tools or self.tools,run)
 def reject(self,**kwargs):
  with self.assertRaises((RuntimeError,KeyError)):self.call(**kwargs)
 def test_exact_two_domains(self):self.assertEqual(len(self.call()['changed_control_tools']),2)
 def test_no_S03_or_S05(self):
  self.reject(run='S03');self.reject(run='S05')
 def test_wrong_source(self):self.reject(identity=dict(self.identity,control_source_signature='changed'))
 def test_wrong_candidate_signature(self):self.reject(identity=dict(self.identity,control_tools_signature='changed'))
 def test_wrong_original_proof(self):self.reject(review=dict(self.review,original_startup_receipt_sha256='changed'))
 def test_unreviewed_extra_tool(self):self.reject(tools=dict(self.tools,stool_worker_py='extra',**{'stool_raw_evidence.py':'new-raw'}))
 def test_missing_delta(self):self.reject(review=dict(self.review,changed_control_tools={}))
 def test_receipt_changed(self):
  self.offline.write_text('{}');self.reject()
 def test_failed_offline_receipt(self):
  d=json.loads(self.offline.read_text());d['passed']=False;self.offline.write_text(json.dumps(d));r=copy.deepcopy(self.review);r['offline_preflight']['sha256']=module.sha(self.offline);self.reject(review=r)
 def test_other_config(self):
  d=json.loads(self.offline.read_text());d['configuration_signature']='other';self.offline.write_text(json.dumps(d));r=copy.deepcopy(self.review);r['offline_preflight']['sha256']=module.sha(self.offline);self.reject(review=r)
 def test_stale_covered_tools(self):
  d=json.loads(self.offline.read_text());d['tested_control_tools']['stool_geometry_guard.py']='old';self.offline.write_text(json.dumps(d));r=copy.deepcopy(self.review);r['offline_preflight']['sha256']=module.sha(self.offline);self.reject(review=r)
 def test_review_status_missing(self):self.reject(review=dict(self.review,status='proposal_only'))

if __name__=='__main__':unittest.main()

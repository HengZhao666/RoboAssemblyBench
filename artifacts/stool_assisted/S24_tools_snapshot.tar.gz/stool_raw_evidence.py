"""Independent exact-path PhysX readers. No pose, velocity or target setters."""
from pathlib import Path
import json
import numpy as np


def array(value):
    """Detach/copy each borrowed frontend buffer before any further SDK read."""
    if hasattr(value, 'detach'):
        value = value.detach()
    if hasattr(value, 'cpu'):
        value = value.cpu()
    if hasattr(value, 'numpy'):
        value = value.numpy()
    result = np.array(value, dtype=float, copy=True)
    if not np.all(np.isfinite(result)):
        raise ValueError('Nonfinite independent native buffer')
    return result


def exact_view_paths(view, expected, label):
    expected = list(expected)
    if not expected or len(set(expected)) != len(expected):
        raise ValueError(label + ': expected paths are empty or duplicated')
    try:
        found = list(view.prim_paths)
        count = getattr(view, 'count', len(found))
    except Exception as exc:
        raise RuntimeError(label + ': native view identity/backend is unavailable') from exc
    if (len(found) != len(expected) or len(set(found)) != len(found)
            or set(found) != set(expected) or int(count) != len(found)):
        raise ValueError(label + ': exact native path membership/count changed')
    return found


def read_raw_body_buffers(view, expected_paths, object_paths):
    """Preserve raw tensor order; index by the paths from that same view."""
    paths = exact_view_paths(view, expected_paths, 'independent rigid bodies')
    if (len(set(object_paths.values())) != len(object_paths)
            or not set(object_paths.values()).issubset(paths)):
        raise ValueError('independent object labels contain aliases or unbound native bodies')
    raw_transforms = view.get_transforms()
    transforms = array(raw_transforms)
    raw_velocities = view.get_velocities()
    velocities = array(raw_velocities)
    if transforms.shape != (len(paths), 7) or velocities.shape != (len(paths), 6):
        raise ValueError('Independent body buffers changed shape')
    norms = np.linalg.norm(transforms[:, 3:7], axis=1)
    # PhysX transforms are float32 xyz+xyzw. This is representation sanity,
    # not a physical pose tolerance; retain the original values unchanged.
    norm_tolerance = 64 * np.finfo(np.float32).eps
    if np.any(np.abs(norms - 1.) > norm_tolerance):
        raise ValueError('Independent body transforms contain non-unit xyzw quaternions')
    if exact_view_paths(view, expected_paths, 'independent rigid bodies') != paths:
        raise ValueError('Independent body order changed during the buffer read')
    bodies = {path: dict(transform=transforms[index].tolist(), velocity=velocities[index].tolist())
              for index, path in enumerate(paths)}
    return dict(bodies=bodies, objects={name: dict(path=path, **bodies[path])
        for name, path in object_paths.items()}, body_buffer_metadata={
            'native_path_order': paths, 'native_count': len(paths),
            'transform_frontend': type(raw_transforms).__module__ + '.' + type(raw_transforms).__name__,
            'velocity_frontend': type(raw_velocities).__module__ + '.' + type(raw_velocities).__name__,
            'transform_shape': list(transforms.shape), 'velocity_shape': list(velocities.shape),
            'orientation_order': 'xyzw', 'quaternion_norms': norms.tolist(),
            'quaternion_norm_sanity_atol': float(norm_tolerance), 'copied_before_next_native_read': True})


def read_raw_articulation_buffers(view, identity, expected_joint_names):
    """Validate native metadata before labeling a complete independent DOF row."""
    path = identity['native_articulation_path']
    exact_view_paths(view, [path], 'independent articulation')
    expected_names = list(expected_joint_names)
    if not expected_names or len(set(expected_names)) != len(expected_names):
        raise ValueError('Expected complete native DOF names are empty or duplicated')
    metatype = getattr(view, 'shared_metatype', None)
    native_names = list(getattr(metatype, 'dof_names', []) or [])
    if native_names != expected_names:
        raise ValueError('Independent native DOF metadata/order differs from the configured wrapper')
    count = int(getattr(view, 'max_dofs', len(native_names)))
    if count != len(native_names):
        raise ValueError('Independent native maximum DOF count differs from complete DOF metadata')
    raw_q = view.get_dof_positions()
    q = array(raw_q)
    raw_qd = view.get_dof_velocities()
    qd = array(raw_qd)
    raw_targets = view.get_dof_position_targets()
    targets = array(raw_targets)
    expected_shape = (1, len(native_names))
    if q.shape != expected_shape or qd.shape != expected_shape or targets.shape != expected_shape:
        raise ValueError('Independent articulation buffers do not match complete native DOF names')
    exact_view_paths(view, [path], 'independent articulation')
    if list(getattr(view.shared_metatype, 'dof_names', []) or []) != native_names:
        raise ValueError('Independent native DOF metadata changed during buffer read')
    return dict(path=path, configured_robot_root=identity['configured_robot_root'],
        identity=dict(identity), view_id=id(view), joint_names=native_names,
        positions=q[0].tolist(), velocities=qd[0].tolist(), position_targets=targets[0].tolist(),
        dof_buffer_metadata={'native_dof_count': len(native_names), 'native_dof_order_verified': True,
            'joint_names_source': 'separate_PhysX_articulation_view.shared_metatype.dof_names',
            'position_frontend': type(raw_q).__module__ + '.' + type(raw_q).__name__,
            'velocity_frontend': type(raw_qd).__module__ + '.' + type(raw_qd).__name__,
            'target_frontend': type(raw_targets).__module__ + '.' + type(raw_targets).__name__,
            'shape': list(expected_shape), 'copied_before_next_native_read': True})


def create_independent_articulation_reader(sim, robot, expected_root):
    """Select identity from the live wrapper; read state only in a new view.

    A referenced robot container and its PhysX articulation root need not be
    the same USD prim. The existing wrapper is used only to identify that
    native articulation, never as a fallback source for independent states.
    """
    root = str(expected_root).rstrip('/')
    if (not root.startswith('/') or not root or root == '/'
            or any(token in root for token in ('*', '?', '[', ']'))):
        raise RuntimeError('Expected robot namespace is not an exact absolute prim root')
    wrapper = getattr(robot, 'articulation', None)
    wrapper_root = str(getattr(wrapper, '_root_prim_path', '')).rstrip('/')
    if wrapper_root != root:
        raise RuntimeError('Existing robot wrapper belongs to a different configured root: ' + wrapper_root)
    articulation_view = getattr(wrapper, '_articulation_view', None)
    existing = getattr(articulation_view, '_physics_view', None)
    if existing is None:
        raise RuntimeError('Existing robot wrapper has no initialized native articulation view: ' + root)
    valid = getattr(articulation_view, 'is_physics_handle_valid', None)
    if callable(valid) and not valid():
        raise RuntimeError('Existing robot native articulation handle is invalid: ' + root)
    try:
        source_paths = list(existing.prim_paths)
    except Exception as exc:
        raise RuntimeError('Cannot read existing native articulation identity: ' + root) from exc
    if len(source_paths) != 1:
        raise RuntimeError('Existing native articulation identity is missing or ambiguous: ' + root)
    actual = str(source_paths[0])
    if (not (actual == root or actual.startswith(root + '/'))
            or any(token in actual for token in ('*', '?', '[', ']'))):
        raise RuntimeError('Existing native articulation path is outside the expected robot namespace: ' + actual)
    independent = sim.create_articulation_view(actual)
    if independent is None or independent is existing:
        raise RuntimeError('Separate native articulation reader was not created: ' + actual)
    try:
        independent_paths = list(independent.prim_paths)
    except Exception as exc:
        raise RuntimeError('Separate native articulation reader has no valid backend: ' + actual) from exc
    if independent_paths != [actual]:
        raise RuntimeError('Separate articulation reader identity differs from the exact existing path: ' + actual)
    identity = dict(configured_robot_root=root, native_articulation_path=actual,
        existing_wrapper_view_id=id(articulation_view), existing_physics_view_id=id(existing),
        independent_physics_view_id=id(independent),
        identity_source='existing_wrapper._articulation_view._physics_view.prim_paths',
        state_source='separate_exact_path_PhysX_articulation_view')
    return independent, identity


def raw_sample_due(boundary, *, final, task_step, physics_stamp):
    """Keep production cadence; tail task ticks freeze while native ticks advance."""
    if boundary == 'post_failure_after_physics':
        index, epoch = physics_stamp.get('index'), physics_stamp.get('epoch')
        try:
            clock_valid = (physics_stamp.get('valid') is True
                and type(index) is int and index >= 0
                and type(epoch) is int and epoch >= 0
                and np.isfinite(float(physics_stamp['time'])) and float(physics_stamp['time']) >= 0.
                and np.isfinite(float(physics_stamp['dt'])) and float(physics_stamp['dt']) > 0.)
        except (KeyError, TypeError, ValueError):
            clock_valid = False
        if not clock_valid:
            raise ValueError('Post-failure raw cadence lacks a valid native physics clock')
        return bool(final or index % 8 == 0)
    return bool(boundary in {'startup', 'terminal', 'control_failure', 'base_support_acquire', 'base_support_open', 'base_support_hold', 'base_support_enter'}
                or final or int(task_step) % 8 == 0)


def install_raw_sampler(task, out):
    from isaacsim.core.simulation_manager import SimulationManager
    from isaacsim.core.utils.stage import get_current_stage
    from pxr import Usd, UsdPhysics
    stamp = task._beam_physics_stamp()
    sim = SimulationManager.get_physics_sim_view()
    if sim is None:
        raise RuntimeError('No existing native physics simulation view')
    expected = list(task._fabrica_assisted_contract['objects'])
    if not expected or len(set(expected)) != len(expected):
        raise RuntimeError('Independent raw object manifest is empty or duplicated')
    object_paths = {name: task._assisted_body_path(name)[1] for name in expected}
    if len(set(object_paths.values())) != len(object_paths):
        raise RuntimeError('Different task objects resolved to the same independent native body')
    stage = get_current_stage()
    robot_paths = {}
    robot_bodies = []
    for name, robot in task.robots.items():
        root = str(robot.articulation._root_prim_path)
        robot_paths[name] = root
        for prim in Usd.PrimRange(stage.GetPrimAtPath(root), Usd.TraverseInstanceProxies()):
            if prim.HasAPI(UsdPhysics.RigidBodyAPI):
                robot_bodies.append(str(prim.GetPath()))
    paths = sorted(set(object_paths.values()) | set(robot_bodies))
    bodies = sim.create_rigid_body_view(paths)
    found = exact_view_paths(bodies, paths, 'independent rigid bodies')
    articulations = {}
    articulation_identities = {}
    expected_dof_names = {}
    for name, root in robot_paths.items():
        view, identity = create_independent_articulation_reader(sim, task.robots[name], root)
        articulations[name] = view
        articulation_identities[name] = identity
        expected_dof_names[name] = list(task.robots[name].articulation.dof_names)
    actual_paths = [identity['native_articulation_path'] for identity in articulation_identities.values()]
    if len(actual_paths) != len(set(actual_paths)):
        raise RuntimeError('Different robots resolved to the same native articulation')
    sequence = 0

    def sample(boundary):
        nonlocal sequence
        stamp_before = task._beam_physics_stamp()
        # Full cadence through the final native window; bounded stride elsewhere.
        final = task.phase == task._fabrica_assisted_contract['final_phase_name']
        cadence_error = None
        try:
            if not raw_sample_due(boundary, final=final, task_step=task.step_counter,
                                  physics_stamp=stamp_before):
                return None
        except ValueError as exc:
            # Preserve this exact invalid clock as an invalid row; no neighbour
            # sample or frozen task tick may manufacture tail completeness.
            cadence_error = str(exc)
        row = dict(kind='independent_raw', sequence=sequence, boundary=boundary,
                   phase=task.phase, task_step=int(task.step_counter),
                   physics_stamp=stamp_before, source='separate_exact_path_PhysX_tensor_views',
                   body_view_id=id(bodies), orientation_order='xyzw',
                   pose_frame='world', velocity_reference='center_of_mass', valid=False)
        try:
            if cadence_error is not None:
                raise ValueError(cadence_error)
            row.update(read_raw_body_buffers(bodies, found, object_paths))
            row['robots'] = {}
            for name, view in articulations.items():
                names = list(task.robots[name].articulation.dof_names)
                if names != expected_dof_names[name]:
                    raise ValueError('Existing wrapper DOF metadata changed after raw-view binding: ' + name)
                row['robots'][name] = read_raw_articulation_buffers(
                    view, articulation_identities[name], expected_dof_names[name])
            row['valid'] = bool(stamp_before.get('valid') and task._beam_physics_stamp() == stamp_before)
        except Exception as exc:
            row['error'] = repr(exc)
        with (Path(out) / 'independent_native_trace.jsonl').open('a') as stream:
            stream.write(json.dumps(row, allow_nan=False, separators=(',', ':')) + '\n')
        sequence += 1
        return dict(valid=row['valid'], physics_stamp=stamp_before, sequence=row['sequence'],
                    body_paths=found, objects=object_paths, error=row.get('error'),
                    source=row['source'], path='independent_native_trace.jsonl',
                    articulation_identities=articulation_identities)

    task._fabrica_independent_raw_sampler = sample
    initial = sample('startup')
    if not initial['valid'] or task._beam_physics_stamp() != stamp:
        raise RuntimeError('Independent native startup read failed: ' + str(initial))
    return initial

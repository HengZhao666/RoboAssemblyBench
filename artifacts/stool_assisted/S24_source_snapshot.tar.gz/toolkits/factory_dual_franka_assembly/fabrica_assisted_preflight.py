"""Task-scoped Fabrica contract validation; no simulator construction or physics.

This validates the actual compiled model, including framework environment aliases.
It is deliberately separate from native geometry/contact and completion evidence.
"""
from __future__ import annotations
import math
from .beam_assisted_preflight import (_get, _plain, _signature, _vector,
    _home_robot_configs, configuration_signature, AssistedConfigurationError,
    SUPPORTED_ADVANCE_TYPES)

STOOL_OBJECTS = frozenset('fabrica_stool_circular_' + str(i) for i in range(9))

STOOL_PRECISE_DESCEND_OBJECTS = {'assemble_03_part_4_descend': 'fabrica_stool_circular_4', 'assemble_04_part_5_descend': 'fabrica_stool_circular_5', 'assemble_05_part_1_descend': 'fabrica_stool_circular_1', 'assemble_06_part_0_descend': 'fabrica_stool_circular_0', 'assemble_07_part_8_descend': 'fabrica_stool_circular_8'}

STOOL_SE3_TRANSPORT_OBJECTS = {'assemble_02_part_6_transport_hover': 'fabrica_stool_circular_6', 'assemble_03_part_4_transport_hover': 'fabrica_stool_circular_4', 'assemble_04_part_5_transport_hover': 'fabrica_stool_circular_5', 'assemble_05_part_1_transport_hover': 'fabrica_stool_circular_1', 'assemble_06_part_0_transport_hover': 'fabrica_stool_circular_0', 'assemble_07_part_8_transport_hover': 'fabrica_stool_circular_8'}

STOOL_SE3_CLEARANCE_OBJECTS = {
    'assemble_00_part_3_pickup_clearance': 'fabrica_stool_circular_3',
    'assemble_00_part_3_assembly_clearance': 'fabrica_stool_circular_3',
    'assemble_01_part_7_pickup_clearance': 'fabrica_stool_circular_7',
    'assemble_01_part_7_assembly_clearance': 'fabrica_stool_circular_7',
    'assemble_02_part_6_pickup_clearance': 'fabrica_stool_circular_6',
    'assemble_02_part_6_assembly_clearance': 'fabrica_stool_circular_6',
    'assemble_03_part_4_pickup_clearance': 'fabrica_stool_circular_4',
    'assemble_03_part_4_assembly_clearance': 'fabrica_stool_circular_4',
    'assemble_04_part_5_pickup_clearance': 'fabrica_stool_circular_5',
    'assemble_04_part_5_assembly_clearance': 'fabrica_stool_circular_5',
    'assemble_05_part_1_pickup_clearance': 'fabrica_stool_circular_1',
    'assemble_05_part_1_assembly_clearance': 'fabrica_stool_circular_1',
    'assemble_06_part_0_pickup_clearance': 'fabrica_stool_circular_0',
    'assemble_06_part_0_assembly_clearance': 'fabrica_stool_circular_0',
    'assemble_07_part_8_pickup_clearance': 'fabrica_stool_circular_8',
    'assemble_07_part_8_assembly_clearance': 'fabrica_stool_circular_8',
}


STOOL_SUPPORT_REPOSITION_SHA256 = 'b3e4a45dd70a753c7ef36265e3439a9ba327fb02001107aa6c3e81f9c3a44278'

STOOL_SUPPORT_ROUTE_PLAN_SHA256 = '1d4c9d3a1e86a75e5de1732e5fe064e49ccf0699d4a2c094fe9bf81ddf866937'


STOOL_PART5_PICKUP_OFFSET_SHA256 = '05765f70cebf454bc0dd1afe31d46aeefdcc5047c488ff39675b535ac9b05237'

def assert_fabrica_assisted_configuration(config_or_task, *, full_mode=True):
    config = _get(config_or_task, 'cfg', _get(config_or_task, 'config', config_or_task))
    runtime = config is not config_or_task
    metadata = _get(config, 'benchmark_metadata', {}) or {}
    contract = metadata.get('fabrica_assisted_contract', {})
    phases = _get(config_or_task, 'phase_specs', _get(config, 'phase_specs', []))
    targets = _get(config_or_task, 'target_poses', _get(config, 'target_poses', {}))
    criteria = _get(config, 'success_criteria', [])
    errors = []
    pickup_routing=contract.get('part5_pickup_clearance_routing')
    def check(value, message):
        if not value: errors.append(message)
    check(contract.get('adapter') == 'stool_circular_ur5e_v1', 'explicit stool adapter contract is required')
    check(contract.get('assembly') == 'stool_circular', 'stool assembly contract mismatch')
    cad=contract.get('cad_pinch', {})
    check(contract.get('grasp_qualification') == 'dual_native_visible_pad_CAD_near_fit', 'stool requires native visible pad CAD near-fit')
    check(cad.get('schema') == 'stool_visible_pad_near_fit_v1', 'stool CAD pinch schema missing')
    check(cad.get('units') == {'distance':'m','driver':'rad','orientation':'rad'}, 'stool CAD units invalid')
    check(cad.get('grasp_region_frame') == 'native_wrist_3_link', 'CAD catalog/native hand region frame missing')
    check(cad.get('pad_mesh_token') == 'fingertipsstep' and cad.get('pad_inner_axis') == 'Y', 'actual fingertip pad face binding missing')
    check(set(cad.get('objects',{})) == STOOL_OBJECTS, 'CAD grasp regions must cover all nine objects')
    try:
        check(0 < cad['target_gap_m'] < cad['max_gap_m'] == contract['install_position_step_m'], 'CAD near-fit gap must derive original stool step')
        check(cad['target_gap_m'] == cad['max_gap_m']/2., 'CAD target near-fit must be half task resolution')
        check(cad['max_center_step_m'] == cad['max_gap_m'], 'CAD center step must derive task position step')
        check(cad['max_center_tracking_lead_m'] == 2.*cad['max_center_step_m'], 'CAD center tracking lead source invalid')
        check(cad['max_joint_step_rad'] == contract['max_joint_step_rad'], 'CAD driver must retain original joint bound')
        check(cad['max_driver_lead_rad'] == contract['max_tracking_error_rad'], 'CAD driver lead must retain original tracking bound')
        check(cad['stable_native_ticks'] == contract['contact_stable_physics_steps'], 'CAD native window changed')
        for obj,row in cad['objects'].items():
            check(row.get('robot') in {'franka_left','franka_right'}, obj+': CAD region robot invalid')
            check(_vector(row.get('object_in_hand_position'),3) and _vector(row.get('object_in_hand_orientation'),4), obj+': catalog CAD region frame invalid')
            check(0 < row['max_center_total_m'] == row['max_grasp_position_error_m'] < 1, obj+': CAD position region invalid')
            check(0 < row['max_grasp_orientation_error_rad'] < 1, obj+': CAD angular region invalid')
            check(0 <= row['driver_open_rad'] < row['driver_closed_rad'] <= 1 and 0 <= row['minimum_sdk_openness'] < 1, obj+': CAD driver interval invalid')
            check(0 <= row['source_closed_openness'] < row['source_preclose_openness'] <= 1 and type(row['source_close_ramp_steps']) is int and row['source_close_ramp_steps']>0, obj+': original closing ramp invalid')
    except (KeyError,TypeError,ValueError):check(False,'CAD pinch contract fields missing/invalid')
    check(set(contract.get('objects', [])) == STOOL_OBJECTS, 'contract must cover exactly nine stool parts')
    check(metadata.get('fabrica_execution_route') == 'assisted', 'explicit Fabrica assisted metadata is required')
    check(metadata.get('formal_physical_success') is False, 'assistance cannot claim formal physical success')
    check(isinstance(phases, list) and bool(phases), 'nonempty phase list required')
    check(isinstance(targets, dict) and bool(targets), 'resolved targets required')
    try:
        robot_configs = _home_robot_configs(config)
    except (TypeError, ValueError) as exc:
        robot_configs = {}; check(False, 'framework robot aliases invalid: ' + str(exc))
    check(set(robot_configs) == {'franka_left', 'franka_right'}, 'two logical UR5e arms required')
    for name, robot in robot_configs.items():
        check(_get(robot, 'type') == 'UR5eRobot', name + ': unexpected robot implementation')
        check(_get(robot, 'hand_link_name') == 'wrist_3_link', name + ': native hand anchor mismatch')
    support = contract.get('base_support', {})
    continuous=support.get('schema')=='stool_continuous_base_support_v3'
    check(continuous and _signature(pickup_routing)==STOOL_PART5_PICKUP_OFFSET_SHA256,'part5 transport offset/source differs from exact reviewed declaration')
    if continuous:
        identity=dict(schema='stool_continuous_base_support_v3',role='base_2_support',robot='franka_right',object='fabrica_stool_circular_2')
        check(all(support.get(k)==v for k,v in identity.items()),'explicit immediate continuous SUPPORT identity required')
        reposition=support.get('reposition',{})
        check(_signature(reposition)==STOOL_SUPPORT_REPOSITION_SHA256,'SUPPORT relocation parameters/evidence differ from frozen geometry declaration')
        points=reposition.get('joint_waypoints_rad',[])
        check(reposition.get('schema')=='stool_support_reposition_v1' and isinstance(points,list) and bool(points)
              and all(isinstance(q,list) and len(q)==6 and all(isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) for x in q) for q in points),
              'SUPPORT relocation requires explicit finite complete6q route')
        expected_row=dict(cad.get('objects',{}).get(identity['object'],{}),
            object_in_hand_position=reposition.get('object_in_hand_position'),
            object_in_hand_orientation=reposition.get('object_in_hand_orientation'))
        check(support.get('cad_row')==expected_row,'SUPPORT changes only declared role pose; original pickup CAD row/region/driver thresholds must remain')
        enter_names=['base_2_support_enter_'+str(i).zfill(2) for i in range(len(points))]
        check(support.get('stable_native_ticks')==contract.get('contact_stable_physics_steps')==12,'SUPPORT acquisition/open must retain twelve native ticks')
        check(support.get('force_support_claimed') is False and support.get('robot_attachment_created') is False and support.get('world_support_retained') is True,'continuous CAD support cannot claim force or rewrite world support')
        canonical=support.get('canonical_phase_names',[]);cycles=support.get('cycles',[]);removed=['base_2_retreat','base_2_park']
        check(isinstance(canonical,list) and len(canonical)==len(set(canonical)),'continuous canonical phase identities missing')
        first='base_2_release_and_lock';last=next((n for n in reversed(canonical) if n.endswith('_release_and_lock')),None)
        valid=first in canonical and last in canonical and canonical.index(first)<canonical.index(last)
        check(valid,'continuous support original release bounds invalid')
        hold=[n for n in canonical[canonical.index(first)+1:canonical.index(last)+1] if n not in removed] if valid else []
        expected=dict(cycle_id='base_support_continuous',moving_object=None,moving_objects=list(contract.get('assembly_order',[])[1:]),
            transport_phase_name=None,enter_after_phase_name=first,exit_after_phase_name=last,enter_phase_names=enter_names,
            acquire_phase_name='base_2_support_acquire',hold_phase_names=hold,open_phase_name='base_2_support_final_open',exit_phase_names=[])
        check(cycles==[expected],'one immediate support lifecycle must span all eight original left parts exactly')
        check(support.get('initial_park_phase_name') is None and support.get('reference_capture_phase_name')==(enter_names[0] if enter_names else None),'continuous support must retain original base-release SDK once at first declared open relocation; no park/recapture')
        route_plan=support.get('motion_route_plan',{});route_rows={None:{'enter':points,'exit':[]}}
        check(route_plan==dict(schema='stool_continuous_no_terminal_park_v1'),'continuous support preserves original no-terminal-park behavior')
        expected_roles={};acquire_names=[expected['acquire_phase_name']];open_names=[expected['open_phase_name']];motion_names=list(expected['enter_phase_names'])+list(expected['exit_phase_names'])
        for stage,names in [('enter',expected['enter_phase_names']),('acquire',acquire_names),('hold',hold),('open',open_names),('exit',expected['exit_phase_names'])]:
            for name in names:expected_roles[name]=dict(identity,cycle_id=expected['cycle_id'],moving_object=None,stage=stage)
        insert_after={first:expected['enter_phase_names']+acquire_names,last:open_names+expected['exit_phase_names']};expected_schedule=[]
        for name in canonical:
            if name in removed:continue
            expected_schedule.append(name);expected_schedule.extend(insert_after.get(name,[]))
        expected_schedule.append(contract.get('final_phase_name'))
        check(support.get('removed_original_phase_names')==removed,'continuous support only replaces original base retreat/park')
        check(support.get('scheduled_phase_names')==expected_schedule and support.get('scheduled_phase_count')==len(expected_schedule),'continuous schedule/count must derive exactly from original left sequence')
    else:
        identity = dict(schema='stool_install_cycle_support_v2',role='base_2_support',robot='franka_right',object='fabrica_stool_circular_2')
        check(all(support.get(k)==v for k,v in identity.items()),'explicit installation-cycle SUPPORT identity required')
        check(support.get('cad_row')==cad.get('objects',{}).get(identity['object']),'SUPPORT row must preserve original base2 catalog geometry')
        check(support.get('stable_native_ticks')==contract.get('contact_stable_physics_steps')==12,'each SUPPORT acquisition/open native window must retain original twelve ticks')
        check(support.get('force_support_claimed') is False and support.get('robot_attachment_created') is False
              and support.get('world_support_retained') is True,'CAD support must retain world support without force-bearing claims')
        canonical=support.get('canonical_phase_names',[]);cycles=support.get('cycles',[]);removed=['base_2_retreat','base_2_park']
        check(isinstance(canonical,list) and all(isinstance(n,str) for n in canonical)
              and len(canonical)==len(set(canonical)), 'canonical phase identities missing')
        check(isinstance(cycles,list) and len(cycles)==8,'exact eight installation support cycles required')
        expected_roles={};insert_after={};acquire_names=[];open_names=[];motion_names=[]
        check(support.get('initial_park_phase_name')=='base_2_support_initial_park','initial support park identity changed')
        expected_roles['base_2_support_initial_park']=dict(identity,cycle_id='base_preparation',moving_object=None,stage='initial_park')
        motion_names.append('base_2_support_initial_park');insert_after['base_2_release_and_lock']=['base_2_support_initial_park']
        route_plan=support.get('motion_route_plan',{});route_rows=route_plan.get('routes',{})
        check(route_plan.get('schema')=='stool_install_cycle_affine_routes_v1' and set(route_rows)==STOOL_OBJECTS-{identity['object']},'exact eight explicit executable cycle routes required')
        check(_signature(route_plan)==STOOL_SUPPORT_ROUTE_PLAN_SHA256,'support route parameters/evidence declaration differ from frozen candidate')
        expected_cycle_ids=[]
        for index,obj in enumerate(contract.get('assembly_order',[])[1:]):
            part=obj.rsplit('_',1)[-1];prefix=f'assemble_{index:02d}_part_{part}';cid=f'install_{index:02d}_part_{part}'
            expected_cycle_ids.append(cid)
            matches=[c for c in cycles if c.get('cycle_id')==cid]
            if len(matches)!=1:check(False,'support cycle missing/duplicate '+cid);continue
            cycle=matches[0];route=route_rows.get(obj,{})
            if (route.get('enter_after') not in {'assembly_clearance','transport_hover'}
                    or route.get('exit_after') not in {'release_and_lock','retreat','park'}
                    or not isinstance(route.get('enter'),list) or not isinstance(route.get('exit'),list)):
                check(False,'explicit support route/handoff missing '+cid);continue
            for stage in ('enter','exit'):
                for point in route[stage]:
                    check(isinstance(point,dict) and set(point)=={'blend_fraction','delta_rad'}
                        and isinstance(point.get('blend_fraction'),(int,float)) and not isinstance(point.get('blend_fraction'),bool)
                        and 0<=point['blend_fraction']<=1 and _vector(point.get('delta_rad'),6),'invalid full-six affine route '+cid)
            enter_after=prefix+'_'+route['enter_after'];exit_after=prefix+'_'+route['exit_after']
            if not (enter_after in canonical and exit_after in canonical and canonical.index(enter_after)<canonical.index(exit_after)):
                check(False,'support original-phase handoff order changed '+cid);continue
            hold=canonical[canonical.index(enter_after)+1:canonical.index(exit_after)+1]
            expected=dict(cycle_id=cid,moving_object=obj,transport_phase_name=prefix+'_transport_hover',
                enter_after_phase_name=enter_after,exit_after_phase_name=exit_after,
                enter_phase_names=[prefix+f'_support_enter_{j:02d}' for j in range(len(route['enter'])+1)],acquire_phase_name=prefix+'_support_acquire',
                hold_phase_names=hold,open_phase_name=prefix+'_support_open',
                exit_phase_names=[prefix+f'_support_exit_{j:02d}' for j in range(len(route['exit'])+1)])
            check(cycle==expected,'exact original installation cycle/support motion scope changed '+cid)
            for stage,names in [('enter',expected['enter_phase_names']),('acquire',[expected['acquire_phase_name']]),
                                ('hold',expected['hold_phase_names']),('open',[expected['open_phase_name']]),('exit',expected['exit_phase_names'])]:
                for name in names:expected_roles[name]=dict(identity,cycle_id=cid,moving_object=obj,stage=stage)
            acquire_names.append(expected['acquire_phase_name']);open_names.append(expected['open_phase_name'])
            motion_names.extend(expected['enter_phase_names']+expected['exit_phase_names'])
            insert_after[expected['enter_after_phase_name']]=expected['enter_phase_names']+[expected['acquire_phase_name']]
            insert_after[expected['exit_after_phase_name']]=[expected['open_phase_name']]+expected['exit_phase_names']
        check([c.get('cycle_id') for c in cycles]==expected_cycle_ids,'support cycles must follow original assembly order')
        expected_schedule=[]
        for name in canonical:
            if name in removed:continue
            expected_schedule.append(name);expected_schedule.extend(insert_after.get(name,[]))
        expected_schedule.append(contract.get('final_phase_name'))
        check(support.get('removed_original_phase_names')==removed,'only original base retreat/park may be replaced')
        check(support.get('scheduled_phase_names')==expected_schedule and support.get('scheduled_phase_count')==len(expected_schedule),
              'support schedule/count must derive strictly from original phase sequence and explicit cycles')
    empty_routes=contract.get('left_empty_joint_routes',{})
    if continuous:
        check(isinstance(empty_routes,dict) and set(empty_routes)==set(['assemble_00_part_3_move_above', 'assemble_01_part_7_move_above', 'assemble_02_part_6_move_above', 'assemble_04_part_5_move_above', 'assemble_06_part_0_move_above']),'exact reviewed empty-route scope required')
        check(_signature(empty_routes)=='f08a417ef785ec9b910f3f302bd8abc86bff116fe9faab18718c9794734fd4c4','empty-route targets/source receipt differ from reviewed route')
    else:
        check(not empty_routes,'prior installation-cycle model may not silently enable continuous-support routes')
    loaded_routes=contract.get('left_loaded_object_routes',{})
    if continuous:
        check(isinstance(loaded_routes,dict) and set(loaded_routes)==set(['assemble_00_part_3_assembly_clearance', 'assemble_01_part_7_assembly_clearance', 'assemble_02_part_6_assembly_clearance', 'assemble_03_part_4_assembly_clearance', 'assemble_04_part_5_assembly_clearance']),'exact original four plus part5 assembly loaded-route phases required')
        check(_signature(loaded_routes)=='231d292cad7b9dc1280ff14b794957e68bf98a2ef4a8d969b1fe9ccc9664ee3e','loaded route targets/source receipts differ from reviewed declarations')
    else:
        check(not loaded_routes,'prior installation-cycle model may not silently enable loaded routes')
    check(_signature(contract.get('left_position_drive_candidate'))=='c9ef5c66527a63a38602bec479ed668e2e19dc876e79a2590b226073abd29c9c','left tracking-drive declaration/evidence changed')
    refinements=contract.get('grasp_refinements',{})
    check(isinstance(refinements,dict) and set(refinements)=={'fabrica_stool_circular_0'},'exact declared part0 grasp refinement required')
    check(_signature(refinements)=='86d2eabde7ad4400ba6879aeb115daf8bce2fdcc28f225a252daa35b446f23b2','part0 grasp/aperture/evidence declaration changed')
    tracked = set(_get(config, 'tracked_object_names', []))
    object_rows = list(_get(config, 'objects', []) or [])
    logical = set(tracked)
    for row in object_rows:
        actual = str(_get(row, 'name', ''))
        matches = [n for n in STOOL_OBJECTS if actual == n or
                   (actual.startswith(n + '_') and actual[len(n)+1:].isdigit())]
        if len(matches) == 1: logical.add(matches[0])
    check(STOOL_OBJECTS <= logical, 'configured objects lack nine stool parts')
    # The framework suffixes config names/prim paths but leaves role metadata
    # logical. Resolve the two sides explicitly, rejecting a cross-env anchor.
    support_binding = {}
    try:
        right = robot_configs[identity['robot']]
        actual_robot = _get(right,'name')
        suffix = actual_robot[len(identity['robot']):]
        candidates = [r for r in object_rows if _get(r,'name') == identity['object']+suffix]
        check(len(candidates)==1, 'SUPPORT object has no unique matching framework alias')
        rp = str(_get(right,'prim_path',''))
        op = str(_get(candidates[0],'prim_path','')) if len(candidates)==1 else ''
        check(rp.endswith('/ur5e_right') and op.endswith('/'+identity['object']), 'SUPPORT exact robot/object prim identity changed')
        if suffix:
            marker = str(_get(config,'robots_root_path','/robots')) + '/'
            omarker = str(_get(config,'objects_root_path','/objects')) + '/'
            check(marker in rp and omarker in op and rp.split(marker)[0] == op.split(omarker)[0],
                  'SUPPORT robot/object aliases cross framework environment roots')
        cycle_bindings = []
        moving_bindings=[(cycle,moving) for cycle in cycles for moving in (cycle.get('moving_objects',[]) if continuous else [cycle.get('moving_object')])]
        for cycle,moving in moving_bindings:
            matches = [r for r in object_rows if _get(r, 'name') == str(moving)+suffix]
            check(len(matches)==1, str(cycle.get('cycle_id'))+': moving object has no unique matching framework alias')
            moving_path = str(_get(matches[0], 'prim_path', '')) if len(matches)==1 else ''
            check(isinstance(moving,str) and moving_path.endswith('/'+moving),
                  str(cycle.get('cycle_id'))+': exact moving object prim identity changed')
            if suffix:
                check(marker in rp and omarker in moving_path and rp.split(marker)[0] == moving_path.split(omarker)[0],
                      str(cycle.get('cycle_id'))+': moving object crosses framework environment roots')
            cycle_bindings.append(dict(cycle_id=cycle.get('cycle_id'), logical_object=moving,
                actual_object=str(moving)+suffix, object_prim_path=moving_path))
        support_binding = dict(logical_robot=identity['robot'], actual_robot=actual_robot,
            robot_prim_path=rp, logical_object=identity['object'], actual_object=identity['object']+suffix,
            object_prim_path=op, cycle_moving_objects=cycle_bindings)
    except (KeyError,TypeError,ValueError):check(False,'SUPPORT framework binding is invalid')
    check(len(criteria) == 9 and {r.get('object') for r in criteria} == STOOL_OBJECTS,
          'original success criteria must cover exactly nine parts')
    original = contract.get('original_success_criteria')
    check(_plain(criteria) == _plain(original), 'original success gates changed')
    for row in criteria:
        check(row.get('require_released') is True and row.get('require_static') is True,
              str(row.get('object')) + ': original release/static gate missing')
        check(row.get('target') in targets, str(row.get('object')) + ': target alias missing')
        for key in ('position_tolerance', 'orientation_tolerance'):
            value = row.get(key)
            check(isinstance(value, (int,float)) and 0 < value < 1, 'invalid original ' + key)
    for name, pose in targets.items():
        check(isinstance(pose, dict) and _vector(pose.get('position'), 3)
              and _vector(pose.get('orientation'), 4)
              and any(abs(float(v)) > 1e-12 for v in pose.get('orientation', [])),
              name + ': invalid resolved pose')
    forbidden_nonempty = {'kinematic_carry', 'gripper_sibling_filters',
                          'object_poses', 'joint_overrides'}
    forbidden_true = {'disable_collision_on_attach', 'disable_collision_on_lock',
                      'filter_gripper_collisions_on_attach', 'allow_noncontact_joint_attachment', 'allow_noncontact_fixed_joint',
                      'pin_pose', 'teleport_to_target_once', 'snap_free_object', 'snap_on_open'}
    def walk(value, path):
        if isinstance(value, list):
            for i, child in enumerate(value): walk(child, f'{path}[{i}]')
        elif isinstance(value, dict):
            for key, child in value.items():
                where = path + '.' + key
                if key in forbidden_nonempty: check(not child, where + ': forbidden bypass')
                if key in forbidden_true: check(not child, where + ': forbidden bypass')
                if key == 'collision_filters':
                    entries = child if isinstance(child,list) else [child]
                    check(all(isinstance(x,dict) and x.get('enabled') is False for x in entries), where + ': collision filters must stay disabled')
                if key in {'target', 'target_name', 'target_object_target', 'target_object_final_target', 'target_pose_target', 'target_object_orientation_target', 'object_orientation_target'} and isinstance(child,str):
                    check(child in targets, where + ': unresolved target ' + child)
                if key in {'robot', 'robot_name'} and isinstance(child,str):
                    check(child in robot_configs, where + ': unresolved logical robot ' + child)
                if key in {'object_collisions', 'object_gravity'}:
                    entries = child if isinstance(child, list) else [child]
                    check(all(isinstance(x,dict) and x.get('enabled') is True for x in entries),
                          where + ': collisions/gravity must remain enabled')
                if key == 'type' and path.endswith('advance'):
                    check(child in SUPPORTED_ADVANCE_TYPES, where + ': unknown advance type')
                walk(child, where)
    timeout_sum = 0; attached = []; installed = []; phase_names = []; close_objects = []
    lift_objects = []
    se3_clearance_names = []; se3_transport_names = []; precise_descend_names = []
    for phase in phases if isinstance(phases, list) else []:
        name = phase.get('name'); phase_names.append(name)
        routing_skill=phase.get('local_skill') or {}
        if name=='assemble_04_part_5_pickup_clearance':
            check(isinstance(pickup_routing,dict) and routing_skill.get('name')=='ur5e_move_part_to_staging'
                  and routing_skill.get('robot')=='franka_left' and routing_skill.get('object')=='fabrica_stool_circular_5'
                  and routing_skill.get('target_object_target')=='part_5_pickup_clearance'
                  and routing_skill.get('target_object_offset')==(pickup_routing or {}).get('target_object_offset')
                  and routing_skill.get('target_object_offset_frame')=='world',str(name)+': exact transport-only offset missing/changed')
        else:
            check('target_object_offset' not in routing_skill and 'target_object_offset_frame' not in routing_skill,
                  str(name)+': part5 transport offset leaked outside its one phase')
        role = phase.get('fabrica_base_support');expected_role=expected_roles.get(name)
        check(role==expected_role,str(name)+': exact installation SUPPORT cycle/phase scope changed')
        if expected_role and expected_role['stage']!='hold':
            stage=expected_role['stage'];skill=phase.get('local_skill',{})
            check(not any(phase.get(k) for k in ('attach','detach','lock','fixture_lock','object_poses')),
                  str(name)+': support coordination may not author object constraints/state')
            if stage in {'acquire','open'}:
                expected_skill='ur5e_close_gripper' if stage=='acquire' else 'ur5e_preshape_gripper'
                check(skill.get('name')==expected_skill and skill.get('robot')==identity['robot']
                      and skill.get('object')==identity['object'],str(name)+': support native controller identity changed')
                check(phase.get('advance')==dict(type='all_of',physics_stable_steps=12,
                    fabrica_base_support_stage=stage,conditions=[
                        dict(type='local_skill_complete',robot=identity['robot'],skill=expected_skill,min_steps=1),
                        dict(type='objects_detached',objects=[identity['object']])]),str(name)+': support twelve-tick window changed')
                if stage=='open':check(skill.get('gripper_openness')==1.,str(name)+': support release must command actual open')
            else:
                request=dict(schema='stool_support_joint_target_v2',source='original_robot_initial_q')
                if stage in {'enter','exit'}:
                    motion_cycle=next(c for c in cycles if c['cycle_id']==expected_role['cycle_id'])
                    points=route_rows[motion_cycle['moving_object']][stage];index=motion_cycle[stage+'_phase_names'].index(name)
                    if index<len(points):request=dict(schema='stool_support_joint_target_v2',source=('declared_support_reposition' if continuous and stage=='enter' else 'park_reference_affine'),waypoint_index=index)
                    else:request['source']='retained_base_release_sdk' if stage=='enter' else 'original_robot_initial_q'
                source=request['source']
                check(skill.get('name')=='ur5e_move_arm_to_joint_positions' and skill.get('robot')==identity['robot']
                      and skill.get('adapter')=='toolkits.factory_dual_franka_assembly.beam_assisted_state:StoolSupportMotionAdapter'
                      and skill.get('fabrica_support_joint_target')==request,
                      str(name)+': actual dynamic joint-target outlet changed')
                check(skill.get('beam_assisted_native_joint_target') is True and skill.get('unwrap_revolute_joints') is False
                      and skill.get('joint_position_tolerance')==.025 and skill.get('joint_target_stable_steps')==8
                      and skill.get('max_joint_step')==skill.get('max_command_joint_step')==contract.get('max_joint_step_rad')
                      and skill.get('max_command_tracking_error')==contract.get('max_tracking_error_rad')
                      and skill.get('gripper_command')=='open' and 'joint_positions' not in skill,
                      str(name)+': original bounded native joint primitive limits/target binding changed')
                check(phase.get('timeout_steps')==support.get('motion_timeout_steps')==1800,str(name)+': original park-derived motion budget changed')
                region=dict(schema='stool_original_grasp_region_v1',position_tolerance_m=support['cad_row']['max_grasp_position_error_m'],
                    orientation_tolerance_rad=support['cad_row']['max_grasp_orientation_error_rad'],stable_native_ticks=8,
                    numeric_source='original base2 CAD grasp region; original native joint-target stable window; not CAD gap/contact qualification')
                if continuous:
                    check(stage=='enter' and source=='declared_support_reposition'
                          and skill.get('fabrica_support_entry_region')==(region if name==motion_cycle['enter_phase_names'][-1] else None),
                          str(name)+': open relocation must retain exact route and final native original-region8 gate')
                    check(support.get('entry_native_region_gate')==region,str(name)+': original native region may not relax')
                else:
                    check(support.get('entry_native_region_gate')==region and skill.get('fabrica_support_entry_region')==(region if stage=='enter' and source=='retained_base_release_sdk' else None),
                          str(name)+': support entry must add actual-native original grasp-region qualification after joint completion')
        check(phase.get('fabrica_assisted_contract') == contract, str(name) + ': task contract absent/changed')
        check(phase.get('beam_assisted') is True, str(name) + ': shared assistance hook absent')
        timeout = phase.get('timeout_steps', _get(config, 'phase_timeout_steps'))
        check(type(timeout) is int and timeout > 0, str(name) + ': invalid timeout')
        if type(timeout) is int: timeout_sum += max(0, timeout)
        walk(phase, str(name))
        for spec in [phase.get('local_skill')] + list((phase.get('local_skills') or {}).values()):
            if not spec: continue
            check(spec.get('use_arm_ik_controller') is False, str(name) + ': hidden SDK IK outlet forbidden')
            check(spec.get('limit_command_to_measured_state') is True, str(name) + ': measured-state limit required')
            if name in STOOL_PRECISE_DESCEND_OBJECTS:
                precise_descend_names.append(name)
                resolution = contract.get('install_position_step_m')
                precision = max(min(resolution * .05, 5e-4), 1e-5)
                check(spec.get('name') == 'ur5e_descend_to_grasp'
                      and spec.get('object') == STOOL_PRECISE_DESCEND_OBJECTS[name],
                      str(name) + ': exact precise descend phase/object pair changed')
                check(spec.get('position_tolerance') == resolution
                      and spec.get('relaxed_position_tolerance') == resolution
                      and spec.get('ik_position_tolerance') == precision,
                      str(name) + ': precise grasp entry/IK resolution changed')
            route=empty_routes.get(name)
            check(spec.get('fabrica_empty_joint_route')==route,str(name)+': empty route must match its exact compiled task declaration')
            if route is not None:
                check(spec.get('name')=='ur5e_move_above_part' and spec.get('object')==route.get('object')
                      and spec.get('robot')=='franka_left' and not spec.get('requires_held_object')
                      and spec.get('prealign_steps')==240 and not spec.get('prealign_until_converged')
                      and spec.get('gripper_command')=='open'
                      and type(route.get('replace_prealign')) is bool
                      and route.get('replace_prealign')==(name=='assemble_01_part_7_move_above'),str(name)+': explicit empty prealign replacement/grip/goal semantics changed')
            loaded_route=loaded_routes.get(name)
            check(spec.get('fabrica_loaded_object_route')==loaded_route,str(name)+': loaded route must match its exact compiled declaration')
            if loaded_route is not None:
                check(spec.get('object')==loaded_route.get('object') and spec.get('robot')=='franka_left'
                      and spec.get('requires_held_object') is True and bool(spec.get('fabrica_object_se3_clearance')),
                      str(name)+': loaded route must retain the original captured-object SE3 outlet')
            offset = spec.get('offset', [])
            native_lift = (spec.get('name') == 'ur5e_retreat_vertical' and spec.get('requires_held_object')
                           and spec.get('offset_frame') == 'world' and len(offset) == 3
                           and offset[:2] == [0., 0.] and offset[2] > 0.)
            se3 = spec.get('fabrica_object_se3_clearance')
            selected_clearance = name in STOOL_SE3_CLEARANCE_OBJECTS
            if selected_clearance:
                se3_clearance_names.append(name)
                resolution = contract.get('install_position_step_m')
                angle_resolution = contract.get('install_orientation_step_rad')
                precision = max(min(resolution * .05, 5e-4), 1e-5)
                check(se3 == {'schema': 'stool_object_se3_clearance_v1',
                    'position_step_m': resolution, 'orientation_step_rad': angle_resolution,
                    'position_lookahead_m': .003, 'orientation_lookahead_rad': 3. * angle_resolution,
                    'position_precision_m': precision, 'original_ik_orientation_tolerance_rad': .002,
                    'numeric_source': 'original Stool insertion p/R steps; unchanged3mm generic TCP budget; three original insertion orientation samples; timeout inverse orientation-lead ratio'}, str(name) + ': exact Stool full-object SE3 contract changed')
                check(spec.get('name') == 'ur5e_move_part_to_staging' and spec.get('object') == STOOL_SE3_CLEARANCE_OBJECTS[name]
                      and spec.get('requires_held_object') is True, str(name) + ': SE3 clearance object/skill changed')
                check(spec.get('cartesian_position_step') == resolution and spec.get('cartesian_orientation_step') == angle_resolution
                      and spec.get('ik_position_tolerance') == precision
                      and spec.get('cartesian_orientation_command_lookahead') == 3. * angle_resolution,
                      str(name) + ': SE3 numerical resolution changed')
                check(timeout == 48000, str(name) + ': explicit inverse orientation-lead timeout budget changed')
                check(not spec.get('beam_assisted_absolute_object_servo'), str(name) + ': Beam absolute outlet forbidden')
            else:
                check(not se3, str(name) + ': SE3 clearance outside exact original phase/object pairs')
            transport = spec.get('fabrica_object_se3_transport')
            if name in STOOL_SE3_TRANSPORT_OBJECTS:
                se3_transport_names.append(name)
                resolution = contract.get('install_position_step_m')
                angle_resolution = contract.get('install_orientation_step_rad')
                precision = max(min(resolution * .05, 5e-4), 1e-5)
                check(transport == {'schema': 'stool_object_se3_transport_v1',
                    'position_step_m': resolution, 'orientation_step_rad': angle_resolution,
                    'position_lookahead_m': .003, 'orientation_lookahead_rad': 3. * angle_resolution,
                    'position_precision_m': precision, 'original_ik_orientation_tolerance_rad': .002,
                    'numeric_source': 'original Stool insertion p/R steps; unchanged3mm generic TCP budget; three original insertion orientation samples; original transport timeout retained'}, str(name) + ': exact Stool SE3 transport contract changed')
                check(spec.get('name') == 'ur5e_move_part_to_staging' and spec.get('object') == STOOL_SE3_TRANSPORT_OBJECTS[name]
                      and spec.get('requires_held_object') is True and not se3,
                      str(name) + ': exact SE3 transport object/skill/mode changed')
                check(spec.get('cartesian_position_step') == resolution and spec.get('cartesian_orientation_step') == angle_resolution
                      and spec.get('ik_position_tolerance') == precision
                      and spec.get('cartesian_orientation_command_lookahead') == 3. * angle_resolution,
                      str(name) + ': SE3 transport numerical resolution changed')
                check(timeout == 4800 and spec.get('hold_for_target_object_settle') is True
                      and spec.get('require_target_object_static') is True
                      and spec.get('target_object_settle_hold_steps') == 48
                      and spec.get('target_object_settle_retry_servo_steps') == 8,
                      str(name) + ': original transport timeout/static/settle contract changed')
                check(not spec.get('beam_assisted_absolute_object_servo') and not spec.get('beam_assisted_transition_settle'),
                      str(name) + ': alternate assisted transport outlet forbidden')
            else:
                check(not transport, str(name) + ': SE3 transport outside exact six phase/object pairs')
            hold = spec.get('fabrica_native_lateral_hold')
            if native_lift:
                lift_objects.append(spec.get('object'))
                expected_hold = {'schema': 'stool_native_object_xy_hold_v2',
                                 'max_lateral_step_m': contract.get('install_position_step_m'),
                                 'numeric_source': 'minimum original stool insertion cartesian_position_step; absolute object-XY inverse TCP increment bound'}
                bias_lifts = {
                    'fabrica_stool_circular_3': 'assemble_00_part_3_lift',
                    'fabrica_stool_circular_7': 'assemble_01_part_7_lift',
                    'fabrica_stool_circular_6': 'assemble_02_part_6_lift',
                    'fabrica_stool_circular_4': 'assemble_03_part_4_lift',
                    'fabrica_stool_circular_5': 'assemble_04_part_5_lift',
                    'fabrica_stool_circular_1': 'assemble_05_part_1_lift',
                    'fabrica_stool_circular_0': 'assemble_06_part_0_lift',
                    'fabrica_stool_circular_8': 'assemble_07_part_8_lift',
                }
                if spec.get('object') in bias_lifts:
                    expected_hold.update(schema='stool_native_object_xy_bias_v1', reference_bias={
                        'max_total_m': contract.get('install_position_step_m') / 2.,
                        'gain_per_native_tick': 1. / contract.get('contact_stable_physics_steps'),
                        'max_step_m': contract.get('install_position_step_m'),
                        'numeric_source': 'half original Stool insertion position step cap; original contact stable native ticks reciprocal gain; original insertion step increment'})
                    check(name == bias_lifts[spec['object']], str(name) + ': XY bias outside exact original lift/object pair')
                    check(spec.get('ik_position_tolerance') == max(min(contract.get('install_position_step_m') * .05, 5e-4), 1e-5),
                          str(name) + ': task-derived numerical IK fidelity missing or changed')
                check(hold == expected_hold,
                      str(name) + ': task-derived absolute object XY hold missing or altered')
                check(spec.get('cartesian_position_step') == .008, str(name) + ': original lift step changed')
            else:
                check(not hold, str(name) + ': native lateral hold outside held world+Z retreat')
        close=phase.get('local_skill',{})
        if close.get('name') == 'ur5e_close_gripper':
            if name not in acquire_names:
                close_objects.append(close.get('object'))
            check(close.get('beam_assisted_visual_pinch') is True, str(name)+': actual CAD close hook missing')
            row=(support.get('cad_row',{}) if name in acquire_names else
                 cad.get('objects',{}).get(close.get('object'),{}))
            check(row.get('object_in_hand_position')==close.get('grasp_relative_position') and row.get('object_in_hand_orientation')==close.get('grasp_relative_orientation'),str(name)+': CAD grasp region differs from catalog close frame')
            check(row.get('robot')==close.get('robot') and row.get('max_grasp_position_error_m')==close.get('close_position_tolerance') and row.get('max_grasp_orientation_error_rad')==close.get('close_orientation_tolerance'), str(name)+': CAD region must retain original close pose limits')
            check(row.get('source_preclose_openness')==close.get('preclose_openness') and row.get('source_closed_openness')==close.get('closed_openness') and row.get('source_close_ramp_steps')==close.get('close_ramp_steps'), str(name)+': CAD driver ramp source mismatch')
            robot=robot_configs.get(close.get('robot'),{})
            check(row.get('driver_open_rad')==_get(robot,'gripper_open_position') and row.get('driver_closed_rad')==_get(robot,'gripper_closed_position'),str(name)+': CAD mechanical driver bounds mismatch')
            check(row.get('minimum_sdk_openness')==float(_get(robot,'gripper_close_openness',0.) or 0.),str(name)+': CAD SDK openness clamp mismatch')
        entries = phase.get('attach', [])
        for entry in entries if isinstance(entries,list) else [entries]:
            if not entry: continue
            attached.append(entry.get('object'))
            check(entry.get('beam_assisted_visual_pinch') is True, str(name)+': native CAD attach hook missing')
            check(entry.get('attachment_mode') == 'fixed_joint'
                  and entry.get('attachment_relative_pose_source') == 'current'
                  and entry.get('beam_assisted') is True,
                  str(name) + ': attachment must freeze current measured transform')
        entries = phase.get('lock', [])
        for entry in entries if isinstance(entries,list) else [entries]:
            if entry and entry.get('target') == contract.get('final_target_names', {}).get(entry.get('object')):
                installed.append(entry.get('object'))
    check(phase_names == expected_schedule, 'actual phase order does not match exact derived SUPPORT scheduling')
    by_name={p.get('name'):p for p in phases}
    try:
        close_source=by_name['base_2_close_and_attach'];open_source=by_name['base_2_preshape']
        for name in acquire_names:
            expected_close=dict(close_source['local_skill'])
            if continuous:
                expected_close.update(grasp_relative_position=support['cad_row']['object_in_hand_position'],
                    grasp_relative_orientation=support['cad_row']['object_in_hand_orientation'])
            check(by_name[name]['local_skill']==expected_close and by_name[name]['timeout_steps']==close_source['timeout_steps'],
                  name+': support acquisition must reuse original base close controller/budget')
        for name in open_names:
            check(by_name[name]['local_skill']==dict(open_source['local_skill'],gripper_openness=1.)
                  and by_name[name]['timeout_steps']==open_source['timeout_steps'],name+': actual open controller/budget changed')
        delta=sum(by_name[n]['timeout_steps'] for n in acquire_names+open_names+motion_names)-3000
        check(support.get('timeout_delta_steps')==delta,'support budget must sum explicit new phases minus original retreat/park')
        check(support.get('max_steps_after_support')==support.get('max_steps_before_support',0)+delta
              and support.get('max_steps_after_support')==_get(config_or_task,'max_steps',_get(config,'max_steps',0)),
              'support global max_steps delta is not strictly accounted')
        right=robot_configs[identity['robot']];initial=_get(right,'initial_joint_positions',{})
        names=['shoulder_pan_joint','shoulder_lift_joint','elbow_joint','wrist_1_joint','wrist_2_joint','wrist_3_joint']
        check(support.get('park_joint_names')==names and support.get('park_joint_positions')==[float(initial[n]) for n in names],
              'park is an actual drive goal copied from original robot configuration; initial state may not change')
    except (KeyError,TypeError,ValueError):check(False,'support source controller/initial goal/budget fields absent')
    check(None not in phase_names and len(phase_names) == len(set(phase_names)), 'phase names duplicate or missing')
    check(len(lift_objects) == 9 and set(lift_objects) == STOOL_OBJECTS, 'nine native world+Z lift hooks required')
    check(set(close_objects) == STOOL_OBJECTS and len(close_objects)==9, 'exactly nine CAD closing skills required')
    check(set(attached) == STOOL_OBJECTS and len(attached) == 9, 'every stool part requires exactly one measured attachment')
    check(set(installed) == STOOL_OBJECTS and len(installed) == 9, 'every stool part requires exactly one final installation support')
    if phases:
        base_locks=[lock for phase in phases for lock in (phase.get('lock',[]) or []) if lock.get('object')==contract.get('base_object') and lock.get('target')==contract.get('final_target_names',{}).get(contract.get('base_object'))]
        check(len(base_locks)==1 and base_locks[0].get('rebase_targets')==contract.get('base_rebase_targets'), 'base target rebase contract changed')
        final = phases[-1]
        check(final.get('name') == contract.get('final_phase_name'), 'final verification phase missing')
        check(set(final.get('gripper_commands', {})) == set(robot_configs)
              and all(v == 'open' for v in final.get('gripper_commands', {}).values()),
              'final phase must command both grippers open')
    budget = _get(config_or_task, 'max_steps', _get(config, 'max_steps', 0))
    check(type(budget) is int and budget > 0, 'positive task budget required')
    check(sorted(se3_clearance_names) == sorted(STOOL_SE3_CLEARANCE_OBJECTS),
          'exact sixteen nonbase SE3 clearance phases missing or duplicated')
    check(sorted(se3_transport_names) == sorted(STOOL_SE3_TRANSPORT_OBJECTS),
          'exact six remaining SE3 transport phases missing or duplicated')
    check(sorted(precise_descend_names) == sorted(STOOL_PRECISE_DESCEND_OBJECTS),
          'exact five remaining precise grasp-entry phases missing or duplicated')
    if runtime:
        check(_plain(phases) == _plain(_get(config, 'phase_specs')), 'runtime phase list differs from reviewed configuration')
        check(_plain(targets) == _plain(_get(config, 'target_poses')), 'runtime targets differ before base rebase')
        check(getattr(config_or_task, '_fabrica_assisted_contract', None) == contract,
              'runtime did not activate reviewed task contract')
        check(STOOL_OBJECTS <= set(getattr(config_or_task, '_object_prims', {})), 'runtime object native bindings missing')
    report = dict(passed=not errors, errors=errors,
        scope='actual compiled task model and framework aliases; no physics or native geometry',
        configuration_signature=configuration_signature(config),
        phase_target_signature=_signature({'phase_specs':phases,'target_poses':targets}),
        task_contract=contract, runtime_interfaces_checked=runtime,
        support_framework_binding=support_binding, phase_count=len(phases), phase_timeout_sum=timeout_sum, max_steps=budget,
        full_mode=bool(full_mode), original_success_criteria=_plain(criteria),
        formal_physical_success=False,
        not_certified=['native contact/constraints', 'dual-arm final-command sweep',
                       'native camera visibility', 'nine-part assembly completion'])
    if errors: raise AssistedConfigurationError(report)
    return report

"""Focused startup collector regressions; synthetic tests, zero native physics."""
from pathlib import Path
from types import SimpleNamespace,ModuleType
from unittest.mock import patch
import copy,json,sys,tempfile
import numpy as np
import stool_startup_evidence as helper
# Local laptop lacks OpenCV. The server uses real cv2; this fallback only writes
# synthetic unit-test PNGs so retention/control flow is still exercised locally.
try:
    import cv2
    CV_BACKEND='OpenCV'
except ImportError:
    from PIL import Image
    cv_module=ModuleType('cv2');cv_module.COLOR_RGB2BGR=1
    cv_module.cvtColor=lambda pixels,mode:pixels[...,::-1]
    def write_png(path,pixels):
        Image.fromarray(pixels[...,::-1]).save(path);return True
    cv_module.imwrite=write_png;sys.modules['cv2']=cv_module
    CV_BACKEND='PIL facade for synthetic unit-test PNGs only'

REPO=Path(__file__).resolve().parents[1]/'stool_repository'
sys.path.insert(0,str(REPO))
STAMP=dict(valid=True,epoch=0,index=12,time=.25,dt=1/48)
NAMES=('third_person_front','left_wrist','right_wrist')


def image(index):
    rgb=np.zeros((4,6,4),np.uint8);rgb[...,3]=255
    rgb[:,:,index%3]=np.arange(24).reshape(4,6)*5+index
    return rgb


def observation():
    return {'franka_left':{'sensors':{name:dict(rgba=image(index),render_reference_time=dict(
        referenceTimeNumerator=1,referenceTimeDenominator=4)) for index,name in enumerate(NAMES)}}}


class FakeReader:
    def __init__(self,task):self.task=task;self.identities={'synthetic':'only_for_collector_regression'}
    def snapshot(self):
        return dict(physics_stamp=copy.deepcopy(STAMP),object_paths={},transforms_xyzw={},velocities={},
            counters=dict(step_counter=self.task.step_counter),phase_transition_history=[])


class FakeTask:
    def __init__(self):
        self.step_counter=0;self.phase_index=0;self.phase_entry_step=0;self.steps=0;self.render_counter=0;self.observations=observation()
    def _beam_physics_stamp(self):return copy.deepcopy(STAMP)
    def get_tracked_object_states(self):raise AssertionError('stateful public getter must never be called')


class FakeRecorder:
    def __init__(self):
        self.frame_stride=8;self._written_png_counts={};self.camera_specs=[dict(video_key=n) for n in NAMES]
    def record(self,task,obs,*,step_index):
        task.get_tracked_object_states()
        for name in NAMES:
            if obs['franka_left']['sensors'][name].get('rgba') is not None:
                self._written_png_counts[name]=self._written_png_counts.get(name,0)+1


def main():
    cases=[]
    def check(name,value):assert value,name;cases.append(dict(name=name,passed=True))
    rgb,p=helper.inspect_pixels(image(0),[6,4]);check('valid_rendered_pixels',p['valid'] and rgb.shape==(4,6,3))
    for name,buffer in [('missing',None),('uniform',np.full((4,6,4),255,np.uint8)),
                        ('nonfinite',np.full((4,6,3),np.nan)),('transparent',np.zeros((4,6,4),np.uint8)),
                        ('wrong_resolution',np.zeros((3,6,3),np.uint8))]:
        check('reject_'+name,not helper.inspect_pixels(buffer,[6,4])[1]['valid'])
    rows=[dict(camera=n,raw_reference_time=dict(referenceTimeNumerator=1,referenceTimeDenominator=4)) for n in NAMES]
    check('same_native_clock',helper.inspect_reference_clocks(rows,STAMP)['passed'])
    bad=copy.deepcopy(rows);bad[1]['raw_reference_time']=None
    check('reject_missing_reference',not helper.inspect_reference_clocks(bad,STAMP)['passed'])
    bad=copy.deepcopy(rows);bad[2]['raw_reference_time']=dict(referenceTimeNumerator=11,referenceTimeDenominator=48)
    check('reject_mixed_render_stamps',not helper.inspect_reference_clocks(bad,STAMP)['passed'])
    distinct=[dict(camera=n,raw_reference_time=dict(referenceTimeNumerator=34,referenceTimeDenominator=30)) for n in NAMES]
    check('distinct_render_native_epochs_are_valid',helper.inspect_reference_clocks(distinct,STAMP)['passed'])
    before_refs=[dict(camera=n,raw_reference_time=dict(referenceTimeNumerator=26,referenceTimeDenominator=30)) for n in NAMES]
    passes=[dict(references=[dict(camera=n,raw_reference_time=dict(referenceTimeNumerator=27+i,referenceTimeDenominator=30)) for n in NAMES],physics_stamp=copy.deepcopy(STAMP),native_state_exactly_unchanged=True) for i in range(8)]
    check('eight_fresh_shared_render_passes',helper.inspect_render_sequence(before_refs,passes,STAMP)['passed'])
    stale=copy.deepcopy(passes);stale[3]['references']=copy.deepcopy(stale[2]['references'])
    check('allow_observed_repeated_shared_stamp_with_fresh_final',helper.inspect_render_sequence(before_refs,stale,STAMP)['passed'])
    all_stale=copy.deepcopy(passes)
    for row in all_stale:row['references']=copy.deepcopy(before_refs)
    check('reject_entire_batch_stale',not helper.inspect_render_sequence(before_refs,all_stale,STAMP)['passed'])
    backwards=copy.deepcopy(passes);backwards[3]['references']=copy.deepcopy(backwards[1]['references'])
    check('reject_render_clock_backwards',not helper.inspect_render_sequence(before_refs,backwards,STAMP)['passed'])
    # Exact P02 scheduler observation: before27/30, calls29,30,31,32,32,33,34,35.
    actual_before=[dict(camera=n,raw_reference_time=dict(referenceTimeNumerator=27,referenceTimeDenominator=30)) for n in NAMES]
    actual_passes=[dict(references=[dict(camera=n,raw_reference_time=dict(referenceTimeNumerator=v,referenceTimeDenominator=30)) for n in NAMES],physics_stamp=copy.deepcopy(STAMP),native_state_exactly_unchanged=True) for v in (29,30,31,32,32,33,34,35)]
    actual_check=helper.inspect_render_sequence(actual_before,actual_passes,STAMP)
    check('exact_P02_renderer_scheduling_fixture',actual_check['passed'] and actual_check['repeated_render_passes']==[5] and actual_check['final_render_stamp_newer_than_before'])
    moved=copy.deepcopy(passes);moved[2]['physics_stamp']['index']+=1
    check('reject_native_change_during_render',not helper.inspect_render_sequence(before_refs,moved,STAMP)['passed'])
    matrix,target=helper.grip_camera_matrix([0.,0.,0.],[[-.04,0.,.2],[.04,0.,.2]])
    check('camera_targets_measured_grip_midpoint',np.allclose(-matrix[:3,2],target/np.linalg.norm(target)) and np.allclose(matrix[:3,3],0))
    check('jaw_line_horizontal_camera_basis',abs(np.dot(matrix[:3,1],np.array([.08,0.,0.])))<1e-12 and np.linalg.det(matrix[:3,:3])>0)
    check('json_preserves_nonfinite_diagnostic',json.dumps(helper.plain({'a':np.array([np.inf])}),allow_nan=False)=='{"a": ["inf"]}')
    task=FakeTask();recorder=FakeRecorder();snapshot=FakeReader(task).snapshot()
    receipt=helper.record_initial_video(recorder,task,task.observations,snapshot)
    check('recorder_readonly_proxy_and_stride_restore',receipt['passed'] and recorder.frame_stride==8)
    base_module=ModuleType('internutopia.core.task');base_module.BaseTask=SimpleNamespace(get_observations=lambda task:task.observations)
    stage_module=ModuleType('isaacsim.core.utils.stage');stage_module.get_current_stage=lambda:None
    entries=[dict(name=n,owner='franka_left',spec=dict(name=n,resolution=[6,4],video_key=n),temporary_params=False) for n in NAMES]
    def run_capture(name,mutate=None,reader=FakeReader,identity_pass=True,expected=True):
        task=FakeTask();recorder=FakeRecorder();calls=[]
        def warm_up(**kwargs):
            calls.append(kwargs);task.render_counter+=1
            for sensor in task.observations['franka_left']['sensors'].values():
                if not sensor.get('test_stale_reference'):
                    sensor['render_reference_time']=dict(referenceTimeNumerator=26+task.render_counter,referenceTimeDenominator=30)
        env=SimpleNamespace(warm_up=warm_up)
        if mutate:mutate(task,env)
        def callback(obs,snap):return helper.record_initial_video(recorder,task,obs,snap)
        with tempfile.TemporaryDirectory(prefix='stool_startup_test_') as directory:
            with patch.dict(sys.modules,{'internutopia.core.task':base_module,'isaacsim.core.utils.stage':stage_module}),\
                 patch.object(helper,'NativeStartupReader',reader),patch.object(helper,'camera_entries',lambda task:[dict(entry,backend=SimpleNamespace(get_render_reference_time=lambda task=task:dict(referenceTimeNumerator=26+task.render_counter,referenceTimeDenominator=30))) for entry in copy.deepcopy(entries)]),\
                 patch.object(helper,'align_native_publication',lambda *args:dict(passed=True,native_unchanged=True)),patch.object(helper,'compare_native_usd',lambda *args:dict(passed=True)),patch.object(helper,'align_wrist_camera_orientation',lambda *args:dict(passed=True)),\
                 patch.object(helper,'inspect_camera_identity',lambda stage,entry:dict(passed=identity_pass)):
                try:report=helper.capture_startup_evidence(task,env,Path(directory),callback);passed=True
                except helper.StartupEvidenceError as exc:report=exc.report;passed=False
            check(name+'_acceptance',passed is expected)
            check(name+'_render_only_eight',calls==[dict(steps=1,render=True,physics=False)]*8)
            check(name+'_pixels_retained_before_rejection',len(list(Path(directory).glob('startup_*.png')))==3)
            check(name+'_video_retained_before_rejection',recorder._written_png_counts=={n:1 for n in NAMES})
            check(name+'_diagnostic_retained',(Path(directory)/'startup_capture_diagnostics.json').is_file())
    run_capture('valid_startup')
    run_capture('stale_camera',lambda task,env:task.observations['franka_left']['sensors'][NAMES[1]].update(
        render_reference_time=dict(referenceTimeNumerator=11,referenceTimeDenominator=48),test_stale_reference=True),expected=False)
    run_capture('duplicated_pixels',lambda task,env:task.observations['franka_left']['sensors'][NAMES[1]].update(rgba=image(0)),expected=False)
    run_capture('wrong_renderer_camera',identity_pass=False,expected=False)
    def change_counter(task,env):
        def warm(**kwargs):
            task.step_counter+=1
            # Preserve the warm-up receipt supplied by the outer test.
            env.calls.append(kwargs)
        previous=env.warm_up
        def wrapper(**kwargs):previous(**kwargs);task.step_counter+=1
        env.warm_up=wrapper
    run_capture('render_changed_task_counter',change_counter,expected=False)
    class BrokenReader:
        def __init__(self,task):raise RuntimeError('synthetic native reader construction failure')
    run_capture('native_failure_still_retains_pixels',reader=BrokenReader,expected=False)
    print(json.dumps(dict(passed=True,cases=cases,count=len(cases),native_physics_executed=0,
        image_writer=CV_BACKEND,scope='synthetic pixel/clock/native-invariance and failure-retention tests; not actual render/native proof')))

if __name__=='__main__':main()

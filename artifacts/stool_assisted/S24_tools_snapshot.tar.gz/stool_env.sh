#!/usr/bin/env bash
# Source this file, then run the selected offline/native entry explicitly.
set -e
STOOL_WORKSPACE=/home/user/beam_integration_20261010_upstream6f57dae
STOOL_ROOT="$STOOL_WORKSPACE/stool_assisted_20261021"
STOOL_SOURCE="$STOOL_ROOT/stool_repository"
source /Embodied_AI/miniconda3/etc/profile.d/conda.sh
conda activate internutopia311
export ISAAC_SIM_ROOT=/home/user/isaacsim-5.1.0
source "$ISAAC_SIM_ROOT/setup_conda_env.sh"
export PYTHONPATH="$STOOL_WORKSPACE/runtime_tools/geometry_deps:$STOOL_SOURCE:$STOOL_ROOT/tools:${PYTHONPATH:-}"
export PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1
export GIT_PYTHON_GIT_EXECUTABLE=/Embodied_AI/miniconda3/bin/git
export INTERNUTOPIA_EXTENSION_PROFILE=ur5e_assembly
export PATH="$STOOL_WORKSPACE/runtime_tools/bin:$PATH"
export OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4
cd "$STOOL_SOURCE"

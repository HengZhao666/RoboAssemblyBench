"""CC09–11 estimator rules through the real production gate and timeout path.

Robot measurements and IK are explicit doubles; target conversion, estimator,
locking, hold, gate, timeout and compiled worker functions execute unchanged.
"""
import ast
import copy
import importlib.util
import json
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

import numpy as np
from toolkits.factory_dual_franka_assembly.plumbers_block_ur5e_skills import UR5eAssemblyAtomicSkillAdapter as Adapter
from toolkits.factory_dual_franka_assembly.planner_primitives import pose_error

ROOT=Path(os.environ['BEAM_ESTIMATE_QUALIFICATION_ROOT'])
EVIDENCE={}
OPTIONS={'close_gate_target_estimate':'parity_balanced_mean','close_gate_target_estimate_ticks':48,
    'close_gate_target_estimate_half_position_tolerance':.00025,
    'close_gate_target_estimate_half_orientation_tolerance':.0025}


class Harness:
    def __init__(self,cls=Adapter,spec=None):
        self.a=cls({});self.spec={'name':'ur5e_close_gripper','continuous_physics':True,
            'require_success':True,'require_close_pose_gate':True,'close_pose_gate_timeout_steps':720,
            'preclose_openness':.25,'lock_target_position':True,'lock_target_orientation':True,**OPTIONS}
        if spec is not None:self.spec=copy.deepcopy(spec)
        self.task=NS(phase='estimate',phase_index=90,phase_entry_step=0,phase_step_counter=0,step_counter=0,
            cfg=NS(task_metadata={}),robots={})
        self.key=(id(self.task),90,0,'franka_left','ur5e_close_gripper')
        self.q=np.zeros(6);self.current_pose=None;self.objects={}
        self.a._current_arm_q=lambda *args:self.q.copy()
        self.a._current_robot_pose=lambda **kw:self.current_pose
        self.a._solve_ik=lambda **kw:None
        self.a._local_grasp_ik=lambda **kw:None
        self.a._debug_close_gate_step=lambda **kw:None

    def tick(self,t,position=None,angle=0.,act=False):
        self.task.step_counter=t;self.task.phase_step_counter=t
        if position is not None:
            self.spec['target_position']=np.asarray(position,float)
            self.spec['target_orientation']=[np.cos(angle/2),0.,0.,np.sin(angle/2)]
        if act:
            return self.a.act(task=self.task,robot_name='franka_left',phase_spec={},skill_spec=self.spec,
                tracked_robots={},tracked_objects=self.objects)
        return self.a._close_pose_gate_action(phase_key=self.key,task=self.task,robot_name='franka_left',
            spec=self.spec,tracked_robots={},tracked_objects=self.objects)

    @property
    def state(self):return self.a._close_gate_state.get(self.key,{})
    @property
    def locked(self):return self.a._phase_locks.get(self.key,{})


class ProductionEstimator(unittest.TestCase):
    def run_signal(self,signal,lock_tick,expected=None,angle=None):
        h=Harness();saved=None
        for tick in range(1,721):
            ready,action,detail=h.tick(tick,signal(tick),0. if angle is None else angle(tick))
            if detail.get('reason')=='close_gate_target_estimating':
                self.assertFalse(ready);self.assertFalse(detail['gate_ready']);self.assertEqual(h.state['ready_steps'],0)
                self.assertNotIn('close_settle_anchor',h.state)
                np.testing.assert_array_equal(action['arm_joint_controller'][0],h.q)
                self.assertEqual(action['gripper_controller'],[.25])
            if tick<(lock_tick or 721):self.assertNotIn('position',h.locked)
            elif tick==lock_tick:
                self.assertEqual(h.state['target_estimate_lock_step'],tick)
                if expected is not None:np.testing.assert_allclose(h.locked['position'],expected,atol=1e-15,rtol=1e-12)
                saved={k:v.copy() for k,v in h.locked.items()}
            else:
                for k,v in saved.items():np.testing.assert_array_equal(h.locked[k],v)
        if lock_tick is None:self.assertNotIn('position',h.locked)
        return h

    def test_constant_and_period_two(self):
        h=self.run_signal(lambda t:[.4,-.2,1.2],48,[.4,-.2,1.2])
        np.testing.assert_allclose(h.locked['orientation'],[1,0,0,0],atol=1e-15)
        h=self.run_signal(lambda t:[.0012*(-1)**t,0,0],48,[0,0,0],lambda t:.0075*(-1)**t)
        self.assertLess(np.linalg.norm(h.locked['position']),1e-6)
        self.assertLess(pose_error(current_position=[0,0,0],target_position=[0,0,0],
            current_orientation=h.locked['orientation'],target_orientation=[1,0,0,0])[1],1e-5)

    def test_total_drift_is_accepted_but_fast_drift_times_out(self):
        h=self.run_signal(lambda t:[.001*(t-1)/719,0,0],48,[.001*23.5/719,0,0])
        self.assertLess(abs(h.locked['position'][0]-.001*23.5/719),40e-6)
        for alternating in (False,True):
            h=Harness()
            for tick in range(1,721):
                p=.0005*(tick-1)/24 + (.0012*(-1)**tick if alternating else 0.)
                action=h.tick(tick,[p,0,0],.0075*(-1)**tick if alternating else 0.,act=True)
                if tick<720:self.assertNotIn('__local_skill_failure__',action)
                self.assertNotIn('position',h.locked)
            self.assertEqual(action['reason'],'close_pose_gate_timeout')
            self.assertEqual(action['diagnostics']['reason'],'close_gate_target_estimating')

    def test_corrected_fixed_step(self):
        self.run_signal(lambda t:[.0022 if t>=30 else 0.,0,0],76,[.0022*47/48,0,0])

    def test_seeded_step_oracle_and_latched_late_steps(self):
        rng=np.random.default_rng(20261115);rows=[];skipped=0
        for number in range(200):
            size=float(rng.uniform(.0003,.005));direction=rng.normal(size=3);direction/=np.linalg.norm(direction)
            step=int(rng.integers(2,201));oracle=None;excluded=False
            for w in range(1,674,2):
                n1=int(np.clip(step-w,0,24));n2=int(np.clip(step-w-24,0,24));delta=abs(n1-n2)*size/24
                if abs(delta-.00025)<=1e-9:excluded=True;break
                if delta<=.00025:oracle=(w+47,n1+n2);break
            if excluded:skipped+=1;continue
            self.assertIsNotNone(oracle);tick,m=oracle
            expected=(48-m)*size/48*direction
            h=self.run_signal(lambda t:direction*size if t>=step else np.zeros(3),tick,expected)
            error=min(m,48-m)*size/48;self.assertLessEqual(error,125e-6+1e-12)
            rows.append({'case':number,'step_tick':step,'size_m':size,'lock_tick':tick,'nearer_plateau_error_m':error})
        EVIDENCE['e2']={'seed':20261115,'generated':200,'skipped_boundary_cases':skipped,'checked':len(rows),'cases':rows}

    def test_repeats_gaps_missing_target_and_wait_trace(self):
        for discontinuity in ('repeat','gap','missing'):
            h=Harness()
            for tick in range(1,21):h.tick(tick,[0,0,0])
            if discontinuity=='missing':
                with patch.object(h.a,'_target_pose',return_value=None):h.tick(21)
                self.assertNotIn('target_estimate_buffer',h.state);h.tick(22,[0,0,0])
            else:h.tick(20 if discontinuity=='repeat' else 22,[0,0,0])
            self.assertEqual(len(h.state['target_estimate_buffer']),1);self.assertNotIn('position',h.locked)
        with tempfile.TemporaryDirectory() as d,patch.dict(os.environ,{'BEAM_CLOSE_GATE_TRACE_PATH':str(Path(d)/'gate.jsonl')}):
            h=Harness();h.tick(1,[0,0,0]);row=json.loads((Path(d)/'gate.jsonl').read_text())
            self.assertEqual(row['reason'],'close_gate_target_estimating');self.assertEqual(row['count'],1)
            self.assertIsNone(row['half_position_delta']);self.assertFalse(row['gate_ready'])

    def test_estimator_runs_before_frozen_and_recenter_modifications(self):
        h=Harness();h.a._close_gate_state[h.key]={'ready_steps':10,'close_settle_anchor':{'old':True},
            'close_arm_frozen':True,'recenter_offset_world':np.array([.001,0,0])}
        h.tick(1,[0,0,0]);self.assertNotIn('close_settle_anchor',h.state)
        np.testing.assert_array_equal(h.state['target_estimate_buffer'][0]['position'],[0,0,0])

    def test_recorded_raw_target_replay_and_absent_flag_compatibility(self):
        Q=Path(os.environ['BEAM_ESTIMATE_ORIGINAL_ROUND'])
        fixture=json.loads((Q/'review/close_failure_fixture.json').read_text())
        cfg=json.loads((Q/'production_worker_config.json').read_text())
        from toolkits.factory_dual_franka_assembly.local_skills import LocalSkillExecutor,normalize_local_skill_spec
        t=NS(cfg=NS(task_metadata=cfg['task_metadata']))
        original=LocalSkillExecutor()._merge_task_defaults(t,normalize_local_skill_spec(cfg['phase_specs'][90],'franka_left'))
        enabled={**original,**OPTIONS,'preclose_openness':.25}
        h=Harness(spec=enabled);h.task.cfg=t.cfg
        def feed(h,row):
            h.task.step_counter=row['step'];h.task.phase_step_counter=row['step']-46248
            h.q=np.asarray(row['current_q']);h.current_pose={'position':np.asarray(row['current_position']),
                'orientation':np.asarray(row['current_orientation'])}
            h.objects={original['object']:{'position':row['object_position'],'orientation':row['object_orientation']}}
            return h.a._close_pose_gate_action(phase_key=h.key,task=h.task,robot_name='franka_left',spec=h.spec,
                tracked_robots={},tracked_objects=h.objects)
        saved=None
        for row in fixture['close_gates']:
            feed(h,row)
            if row['step']<46296:self.assertNotIn('position',h.locked)
            elif saved is None:
                self.assertEqual(h.state['target_estimate_lock_step'],46296);saved=copy.deepcopy(h.locked)
            else:
                for k,v in saved.items():np.testing.assert_array_equal(h.locked[k],v)
        reference=json.loads((Q/'review/cc08/mean_replay_and_fixture_contacts.json').read_text())['mean_rule_analysis']
        target=reference['first_lock']['target'];delta=reference['first_lock']['half_deltas']
        np.testing.assert_allclose(saved['position'],target['position'],atol=1e-15,rtol=1e-12)
        np.testing.assert_allclose(saved['orientation'],target['orientation'],atol=1e-12,rtol=0)
        self.assertLessEqual(abs(h.state['target_estimate_half_deltas']['half_position_delta']-delta['half_position_delta_m']),1e-9)
        self.assertLessEqual(abs(h.state['target_estimate_half_deltas']['half_orientation_delta']-delta['half_orientation_delta_rad']),1e-9)
        position_error,orientation_error=pose_error(current_position=saved['position'],current_orientation=saved['orientation'],
            target_position=reference['reference_mean_46252_46968']['position'],target_orientation=reference['reference_mean_46252_46968']['orientation'])
        self.assertLess(abs(position_error-reference['locked_position_error_from_reference_m']),1e-9)
        self.assertLess(abs(orientation_error-reference['locked_orientation_error_from_reference_rad']),1e-9)
        modspec=importlib.util.spec_from_file_location('v219_estimate_baseline',ROOT/'baseline/toolkits/factory_dual_franka_assembly/plumbers_block_ur5e_skills.py')
        module=importlib.util.module_from_spec(modspec);modspec.loader.exec_module(module)
        old=Harness(module.UR5eAssemblyAtomicSkillAdapter,original);new=Harness(spec=original)
        old.task.cfg=new.task.cfg=t.cfg
        # Full gate path: measured original TCP/q, deterministic IK feedback
        # double, actual target conversion, servo limits and gate stability.
        old.a._solve_ik=new.a._solve_ik=lambda **kw:np.asarray(kw['warm_start']).copy()
        encode=lambda value:json.dumps(value,sort_keys=True,default=lambda x:x.tolist())
        for row in fixture['close_gates']:self.assertEqual(encode(feed(old,row)),encode(feed(new,row)))
        EVIDENCE['recorded']={'rows':len(fixture['close_gates']),'lock_step':h.state['target_estimate_lock_step'],
            'position_error_from_full_mean_m':position_error,'orientation_error_from_full_mean_rad':orientation_error,
            'half_deltas':h.state['target_estimate_half_deltas'],'absent_flag_gate_outputs_equal':720,
            'scope':'Production target/gate/limits/stability; original measured feedback, deterministic IK double; no PhysX.'}


if __name__=='__main__':unittest.main()

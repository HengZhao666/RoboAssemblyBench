"""Preserve one completed formal run's media/audit and close only its ledger row."""
from pathlib import Path
import argparse
import datetime
import fcntl
import importlib.util
import json
import re
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('run', help='latest completed formal ID')
    parser.add_argument('--resume-existing-audit', action='store_true')
    args = parser.parse_args()
    if not re.fullmatch(r'S[0-9]{2,}', args.run):
        parser.error('invalid formal ID')
    root = Path(__file__).resolve().parents[1]
    # Serialize launch and closure, including resume after a post-audit interruption.
    with (root/'stool_run.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        close(root, args)


def close(root, args):
    run = root / 'runs' / args.run
    ledger = root / 'execution_ledger.json'
    state = json.loads(ledger.read_text())
    execution = state['execution']
    row = execution['attempts'][-1]
    if row['id'] != args.run or row['closed'] or not (run/'finished_at').exists():
        raise RuntimeError('Only the latest completed, unclosed formal run can close')
    grant = row.get('grant', 'G01')
    if execution['formal_rounds_closed'] + 1 != execution['formal_rounds_started']:
        raise RuntimeError('Formal closure counter/order mismatch')
    audit_path, closure_path = run/'independent_audit.json', run/'formal_closure.json'
    if (audit_path.exists() or closure_path.exists()) and not args.resume_existing_audit:
        raise RuntimeError('Official audit/closure already exists; explicit resume never rewrites it')
    timing = dict(started_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  interpretation='Postprocessing wall time only; reused original media/audit have no new decode/audit duration')
    media = run/'media_verification.json'
    start = time.monotonic()
    if not media.exists():
        subprocess.run([sys.executable, str(root/'tools/check_stool_media.py'), str(run),
            '--ffmpeg-bin', '/Embodied_AI/miniconda3/envs/fabrica/bin'], check=False)
        timing['media_invocation_wall_seconds'] = time.monotonic()-start
        timing['media_report_reused'] = False
    else:
        timing['media_invocation_wall_seconds'] = None
        timing['media_report_reused'] = True
    spec = importlib.util.spec_from_file_location('stool_run_audit', root/'tools/audit_stool_run.py')
    auditor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(auditor)
    if args.resume_existing_audit:
        audit = json.loads(audit_path.read_text())
        if audit['auditor_sha256'] != auditor.digest(root/'tools/audit_stool_run.py'):
            raise RuntimeError('Existing official audit belongs to a different auditor')
        timing['audit_invocation_wall_seconds'] = None
        timing['official_audit_reused'] = True
    else:
        start = time.monotonic()
        audit = auditor.run_audit(run, source_binding=run/'runtime_source_binding.json', media_report=media)
        with audit_path.open('x') as stream:
            json.dump(audit, stream, indent=2, allow_nan=False)
            stream.write('\n')
        timing['audit_invocation_wall_seconds'] = time.monotonic()-start
        timing['official_audit_reused'] = False
    submitted = {}
    max_step = None
    boundary = run/'physics_boundary_trace.jsonl'
    if boundary.exists():
        with boundary.open() as stream:
            for line in stream:
                record = json.loads(line)
                max_step = max(max_step or 0, record.get('task_step', 0))
                for name, robot in record.get('robots', {}).items():
                    sequence = robot.get('sdk_submission', {}).get('batch_sequence', 0)
                    if isinstance(sequence, int) and not isinstance(sequence, bool):
                        submitted[name] = max(submitted.get(name, 0), sequence)
    first = any(submitted.values())
    original = audit['original_main_report']
    closure = dict(id=args.run, closed=True, grant=grant, native_observed=boundary.exists(),
        first_policy_action_observed=first, observed_sdk_sequences=submitted,
        last_observed_task_step=max_step, main_task_success=original.get('reported_success'),
        original_terminal_reason=original.get('terminal_reason'),
        full_motion_complete=audit.get('full_motion_completed') is True,
        strict_independent_audit=audit['strict_independent_audit_passed'],
        accepted_full_assembly=audit['accepted_full_assembly'],
        independent_audit=str(run/'independent_audit.json'),
        closure=str(run/'formal_closure.json'), media_verification=str(media),
        closed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), postprocessing_timing=timing)
    if closure_path.exists():
        original_closure = json.loads(closure_path.read_text())
        for key in closure:
            if key not in ('closed_at_utc', 'postprocessing_timing') and original_closure.get(key) != closure[key]:
                raise RuntimeError('Existing closure disagrees with original audit/evidence')
        closure = original_closure
    else:
        with closure_path.open('x') as stream:
            json.dump(closure, stream, indent=2)
            stream.write('\n')
    row.update(closure)
    execution['formal_rounds_closed'] += 1
    execution['first_policy_actions_observed'] = sum(
        int(item.get('first_policy_action_observed', False)) for item in execution['attempts'])
    for name in ('main_task_success', 'full_motion_complete', 'strict_independent_audit', 'accepted_full_assembly'):
        execution[name] = closure[name]
    execution['status'] = (grant+'_formal_limit_closed_paused'
        if execution['formal_rounds_closed'] >= state['authorization']['round_limit']
        else grant+'_'+args.run+'_closed_review_before_next')
    state['updated_at_utc'] = closure['closed_at_utc']
    temporary = ledger.with_suffix('.tmp')
    temporary.write_text(json.dumps(state, indent=2)+'\n')
    temporary.replace(ledger)
    print(json.dumps(closure))


if __name__ == '__main__':
    main()

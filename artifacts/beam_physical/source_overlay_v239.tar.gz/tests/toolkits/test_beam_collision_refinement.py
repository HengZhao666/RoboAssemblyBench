"""Geometry invariants, not a contact-dynamics or assembly success test."""
import unittest
from collections import Counter
import numpy as np
from roboassemblybench.core.beam_collision_refinement import refine_collision_triangles


def areas(p, f):
    v = p[f]
    return np.linalg.norm(np.cross(v[:,1]-v[:,0],v[:,2]-v[:,0]),axis=1)/2


class CollisionRefinement(unittest.TestCase):
    def test_noop_preserves_bytes_and_does_not_alias_inputs(self):
        p=np.array([[0.,0,0],[1.,0,0],[0,1.,0]])
        f=np.array([[0,1,2]],dtype=np.int64)
        r=refine_collision_triangles(p,f,2.)
        self.assertEqual(r['points'].tobytes(),p.tobytes())
        self.assertEqual(r['faces'].tobytes(),f.tobytes())
        self.assertFalse(np.shares_memory(r['points'],p))
        self.assertFalse(np.shares_memory(r['faces'],f))

    def test_shared_edges_and_winding_remain_closed_through_multiple_rounds(self):
        p=np.array([[0.,0,0],[1.,0,0],[0.,1,0],[0.,0,1]])
        f=np.array([[0,2,1],[0,1,3],[0,3,2],[1,2,3]])
        r=refine_collision_triangles(p,f,.22)
        edges=Counter(tuple(sorted((int(t[a]),int(t[b])))) for t in r['faces'] for a,b in [(0,1),(1,2),(2,0)])
        self.assertEqual(set(edges.values()),{2})
        directed=Counter((int(t[a]),int(t[b])) for t in r['faces'] for a,b in [(0,1),(1,2),(2,0)])
        self.assertTrue(all(directed[b,a]==n for (a,b),n in directed.items()))
        self.assertEqual(len(r['points'])-len(edges)+len(r['faces']),2)
        v=r['points'][r['faces']]
        self.assertAlmostEqual(np.einsum('ij,ij->i',v[:,0],np.cross(v[:,1],v[:,2])).sum()/6,1/6,places=13)
        self.assertGreater(r['rounds'],1)

    def test_asymmetric_skinny_faces_preserve_each_original_surface(self):
        rng=np.random.default_rng(731)
        for _ in range(20):
            p=rng.normal(size=(3,3))
            p[2]=p[0]+.001*(p[1]-p[0])+.008*rng.normal(size=3)
            f=np.array([[0,1,2]])
            r=refine_collision_triangles(p,f,.13)
            self.assertTrue(np.array_equal(r['points'][:3],p))
            self.assertAlmostEqual(areas(r['points'],r['faces']).sum(),areas(p,f).sum(),places=12)
            v=r['points'][r['faces']]
            n=np.cross(p[1]-p[0],p[2]-p[0]);n/=np.linalg.norm(n)
            self.assertLess(np.abs((r['points']-p[0])@n).max(),1e-12)
            self.assertTrue(np.all(np.cross(v[:,1]-v[:,0],v[:,2]-v[:,0])@n>0))
            self.assertLessEqual(max(np.linalg.norm(v[:,a]-v[:,b],axis=1).max() for a,b in [(0,1),(1,2),(2,0)]),.13*(1+1e-12))

    def test_rejects_bad_values_and_resource_explosion(self):
        p=np.array([[0.,0,0],[1.,0,0],[0,1.,0]]);f=np.array([[0,1,2]])
        for limit in [True,False,0.,-1.,float('inf'),float('nan'),'1']:
            with self.subTest(limit=limit),self.assertRaises(ValueError):refine_collision_triangles(p,f,limit)
        for bad in [np.array([[0.,1.,2.]]),np.array([[0,1,3]]),np.array([[0,0,2]])]:
            with self.assertRaises(ValueError):refine_collision_triangles(p,bad,.1)
        with self.assertRaises(ValueError):refine_collision_triangles(p,f,.0001,max_faces=4)
        self.assertTrue(np.array_equal(p,[[0,0,0],[1,0,0],[0,1,0]]))


if __name__=='__main__':unittest.main()

"""Standalone constraint-checking demonstrations."""

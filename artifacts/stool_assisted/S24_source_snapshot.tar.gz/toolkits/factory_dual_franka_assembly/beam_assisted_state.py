"""Measured-pose assistance for the explicitly selected Beam route."""
from __future__ import annotations

import copy
import json
import math
import os
from pathlib import Path

import numpy as np


def bounded_native_target(target, actual, previous=None, step=.02, tracking=.12, *, unwrap=True):
    actual = np.asarray(actual, dtype=float).reshape(-1)
    target = np.asarray(target, dtype=float).reshape(-1)
    if target.shape != actual.shape or not np.all(np.isfinite([target, actual])):
        raise ValueError('invalid assisted arm command/state')
    if unwrap:
        target = actual + (target - actual + np.pi) % (2*np.pi) - np.pi
    anchor = actual
    if previous is not None:
        previous = np.asarray(previous, dtype=float).reshape(-1)
        if (previous.shape == actual.shape and np.all(np.isfinite(previous))
                and np.max(np.abs(previous-actual)) <= tracking):
            anchor = previous
    result = anchor + np.clip(target-anchor, -step, step)
    return np.clip(result, actual-tracking, actual+tracking)


def consecutive_native_gate(state, stamp, ready, required, poses=None,
                            position_drift_limit=.0003, orientation_drift_limit=.005):
    """Count a predicate once on consecutive, unchanged native physics ticks."""
    valid = (stamp.get('valid') is True and type(stamp.get('epoch')) is int
             and type(stamp.get('index')) is int)
    try:
        valid = bool(valid and stamp['epoch'] >= 0 and stamp['index'] >= 0
                     and math.isfinite(stamp['time']) and stamp['time'] >= 0
                     and math.isfinite(stamp['dt']) and stamp['dt'] > 0)
    except (KeyError, TypeError):
        valid = False
    if not valid:
        state.update(previous=None, count=0, pose_anchor=None)
        return False
    old = state.get('previous')
    same = bool(old and (old['epoch'], old['index']) == (stamp['epoch'], stamp['index']))
    if same and (old['time'] != stamp['time'] or old['dt'] != stamp['dt']):
        state.update(previous=None, count=0, pose_anchor=None)
        return False
    if not ready:
        state.update(previous=dict(stamp), count=0, pose_anchor=None)
        return False
    if not same:
        consecutive = bool(old and old['epoch'] == stamp['epoch']
            and stamp['index'] == old['index'] + 1
            and math.isclose(old['dt'], stamp['dt'], rel_tol=1e-9, abs_tol=1e-12)
            and math.isclose(stamp['time'] - old['time'], stamp['dt'],
                             rel_tol=1e-6, abs_tol=max(1e-10, stamp['dt'] * 1e-6)))
        if not consecutive:
            state['count'] = 0
            state['pose_anchor'] = None
        state['count'] = state.get('count', 0) + 1
        state['previous'] = dict(stamp)
    if poses is not None:
        from .planner_primitives import pose_error
        last_poses = state.get('last_poses')
        if same and last_poses is not None:
            changed = set(last_poses) != set(poses)
            for name, current in poses.items():
                previous = last_poses.get(name)
                if previous is None:
                    changed = True
                    continue
                dp, dq = pose_error(current_position=current['position'],
                    current_orientation=current['orientation'],
                    target_position=previous['position'], target_orientation=previous['orientation'])
                changed = bool(changed or dp > 1e-12 or dq > 1e-12
                    or current['body_path'] != previous['body_path']
                    or current['motion_view_id'] != previous['motion_view_id'])
            if changed:
                state.update(count=0, pose_anchor=None, last_poses=None)
                return False
        state['last_poses'] = copy.deepcopy(poses)
        anchor = state.get('pose_anchor')
        if anchor is not None:
            stable = set(anchor) == set(poses)
            for name, current in poses.items():
                previous = anchor.get(name)
                if previous is None:
                    stable = False
                    continue
                position_error, orientation_error = pose_error(
                    current_position=current['position'], current_orientation=current['orientation'],
                    target_position=previous['position'], target_orientation=previous['orientation'])
                stable = bool(stable and position_error <= position_drift_limit
                    and orientation_error <= orientation_drift_limit
                    and current['body_path'] == previous['body_path']
                    and current['motion_view_id'] == previous['motion_view_id'])
            if not stable:
                state.update(count=0, pose_anchor=None)
                return False
        else:
            state['pose_anchor'] = copy.deepcopy(poses)
    return state.get('count', 0) >= max(int(required), 1)


class BeamAssistedState:
    def _assisted_task_contract(self):
        """Only explicit task opt-ins may parameterize the legacy Beam hooks."""
        return getattr(self, '_fabrica_assisted_contract', {}) or {}

    def _assisted_final_phase_name(self):
        return self._assisted_task_contract().get('final_phase_name', 'beam_assisted_final_verification')

    def _assisted_forbid_body_rewrite(self, object_name, operation):
        if (getattr(self, '_beam_assisted_enabled', False)
                and (str(object_name).startswith('fabrica_beam_')
                     or object_name in self._assisted_task_contract().get('objects', []))):
            raise RuntimeError(f'assisted route forbids {operation}: {object_name}')

    def _assisted_event(self, event, **detail):
        path = os.environ.get('BEAM_ASSISTED_TRACE_PATH')
        if path:
            with Path(path).open('a') as stream:
                stream.write(json.dumps({'event': event, 'step': int(self.step_counter),
                    'phase': self.phase, 'physics_stamp': self._beam_physics_stamp(),
                    'route': 'assisted', 'formal_physical_success': False,
                    **detail}, default=lambda x: x.tolist())+'\n')

    def _assisted_body_path(self, object_name):
        body = self._resolve_object(object_name)
        prim = self._object_prims[object_name]
        owners = list(self._iter_rigid_body_prims(prim))
        if len(owners) != 1:
            raise RuntimeError(f'assisted object must resolve one rigid body: {object_name}')
        return body, str(owners[0].GetPath())

    def _assisted_joint(self, path, body_path, position, orientation,
                        hand=None):
        from pxr import Gf, Sdf, UsdPhysics
        from isaacsim.core.utils.stage import get_current_stage
        from .planner_primitives import relative_pose
        stage = get_current_stage()
        if stage.GetPrimAtPath(path).IsValid():
            stage.RemovePrim(path)
        joint = UsdPhysics.FixedJoint.Define(stage, path)
        joint.CreateJointEnabledAttr(False)
        joint.CreateExcludeFromArticulationAttr(True)
        joint.CreateBody0Rel().SetTargets([Sdf.Path(body_path)])
        joint.CreateLocalPos0Attr(Gf.Vec3f(0, 0, 0))
        joint.CreateLocalRot0Attr(Gf.Quatf(1, 0, 0, 0))
        if hand is None:
            local_p, local_q = position, orientation
        else:
            hand_p, hand_q = hand.get_pose()
            local_p, local_q = relative_pose(base_position=hand_p,
                base_orientation=hand_q, world_position=position,
                world_orientation=orientation)
            joint.CreateBody1Rel().SetTargets([Sdf.Path(hand.unwrap().prim_path)])
        joint.CreateLocalPos1Attr(Gf.Vec3f(*map(float, local_p)))
        joint.CreateLocalRot1Attr(Gf.Quatf(*map(float, local_q)))
        joint.CreateCollisionEnabledAttr(True)
        joint.CreateJointEnabledAttr(True)
        local_rotation = joint.GetLocalRot1Attr().Get()
        self._assisted_event('joint_anchor_readback', joint_path=path,
            body0=list(map(str, joint.GetBody0Rel().GetTargets())),
            body1=list(map(str, joint.GetBody1Rel().GetTargets())),
            local_position0=list(joint.GetLocalPos0Attr().Get()),
            local_position1=list(joint.GetLocalPos1Attr().Get()),
            local_orientation1=[float(local_rotation.GetReal()),
                                *map(float, local_rotation.GetImaginary())],
            authored_enabled=joint.GetJointEnabledAttr().Get(),
            collision_enabled=joint.GetCollisionEnabledAttr().Get(),
            measured_object_position=position, measured_object_orientation=orientation,
            scope='USD joint-attribute readback at creation; not a native solver-error measurement')
        return path

    def _assisted_remove_world_joint(self, object_name):
        joints = getattr(self, '_assisted_world_joints', {})
        path = joints.pop(object_name, None)
        getattr(self, '_assisted_install_alignment', {}).pop(object_name, None)
        if path:
            from isaacsim.core.utils.stage import get_current_stage
            get_current_stage().RemovePrim(path)
            self._assisted_event('remove_world_support', object=object_name,
                                 joint_path=path)

    def _assisted_attach(self, object_name, robot_name, phase_spec, attach_spec):
        from .planner_primitives import relative_pose
        metrics = self._gripper_contact_metrics(object_name, robot_name,
                                               attach_spec=attach_spec)
        strict = self._strict_physical_grasp_contact(object_name, metrics,
                                                    attach_spec=attach_spec)
        visual_pinch = bool(attach_spec.get('beam_assisted_visual_pinch'))
        visual_detail = None
        if visual_pinch:
            from .beam_assisted_visual_grasp import ready, native_gaps, hold_command
            if not ready(self, robot_name, object_name):
                raise RuntimeError('assisted joint rejected: visible surfaces are not in a clear dual pinch')
            gaps, _ = native_gaps(self, robot_name, object_name)
            visual_detail = {'qualification': ('dual_native_visible_pad_CAD_near_fit'
                if self._assisted_task_contract() else 'dual_visible_CAD_surfaces'), 'gaps': gaps,
                             'force_contact_is_not_the_assisted_qualification': True}
            saved = {'gripper_openness': hold_command(self, robot_name, object_name)}
        elif not strict.get('physical_contact_ready'):
            raise RuntimeError('assisted joint rejected: fingers are not touching the part')
        else:
            saved = getattr(self, '_ur5e_contact_hold_commands', {}).get(robot_name)
        if self._assisted_task_contract():
            key = (self.phase_index, self.phase_entry_step, object_name, robot_name)
            gate = getattr(self, '_fabrica_contact_gates', {}).get(key, {})
            if (gate.get('previous') != self._beam_physics_stamp()
                    or gate.get('count', 0) < int(self._assisted_task_contract()['contact_stable_physics_steps'])):
                raise RuntimeError('stool attachment lacks its current native contact qualification window')
            # Save the final openness only after that batch reached the SDK;
            # the generic close controller need not opt in to Beam control.
            submitted = getattr(self, '_fabrica_final_gripper_commands', {}).get(robot_name)
            robot = self.robots[robot_name]
            if (not submitted or submitted['expected_sdk_batch_sequence'] != getattr(robot, '_action_batch_sequence', None)
                    or 'gripper_controller' not in getattr(robot, 'last_action_controller_names', [])):
                raise RuntimeError('stool attachment lacks its completed final gripper SDK command')
            if visual_pinch and not np.isclose(float(saved['gripper_openness']),
                    float(submitted['gripper_openness']), rtol=0., atol=0.):
                raise RuntimeError('stool CAD hold differs from completed final SDK gripper command')
            saved = submitted
        if saved is None or not np.isfinite(saved.get('gripper_openness', np.nan)):
            raise RuntimeError('assisted grasp lacks its actual closing command')
        if visual_pinch:
            if not hasattr(self, '_ur5e_contact_hold_commands'):
                self._ur5e_contact_hold_commands = {}
            self._ur5e_contact_hold_commands[robot_name] = copy.deepcopy(saved)
        body, body_path = self._assisted_body_path(object_name)
        stamp = self._beam_physics_stamp()
        if self._assisted_task_contract() and stamp.get('valid') is not True:
            raise RuntimeError('assisted attachment lacks a native clock')
        position, orientation = body.get_pose()
        hand = self._get_robot_hand_rigid_body(robot_name)
        if hand is None:
            raise RuntimeError('assisted joint rejected: missing native hand body')
        tcp_p, tcp_q = self._get_robot_task_pose(robot_name)
        rel_p, rel_q = relative_pose(base_position=tcp_p, base_orientation=tcp_q,
                                    world_position=position, world_orientation=orientation)
        captured_joint_positions = np.asarray(self.robots[robot_name].articulation.get_joint_positions()).copy()
        captured_hand_position, captured_hand_orientation = hand.get_pose()
        hand_object_p, hand_object_q = relative_pose(
            base_position=captured_hand_position, base_orientation=captured_hand_orientation,
            world_position=position, world_orientation=orientation)
        hand_tcp_p, hand_tcp_q = relative_pose(
            base_position=captured_hand_position, base_orientation=captured_hand_orientation,
            world_position=tcp_p, world_orientation=tcp_q)
        if self._assisted_task_contract() and self._beam_physics_stamp() != stamp:
            raise RuntimeError('native clock changed while capturing attachment frames')
        self._assisted_remove_world_joint(object_name)
        path = self._assisted_joint(self._attachment_joint_path(object_name),
                                   body_path, position, orientation, hand)
        self._attachment_joints[object_name] = path
        self._attachments[object_name] = {
            'robot_name': robot_name, 'position': rel_p.tolist(),
            'orientation': rel_q.tolist(), 'mode': 'fixed_joint',
            'joint_path': path, 'contact_metrics': copy.deepcopy(metrics),
            'collision_disabled': False, 'attach_spec': copy.deepcopy(attach_spec),
            'phase': phase_spec.get('name'), 'attach_step': int(self.step_counter),
            'attach_world_position': np.asarray(position).tolist(),
            'attach_world_orientation': np.asarray(orientation).tolist(),
            'capture_physics_stamp': dict(stamp),
            'hand_object_position': np.asarray(hand_object_p).tolist(),
            'hand_object_orientation': np.asarray(hand_object_q).tolist(),
            'hand_tcp_position': np.asarray(hand_tcp_p).tolist(),
            'hand_tcp_orientation': np.asarray(hand_tcp_q).tolist(),
            'tcp_frame_source': 'task_measured_eef' if self._assisted_task_contract() else 'legacy_beam_measured_joint_lula',
        }
        self._attachments[object_name]['assisted_hold_openness'] = float(saved['gripper_openness'])
        self._locked_targets.pop(object_name, None)
        self._frozen_lock_poses.pop(object_name, None)
        self._locked_collision_states.pop(object_name, None)
        self._assisted_event('attach_measured_pose', object=object_name,
            robot=robot_name, joint_path=path, position=position,
            orientation=orientation, contact_metrics=metrics, strict_contact=strict,
            visible_pinch=visual_detail,
            full_joint_positions=captured_joint_positions,
            native_hand_position=captured_hand_position,
            native_hand_orientation=captured_hand_orientation)

    def _assisted_lock(self, object_name, target_name, lock_spec):
        if self._locked_targets.get(object_name) == target_name:
            return
        body, body_path = self._assisted_body_path(object_name)
        position, orientation = body.get_pose()
        contract = self._assisted_task_contract()
        if contract:
            # The original stool base release rebases the complete assembly.
            # Preserve this measured transform before authoring the support.
            from .planner_primitives import relative_pose, compose_pose
            rebased_names = list(dict.fromkeys([*self._as_list(lock_spec.get('rebase_targets')), target_name]))
            if lock_spec.get('rebase_targets'):
                original = copy.deepcopy({name: self.target_poses[name] for name in rebased_names})
                anchor = original[target_name]
                for name in rebased_names:
                    pose = original[name]
                    local_p, local_q = relative_pose(base_position=anchor['position'],
                        base_orientation=anchor['orientation'], world_position=pose['position'],
                        world_orientation=pose['orientation'])
                    world_p, world_q = compose_pose(base_position=position, base_orientation=orientation,
                        local_position=local_p, local_orientation=local_q)
                    self.target_poses[name] = {'position': np.asarray(world_p), 'orientation': np.asarray(world_q)}
                self._assisted_event('rebase_targets', object=object_name,
                    original_targets=original, running_targets={name:self.target_poses[name] for name in rebased_names},
                    measured_anchor_position=position, measured_anchor_orientation=orientation)
        released_robot = self._attachments.get(object_name, {}).get('robot_name')
        self._remove_attachment_joint(object_name)
        self._attachments.pop(object_name, None)
        path = self._attachment_joint_path(object_name) + '_world_support'
        self._assisted_joint(path, body_path, position, orientation)
        if not hasattr(self, '_assisted_world_joints'):
            self._assisted_world_joints = {}
        self._assisted_world_joints[object_name] = path
        final_target = contract.get('final_target_names', {}).get(object_name)
        if (target_name == final_target if contract else target_name.endswith('_assembled')):
            if not hasattr(self, '_assisted_install_alignment'):
                self._assisted_install_alignment = {}
            target = self.target_poses[target_name]
            self._assisted_install_alignment[object_name] = {
                'joint_path': path, 'position': np.asarray(position, float).copy(),
                'orientation': np.asarray(orientation, float).copy(),
                'target_position': np.asarray(target['position'], float).copy(),
                'target_orientation': np.asarray(target['orientation'], float).copy(),
                'release_robot': released_robot,
                'complete': False,
            }
        self._locked_targets[object_name] = target_name
        self._lock_pin_pose[object_name] = False
        self._locked_collision_states[object_name] = True
        self._frozen_lock_poses.pop(object_name, None)
        self._assisted_event('support_measured_pose', object=object_name,
            target=target_name, joint_path=path, position=position,
            orientation=orientation, target_pose=self.target_poses.get(target_name))

    def _assisted_update_install_alignment(self):
        if getattr(self, 'failed', False):
            return
        states = getattr(self, '_assisted_install_alignment', {})
        eligible = {name: s for name, s in states.items()
                    if not s['complete'] and (not s.get('release_robot') or
                       self._assisted_robot_gripper_is_open(s['release_robot']))}
        if not eligible:
            return
        stamp = self._beam_physics_stamp()
        if not stamp.get('valid'):
            raise RuntimeError('assisted installation alignment lacks a native physics clock')
        clock = (stamp.get('epoch'), stamp['index'])
        if getattr(self, '_assisted_alignment_clock', None) == clock:
            return
        self._assisted_alignment_clock = clock
        from pxr import Gf, UsdPhysics
        from isaacsim.core.utils.stage import get_current_stage
        stage = get_current_stage()
        for name, s in eligible.items():
            contract = self._assisted_task_contract()
            position_step = float(contract['install_position_step_m']) if contract else .0001
            orientation_step = float(contract['install_orientation_step_rad']) if contract else .0002
            delta = s['target_position'] - s['position']
            length = float(np.linalg.norm(delta))
            proposed_position = s['position'] + delta * min(1., position_step / max(length, 1e-15))
            q = s['orientation'] / np.linalg.norm(s['orientation'])
            target = s['target_orientation'] / np.linalg.norm(s['target_orientation'])
            if np.dot(q, target) < 0:
                target = -target
            angle = 2 * np.arccos(np.clip(np.dot(q, target), -1., 1.))
            ratio = min(1., orientation_step / max(float(angle), 1e-15))
            q = (1-ratio)*q + ratio*target
            proposed_orientation = q / np.linalg.norm(q)
            if contract:
                guard = getattr(self, '_fabrica_production_support_guard', None)
                if not callable(guard):
                    raise RuntimeError('stool installation anchor lacks its complete-scene production guard')
                detail = guard(name, proposed_position.copy(), proposed_orientation.copy(), dict(stamp))
                if (not isinstance(detail, dict) or detail.get('passed') is not True
                        or detail.get('object', name) != name
                        or detail.get('physics_stamp', stamp) != stamp
                        or self._beam_physics_stamp() != stamp):
                    raise RuntimeError('stool installation support command rejected or stale')
                self._assisted_event('fabrica_installation_support_guard', **dict(detail, object=name))
            s['position'] = proposed_position
            s['orientation'] = proposed_orientation
            joint = UsdPhysics.FixedJoint.Get(stage, s['joint_path'])
            if not joint:
                raise RuntimeError('assisted installation support joint disappeared')
            joint.GetLocalPos1Attr().Set(Gf.Vec3f(*map(float, s['position'])))
            joint.GetLocalRot1Attr().Set(Gf.Quatf(*map(float, s['orientation'])))
            if int(self.step_counter) % 8 == 0:
                self._assisted_event('installation_anchor_command', object=name,
                    anchor_position=s['position'], anchor_orientation=s['orientation'],
                    target_position=s['target_position'], target_orientation=s['target_orientation'],
                    max_anchor_step_m=position_step, max_anchor_step_rad=orientation_step)
            if length <= position_step and angle <= orientation_step:
                s['complete'] = True
                self._assisted_event('installation_anchor_at_goal', object=name,
                    anchor_position=s['position'], anchor_orientation=s['orientation'],
                    max_anchor_step_m=position_step, max_anchor_step_rad=orientation_step,
                    actual_pose_still_requires_native_readback=True)

    def _assisted_release_open(self, phase_spec):
        final = phase_spec.get('name') == self._assisted_final_phase_name()
        if not phase_spec.get('lock') and not phase_spec.get('detach') and not final:
            return True
        for name, command in phase_spec.get('gripper_commands', {}).items():
            if command != 'open':
                continue
            if not self._assisted_robot_gripper_is_open(name):
                return False
        installed = list(phase_spec.get('beam_assisted_installed_parts', []))
        if not installed:
            return True
        stamp = self._beam_physics_stamp()
        sample = self._assisted_installation_sample(installed, stamp, final=final)
        self._assisted_install_gate_sample = sample
        key = (self.phase_index, self.phase_entry_step, tuple(installed))
        gates = getattr(self, '_assisted_release_gates', None)
        if gates is None:
            gates = self._assisted_release_gates = {}
        gate = gates.setdefault(key, {})
        contract = self._assisted_task_contract()
        required = 1 if final else int(contract.get('release_stable_physics_steps', 12))
        ready = consecutive_native_gate(gate, stamp, sample['ready'], required,
            poses=sample['objects'], position_drift_limit=contract.get('stable_position_drift_m', .0003),
            orientation_drift_limit=contract.get('stable_orientation_drift_rad', .005))
        previous = gate.get('reported')
        signature = (sample['ready'], sample.get('reason'), ready)
        if previous != signature or int(self.step_counter) % 48 == 0:
            self._assisted_event('installation_native_gate', final=final,
                required_stable_physics_steps=required,
                stable_physics_steps=gate.get('count', 0), ready=ready, sample=sample)
            gate['reported'] = signature
        return ready

    def _assisted_native_body_motion(self, name, epoch, *, include_center_of_mass=False):
        """Read only existing exact-path views; qualification never initializes one."""
        from .beam_support_state import live_body_snapshot
        body, path = self._assisted_body_path(name)
        native = getattr(self, '_assisted_native_body_readers', {}).get(path)
        errors = []
        for source, wrapper in (('preflight_native_reader', native), ('resolved_object', body)):
            if wrapper is None:
                continue
            unwrap = getattr(wrapper, 'unwrap', None)
            reader = unwrap() if callable(unwrap) else wrapper
            if str(getattr(reader, 'prim_path', '')) != path:
                raise ValueError('Assisted native installation body path alias: ' + name)
            view = getattr(reader, '_rigid_prim_view', None)
            if view is None or not view.is_physics_handle_valid():
                errors.append(source + ':invalid_or_absent_live_view')
                continue
            observed = getattr(self, '_assisted_install_observed_views', None)
            if observed is None:
                observed = self._assisted_install_observed_views = {}
            # Retain read-only references so replacing a wrapper cannot reuse
            # an old Python identity while a pose window/certificate owns it.
            observed.setdefault((epoch, path, id(view)), view)
            result = live_body_snapshot(view)
            if include_center_of_mass:
                from .beam_physics_diagnostics import _body_com_snapshot
                com = _body_com_snapshot(view, np.asarray([result['position']], float),
                                         np.asarray([result['orientation']], float))
                if not com.get('valid') or com.get('position_frame') != 'world':
                    raise ValueError('Assisted transition lacks an existing live COM readback')
                result.update(center_of_mass_valid=True, center_of_mass_source=com['source'],
                    center_of_mass_position_frame='world', center_of_mass_orientation_order='wxyz',
                    center_of_mass_position=com['world_positions'][0],
                    center_of_mass_orientation=com['world_orientations'][0])
            result.update(body_path=path, motion_view_id=id(view),
                          motion_source='existing_exact_path_native_view',
                          existing_view_source=source)
            return result
        raise ValueError('No existing live assisted installation view for ' + name + '; ' + ','.join(errors))

    def _assisted_support_joint_live(self, name, state, body_path):
        from pxr import UsdPhysics
        from isaacsim.core.utils.stage import get_current_stage
        path = getattr(self, '_assisted_world_joints', {}).get(name)
        if not path or path != state.get('joint_path'):
            return False
        joint = UsdPhysics.FixedJoint.Get(get_current_stage(), path)
        return bool(joint and joint.GetJointEnabledAttr().Get()
                    and [str(p) for p in joint.GetBody0Rel().GetTargets()] == [body_path]
                    and not joint.GetBody1Rel().GetTargets())

    def _assisted_home_sample(self, targets, stamp):
        """Read existing native arm views on the configured raw initial branch."""
        result = {'ready': False, 'physics_stamp': dict(stamp), 'robots': {}}
        try:
            if (stamp.get('valid') is not True or type(stamp.get('epoch')) is not int
                    or type(stamp.get('index')) is not int or stamp['epoch'] < 0
                    or stamp['index'] < 0 or not math.isfinite(stamp['time'])
                    or not math.isfinite(stamp['dt']) or stamp['time'] < 0 or stamp['dt'] <= 0
                    or self._beam_physics_stamp() != stamp):
                raise ValueError('Home qualification lacks the current native physics clock')
            if not isinstance(targets, dict) or len(targets) != 2 or set(targets) != set(self.robots):
                raise ValueError('Home qualification must cover both configured robots')
            arm_names = ['shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint',
                         'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint']
            for name, target in targets.items():
                robot = self.robots[name]
                config = robot.config
                configured = config.initial_joint_positions
                names = target.get('joint_names')
                goal = np.asarray(target.get('joint_positions'), dtype=float)
                if (names != arm_names or goal.shape != (6,) or not np.all(np.isfinite(goal))
                        or target.get('tolerance_rad') != .01
                        or not isinstance(configured, dict)
                        or any(j not in configured for j in arm_names)
                        or not np.array_equal(goal, np.asarray([configured[j] for j in arm_names], float))):
                    raise ValueError('Home target differs from the configured initial native branch: ' + name)
                articulation = robot.articulation
                view = articulation._articulation_view
                if not view.is_physics_handle_valid():
                    raise ValueError('Home qualification lacks an existing live articulation view: ' + name)
                native_names = list(articulation.dof_names)
                if (len(native_names) != 12 or len(set(native_names)) != 12
                        or any(native_names.count(j) != 1 for j in arm_names)):
                    raise ValueError('Home native joint names are incomplete or aliased: ' + name)
                raw = np.asarray(view.get_joint_positions(clone=True), dtype=float)
                if raw.shape != (1, len(native_names)) or not np.all(np.isfinite(raw)):
                    raise ValueError('Home qualification lacks complete finite native joint readback: ' + name)
                actual = raw[0, [native_names.index(j) for j in arm_names]]
                error = float(np.max(np.abs(actual - goal)))
                result['robots'][name] = {'ready': error <= .01,
                    'joint_names': list(names), 'target_joint_positions': goal.tolist(),
                    'joint_positions': actual.tolist(), 'maximum_error_rad': error,
                    'tolerance_rad': .01, 'native_dof_names': native_names,
                    'full_native_joint_positions': raw[0].tolist(),
                    'articulation_id': id(articulation), 'motion_view_id': id(view),
                    'source': 'same_existing_live_articulation_view.get_joint_positions',
                    'angle_comparison': 'raw_native_branch_no_modulo'}
                if (list(articulation.dof_names) != native_names
                        or articulation._articulation_view is not view
                        or not view.is_physics_handle_valid()):
                    raise ValueError('Home articulation identity changed during native readback: ' + name)
            if (len({r['articulation_id'] for r in result['robots'].values()}) != 2
                    or len({r['motion_view_id'] for r in result['robots'].values()}) != 2):
                raise ValueError('Home qualification aliased the two robot articulations/views')
            if self._beam_physics_stamp() != stamp:
                raise ValueError('Home physics clock changed during native readback')
            result['ready'] = all(r['ready'] for r in result['robots'].values())
            if not result['ready']:
                result['reason'] = 'native_arm_outside_initial_joint_tolerance'
        except Exception as exc:
            result['reason'] = f'{type(exc).__name__}: {exc}'
        return result

    def _assisted_installation_sample(self, names, stamp, *, final=False):
        """Qualify all installed actors at one clock, including actual motion."""
        from .planner_primitives import pose_error
        result = {'ready': False, 'physics_stamp': dict(stamp), 'objects': {}}
        try:
            if stamp.get('valid') is not True:
                raise ValueError('Installation native physics clock unavailable')
            if not names or len(set(names)) != len(names):
                raise ValueError('Installation body collection is empty or duplicated')
            states = getattr(self, '_assisted_install_alignment', {})
            for name in names:
                state = states.get(name)
                if not state or not state.get('complete'):
                    raise ValueError('Installation anchor has not reached its goal: ' + name)
                if name in getattr(self, '_attachments', {}):
                    raise ValueError('Installed part remains attached to a robot: ' + name)
                contract = self._assisted_task_contract()
                target_name = getattr(self, '_locked_targets', {}).get(name)
                valid_target = (target_name == contract.get('final_target_names', {}).get(name)
                    if contract else bool(target_name and target_name.endswith('_assembled')))
                if not valid_target:
                    raise ValueError('Installed part lacks its final target: ' + name)
                motion = self._assisted_native_body_motion(name, stamp['epoch'])
                if not self._assisted_support_joint_live(name, state, motion['body_path']):
                    raise ValueError('Installation world-support joint is absent or invalid: ' + name)
                target = self.target_poses[target_name]
                position_error, orientation_error = pose_error(
                    current_position=motion['position'], current_orientation=motion['orientation'],
                    target_position=target['position'], target_orientation=target['orientation'])
                if contract:
                    criteria = {c['object']: c for c in self.cfg.success_criteria}
                    criterion = criteria[name]
                    position_limit, orientation_limit = self._target_tolerances(target_spec=target,
                        default_position_tolerance=float(criterion.get('position_tolerance', criterion.get('tolerance', .03))),
                        default_orientation_tolerance=criterion.get('orientation_tolerance'))
                else:
                    position_limit, orientation_limit = (.003 if final else .001), (.04 if final else .003)
                within = bool(position_error <= position_limit
                    and (orientation_limit is None or orientation_error <= orientation_limit))
                result['objects'][name] = {**motion, 'target': target_name,
                    'position_error': float(position_error), 'orientation_error': float(orientation_error),
                    'ready': within, 'velocity_qualification': 'raw_diagnostic_only_pose_window_required'}
                try:
                    if contract:
                        criterion = criteria[name]
                        static = self._object_velocity_metrics(name,
                            linear_threshold=float(criterion.get('linear_velocity_threshold', .01)),
                            angular_threshold=float(criterion.get('angular_velocity_threshold', .5)))
                    else:
                        static = self._object_velocity_metrics(name)
                    result['objects'][name]['legacy_static_reading'] = static
                    if contract and criterion.get('require_static'):
                        result['objects'][name]['ready'] = bool(within and static.get('valid') and static.get('is_static'))
                except Exception as exc:
                    result['objects'][name]['legacy_static_reading'] = {'error': str(exc)}
            phases = getattr(self, 'phase_specs', [])
            has_home_targets = bool(final and phases and 'beam_assisted_home_targets' in phases[-1])
            if has_home_targets:
                home_targets = phases[-1]['beam_assisted_home_targets']
                result['home'] = self._assisted_home_sample(home_targets, stamp)
                if not result['home']['ready']:
                    raise ValueError('Final native home rejected: ' + str(result['home'].get('reason')))
            if self._beam_physics_stamp() != stamp:
                raise ValueError('Installation physics clock changed during native readback')
            result['ready'] = all(o['ready'] for o in result['objects'].values())
            if not result['ready']:
                result['reason'] = 'native_pose_outside_installation_limits'
        except Exception as exc:
            result['reason'] = f'{type(exc).__name__}: {exc}'
        if (not result['ready'] and final and getattr(self, 'phase_specs', [])
                and 'beam_assisted_home_targets' in self.phase_specs[-1]):
            # The ordinary runner may return before conditions_stable when
            # release/native qualification fails. Clear this new joint/object
            # window immediately rather than retaining a stale certificate.
            gate = getattr(self, '_assisted_final_gate', None)
            if gate is not None:
                gate.update(previous=None, count=0, pose_anchor=None,
                            last_poses=None, previous_home=None)
            self.__dict__.pop('_assisted_final_certificate', None)
        return result

    def _assisted_conditions_stable(self, advance, ready):
        """Final common window uses this route's clock, independent of table contact."""
        support_stage=advance.get('fabrica_base_support_stage')
        if support_stage is not None:
            return self._assisted_base_support_condition(support_stage,advance,ready)
        key = (self.phase_index, self.phase_entry_step, json.dumps(advance, sort_keys=True))
        state = getattr(self, '_assisted_final_gate', None)
        if state is None or state['key'] != key:
            state = self._assisted_final_gate = {'key': key}
        stamp = self._beam_physics_stamp()
        sample = getattr(self, '_assisted_install_gate_sample', {})
        ready = bool(ready and sample.get('ready')
                     and sample.get('physics_stamp') == stamp)
        if self._assisted_task_contract().get('base_support'):
            ready = bool(ready and self._assisted_base_support_released_ready())
        if 'home' in sample:
            home = sample['home']
            ready = bool(ready and home.get('ready') and home.get('physics_stamp') == stamp
                         and set(home.get('robots', {})) == set(self.robots))
            previous_home = state.get('previous_home')
            if previous_home and ready:
                same = previous_home['physics_stamp'] == stamp
                for name, current in home['robots'].items():
                    old = previous_home['robots'].get(name, {})
                    replaced = any(current.get(k) != old.get(k) for k in
                                   ('articulation_id', 'motion_view_id', 'native_dof_names'))
                    changed_same_tick = same and current.get('full_native_joint_positions') != old.get('full_native_joint_positions')
                    if replaced or changed_same_tick:
                        ready = False
            state['previous_home'] = copy.deepcopy(home) if ready else None
        contract = self._assisted_task_contract()
        qualified = consecutive_native_gate(state, stamp, ready, advance['physics_stable_steps'],
            poses=sample.get('objects', {}), position_drift_limit=contract.get('stable_position_drift_m', .0003),
            orientation_drift_limit=contract.get('stable_orientation_drift_rad', .005))
        phases = getattr(self, 'phase_specs', [])
        if (qualified and phases and self.phase_index == len(phases) - 1
                and self.phase == phases[-1].get('name') == self._assisted_final_phase_name()
                and int(advance['physics_stable_steps']) >= int(contract.get('final_stable_physics_steps', 240))):
            self._assisted_final_certificate = {
                'identity': self._assisted_final_identity(phases[-1]),
                'phase_index': self.phase_index, 'phase_entry_step': self.phase_entry_step,
                'gate_key': key, 'physics_stamp': dict(stamp),
                'stable_physics_steps': state.get('count', 0),
                'required_stable_physics_steps': int(advance['physics_stable_steps']),
                'native_poses': copy.deepcopy(sample['objects']),
            }
            if 'home' in sample:
                self._assisted_final_certificate['native_home'] = copy.deepcopy(sample['home'])
        elif not qualified:
            self.__dict__.pop('_assisted_final_certificate', None)
        if state.get('reported_ready') != qualified or int(self.step_counter) % 48 == 0:
            self._assisted_event('final_native_common_window', ready=qualified,
                stable_physics_steps=state.get('count', 0),
                required_stable_physics_steps=advance['physics_stable_steps'],
                pose_drift_position_budget_m=contract.get('stable_position_drift_m', .0003),
                pose_drift_orientation_budget_rad=contract.get('stable_orientation_drift_rad', .005))
            state['reported_ready'] = qualified
        return qualified

    def _assisted_final_identity(self, final):
        cfg = getattr(self, 'cfg', None)
        criteria = getattr(cfg, 'success_criteria', [])
        targets = {str(c.get('target') or c.get('target_name')):
                   self.target_poses.get(c.get('target') or c.get('target_name')) for c in criteria}
        return {'task_instance': id(self), 'task_name': getattr(self, 'name', None),
            'episode': [getattr(cfg, k, None) for k in ('recipe', 'seed', 'layout_seed', 'episode_idx')],
            'configuration': json.dumps({'final': final, 'criteria': criteria, 'targets': targets},
                sort_keys=True, allow_nan=False, default=lambda value: value.tolist())}

    def _assisted_final_success_ready(self):
        """Recheck this episode's completed native window, including after terminal transition."""
        from .planner_primitives import pose_error
        reason = None
        sample = None
        try:
            phases = self.phase_specs
            if not phases or getattr(self, 'failed', False):
                raise ValueError('Assisted final phase is absent or the episode failed')
            final = phases[-1]
            contract = self._assisted_task_contract()
            if final.get('name') != self._assisted_final_phase_name():
                raise ValueError('Assisted final verification phase is absent')
            in_final = self.phase_index == len(phases) - 1 and self.phase == final['name']
            completed = (getattr(self, 'success', False) and self.phase == 'complete'
                         and self.phase_index == len(phases)
                         and getattr(self, 'phase_status', None) == 'success'
                         and getattr(self, 'terminal_reason', None) == 'success-criteria-met')
            if not (in_final or completed):
                raise ValueError('Assisted success cannot precede final verification')
            certificate = getattr(self, '_assisted_final_certificate', None)
            gate = getattr(self, '_assisted_final_gate', {})
            required = int(final.get('advance', {}).get('physics_stable_steps', 0))
            if (not certificate or required < int(contract.get('final_stable_physics_steps', 240))
                    or certificate['identity'] != self._assisted_final_identity(final)
                    or certificate['phase_index'] != len(phases) - 1
                    or certificate['gate_key'] != gate.get('key')
                    or certificate['required_stable_physics_steps'] != required
                    or certificate['stable_physics_steps'] < required
                    or gate.get('count', 0) < required):
                raise ValueError('Assisted final native window is absent or belongs to another episode/phase')
            if in_final and self.phase_entry_step != certificate['phase_entry_step']:
                raise ValueError('Assisted final phase was re-entered after qualification')
            stamp = self._beam_physics_stamp()
            if not stamp.get('valid') or stamp != certificate['physics_stamp']:
                raise ValueError('Assisted final certificate is not from the current native physics sample')
            names = list(final.get('beam_assisted_installed_parts', []))
            expected = (set(contract['objects']) if contract else
                {'fabrica_beam_' + n for n in ('6', '3', '2', '1', '0')})
            criteria = self.cfg.success_criteria
            if (len(names) != len(expected) or set(names) != expected
                    or len(criteria) != len(expected) or {c['object'] for c in criteria} != expected
                    or set(certificate['native_poses']) != expected):
                raise ValueError('Assisted final native qualification must cover the exact task part collection')
            if contract.get('base_support') and not self._assisted_base_support_released_ready():
                raise ValueError('Stool final verification lacks this episode support acquisition and actual release')
            commands = final.get('gripper_commands', {})
            if set(commands) != set(self.robots) or any(c != 'open' for c in commands.values()):
                raise ValueError('Assisted final phase does not open both grippers')
            if not all(self._assisted_robot_gripper_is_open(name) for name in commands):
                raise ValueError('Assisted final native grippers are not fully open')
            sample = self._assisted_installation_sample(names, stamp, final=True)
            if not sample['ready']:
                raise ValueError('Assisted final native readback rejected: ' + str(sample.get('reason')))
            for name, current in sample['objects'].items():
                recorded = certificate['native_poses'][name]
                dp, dq = pose_error(current_position=current['position'],
                    current_orientation=current['orientation'],
                    target_position=recorded['position'], target_orientation=recorded['orientation'])
                if (current['body_path'] != recorded['body_path']
                        or current['motion_view_id'] != recorded['motion_view_id']
                        or dp > 1e-9 or dq > 1e-8):
                    raise ValueError('Assisted final body/view changed within the certified physics sample: ' + name)
            if 'beam_assisted_home_targets' in final:
                home = sample.get('home', {})
                recorded_home = certificate.get('native_home', {})
                if (not home.get('ready') or not recorded_home.get('ready')
                        or home.get('physics_stamp') != stamp or recorded_home.get('physics_stamp') != stamp
                        or set(home.get('robots', {})) != set(self.robots)
                        or set(recorded_home.get('robots', {})) != set(self.robots)):
                    raise ValueError('Assisted final native home certificate is absent or incomplete')
                for name, current in home['robots'].items():
                    recorded = recorded_home['robots'][name]
                    if any(current.get(k) != recorded.get(k) for k in
                           ('articulation_id', 'motion_view_id', 'native_dof_names',
                            'joint_names', 'target_joint_positions', 'full_native_joint_positions')):
                        raise ValueError('Assisted final arm/view changed within the certified physics sample: ' + name)
            if self._beam_physics_stamp() != stamp:
                raise ValueError('Assisted final physics clock changed during success recheck')
        except Exception as exc:
            reason = f'{type(exc).__name__}: {exc}'
        self._assisted_success_native_sample = sample
        decision = {'ready': reason is None, 'reason': reason}
        if decision != getattr(self, '_assisted_success_last_decision', None):
            self._assisted_event('final_success_native_recheck', **decision)
            self._assisted_success_last_decision = decision
        return reason is None

    def _assisted_installed_poses_ready(self, names):
        sample = getattr(self, '_assisted_install_gate_sample', {})
        return bool(sample.get('ready') and sample.get('physics_stamp') == self._beam_physics_stamp()
                    and names and set(names).issubset(sample.get('objects', {})))

    def _assisted_robot_gripper_is_open(self, name):
        q = np.asarray(self.robots[name].articulation.get_joint_positions(), float)
        if q.shape != (12,) or not np.all(np.isfinite(q)):
            raise RuntimeError('assisted release lacks the complete native gripper state')
        return bool(np.max(np.abs(q[6:])) <= self._assisted_task_contract().get('gripper_open_joint_tolerance_rad', .05))

    def _assisted_detach(self, object_name):
        self._remove_attachment_joint(object_name)
        self._attachments.pop(object_name, None)
        self._assisted_event('detach_grasp', object=object_name)

    def _assisted_support_global(self):
        settings = self._assisted_task_contract()['base_support']
        stamp = self._beam_physics_stamp()
        state = getattr(self, '_fabrica_support_cycles', None)
        signature = json.dumps(settings, sort_keys=True, allow_nan=False)
        robot_ids = {n:id(r.articulation) for n,r in self.robots.items()}
        if state is not None:
            if (stamp.get('valid') is not True or state['epoch'] != stamp['epoch']
                    or state['robot_ids'] != robot_ids or state['contract_identity'] != signature
                    or state['world_joint'] != getattr(self,'_assisted_world_joints',{}).get(settings['object'])):
                raise ValueError('Stool installation support runtime/world/episode identity changed')
            return state
        phase = self.get_current_phase_spec() or {}
        if phase.get('name') != settings.get('reference_capture_phase_name',settings.get('initial_park_phase_name')):
            raise ValueError('Stool support cannot capture its base drive after initial park entry')
        native = self._assisted_installation_sample([settings['object']],stamp)
        if not native.get('ready'):raise ValueError('Stool support reference lacks released original base installation')
        right = self._assisted_stool_final_sdk_command(settings['robot'])
        left = self._assisted_stool_final_sdk_command('franka_left')
        if right['receipt'].get('phase') != 'base_2_release_and_lock' or left['receipt'].get('phase') != 'base_2_release_and_lock':
            raise ValueError('Stool support reference is not the original base release actual SDK batch')
        motion = native['objects'][settings['object']]
        state = dict(epoch=stamp['epoch'],robot_ids=robot_ids,contract_identity=signature,
            world_joint=getattr(self,'_assisted_world_joints',{}).get(settings['object']),
            base_identity=(motion['body_path'],motion['motion_view_id']),
            support_reference=copy.deepcopy(right),initial_left_drive=copy.deepcopy(left),
            cycles={},active_cycle_index=-1,parked_drive=None,parked_after=None)
        self._fabrica_support_cycles = state
        self._assisted_event('fabrica_support_base_reference',actual_final_SDK=right,
            native_base=motion,physics_stamp=stamp,force_support_claimed=False)
        return state

    def _assisted_base_support_role(self):
        settings = self._assisted_task_contract().get('base_support')
        phase = (self.get_current_phase_spec() if hasattr(self,'get_current_phase_spec') else {}) or {}
        role = phase.get('fabrica_base_support')
        if not role:return None
        identity = {k:settings[k] for k in ('schema','role','robot','object')} if settings else {}
        if (not settings or settings.get('schema') not in {'stool_install_cycle_support_v2','stool_continuous_base_support_v3'}
                or settings.get('object')!=self._assisted_task_contract().get('base_object')
                or settings.get('robot')!='franka_right'):
            raise ValueError('Stool cycle support contract identity changed')
        if role.get('stage')=='initial_park':
            expected=dict(identity,cycle_id='base_preparation',moving_object=None,stage='initial_park')
            if role != expected or phase['name']!=settings['initial_park_phase_name']:
                raise ValueError('Stool initial park role identity changed')
            self._assisted_support_global();return role
        cycles=settings['cycles'];matches=[c for c in cycles if c['cycle_id']==role.get('cycle_id')]
        if len(matches)!=1:raise ValueError('Stool support cycle identity absent/duplicate')
        cycle=matches[0];stage=role.get('stage')
        expected=dict(identity,cycle_id=cycle['cycle_id'],moving_object=cycle['moving_object'],stage=stage)
        allowed={'enter':cycle['enter_phase_names'],'acquire':[cycle['acquire_phase_name']],
            'hold':cycle['hold_phase_names'],'open':[cycle['open_phase_name']],'exit':cycle['exit_phase_names']}
        if role!=expected or stage not in allowed or phase['name'] not in allowed[stage]:
            raise ValueError('Stool support phase is outside its exact installation cycle')
        global_state=self._assisted_support_global();index=cycles.index(cycle)
        runtime=global_state['cycles'].get(cycle['cycle_id'])
        if runtime is None:
            immediate=settings['schema']=='stool_continuous_base_support_v3'
            if immediate:
                if (len(cycles)!=1 or index!=0 or global_state['active_cycle_index']!=-1
                        or stage!=('enter' if cycle.get('enter_phase_names') else 'acquire')
                        or phase['name']!=(cycle['enter_phase_names'][0] if cycle.get('enter_phase_names') else cycle['acquire_phase_name'])
                        or cycle.get('moving_object') is not None
                        or cycle.get('moving_objects')!=self._assisted_task_contract()['assembly_order'][1:]):
                    raise ValueError('Stool immediate support must start once after original base release')
            elif (stage!='enter' or phase['name']!=cycle['enter_phase_names'][0]
                    or index!=global_state['active_cycle_index']+1
                    or global_state.get('parked_drive') is None
                    or global_state.get('parked_after')!=('base_preparation' if index==0 else cycles[index-1]['cycle_id'])):
                raise ValueError('Stool support cycle cannot skip prior parked/released completion')
            runtime=dict(cycle=copy.deepcopy(cycle),support=None,pending=None,left_entry_drive=None,left_release_drive=None,motion_targets={})
            global_state['cycles'][cycle['cycle_id']]=runtime;global_state['active_cycle_index']=index
        if runtime['cycle']!=cycle or global_state['active_cycle_index']!=index:
            raise ValueError('Stool support cycle order/contract changed')
        self._fabrica_base_support = runtime['support']
        self._fabrica_base_support_pending = runtime['pending']
        return role

    def _assisted_support_runtime(self, role):
        return self._assisted_support_global()['cycles'][role['cycle_id']]

    def _assisted_support_left_drive(self, role):
        global_state=self._assisted_support_global()
        immediate=self._assisted_task_contract()['base_support']['schema']=='stool_continuous_base_support_v3'
        if role['stage']=='initial_park' or (immediate and role['stage'] in {'enter','acquire'}):
            saved=global_state['initial_left_drive']
        else:
            runtime=self._assisted_support_runtime(role);cycle=runtime['cycle']
            entering=role['stage'] in {'enter','acquire'}
            key='left_entry_drive' if entering else 'left_release_drive'
            saved=runtime[key]
            if saved is None:
                sdk=self._assisted_stool_final_sdk_command('franka_left')
                expected=cycle['enter_after_phase_name'] if entering else cycle['exit_after_phase_name']
                if sdk['receipt'].get('phase')!=expected:
                    raise ValueError('Stool coordinated left hold lacks the completed original phase SDK drive')
                attachments=getattr(self,'_attachments',{})
                moving_objects=cycle.get('moving_objects',[]) if immediate else [cycle['moving_object']]
                attachment=attachments.get(cycle['moving_object'])
                if immediate and not entering and any(name in attachments for name in moving_objects):
                    raise ValueError('Stool final support opening requires every original left moving object detached')
                if entering:
                    if not attachment or attachment.get('robot_name')!='franka_left' or sdk['gripper_openness']!=attachment.get('assisted_hold_openness'):
                        raise ValueError('Stool entry hold lacks the original qualified left grasp command')
                elif attachment is not None or sdk['gripper_openness']!=1.:
                    raise ValueError('Stool exit hold must follow original released/open left installation')
                runtime[key]=copy.deepcopy(sdk);saved=runtime[key]
                self._assisted_event('fabrica_support_left_drive_capture',cycle_id=role['cycle_id'],
                    moving_object=role['moving_object'],stage=role['stage'],handoff_phase_name=expected,actual_final_SDK=saved,
                    scope='complete existing drive target; no pose or attachment rewrite')
        sdk=self._assisted_stool_final_sdk_command('franka_left')
        if (sdk['articulation_id']!=saved['articulation_id'] or not np.array_equal(sdk['arm_q'],saved['arm_q'])
                or sdk['gripper_openness']!=saved['gripper_openness']):
            raise ValueError('Stool coordinated left full SDK equilibrium changed during right motion')
        return saved

    def _assisted_support_parked_drive(self):
        global_state=self._assisted_support_global();settings=self._assisted_task_contract()['base_support']
        index=global_state['active_cycle_index']
        cycle=settings['cycles'][index] if index>=0 else None
        expected=cycle['exit_phase_names'][-1] if cycle else settings['initial_park_phase_name']
        after=cycle['cycle_id'] if cycle else 'base_preparation'
        sdk=self._assisted_stool_final_sdk_command(settings['robot'])
        if global_state['parked_after']!=after:
            if (sdk['receipt'].get('phase')!=expected or sdk['gripper_openness']!=1.
                    or (cycle and not (global_state['cycles'][after].get('support') or {}).get('released'))):
                raise ValueError('Stool idle right arm has no newly completed released/parked actual SDK drive')
            global_state['parked_drive']=copy.deepcopy(sdk);global_state['parked_after']=after
        saved=global_state['parked_drive']
        if (not saved or not np.array_equal(saved['arm_q'],sdk['arm_q']) or sdk['gripper_openness']!=1.
                or saved['articulation_id']!=sdk['articulation_id']):
            raise ValueError('Stool idle right parked actual SDK target changed')
        return saved

    def _assisted_support_motion_spec(self, spec):
        role=self._assisted_base_support_role()
        if role is None or role['stage'] not in {'initial_park','enter','exit'}:
            raise ValueError('Stool support joint target is outside its explicit motion stage')
        settings=self._assisted_task_contract()['base_support'];global_state=self._assisted_support_global()
        request=dict(schema='stool_support_joint_target_v2',source='original_robot_initial_q')
        point=None
        if role['stage']!='initial_park':
            runtime=self._assisted_support_runtime(role);cycle=runtime['cycle'];stage=role['stage']
            continuous=settings['schema']=='stool_continuous_base_support_v3'
            route=({'enter':settings['reposition']['joint_waypoints_rad']} if continuous and stage=='enter' else
                {'exit':settings['motion_route_plan']['exit_waypoints']} if continuous else settings['motion_route_plan']['routes'][cycle['moving_object']])
            index=cycle[stage+'_phase_names'].index(self.get_current_phase_spec()['name'])
            if index<len(route[stage]):
                request=dict(schema='stool_support_joint_target_v2',source=('declared_support_reposition' if continuous and stage=='enter' else 'park_reference_affine'),waypoint_index=index)
                point=route[stage][index]
            elif index==len(route[stage]):
                request['source']='retained_base_release_sdk' if stage=='enter' else 'original_robot_initial_q'
            else:raise ValueError('Stool support waypoint is outside its exact declared route')
        if spec.get('fabrica_support_joint_target')!=request or spec.get('robot')!=role['robot']:
            raise ValueError('Stool support exact full-joint motion target source changed')
        park=np.asarray(settings['park_joint_positions'],float);reference=np.asarray(global_state['support_reference']['arm_q'],float)
        if park.shape!=(6,) or reference.shape!=(6,) or not np.all(np.isfinite(np.r_[park,reference])):
            raise ValueError('Stool support actual complete joint reference is invalid')
        if request['source']=='declared_support_reposition':
            goal=np.asarray(point,float).copy()
            if goal.shape!=(6,) or not np.all(np.isfinite(goal)):
                raise ValueError('Stool support declared complete joint waypoint is invalid')
        elif request['source']=='retained_base_release_sdk':goal=reference.copy()
        elif request['source']=='original_robot_initial_q':goal=park.copy()
        else:
            fraction=point['blend_fraction'];delta=np.asarray(point['delta_rad'],float)
            if (isinstance(fraction,bool) or not isinstance(fraction,(int,float)) or not np.isfinite(fraction)
                    or not 0<=fraction<=1 or delta.shape!=(6,) or not np.all(np.isfinite(delta))):
                raise ValueError('Stool affine joint waypoint is invalid')
            affine_park=np.asarray(park,np.float32).astype(float)
            goal=affine_park+fraction*(reference-affine_park)+delta
        if not np.all(np.isfinite(goal)):raise ValueError('Stool support joint target is not finite')
        runtime=global_state if role['stage']=='initial_park' else self._assisted_support_runtime(role)
        cache=runtime.setdefault('motion_targets',{});key=(self.phase_index,self.phase_entry_step)
        if key in cache and not np.array_equal(cache[key],goal):raise ValueError('Stool retained complete motion target changed')
        cache.setdefault(key,goal.copy())
        resolved=copy.deepcopy(spec);resolved['joint_positions']=cache[key].tolist()
        return resolved

    def _assisted_support_entry_region_ready(self):
        from .planner_primitives import normalize_quat, quat_rotate, quat_multiply, pose_error
        role=self._assisted_base_support_role()
        if (role is None or role['stage']!='enter' or self.get_current_phase_spec()['name']
                !=self._assisted_support_runtime(role)['cycle']['enter_phase_names'][-1]):
            raise ValueError('Stool entry region gate is outside its final right entry waypoint')
        settings=self._assisted_task_contract()['base_support'];limits=settings['entry_native_region_gate']
        runtime=self._assisted_support_runtime(role);stamp=self._beam_physics_stamp()
        installed=self._assisted_installation_sample([role['object']],stamp)
        if not installed.get('ready'):raise ValueError('Stool support entry lacks the original installed world-supported base')
        body=installed['objects'][role['object']]
        if (body['body_path'],body['motion_view_id'])!=self._assisted_support_global()['base_identity']:
            raise ValueError('Stool support entry base native identity changed')
        root=self._fabrica_production_action_guard.data['robots'][role['robot']]['root_path']
        hand_path=root+'/wrist_3_link'
        hand=getattr(self,'_assisted_native_body_readers',{}).get(hand_path)
        reader=hand.unwrap() if hand is not None else None
        view=getattr(reader,'_rigid_prim_view',None)
        if reader is None or str(reader.prim_path)!=hand_path or view is None:
            raise ValueError('Stool support entry lacks its exact existing live native hand reader')
        from .beam_support_state import live_body_snapshot
        hand_native=live_body_snapshot(view)
        view_key=(self.phase_index,self.phase_entry_step,role['cycle_id'])
        views=runtime.setdefault('entry_hand_views',{})
        if view_key in views and views[view_key] is not view:
            raise ValueError('Stool support entry live native hand view changed')
        views.setdefault(view_key,view)
        hp=np.asarray(hand_native['position'],float);hq=normalize_quat(hand_native['orientation'])
        if hp.shape!=(3,) or not np.all(np.isfinite(hp)):raise ValueError('Stool support entry native hand pose is invalid')
        inverse=np.asarray(hq,float).copy();inverse[1:]*=-1.
        relative_p=quat_rotate(inverse,np.asarray(body['position'],float)-hp)
        relative_q=normalize_quat(quat_multiply(inverse,body['orientation']))
        row=settings['cad_row'];dp,da=pose_error(current_position=relative_p,current_orientation=relative_q,
            target_position=row['object_in_hand_position'],target_orientation=row['object_in_hand_orientation'])
        sdk=self._assisted_stool_final_sdk_command(role['robot'])
        if self._beam_physics_stamp()!=stamp:raise ValueError('Stool support entry native region sample changed clock')
        ready=bool(dp<=limits['position_tolerance_m'] and da<=limits['orientation_tolerance_rad']
                   and sdk['gripper_openness']==1. and self._assisted_robot_gripper_is_open(role['robot']))
        independent=None
        if ready and settings['schema']=='stool_continuous_base_support_v3':
            sampler=getattr(self,'_fabrica_base_support_independent_sample',None)
            if not callable(sampler):raise ValueError('Stool final support entry lacks its independent full-state sampler')
            independent=sampler('enter')
            if (not isinstance(independent,dict) or independent.get('passed') is not True
                    or independent.get('physics_stamp')!=stamp or self._beam_physics_stamp()!=stamp):
                raise ValueError('Stool final support entry independent native sample is missing or stale')
        key=(self.phase_index,self.phase_entry_step,role['cycle_id'])
        gate=runtime.setdefault('entry_region_gates',{}).setdefault(key,{})
        qualified=consecutive_native_gate(gate,stamp,ready,limits['stable_native_ticks'])
        detail=dict(cycle_id=role['cycle_id'],moving_object=role['moving_object'],ready=ready,qualified=qualified,
            stable_native_ticks=gate.get('count',0),required_native_ticks=limits['stable_native_ticks'],
            position_error_m=float(dp),orientation_error_rad=float(da),limits=copy.deepcopy(limits),
            native_hand_position=hp,native_hand_orientation=hq,native_hand_path=hand_path,native_hand_view_id=id(view),native_hand_motion=hand_native,native_object=body,
            measured_object_in_hand_position=relative_p,measured_object_in_hand_orientation=relative_q,
            actual_final_SDK=sdk,physics_stamp=stamp,qualification='original native grasp-region admission only; CAD gaps qualify later')
        if settings['schema']=='stool_continuous_base_support_v3':detail['independent_raw']=independent
        self._assisted_event('fabrica_support_entry_region',**detail)
        return qualified,detail

    def _assisted_stool_final_sdk_command(self, robot_name):
        stamp=self._beam_physics_stamp();robot=self.robots[robot_name]
        receipt=getattr(self,'_fabrica_final_gripper_commands',{}).get(robot_name) or {}
        published=receipt.get('physics_stamp') or {}
        q=np.asarray(getattr(self,'_assisted_published_q',{}).get(robot_name),float)
        opening=receipt.get('gripper_openness')
        if (stamp.get('valid') is not True or type(stamp.get('epoch')) is not int
                or type(stamp.get('index')) is not int or published.get('valid') is not True
                or published.get('epoch')!=stamp['epoch'] or type(published.get('index')) is not int
                or stamp['index']-published['index'] not in (0,1)
                or type(receipt.get('expected_sdk_batch_sequence')) is not int
                or receipt['expected_sdk_batch_sequence']!=getattr(robot,'_action_batch_sequence',None)
                or not {'arm_joint_controller','gripper_controller'}<=set(getattr(robot,'last_action_controller_names',()))
                or q.shape!=(6,) or not np.all(np.isfinite(q))
                or not isinstance(opening,(int,float)) or isinstance(opening,bool)
                or not np.isfinite(opening) or not 0<=opening<=1):
            raise ValueError('Stool base support lacks a fresh actual full-arm/gripper SDK command')
        return dict(arm_q=q.copy(),gripper_openness=float(opening),receipt=copy.deepcopy(receipt),
                    articulation_id=id(robot.articulation))

    def _assisted_base_support_sample(self):
        role=self._assisted_base_support_role()
        if role is None:raise ValueError('Stool base support sample lacks explicit role')
        stamp=self._beam_physics_stamp();name=role['object'];robot=role['robot']
        installed=self._assisted_installation_sample([name],stamp)
        if not installed.get('ready'):raise ValueError('Stool base support world/native installation invalid: '+str(installed.get('reason')))
        motion=installed['objects'][name]
        context=self._assisted_support_global()
        if (motion['body_path'],motion['motion_view_id'])!=context['base_identity']:
            raise ValueError('Stool cycle support base native binding changed')
        from .beam_assisted_visual_grasp import stool_base_support_sample
        cad=stool_base_support_sample(self,robot,name)
        sdk=self._assisted_stool_final_sdk_command(robot)
        if cad['physics_stamp']!=stamp or self._beam_physics_stamp()!=stamp:
            raise ValueError('Stool base support clock changed during qualification')
        identity=(stamp['epoch'],role['cycle_id'],name,robot,motion['body_path'],motion['motion_view_id'],
            getattr(self,'_assisted_world_joints',{}).get(name),sdk['articulation_id'])
        return dict(ready=bool(cad['ready']),physics_stamp=stamp,identity=identity,
                    native_object=motion,CAD=cad,SDK=sdk,force_support_claimed=False)

    def _assisted_base_support_condition(self, stage, advance, ready):
        role = self._assisted_base_support_role()
        settings = self._assisted_task_contract().get('base_support', {})
        if (stage not in {'acquire', 'open'} or role is None or role['stage'] != stage
                or advance.get('physics_stable_steps') != settings.get('stable_native_ticks')):
            raise ValueError('Stool base support advance contract changed')
        stamp = self._beam_physics_stamp()
        key = (self.phase_index, self.phase_entry_step, stage)
        gates = self.__dict__.setdefault('_fabrica_base_support_gates', {})
        gate = gates.setdefault(key, {})
        detail = {}; sample = None
        try:
            if stage == 'acquire':
                sample = self._assisted_base_support_sample()
                from .beam_assisted_visual_grasp import hold_command
                qualified = bool(ready and sample['ready'] and
                    hold_command(self, role['robot'], role['object']) == sample['SDK']['gripper_openness'])
                ownership = (sample['identity'], tuple(sample['SDK']['arm_q']), sample['SDK']['gripper_openness'])
                pending = getattr(self, '_fabrica_base_support_pending', None)
                if qualified and pending is None:
                    self._fabrica_base_support_pending = dict(phase_key=key,
                        identity=sample['identity'], arm_q=sample['SDK']['arm_q'].copy(),
                        gripper_openness=sample['SDK']['gripper_openness'])
                    pending = self._fabrica_base_support_pending
                    self._assisted_support_runtime(role)['pending'] = pending
                if pending is not None and (pending['phase_key'] != key
                        or pending['identity'] != sample['identity']
                        or not np.array_equal(pending['arm_q'], sample['SDK']['arm_q'])
                        or pending['gripper_openness'] != sample['SDK']['gripper_openness']):
                    raise ValueError('Stool support acquisition must retain its qualified actual SDK drive')
                if gate.get('ownership') != ownership:
                    gate.clear(); gate['ownership'] = ownership
                poses = {role['object']: copy.deepcopy(sample['native_object'])}
            else:
                state = getattr(self, '_fabrica_base_support', None)
                if not state:
                    raise ValueError('Stool support open lacks an acquired support')
                sdk = self._assisted_stool_final_sdk_command(role['robot'])
                opening = state.get('opening_started') or {}
                qualified = bool(ready and opening.get('publication_physics_stamp',{}).get('epoch') == stamp['epoch']
                    and type(opening.get('expected_sdk_batch_sequence')) is int
                    and opening['expected_sdk_batch_sequence'] <= sdk['receipt']['expected_sdk_batch_sequence']
                    and state['identity'][0] == stamp['epoch']
                    and sdk['articulation_id'] == state['identity'][-1]
                    and sdk['gripper_openness'] == 1.
                    and self._assisted_robot_gripper_is_open(role['robot'])
                    and np.array_equal(sdk['arm_q'], state['arm_q']))
                detail['actual_final_SDK'] = sdk; poses = None
            if qualified:
                sampler = getattr(self, '_fabrica_base_support_independent_sample', None)
                if not callable(sampler):
                    raise ValueError('Stool support native window lacks its independent full-state sampler')
                independent = sampler(stage)
                detail['independent_raw'] = independent
                if (not isinstance(independent, dict) or independent.get('passed') is not True
                        or independent.get('physics_stamp') != stamp):
                    raise ValueError('Stool support independent qualification sample is missing or stale')
                detail['independent_raw'] = independent
            passed = consecutive_native_gate(gate, stamp, qualified, settings['stable_native_ticks'],
                poses=poses, position_drift_limit=self._assisted_task_contract()['stable_position_drift_m'],
                orientation_drift_limit=self._assisted_task_contract()['stable_orientation_drift_rad'])
            if passed:
                if stage == 'acquire':
                    existing = getattr(self, '_fabrica_base_support', None)
                    if existing is None:
                        self._fabrica_base_support = dict(identity=sample['identity'],
                            arm_q=sample['SDK']['arm_q'].copy(),
                            gripper_openness=sample['SDK']['gripper_openness'],
                            acquire_physics_stamp=copy.deepcopy(stamp),
                            acquisition_sample=copy.deepcopy(sample), released=False,
                            cad_row_identity=json.dumps(settings['cad_row'], sort_keys=True, allow_nan=False))
                        self._assisted_support_runtime(role)['support'] = self._fabrica_base_support
                    elif (existing['identity'] != sample['identity'] or existing.get('released')
                            or not np.array_equal(existing['arm_q'], sample['SDK']['arm_q'])
                            or existing['gripper_openness'] != sample['SDK']['gripper_openness']):
                        raise ValueError('Stool acquired support command cannot be replaced')
                elif not state.get('released'):
                    state.update(released=True, release_physics_stamp=copy.deepcopy(stamp))
            detail.update(ready=qualified, qualified=passed, stable_native_ticks=gate.get('count', 0),
                required_native_ticks=settings['stable_native_ticks'], sample=sample,
                force_support_claimed=False)
        except Exception as exc:
            consecutive_native_gate(gate, stamp, False, settings['stable_native_ticks'])
            passed = False; detail.update(ready=False, qualified=False, reason=repr(exc), sample=sample)
        if detail.get('ready') or gate.get('reported') != passed or int(self.step_counter) % 8 == 0:
            self._assisted_event('fabrica_base_support_' + stage, cycle_id=role['cycle_id'], moving_object=role['moving_object'], **detail); gate['reported'] = passed
        return passed

    def _assisted_base_support_pending_action(self):
        role = self._assisted_base_support_role()
        pending = getattr(self, '_fabrica_base_support_pending', None)
        key = (self.phase_index, self.phase_entry_step, 'acquire')
        if not role or role['stage'] != 'acquire' or not pending or pending['phase_key'] != key:
            raise ValueError('Stool support pending drive belongs to another phase')
        sample = self._assisted_base_support_sample()
        if (not sample['ready'] or pending['identity'] != sample['identity']
                or not np.array_equal(pending['arm_q'], sample['SDK']['arm_q'])
                or pending['gripper_openness'] != sample['SDK']['gripper_openness']):
            raise RuntimeError('Stool support lost qualification while retaining its acquisition drive')
        return {'arm_joint_controller': [pending['arm_q'].tolist()],
                'gripper_controller': [pending['gripper_openness']]}

    def _assisted_support_released_drive(self):
        settings=self._assisted_task_contract()['base_support']
        if settings.get('schema')!='stool_continuous_base_support_v3':
            raise ValueError('Stool released continuous drive belongs only to its explicit v3 lifecycle')
        context=self._assisted_support_global();cycles=settings['cycles']
        if len(cycles)!=1 or context['active_cycle_index']!=0 or set(context['cycles'])!={cycles[0]['cycle_id']}:
            raise ValueError('Stool continuous support has not completed its single acquired lifecycle')
        support=context['cycles'][cycles[0]['cycle_id']].get('support')
        sdk=self._assisted_stool_final_sdk_command(settings['robot'])
        if (not support or not support.get('released') or support['identity'][0]!=context['epoch']
                or support['identity'][-1]!=sdk['articulation_id']
                or not np.array_equal(support['arm_q'],sdk['arm_q']) or sdk['gripper_openness']!=1.
                or not self._assisted_robot_gripper_is_open(settings['robot'])):
            raise ValueError('Stool continuous support lacks its actual released/open qualified full-arm SDK drive')
        return sdk

    def _assisted_base_support_released_ready(self):
        settings=self._assisted_task_contract().get('base_support')
        if not settings:return True
        try:
            context=self._assisted_support_global()
            if (set(context['cycles'])!={c['cycle_id'] for c in settings['cycles']}
                    or context['active_cycle_index']!=len(settings['cycles'])-1):return False
            for cycle in settings['cycles']:
                support=context['cycles'][cycle['cycle_id']]['support']
                if not support or not support.get('released') or support['identity'][0]!=context['epoch']:return False
            if settings.get('schema')=='stool_continuous_base_support_v3':
                return bool(self._assisted_support_released_drive())
            saved=self._assisted_support_parked_drive()
            return bool(context['parked_after']==settings['cycles'][-1]['cycle_id']
                and saved['gripper_openness']==1. and self._assisted_robot_gripper_is_open(settings['robot']))
        except (KeyError,AttributeError,TypeError,ValueError,RuntimeError):return False

    def _assisted_base_support_hold(self):
        role=self._assisted_base_support_role()
        settings=self._assisted_task_contract().get('base_support',{});state=getattr(self,'_fabrica_base_support',None)
        if not state or state.get('released'):raise ValueError('Stool support hold lacks acquired active support')
        if state['cad_row_identity']!=json.dumps(settings['cad_row'],sort_keys=True,allow_nan=False):
            raise ValueError('Stool support CAD role anchor changed after acquisition')
        sample=self._assisted_base_support_sample()
        if settings.get('schema')=='stool_continuous_base_support_v3':
            recorder=getattr(self,'_fabrica_base_support_primary_record',None)
            if not callable(recorder):raise ValueError('Stool continuous hold lacks its primary/independent evidence callback')
            recorded=recorder('hold',sample)
            if not isinstance(recorded,dict) or recorded.get('passed') is not True or recorded.get('physics_stamp')!=sample['physics_stamp']:
                raise ValueError('Stool continuous hold evidence is missing or stale')
        if (sample['identity']!=state['identity'] or not sample['ready']
                or not np.array_equal(sample['SDK']['arm_q'],state['arm_q'])
                or sample['SDK']['gripper_openness']!=state['gripper_openness']):
            self._assisted_event('fabrica_base_support_lost',cycle_id=role['cycle_id'],moving_object=role['moving_object'],sample=sample,force_support_claimed=False)
            raise RuntimeError('Stool right base support lost its native CAD fit or actual final SDK ownership')
        if int(self.step_counter)%8==0:self._assisted_event('fabrica_base_support_hold',cycle_id=role['cycle_id'],moving_object=role['moving_object'],sample=sample,force_support_claimed=False)
        return state

    def _assisted_idle_action(self, robot_name, phase_spec):
        role=self._assisted_base_support_role()
        settings=self._assisted_task_contract().get('base_support')
        if role and robot_name=='franka_left' and role['stage'] in {'initial_park','enter','acquire','open','exit'}:
            saved=self._assisted_support_left_drive(role)
            return {'arm_joint_controller':[saved['arm_q'].tolist()],'gripper_controller':[saved['gripper_openness']]}
        if role and role['stage']=='hold' and robot_name==role['robot']:
            state=self._assisted_support_runtime(role).get('support')
            if not state or state.get('released'):raise ValueError('Stool installation support lacks its acquired actual drive')
            return {'arm_joint_controller':[state['arm_q'].tolist()],'gripper_controller':[state['gripper_openness']]}
        if settings and not role and robot_name==settings['robot'] and getattr(self,'_fabrica_support_cycles',None):
            saved=(self._assisted_support_released_drive() if settings.get('schema')=='stool_continuous_base_support_v3'
                   else self._assisted_support_parked_drive())
            return {'arm_joint_controller':[saved['arm_q'].tolist()],'gripper_controller':[1.]}
        subset = self.robots[robot_name].controllers['arm_joint_controller'].get_joint_subset()
        actual = np.asarray(subset.get_joint_positions(), dtype=float)
        support = phase_spec.get('beam_assisted_visual_support') or {}
        if support.get('robot') == robot_name:
            # This entry is called only for an inactive arm. Preserve the last
            # published PD equilibrium instead of replacing it with measured q.
            stamp = self._beam_physics_stamp()
            published_stamp = getattr(self, '_assisted_published_q_stamps', {}).get(robot_name)
            anchor = np.asarray(getattr(self, '_assisted_published_q', {}).get(robot_name), dtype=float)
            if (stamp.get('valid') is not True or type(stamp.get('epoch')) is not int
                    or type(stamp.get('index')) is not int or stamp['epoch'] < 0 or stamp['index'] < 0
                    or not isinstance(published_stamp, dict)
                    or published_stamp.get('epoch') != stamp['epoch']
                    or type(published_stamp.get('index')) is not int
                    or stamp['index']-published_stamp['index'] not in (0, 1)
                    or anchor.shape != (6,) or actual.shape != (6,)
                    or not np.all(np.isfinite([anchor, actual]))
                    or np.max(np.abs(anchor-actual)) > .12+1e-12):
                raise ValueError('visual support idle lacks a fresh valid final-published arm target')
            anchor = anchor.copy()
        else:
            if not hasattr(self, '_assisted_idle_anchors'):
                self._assisted_idle_anchors = {}
            anchor = self._assisted_idle_anchors.setdefault(robot_name, actual.copy())
        action = {'arm_joint_controller': [anchor.tolist()]}
        command = phase_spec.get('gripper_commands', {}).get(robot_name)
        if command in ('open', 'close'):
            action['gripper_controller'] = [1.0 if command == 'open' else 0.0]
        elif isinstance(command, (int, float)):
            action['gripper_controller'] = [float(command)]
        elif command is not None:
            raise RuntimeError('assisted idle arm has an unsupported gripper command')
        return action

    def _assisted_active_arm(self, robot_name):
        getattr(self, '_assisted_idle_anchors', {}).pop(robot_name, None)

    def _assisted_arm_joint_limits(self, name):
        """Read the existing live native view; never invent a periodic range."""
        articulation = self.robots[name].articulation
        view = articulation._articulation_view
        if not view.is_physics_handle_valid():
            raise ValueError('assisted native joint limits lack a live physics handle')
        stamp = self._beam_physics_stamp()
        if stamp.get('valid') is not True or type(stamp.get('epoch')) is not int:
            raise ValueError('assisted native joint limits lack a live epoch')
        identity = (id(articulation), id(view), stamp['epoch'])
        cache = self.__dict__.setdefault('_assisted_arm_limits_cache', {})
        cached = cache.get(name)
        if cached is not None and cached['identity'] == identity:
            return cached['limits'].copy()
        names = list(articulation.dof_names)
        arm = ('shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint',
               'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint')
        values = np.asarray(view.get_dof_limits(), dtype=np.float32)
        if (len(names) != len(set(names)) or values.shape != (1, len(names), 2)
                or any(names.count(n) != 1 for n in arm)):
            raise ValueError('assisted native joint limit names/shape are invalid')
        limits = values[0, [names.index(n) for n in arm]].copy()
        if not np.all(np.isfinite(limits)) or np.any(limits[:, 0] >= limits[:, 1]):
            raise ValueError('assisted native arm joint limits are invalid')
        cache[name] = dict(identity=identity, limits=limits.copy())
        self._assisted_event('native_arm_joint_limits', robot=name,
            joint_names=list(arm), limits_rad=limits, physics_stamp=stamp,
            source='same_existing_live_articulation_view.get_dof_limits')
        return limits

    def _assisted_guard_actions(self, actions):
        if self._assisted_task_contract():
            stamp = self._beam_physics_stamp()
            guard = getattr(self, '_fabrica_production_action_guard', None)
            if stamp.get('valid') is not True or not callable(guard):
                raise RuntimeError('stool final batch lacks its native clock and production geometry guard')
            if set(actions) != set(self.robots):
                raise RuntimeError('stool final batch must include both arms and complete grippers')
            role=self._assisted_base_support_role()
            opening_state = None
            if role and role['stage'] in {'initial_park','enter','acquire','open','exit'}:
                saved=self._assisted_support_left_drive(role)
                left=actions['franka_left']
                if (not np.array_equal(np.asarray(left.get('arm_joint_controller'),float),saved['arm_q'][None,:])
                        or left.get('gripper_controller')!=[saved['gripper_openness']]):
                    raise ValueError('Stool right coordination must retain the full accepted left SDK drive')
                if role['stage']=='exit' and not (self._assisted_support_runtime(role).get('support') or {}).get('released'):
                    raise ValueError('Stool right exit cannot precede its twelve actual-open native ticks')
            if role and role['stage'] in {'hold','open'}:
                if role['stage']=='hold':
                    state=self._assisted_base_support_hold()
                    q=np.asarray((actions[role['robot']] or {}).get('arm_joint_controller'),float)
                    opening=(actions[role['robot']] or {}).get('gripper_controller')
                    if q.shape!=(1,6) or not np.array_equal(q[0],state['arm_q']) or opening!=[state['gripper_openness']]:
                        raise ValueError('Stool support command changed its qualified arm/gripper drive')
                else:
                    state=getattr(self,'_fabrica_base_support',None)
                    if not state:raise ValueError('Stool support opening lacks acquired command')
                    if not state.get('opening_started'):
                        # The first release command still observes the last
                        # support sample. Later open fingers need not near-fit.
                        self._assisted_base_support_hold()
                        opening_state = state
                    else:
                        self._assisted_stool_final_sdk_command(role['robot'])
                    if actions[role['robot']].get('gripper_controller') != [1.]:
                        raise ValueError('Stool support release must explicitly command full open')
                    # Opening changes only aperture, retaining the complete
                    # actual previously accepted support arm equilibrium.
                    actions[role['robot']]['arm_joint_controller']=[state['arm_q'].tolist()]
            for object_name, state in getattr(self, '_attachments', {}).items():
                robot = state['robot_name']
                if self._assisted_task_contract().get('cad_pinch'):
                    from .beam_assisted_visual_grasp import verify_stool_held_fit
                    verify_stool_held_fit(self, robot, object_name)
                actions[robot]['gripper_controller'] = [state['assisted_hold_openness']]
            guarded = guard(actions)
            if (not isinstance(guarded, dict) or set(guarded) != set(self.robots)
                    or self._beam_physics_stamp() != stamp):
                raise RuntimeError('stool production batch guard returned an incomplete or stale batch')
            commands = self._fabrica_final_gripper_commands = {}
            previous = getattr(self, '_assisted_published_q', {})
            for name, action in guarded.items():
                if 'arm_ik_controller' in action or 'arm_joint_controller' not in action:
                    raise RuntimeError('stool final batch must use one explicit joint command per arm')
                previous[name] = np.asarray(action['arm_joint_controller'][0], float).copy()
                opening = np.asarray(action.get('gripper_controller'), float)
                if opening.shape != (1,) or not np.all(np.isfinite(opening)) or not 0 <= opening[0] <= 1:
                    raise RuntimeError('stool final batch lacks a finite normalized gripper command')
                commands[name] = {'gripper_openness': float(opening[0]), 'physics_stamp': dict(stamp),
                    'phase':self.phase,'phase_index':self.phase_index,'phase_entry_step':self.phase_entry_step,
                    'expected_sdk_batch_sequence': getattr(self.robots[name], '_action_batch_sequence', 0) + 1}
            self._assisted_published_q = previous
            if opening_state is not None:
                opening_state['opening_started'] = dict(publication_physics_stamp=dict(stamp),
                    expected_sdk_batch_sequence=commands[role['robot']]['expected_sdk_batch_sequence'],
                    scope='guarded opening publication only; actual SDK/open12 qualification remains required')
            self._assisted_event('fabrica_final_published_batch', actions=guarded, native_stamp=stamp,
                expected_sdk_batch_sequences={name: value['expected_sdk_batch_sequence'] for name, value in commands.items()})
            return guarded
        previous = getattr(self, '_assisted_published_q', {})
        phase = self.get_current_phase_spec() if hasattr(self, 'get_current_phase_spec') else {}
        empty_return = bool(phase.get('beam_assisted_empty_return_guard'))
        if empty_return:
            empty_stamp = self._beam_physics_stamp()
            if (empty_stamp.get('valid') is not True
                    or type(empty_stamp.get('epoch')) is not int
                    or type(empty_stamp.get('index')) is not int):
                raise ValueError('assisted empty return lacks a native physics clock')
            if getattr(self, '_attachments', {}):
                raise ValueError('assisted empty return cannot move an attached part')
            if set(actions) != set(self.robots):
                raise ValueError('assisted empty return lacks the complete dual-arm SDK batch')
            for name in self.robots:
                action = actions[name] or {}
                if action.get('arm_joint_controller') is None:
                    raise ValueError('assisted empty return lacks a final arm target: ' + name)
                opening = np.asarray(action.get('gripper_controller'), dtype=float)
                if (opening.shape != (1,) or not np.all(np.isfinite(opening))
                        or opening[0] != 1.0 or not self._assisted_robot_gripper_is_open(name)):
                    raise ValueError('assisted empty return requires both actual/commanded grippers open')
                config = self.robots[name].config
                if (config.gripper_open_position != 0.
                        or config.initial_joint_positions.get('finger_joint') != 0.):
                    raise ValueError('assisted empty return requires the configured zero-open gripper branch')
        if phase.get('local_skill', {}).get('beam_assisted_production_cad_guard'):
            # Predict both arms from this same SDK batch, including the idle
            # support arm's outer native clamp, before checking either sweep.
            pending = {}
            for name, action in actions.items():
                target = (action or {}).get('arm_joint_controller')
                if target is not None:
                    subset = self.robots[name].controllers['arm_joint_controller'].get_joint_subset()
                    actual = np.asarray(subset.get_joint_positions(), dtype=float)
                    pending[name] = bounded_native_target(target[0], actual, previous.get(name),
                        unwrap=not phase.get('beam_assisted_empty_return_guard', False))
            self._assisted_batch_arm_candidates = pending
        for name, action in actions.items():
            if not action:
                continue
            target = action.get('arm_joint_controller')
            if 'arm_ik_controller' in action and target is None:
                raise RuntimeError('assisted command must pass the explicit native joint guard')
            # The robot's explicit-joint override already suppresses this IK
            # entry. Remove it here so the recorded action has one arm path.
            redundant_ik = action.pop('arm_ik_controller', None) is not None
            if target is None:
                continue
            subset = self.robots[name].controllers['arm_joint_controller'].get_joint_subset()
            actual = np.asarray(subset.get_joint_positions(), dtype=float)
            bounded = bounded_native_target(target[0], actual, previous.get(name),
                unwrap=not phase.get('beam_assisted_empty_return_guard', False))
            context = getattr(self, '_beam_assisted_command_contexts', {}).get(name)
            current_phase = self.get_current_phase_spec() if hasattr(self, 'get_current_phase_spec') else {}
            from .local_skills import normalize_local_skill_spec
            current_skill = normalize_local_skill_spec(current_phase, name) or {}
            current_absolute = bool(current_skill.get('beam_assisted_absolute_object_servo')
                                    and current_skill.get('requires_held_object'))
            if current_absolute:
                if context is None:
                    raise ValueError('assisted final command has no current object-servo context')
                bounded, object_guard = context['adapter']._assisted_verify_published_held_command(
                    task=self, robot_name=name, context=context,
                    command_q=bounded, current_q=actual, previous_q=previous.get(name))
                if int(self.step_counter) % 8 == 0 or object_guard['accepted_ratio'] < 1.:
                    self._assisted_event('published_object_guard', robot=name, **object_guard)
            if current_phase.get('beam_assisted_native_joint_limits'):
                limits = self._assisted_arm_joint_limits(name)
                # Match the SDK/native float32 conversion exactly. This is
                # not a widened physical range or a modulo-angle comparison.
                native_target = np.asarray(bounded, dtype=np.float32)
                if np.any(native_target < limits[:, 0]) or np.any(native_target > limits[:, 1]):
                    self._assisted_event('native_joint_limit_rejected', robot=name,
                        requested_final_q=bounded, native_float32_target=native_target,
                        limits_rad=limits, physics_stamp=self._beam_physics_stamp())
                    raise ValueError('assisted final target exceeds actual native joint limits')
            action['arm_joint_controller'] = [bounded.tolist()]
            previous[name] = bounded.copy()
            held = next((s for s in getattr(self, '_attachments', {}).values()
                         if s.get('robot_name') == name
                         and s.get('attach_spec', {}).get('beam_assisted')), None)
            if held is not None or (current_phase.get('beam_assisted_visual_support') or {}).get('robot') == name:
                if not hasattr(self, '_assisted_published_q_stamps'):
                    self._assisted_published_q_stamps = {}
                stamp = self._beam_physics_stamp()
                self._assisted_published_q_stamps[name] = {
                    'epoch': stamp.get('epoch') if stamp.get('valid') is True else None,
                    'index': stamp.get('index') if stamp.get('valid') is True else None,
                }
            getattr(self, '_ur5e_plumbers_last_arm_command_q', {})[name] = bounded.copy()
            if held is not None:
                action['gripper_controller'] = [held['assisted_hold_openness']]
            entry = getattr(self, 'phase_entry_step', None)
            trace_spec = current_phase.get('local_skill') or {}
            trace_ticks = (24 if trace_spec.get('beam_assisted_phase_handoff_ticks') is not None
                           else 96 if trace_spec.get('beam_assisted_alignment_hold')
                           and current_phase.get('name', '').endswith('_insert_00') else -1)
            handoff_trace = bool(type(entry) is int
                and 0 <= int(self.step_counter)-entry <= trace_ticks)
            if (int(self.step_counter) % 8 == 0 or handoff_trace
                    or trace_spec.get('beam_assisted_transition_settle')):
                self._assisted_event('published_command', robot=name,
                    actual_q=actual, requested_q=np.asarray(target[0]),
                    published_q=bounded, redundant_ik_removed=redundant_ik)
        if empty_return:
            pending_final_targets = {
                name: np.asarray(actions[name]['arm_joint_controller'][0], dtype=float).copy()
                for name in self.robots}
            self._assisted_batch_arm_candidates = pending_final_targets
            guard = getattr(self, '_assisted_production_cad_guard', None)
            if not callable(guard) or self._beam_physics_stamp() != empty_stamp:
                raise ValueError('assisted empty return lacks a same-clock production CAD guard')
            allowed, detail = guard(empty=True, physics_stamp=empty_stamp,
                installed_objects=phase.get('beam_assisted_installed_parts', []))
            if not allowed:
                self._assisted_event('empty_return_cad_rejected', **detail)
                raise ValueError('assisted empty return final dual-arm sweep rejected')
            if self._beam_physics_stamp() != empty_stamp:
                raise ValueError('native clock changed during assisted empty return final guard')
            if int(self.step_counter) % 8 == 0:
                self._assisted_event('empty_return_published_guard', **detail)
        self._assisted_published_q = previous
        return actions


class StoolSupportMotionAdapter:
    """Resolve full6q then delegate the existing bounded joint controller.

    Only its completion outlet is extended for entry: the original coarse
    joint predicate cannot advance before the actual native grasp region is
    stable. Motion, joint counters and source goals remain in the original atom.
    """
    def __init__(self, spec):
        from .plumbers_block_ur5e_skills import UR5eAssemblyAtomicSkillAdapter
        class EntryQualifiedJointController(UR5eAssemblyAtomicSkillAdapter):
            @staticmethod
            def _mark_complete(*,task,robot_name,skill_name,detail):
                role=task._assisted_base_support_role()
                if (role and role['stage']=='enter' and task.get_current_phase_spec()['name']
                        ==task._assisted_support_runtime(role)['cycle']['enter_phase_names'][-1]):
                    ready,region=task._assisted_support_entry_region_ready()
                    if not ready:return
                    detail=dict(detail,native_support_entry_region=region)
                UR5eAssemblyAtomicSkillAdapter._mark_complete(task=task,robot_name=robot_name,
                    skill_name=skill_name,detail=detail)
        self._controller=EntryQualifiedJointController({})
    def act(self, *, task, robot_name, phase_spec, skill_spec,
            tracked_robots, tracked_objects, checkpoint_path=None):
        resolved=task._assisted_support_motion_spec(skill_spec)
        return self._controller.act(task=task,robot_name=robot_name,phase_spec=phase_spec,
            skill_spec=resolved,tracked_robots=tracked_robots,tracked_objects=tracked_objects,
            checkpoint_path=checkpoint_path)

"""Bounded public command accumulation on biased, evolving toy feedback.

This exercises real act/gates/limits; the contact fixture never qualifies a grasp.
"""
import unittest
import numpy as np
import test_beam_weak_side_recenter as replay


class Feedback(unittest.TestCase):
    def run_model(self, enabled, bias, frozen=False):
        adapter,task,native,state,act=replay.FinalActionRecenterSafety().fixture(
            initial=.000204,consistent=True,feedback=enabled)
        action=act()
        # Measured state changes before the actual issuance, as in r29.
        native['q'][0]=.00015
        target=None
        for tick in range(101,360):
            task.step_counter=task.phase_step_counter=tick
            action=act()
            if '__local_skill_failure__' in action:break
            pending=state.get('force_recenter_pending')
            if target is None and pending and pending.get('lifecycle')=='final_action_issued':
                target=pending['motion_target_position_world'].copy()
            if target is not None and pending is not None:
                np.testing.assert_array_equal(pending['motion_target_position_world'],target)
            if not frozen:
                # First-order lag plus a constant drive/load offset; no
                # ideal instantaneous tracking or simulated contact response.
                requested=np.array(action['arm_joint_controller'][0]);requested[0]+=bias
                native['q'] += .4*(requested-native['q'])
            if target is not None and pending is None:break
        return adapter,task,native,state,action,target,act

    def test_v205_fixed_target_still_times_out_with_drive_offset(self):
        *_,action,_,_=self.run_model(False,.00008)
        self.assertEqual(action.get('reason'),'close_recenter_motion_timeout')

    def test_accumulation_finishes_without_moving_completion_target(self):
        for bias in [.00008,.00015,-.00008]:
            with self.subTest(bias=bias):
                adapter,task,native,state,action,target,act=self.run_model(True,bias)
                self.assertNotIn('__local_skill_failure__',action)
                self.assertNotIn('force_recenter_pending',state)
                self.assertLessEqual(abs(native['q'][0]-target[1]),.00000625)
                self.assertLessEqual(state['force_recenter_travel']+state['recenter_feedback_travel'],.002)
                np.testing.assert_array_equal(state['contact_arm_anchor']['position'],np.zeros(3))
                previous=np.array(action['arm_joint_controller'][0])
                adapter._solve_ik=lambda **kw: (_ for _ in ()).throw(AssertionError('holding command re-solved IK'))
                task.step_counter+=1;task.phase_step_counter+=1
                next_action=act()
                np.testing.assert_allclose(next_action['arm_joint_controller'][0],previous,atol=1e-12)

    def test_frozen_real_feedback_cannot_be_acknowledged(self):
        *_,action,_,_=self.run_model(True,.00008,frozen=True)
        self.assertTrue(action.get('__local_skill_failure__'))
        self.assertEqual(action.get('reason'),'close_recenter_motion_timeout')

    def test_hard_force_stops_new_arm_commands_and_keeps_gripper_unload(self):
        adapter,task,native,state,act=replay.FinalActionRecenterSafety().fixture(
            initial=.000204,consistent=True,feedback=True)
        action=act();native['q'][0]=.00015
        for tick in range(101,110):
            task.step_counter=task.phase_step_counter=tick;action=act()
            native['q'] += .4*(np.array(action['arm_joint_controller'][0])-native['q'])
        previous=np.array(action['arm_joint_controller'][0]);native['right_force']=80.
        task.step_counter+=1;task.phase_step_counter+=1;action=act()
        np.testing.assert_allclose(action['arm_joint_controller'][0],previous,atol=1e-12)
        self.assertEqual(state['force_recenter_stop_event']['stop_cause'],'hard_force_limit') if 'force_recenter_stop_event' in state else None
        self.assertNotIn('force_recenter_pending',state)
        self.assertLess(.8*(1-action['gripper_controller'][0]),.737)

    def test_three_axis_lag_and_signed_offsets_use_one_frozen_goal(self):
        for bias in [np.array([.00007,.00008,-.00005]),np.array([-.00007,-.00008,.00005])]:
            with self.subTest(bias=bias.tolist()):
                adapter,task,native,state,act=replay.FinalActionRecenterSafety().fixture(
                    initial=.000204,consistent=True,feedback=True)
                controller=task.robots['left'].controllers['arm_ik_controller']
                raw=controller._kinematics_solver.get_kinematics_solver()
                raw.compute_inverse_kinematics=lambda frame,position,orientation,**kw:(np.r_[position,np.zeros(3)],True)
                raw.compute_forward_kinematics=lambda frame,q:(np.asarray(q[:3]),np.eye(3))
                pose=lambda:{'position':native['q'][:3].copy(),'orientation':np.array([1.,0.,0.,0.])}
                adapter._current_robot_pose=lambda **kw:pose()
                adapter._target_pose=lambda **kw:pose()
                act();native['q'][:3]=[.00008,.00015,-.00005];target=None
                for tick in range(101,340):
                    task.step_counter=task.phase_step_counter=tick;action=act()
                    self.assertNotIn('__local_skill_failure__',action)
                    pending=state.get('force_recenter_pending')
                    if pending is not None:
                        target=target if target is not None else pending['motion_target_position_world'].copy()
                        np.testing.assert_array_equal(pending['motion_target_position_world'],target)
                    requested=np.asarray(action['arm_joint_controller'][0]).copy();requested[:3]+=bias
                    native['q'] += .3*(requested-native['q'])
                    if target is not None and pending is None:break
                self.assertNotIn('force_recenter_pending',state)
                self.assertLessEqual(abs(native['q'][1]-target[1]),.00000625)
                self.assertLessEqual(np.linalg.norm((native['q'][:3]-target)[[0,2]]),.0001)


if __name__=='__main__':unittest.main()

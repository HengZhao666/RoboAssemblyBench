"""Freeze one source-bound stool attempt and atomically consume its own quota."""
from pathlib import Path
import argparse
import datetime
import fcntl
import hashlib
import json
import os
import re
import subprocess
import tarfile
import time

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'stool_repository'
LEDGER = ROOT / 'execution_ledger.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(root):
    files = {}
    for directory, dirs, names in os.walk(root, followlinks=False):
        dirs[:] = [d for d in dirs if d not in {'.git', 'outputs', '__pycache__', '.pytest_cache'}]
        for name in names:
            path = Path(directory) / name
            if path.is_file() and not path.is_symlink() and not name.startswith('._'):
                files[str(path.relative_to(root))] = sha(path)
    return files


CONTROL_TOOLS = ('stool_worker.py', 'stool_raw_evidence.py', 'stool_startup_evidence.py',
                 'stool_geometry_guard.py', 'stool_sweep_model.py', 'stool_export_geometry.py',
                 'run_stool.sh', 'stool_env.sh')


def control_sources(sources):
    return {n: v for n, v in sources.items()
            if n.startswith(('internutopia/', 'internutopia_extension/', 'roboassemblybench/', 'toolkits/'))
            and '/assets/' not in n and n.endswith(('.py', '.yaml', '.json', '.sh'))}


def control_identity(sources, tools):
    code = control_sources(sources)
    runtime = {n: tools[n] for n in CONTROL_TOOLS}
    return dict(control_source_signature=hashlib.sha256(json.dumps(code, sort_keys=True).encode()).hexdigest(),
                control_tools_signature=hashlib.sha256(json.dumps(runtime, sort_keys=True).encode()).hexdigest())


def changed_files(before, after):
    return {n: dict(before=before.get(n), after=after.get(n))
            for n in sorted(set(before) | set(after)) if before.get(n) != after.get(n)}


def reviewed_startup_reuse(path, receipt, proof, identity, sources, tools, run,
                           grant, preflight, configuration_signature):
    """Bind reviewed differences; every formal run retains its own native gates."""
    path = path.resolve()
    if ROOT.resolve() not in path.parents:
        raise RuntimeError('Startup domain review must be inside this stool workspace')
    review = json.loads(path.read_text())
    legacy = grant == 'G02' and run == 'S04'
    if (review.get('for_formal_run') != run
            or review.get('status') != 'reviewed_for_unchanged_domain_reuse'
            or review.get('original_startup_receipt_sha256') != sha(receipt)
            or review.get('candidate_control_identity') != identity):
        raise RuntimeError('Startup domain review does not bind this formal candidate')
    baseline = json.loads((receipt.parent/'source_binding.json').read_text())
    for key in ('control_source_signature', 'control_tools_signature', 'configuration_signature'):
        if baseline.get(key) != proof.get(key):
            raise RuntimeError('Startup proof differs from its original sealed source binding')
    changes = changed_files({n: baseline['tools_manifest'][n] for n in CONTROL_TOOLS},
                            {n: tools[n] for n in CONTROL_TOOLS})
    source_changes = changed_files(control_sources(baseline['source_manifest']), control_sources(sources))
    if changes != review.get('changed_control_tools'):
        raise RuntimeError('Startup review does not enumerate exact control-tool differences')
    if legacy:
        if (source_changes or proof.get('configuration_signature') != configuration_signature
                or not changes or not set(changes) <= {'stool_geometry_guard.py', 'stool_startup_evidence.py'}):
            raise RuntimeError('Legacy S04 review exceeds its original unchanged-source scope')
    elif (review.get('active_grant') != grant
            or review.get('actual_worker_preflight_sha256') != sha(preflight)
            or review.get('configuration_signature') != configuration_signature
            or review.get('changed_control_sources') != source_changes):
        raise RuntimeError('Current grant/source/config/actual-worker review is absent or stale')
    offline = review.get('offline_preflight') or {}
    check = Path(offline.get('path', '')).resolve()
    if ROOT.resolve() not in check.parents or not check.is_file() or sha(check) != offline.get('sha256'):
        raise RuntimeError('Changed-domain offline receipt is absent, outside this task, or changed')
    validated = json.loads(check.read_text())
    if (validated.get('passed') is not True
            or validated.get('tested_control_tools') != {n: changes[n]['after'] for n in changes}
            or validated.get('configuration_signature') != configuration_signature
            or (not legacy and (validated.get('tested_control_sources') !=
                {n: source_changes[n]['after'] for n in source_changes}
                or validated.get('actual_worker_preflight_sha256') != sha(preflight)))):
        raise RuntimeError('Changed-domain offline receipt does not validate the exact candidate')
    return dict(path=str(path), sha256=sha(path), changed_control_tools=changes,
        changed_control_sources=source_changes, offline_preflight=offline,
        scope='Reuse only explicitly reviewed P05 domains; exact candidate differences checked offline; this formal run must pass its own native/config/assets/camera/SDK startup gates',
        changed_domains_native_validation='pending this formal run startup; no claim P05 executed changed code')


def check_deadline(authorization, startup=False, now=None):
    guard = authorization.get('deadline_guard')
    if guard is None:
        return
    if guard.get('schema') != 'stool_absolute_utc_deadline_v1':
        raise RuntimeError('Invalid Stool UTC deadline schema')
    try:
        latest = datetime.datetime.fromisoformat(guard['latest_formal_launch_utc'])
        hard = datetime.datetime.fromisoformat(guard['hard_stop_utc'])
        if (latest.tzinfo is None or hard.tzinfo is None
                or latest.utcoffset() != datetime.timedelta(0)
                or hard.utcoffset() != datetime.timedelta(0) or latest >= hard):
            raise ValueError('invalid UTC ordering')
        current = datetime.datetime.now(datetime.timezone.utc) if now is None else now
        if current.tzinfo is None:
            raise ValueError('UTC clock required')
    except (KeyError, TypeError, ValueError) as error:
        raise RuntimeError('Invalid Stool absolute UTC deadline') from error
    if current >= hard or (not startup and current >= latest):
        raise RuntimeError('Stool UTC deadline does not permit a new launch; existing processes remain untouched')


def authorize(ledger, run, startup=False):
    authorization, execution = ledger['authorization'], ledger['execution']
    check_deadline(authorization, startup)
    if authorization.get('paused') is True:
        raise RuntimeError('Stool task is paused; explicit human resume is required')
    pause_after = authorization.get('pause_after_run')
    if pause_after is not None:
        if (not isinstance(pause_after, str) or not re.fullmatch(r'S[0-9]{2,}', pause_after)
                or execution['formal_rounds_started'] >= int(pause_after[1:])):
            raise RuntimeError('Human pause-after-run boundary does not permit another launch')
    grant = authorization['active_grant']
    index, limit = execution['formal_rounds_started'], authorization['round_limit']
    start = authorization['active_grant_starting_count']
    additional = authorization['additional_rounds_authorized']
    if (not re.fullmatch(r'G[0-9]{2,}', grant) or not all(type(v) is int for v in (index, limit, start, additional))
            or additional <= 0 or limit != start + additional or not start <= index < limit
            or execution['formal_rounds_closed'] != index
            or execution['formal_rounds_remaining'] != limit-index):
        raise RuntimeError('Stool grant/quota/order/previous closure does not permit this run')
    if not startup:
        if run != f'S{index+1:02d}':
            raise RuntimeError('Formal run order mismatch')
    else:
        probes = ledger['startup_preflights']
        permission = authorization['startup_only_preflight']
        if (permission.get('authorized') is not True or probes.get('grant_id') != grant
                or probes['started'] >= permission['max_diagnostic_launches']
                or probes['started'] != probes['closed'] or run != f"{grant}_P{probes['started']+1:02d}"):
            raise RuntimeError('Startup-only diagnostic grant/cap/order/closure mismatch')
    return grant


def write(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2) + '\n')
    temp.replace(path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('run', nargs='?', help='exact next formal ID; active grant and cap enforced by ledger')
    parser.add_argument('--startup', help='startup-only ID; exact order and cap enforced by ledger')
    args = parser.parse_args()
    if bool(args.run) == bool(args.startup):
        parser.error('select one formal run or one startup-only diagnostic')
    run = args.startup or args.run
    startup = bool(args.startup)
    subprocess.run(['bash', str(ROOT/'tools/run_stool.sh'), '--validate',
                    'startup' if startup else 'formal', run], check=True)
    with (ROOT / 'stool_run.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        ledger = json.loads(LEDGER.read_text())
        execution = ledger['execution']
        grant = authorize(ledger, run, startup)
        preflight = ROOT / 'worker_preflight.json'
        review = json.loads(preflight.read_text())
        if review.get('passed') is not True:
            raise RuntimeError('Actual worker/framework preflight missing')
        sources = inventory(SOURCE)
        tools = inventory(ROOT / 'tools')
        identity = control_identity(sources, tools)
        startup_binding = None
        if not startup:
            probes = ledger['startup_preflights']
            if not probes.get('current_pass_receipt'):
                raise RuntimeError('No completed startup-only native preflight receipt')
            receipt = Path(probes['current_pass_receipt'])
            proof = json.loads(receipt.read_text())
            if (proof.get('passed') is not True or proof.get('robot_sdk_submissions') != 0
                    or proof.get('assembly_success_claimed') is not False):
                raise RuntimeError('Original startup-only native preflight receipt is not valid')
            startup_binding = dict(path=str(receipt), sha256=sha(receipt))
            if (grant != 'G02' or not probes.get('passed_current_candidate')
                    or proof.get('control_tools_signature') != identity['control_tools_signature']
                    or proof.get('control_source_signature') != identity['control_source_signature']
                    or proof.get('configuration_signature') != review['worker']['configuration_signature']):
                domain_review = (probes.get(run+'_domain_review_receipt') or probes.get('domain_review_receipt')
                                 or (probes.get('S04_domain_review_receipt') if grant == 'G02' and run == 'S04' else None))
                if not domain_review:
                    raise RuntimeError('This formal candidate has no explicit grant-bound domain review')
                startup_binding['domain_reuse_review'] = reviewed_startup_reuse(
                    Path(domain_review), receipt, proof, identity, sources, tools, run, grant,
                    preflight, review['worker']['configuration_signature'])
        out = ROOT / ('startup_preflights' if startup else 'runs') / run
        out.mkdir(parents=True, exist_ok=False)
        for name, root, manifest in [('source', SOURCE, sources), ('tools', ROOT / 'tools', tools)]:
            with tarfile.open(out / (name + '_snapshot.tar.gz'), 'x:gz') as archive:
                for relative in manifest:
                    archive.add(root / relative, arcname=relative, recursive=False)
        gate = dict(run=run, grant=grant, mode='startup_only' if startup else 'formal', run_directory=str(out),
                    **identity, startup_preflight=startup_binding,
                    configuration_signature=review['worker']['configuration_signature'],
                    actual_worker_preflight_sha256=sha(preflight),
                    source_root=str(SOURCE), source_manifest=sources, tools_manifest=tools,
                    source_manifest_sha256=hashlib.sha256(json.dumps(sources, sort_keys=True).encode()).hexdigest(),
                    tool_manifest_sha256=hashlib.sha256(json.dumps(tools, sort_keys=True).encode()).hexdigest(),
                    seed=0, layout_seed=4906, formal_physical_success=False,
                    asset_identity_scope='resource links in baseline/bootstrap.json; composed layer hashes in scene_geometry.json after initialization',
                    original_worker_baseline_sha256=sha(ROOT / 'baseline/original_worker_config.json'))
        write(out / 'launch_gate.json', gate)
        write(out / 'source_binding.json', dict(passed=True, **gate,
            source_archive_sha256=sha(out/'source_snapshot.tar.gz'),
            tools_archive_sha256=sha(out/'tools_snapshot.tar.gz')))
        # Recheck after source/tool sealing, before quota or process creation.
        authorize(ledger, run, startup)
        utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
        if startup:
            probes['started'] += 1
            probes['attempts'].append(dict(id=run, output=str(out), closed=False, robot_sdk_submissions=0))
        else:
            execution['formal_rounds_started'] += 1
            execution['formal_rounds_remaining'] -= 1
        # Launcher invocation consumes quota; native initialization is confirmed separately.
        execution['status'] = run + '_launching'
        if not startup:
            execution['attempts'].append(dict(id=run, grant=grant, started_at_utc=utc, output=str(out),
                source_binding=str(out/'source_binding.json'), closed=False, native_observed=False))
        write(LEDGER, ledger)
        launched_monotonic_ns = time.monotonic_ns()
        with (out/'runner.log').open('xb') as log:
            process = subprocess.Popen(['bash', str(ROOT/'tools/run_stool.sh'),
                'startup' if startup else 'formal', run],
                cwd=SOURCE, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                start_new_session=True, env=dict(os.environ, STOOL_AUTHORIZED_GRANT=grant,
                    STOOL_AUTHORIZED_RUN=run, STOOL_AUTHORIZED_MODE='startup' if startup else 'formal'))
        receipt = dict(run=run, grant=grant, mode='startup_only' if startup else 'formal', pid=process.pid, utc=utc, output=str(out),
                       process_launch_monotonic_ns=launched_monotonic_ns,
                       source_binding_sha256=sha(out/'source_binding.json'))
        write(out/'launch_receipt.json', receipt)
        print(json.dumps(receipt))


if __name__ == '__main__':
    main()

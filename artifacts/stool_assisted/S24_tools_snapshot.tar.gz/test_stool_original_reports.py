"""Offline original-report regressions; no simulator/SDK or historical report edits."""
from pathlib import Path
from types import SimpleNamespace
import copy, hashlib, json, sys, tempfile, ast, tarfile
import numpy as np
BASE = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(BASE/'tools'), str(BASE/'stool_repository')]
from stool_sweep_model import SceneModel
from toolkits.constraint_checking.integration.stage_precheck import StageTrajectoryPrechecker
from toolkits.constraint_checking.integration.models import UR5E_ROBOTIQ_MODEL
from toolkits.constraint_checking.integration.entity_geometry import TaskEntityGeometryMonitor
import audit_stool_run as auditor


def main():
    cases = []
    def check(name, predicate):
        assert predicate, name
        cases.append(name)
    def rejects(name, callback):
        try: callback()
        except (ValueError, FileNotFoundError): cases.append(name)
        else: raise AssertionError(name)
    run = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else BASE/'grant02/server_evidence/runs/S04'
    scene_path = run/'scene_geometry.json'
    model = SceneModel(scene_path); data = model.data
    cfg = json.loads((run/'expected_runtime_config.json').read_text())
    robots = {}; q_before = {}
    for name, record in data['robots'].items():
        q = np.asarray(record['joint_positions'], float).copy(); q_before[name] = q.copy()
        rc = next(r for r in cfg['robots'] if r['name'].startswith(name))
        gripper = SimpleNamespace(joint_opened_positions=np.asarray([rc['gripper_open_position']]),
                                  joint_closed_positions=np.asarray([rc['gripper_closed_position']]))
        robots[name] = SimpleNamespace(articulation=SimpleNamespace(get_joint_positions=lambda q=q:q),
            config=SimpleNamespace(**rc), controllers={'gripper_controller':SimpleNamespace(_gripper=gripper)})
    native = model.poses(q_before)
    stamp = dict(valid=True, epoch=1, index=3, time=.0125, dt=1/240.)
    guard = SimpleNamespace(data=data, model=model, monitor=SimpleNamespace(current_poses=lambda:native))
    task = SimpleNamespace(_fabrica_assisted_contract={'assembly':'stool_circular'},
        _fabrica_production_action_guard=guard, _assisted_geometry_snapshot=data,
        robots=robots, _attachments={}, _beam_physics_stamp=lambda:copy.deepcopy(stamp))
    pre = StageTrajectoryPrechecker.__new__(StageTrajectoryPrechecker)
    pre.model=UR5E_ROBOTIQ_MODEL; pre._frame_coverage={}
    actions={name:dict(arm_joint_controller=[q[:6].tolist()],gripper_controller=[.5]) for name,q in q_before.items()}
    prediction=pre._calibrated_scene_path(task, actions, 8)
    for name in robots:
        root=data['robots'][name]['root_path']; tip=root+'/Gripper/Robotiq_2F_85/left_inner_finger'
        wrist=root+'/wrist_3_link'
        displacement=float(np.linalg.norm(prediction[-1][0][tip][:3,3]-native[tip][:3,3]))
        check(name+'_actual_scene_stationary_arm_closing_tip_moves',displacement>.005)
        check(name+'_actual_scene_wrist_only_legacy_prediction_misses_closing_motion',
              np.max(abs(prediction[-1][0][wrist]-native[wrist]))<1e-12 and displacement>.005)
        check(name+'_all_nine_original_gripper_frames_are_actually_predicted',
              pre._frame_coverage[name]['gripper_articulation_swept'] and
              len(pre._frame_coverage[name]['unique_mapping'])==16)
        check(name+'_exact_native_start',all(np.array_equal(prediction[0][0][p],native[p])
              for p in pre._frame_coverage[name]['unique_mapping'].values()))
    check('offline_full_scene_initial_graph_has_no_gaps',not model.gaps)
    for name in robots:check(name+'_no_native_joint_input_mutation',np.array_equal(q_before[name],robots[name].articulation.get_joint_positions()))
    legacy=SimpleNamespace(_fabrica_assisted_contract={})
    check('legacy_Beam_does_not_enter_stool_hook',pre._calibrated_scene_path(legacy, {}, 8) is None)
    bad=copy.copy(task);bad._fabrica_production_action_guard=None
    rejects('missing_full_graph_is_rejected',lambda:pre._calibrated_scene_path(bad,actions,8))
    bad_actions=copy.deepcopy(actions);bad_actions['franka_left']['gripper_controller']=[float('nan')]
    rejects('invalid_gripper_target_is_rejected',lambda:pre._calibrated_scene_path(task,bad_actions,8))
    body=data['robots']['franka_left']['root_path']+'/Gripper/Robotiq_2F_85/left_inner_finger'
    saved=native.pop(body)
    rejects('missing_real_gripper_body_is_rejected',lambda:pre._calibrated_scene_path(task,actions,8))
    native[body]=saved
    held_skipped = []
    try:
        from scipy.spatial.transform import Rotation
    except ImportError:
        held_skipped.append('actual S04 held-payload positive/endpoints/residual negative require server scipy; no native run')
    else:
        from toolkits.constraint_checking.integration.entity_geometry import pose_matrix
        capture=next(json.loads(line) for line in (run/'assisted_trace.jsonl').open()
            if 'attach_measured_pose' in line and 'fabrica_stool_circular_3' in line)
        raw=next(json.loads(line) for line in (run/'independent_native_trace.jsonl').open()
            if 'after_physics' in line and json.loads(line).get('physics_stamp',{}).get('index')==4964)
        for path,row in raw['bodies'].items():
            t=row['transform'];native[path]=pose_matrix(t[:3],[t[6],*t[3:6]])
        for name,robot in robots.items():
            joint_names=data['robots'][name]['joint_names'];actual=raw['robots'][name]
            ordered=np.asarray([actual['positions'][actual['joint_names'].index(n)] for n in joint_names])
            robot.articulation.get_joint_positions=lambda ordered=ordered:ordered
            actions[name]['arm_joint_controller']=[ordered[:6].tolist()]
            actions[name]['gripper_controller']=[float((ordered[joint_names.index('finger_joint')]-robot.config.gripper_closed_position)/(robot.config.gripper_open_position-robot.config.gripper_closed_position))]
        capture_hand=pose_matrix(capture['native_hand_position'],capture['native_hand_orientation'])
        frozen=np.linalg.inv(capture_hand)@pose_matrix(capture['position'],capture['orientation'])
        frozen_q=Rotation.from_matrix(frozen[:3,:3]).as_quat()[[3,0,1,2]].tolist()
        held_state=dict(robot_name='franka_left',hand_object_position=frozen[:3,3].tolist(),
            hand_object_orientation=frozen_q,attach_spec=dict(position_tolerance=.007,orientation_tolerance=.1))
        task._attachments={'fabrica_stool_circular_3':held_state};stamp.update(raw['physics_stamp'])
        actions['franka_left']['arm_joint_controller'][0][0]+=.01
        before_state=copy.deepcopy(task._attachments)
        predicted=pre._calibrated_scene_path(task,actions,8)
        part=data['object_body_coverage']['fabrica_stool_circular_3'][0]
        hand=data['robots']['franka_left']['root_path']+'/wrist_3_link'
        check('actual_S04_4964_held_start_exact_native',np.array_equal(predicted[0][0][part],native[part]))
        check('actual_S04_4964_frozen_endpoint_preserved',np.max(abs(predicted[-1][0][part]-predicted[-1][0][hand]@frozen))<1e-12)
        check('actual_S04_held_prediction_does_not_reanchor_capture',task._attachments==before_state)
        held_state['hand_object_position'][0]+=.02
        rejects('actual_S04_held_native_frozen_position_drift_rejected',lambda:pre._calibrated_scene_path(task,actions,8))
        task._attachments=copy.deepcopy(before_state)
        bad_rot=Rotation.from_rotvec([.2,0,0])*Rotation.from_matrix(frozen[:3,:3])
        task._attachments['fabrica_stool_circular_3']['hand_object_orientation']=bad_rot.as_quat()[[3,0,1,2]].tolist()
        rejects('actual_S04_held_native_frozen_orientation_drift_rejected',lambda:pre._calibrated_scene_path(task,actions,8))
        task._attachments={}
    # Original legacy FK methods themselves are byte-for-byte AST equivalent.
    source=BASE/'stool_repository/toolkits/constraint_checking/integration/stage_precheck.py'
    archive=run/'source_snapshot.tar.gz'
    with tarfile.open(archive) as tar:
        member=next(m for m in tar.getmembers() if m.name.endswith('toolkits/constraint_checking/integration/stage_precheck.py'))
        old=ast.parse(tar.extractfile(member).read().decode())
    new=ast.parse(source.read_text())
    for name in ('_forward_link_positions','_swept_entity_poses'):
        pick=lambda tree:next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name==name)
        check('old_Beam_'+name+'_unchanged',ast.dump(pick(old),include_attributes=False)==ast.dump(pick(new),include_attributes=False))
    # Real scene gives explicit visible meshes even for physically absent roots.
    roots=['factory_background_visual','factory_floor_visual','factory_table_leg_front_left',
           'factory_table_leg_front_right','factory_table_leg_back_left','factory_table_leg_back_right']
    inventory=[]
    for name in roots:
        mesh=next(m for m in data['visible_meshes'] if m['object']==name)
        inventory.append(dict(root=mesh['prim'],primitive_count=1,enabled_supported_count=0,
            status='no_collision_api_declared',traversal='Usd.PrimRange(root, Usd.TraverseInstanceProxies())',
            prims=[dict(prim=mesh['prim'],type='Cube',collision_api=False,enabled=None,supported_type=True)]))
    cov=dict(physical_inventory_schema='usd_collider_inventory_v1',root_collider_inventory=inventory,skipped=[])
    check('typed_six_visual_roots_remain_in_real_visible_scene',auditor.original_geometry_inventory(cov,data)==set())
    altered=copy.deepcopy(data);altered['visible_meshes']=[m for m in altered['visible_meshes'] if m['object']!=roots[0]]
    rejects('physical_absence_never_excuses_missing_visible_root',lambda:auditor.original_geometry_inventory(cov,altered))
    altered=copy.deepcopy(cov);altered['root_collider_inventory'][0]['prims'][0].update(collision_api=True,enabled=True,type='Sphere',supported_type=False)
    rejects('unsupported_enabled_collider_not_waived',lambda:auditor.original_geometry_inventory(altered,data))
    usd_inventory_skipped = []
    if len(sys.argv) > 2:
        from pxr import Usd
        from toolkits.constraint_checking.integration.entity_geometry import enumerate_usd_colliders
        stage = Usd.Stage.Open(str(Path(sys.argv[2]).resolve()))
        original = json.loads((run/'collect_results.json').read_text())[0]['runtime_constraint_monitor']['entity_geometry']
        paths = [row['root'] for row in original['missing']]
        colliders, actual_inventory = enumerate_usd_colliders(stage, [(p,'static:offline',None,p.rsplit('/',1)[-1]) for p in paths])
        statuses = [row['status'] for row in actual_inventory['root_collider_inventory']]
        check('actual_sealed_USD_six_no_API_four_explicit_disabled',statuses.count('no_collision_api_declared')==6 and statuses.count('all_declared_colliders_disabled')==4)
        check('actual_sealed_USD_original_ten_roots_extract_without_unsupported_gap',not colliders and not actual_inventory['missing'] and len(actual_inventory['skipped'])==4)
        check('actual_sealed_USD_typed_inventory_verified_against_original_visible_scene',len(auditor.original_geometry_inventory(actual_inventory,data))==4)
    else:
        usd_inventory_skipped.append('actual USD extraction requires explicit saved layer argument and server pxr; no native run')
    with tempfile.TemporaryDirectory(prefix='stool_original_stream_') as temp:
        path=Path(temp)/'entity_geometry_trace.jsonl';events=[dict(id=i) for i in range(5002)]
        payload=(json.dumps(dict(step=8,body_poses={'/body':np.eye(4).tolist()},events=events))+'\n').encode()
        path.write_bytes(payload)
        cov=dict(events=events[-5000:],events_dropped_from_summary=2,sampled_checks=1,
            uncapped_trace_receipt=dict(schema='entity_geometry_uncapped_trace_v1',path=str(path),start_offset=0,
              bytes=len(payload),sha256=hashlib.sha256(payload).hexdigest(),records=1,events=5002,
              summary_events=5000,summary_omitted_events=2,summary_is_exact_suffix=True))
        check('complete_stream_resolves_only_summary_truncation',auditor.original_uncapped_trace(cov,path)['events']==5002)
        for key in ('sha256','records','events','bytes'):
            bad=copy.deepcopy(cov);bad['uncapped_trace_receipt'][key]='bad'
            rejects('wrong_trace_'+key+'_rejected',lambda bad=bad:auditor.original_uncapped_trace(bad,path))
        bad=copy.deepcopy(cov);bad['events'][0]={'id':-1}
        rejects('changed_summary_suffix_rejected',lambda:auditor.original_uncapped_trace(bad,path))
        missing=copy.deepcopy(cov);missing.pop('uncapped_trace_receipt')
        rejects('summary_without_uncapped_receipt_stays_missing',lambda:auditor.original_uncapped_trace(missing,path))
        # Exercise the actual monitor observe/finalize writer (FCL replaced only
        # by a deterministic checker; the serialization and retention are real).
        mon=TaskEntityGeometryMonitor.__new__(TaskEntityGeometryMonitor)
        mon.task=SimpleNamespace(phase='offline');mon.current_poses=lambda:{'/body':np.eye(4)}
        mon.checker=SimpleNamespace(check=lambda *a,**k:dict(closest_nonexempt_pair=None,events=[],step=k['step']),coverage=lambda:{})
        mon.steps=0;mon.minimum=None;mon.events=[];mon.events_dropped=0;mon.pair_minima={};mon.gaps={};mon.errors=[]
        mon._trace_path=None;mon._trace_start=None;mon._trace_bytes=0;mon._trace_records=0;mon._trace_events=0;mon._trace_hash=hashlib.sha256()
        import os
        prior=os.environ.get('BEAM_ENTITY_GEOMETRY_TRACE_PATH');os.environ['BEAM_ENTITY_GEOMETRY_TRACE_PATH']=str(Path(temp)/'actual_writer.jsonl')
        try:mon.observe(8,None);mon.observe(16,None)
        finally:
            if prior is None:os.environ.pop('BEAM_ENTITY_GEOMETRY_TRACE_PATH')
            else:os.environ['BEAM_ENTITY_GEOMETRY_TRACE_PATH']=prior
        report=mon.finalize()
        check('actual_original_writer_receipt_reconciles',auditor.original_uncapped_trace(report,Path(report['uncapped_trace_receipt']['path']))['records']==2)
    print(json.dumps(dict(passed=True,count=len(cases),cases=cases,native_physics_executed=0,
        scene_sha256=hashlib.sha256(scene_path.read_bytes()).hexdigest(),
        held_fixture_skipped=held_skipped,usd_inventory_skipped=usd_inventory_skipped,scope='actual S04 SceneModel and old-source AST; synthetic declared inventory/stream corruptions; no force or collision success claim')))

if __name__=='__main__':main()

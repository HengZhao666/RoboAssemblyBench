"""Same-clock final dual-UR5e/Robotiq/stool batch guard.

Every loaded rendered/authored collision mesh is inventoried. Full robot meshes,
all nine native parts, fixtures and chosen environment participate. This is a
finite sampled geometric guard, not continuous collision or native contact proof.
"""
from __future__ import annotations
from pathlib import Path
from contextlib import contextmanager
import copy, hashlib, itertools, json, math, time
import numpy as np
from stool_sweep_model import SceneModel
from stool_export_geometry import export_geometry

ARM = ('shoulder_pan_joint','shoulder_lift_joint','elbow_joint','wrist_1_joint','wrist_2_joint','wrist_3_joint')
# Authored Robotiq 2F85 linkage. These are robot kinematics, not Beam task values.
MIMIC = {'finger_joint':1.,'right_outer_knuckle_joint':1.,'left_inner_finger_joint':-1.,
         'right_inner_finger_joint':1.,'left_inner_finger_knuckle_joint':-1.,'right_inner_finger_knuckle_joint':-1.}
FINGERS = ('/left_inner_finger','/right_inner_finger')


def _inverse(t):
    result=np.eye(4);result[:3,:3]=t[:3,:3].T;result[:3,3]=-result[:3,:3]@t[:3,3];return result


def _payload_bridge_pose(native_body,hand,frozen,measured,interpolate,fraction):
    if fraction==0.:return native_body.copy()
    if fraction==1.:return hand@frozen
    bridge=np.eye(4);bridge[:3,3]=(1-fraction)*measured[:3,3]+fraction*frozen[:3,3]
    bridge[:3,:3]=interpolate([fraction]).as_matrix()[0]
    return hand@bridge


class StoolMeshGuard:
    def __init__(self,task,monitor,data,out):
        import fcl
        self.fcl=fcl;self.task=task;self.monitor=monitor;self.out=Path(out)
        self.model=SceneModel(self.out/'scene_geometry.json');self.data=data
        self.contract=data['task_contract'];self.objects=set(data['task_objects'])
        self.support_object_names={'fabrica_fixture','optical_board','factory_tabletop_visual'}
        if data['gaps'] or self.model.gaps:
            raise ValueError('stool geometry coverage gaps: '+repr(data['gaps']+self.model.gaps))
        self.meshes=data['visible_meshes'];self.shapes=[];corners=[]
        self.robot_bodies={m['body'] for m in self.meshes if m.get('robot')}
        self.object_bodies={name:data['object_body_coverage'][name][0] for name in self.objects}
        self.joint_interfaces={frozenset((j['parent'][0],j['child'][0])) for j in data['joints']
            if j['robot'] and j['enabled'] and len(j['parent'])==len(j['child'])==1}
        self.exemptions=[];self.pairs=[];self.initial_support={};self.calls=0;self.samples=0
        self.physics_stamp=task._beam_physics_stamp();self.initial_poses=monitor.current_poses()
        for m in self.meshes:
            points=np.asarray(m['points'],float);faces=np.asarray(m['triangles'],np.int32)
            shape=fcl.BVHModel();shape.beginModel(len(faces),len(points));shape.addSubModel(points,faces);shape.endModel()
            self.shapes.append(fcl.CollisionObject(shape))
            corners.append(list(itertools.product(*zip(points.min(axis=0),points.max(axis=0)))))
        self.corners=np.asarray(corners,float)
        for i,j in itertools.combinations(range(len(self.meshes)),2):
            a,b=self.meshes[i],self.meshes[j]
            if a['body']==b['body']:continue
            if not (a['robot'] or b['robot'] or a['object'] in self.objects or b['object'] in self.objects): continue
            reason=None
            if a['robot'] and a['robot']==b['robot']:
                if frozenset((a['body'],b['body'])) in self.joint_interfaces:
                    reason='exact_authored_joint_interface'
                housing=(a['body'].endswith('/Gripper/Robotiq_2F_85/base_link') and b['body'].endswith(('/left_inner_knuckle','/right_inner_knuckle'))) or (b['body'].endswith('/Gripper/Robotiq_2F_85/base_link') and a['body'].endswith(('/left_inner_knuckle','/right_inner_knuckle')))
                if housing:reason='exact_authored_housing_bearing_interface'
            for robot_mesh,environment_mesh in ((a,b),(b,a)):
                if robot_mesh['robot'] and environment_mesh['object']=='factory_tabletop_visual' and robot_mesh['body']==data['robots'][robot_mesh['robot']]['root_path']+'/base_link':
                    reason='exact_fixed_robot_table_mount'
            if reason:self.exemptions.append(dict(mesh_a=a['prim'],mesh_b=b['prim'],reason=reason))
            else:self.pairs.append((i,j))
        self.indices=np.asarray(self.pairs,int).reshape(-1,2)
        baseline=self._check_scene(self.initial_poses,initial=True)
        self.initial_report=baseline
        self._write('stool_geometry_initial.json',dict(passed=not baseline['collisions'],initial=baseline,
            meshes=len(self.meshes),pairs=len(self.pairs),exemptions=self.exemptions,
            baseline_support_pairs=list(self.initial_support.values()),model=self.model.initial_validation(),
            full_stage_export=True,formal_physical_success=False))
        if baseline['collisions']:
            raise ValueError('initial full-stage stool geometry collision: '+repr(baseline['collisions'][0]))

    def _write(self,name,value):
        (self.out/name).write_text(json.dumps(value,default=lambda x:x.tolist())+'\n')

    @contextmanager
    def _exact_query_scope(self):
        """Reuse exact FCL hit/depth only within one action or support call."""
        previous=getattr(self,'_exact_query_cache',None)
        self._exact_query_cache=dict(values={},hits=0,misses=0,selected_pair_queries=0,
                                     scene_samples=0,started=time.perf_counter())
        try:yield
        finally:
            self.last_exact_query_cache_stats=self._exact_query_stats()
            self._exact_query_cache=previous

    def _exact_query_stats(self):
        scope=getattr(self,'_exact_query_cache',None)
        if scope is None:return None
        return dict(hits=scope['hits'],misses=scope['misses'],
            selected_pair_queries=scope['selected_pair_queries'],scene_samples=scope['scene_samples'],
            stored_entries=len(scope['values']),elapsed_wall_seconds=time.perf_counter()-scope['started'],
            scope='one action/support call; full absolute transform bytes; hit/depth only; classification always recomputed')

    def _query_collision_hit_depth(self,index,i,j,transforms):
        scope=getattr(self,'_exact_query_cache',None)
        if scope is not None:
            key=(int(index),int(i),int(j),transforms.dtype.str,transforms.shape[1:],
                 transforms[i].tobytes(order='C'),transforms[j].tobytes(order='C'))
            scope['selected_pair_queries']+=1
            if key in scope['values']:
                scope['hits']+=1
                return scope['values'][key]
        fcl=self.fcl;result=fcl.CollisionResult()
        hit=fcl.collide(self.shapes[i],self.shapes[j],
            fcl.CollisionRequest(num_max_contacts=8,enable_contact=True),result)
        depth=max((float(c.penetration_depth) for c in result.contacts),default=0.) if hit else 0.
        value=(hit,depth)
        if scope is not None:
            scope['values'][key]=value;scope['misses']+=1
        return value

    def _contact_reason(self,a,b,initial,depth):
        task=self.task;phase=task.get_current_phase_spec() or {};text=str(phase.get('name',''))
        active=phase.get('local_skill') or {};part=active.get('object');robot=active.get('robot')
        for item in (phase.get('attach',[]) or []):
            if isinstance(item,dict):part=part or item.get('object');robot=robot or item.get('robot')
        for x,y in ((a,b),(b,a)):
            if x['object'] in self.objects and y['robot'] and y['body'].endswith(FINGERS):
                holder=(getattr(task,'_attachments',{}) or {}).get(x['object'],{}).get('robot_name')
                if holder==y['robot'] or (x['object']==part and y['robot']==robot and any(s in text for s in ('grasp','close','descend','release'))):
                    # This task's CAD near-fit contract permits separation,
                    # not mesh penetration. Include the whole inner finger,
                    # so a legal pad distance cannot hide a finger-body hit.
                    if (self.contract.get('cad_pinch') or {}).get('schema') == 'stool_visible_pad_near_fit_v1':
                        return None
                    return 'exact_active_or_attached_inner_finger_contact'
        pair=frozenset((a['object'],b['object']))
        assembly_pairs={frozenset(p) for p in self.contract.get('assembly_contact_pairs',[])}
        installed=set(phase.get('beam_assisted_installed_parts',[]))
        if pair in assembly_pairs and (pair <= installed or
            (part in pair and any(s in text for s in ('insert','release','settle')))):
            return 'exact_catalog_socket_pair_in_assembly_phase'
        for x,y in ((a,b),(b,a)):
            if x['object'] not in self.objects or y['robot'] or y['object'] not in self.support_object_names:continue
            key=x['prim']+' | '+y['prim']
            if initial:
                self.initial_support[key]=dict(mesh_a=x['prim'],mesh_b=y['prim'],part=x['object'],
                    environment=y['object'],initial_depth_m=depth)
                return 'native_initial_part_fixture_support'
            support=self.initial_support.get(key)
            if support and depth <= support['initial_depth_m'] + 1e-6:
                if x['object'] not in (getattr(task,'_attachments',{}) or {}) and x['object'] not in installed:
                    return 'unchanged_native_initial_part_fixture_support'
                if x['object']==part and any(s in text for s in ('grasp','close','descend')):
                    return 'pickup_qualified_exact_initial_fixture_pair'
        return None

    def _check_scene(self,poses,*,initial=False):
        scope=getattr(self,'_exact_query_cache',None)
        if scope is not None:scope['scene_samples']+=1
        fcl=self.fcl;transforms=np.asarray([poses[m['body']] for m in self.meshes])
        world=np.einsum('nkj,nij->nki',self.corners,transforms[:,:3,:3])+transforms[:,:3,3][:,None,:]
        lo=world.min(axis=1);hi=world.max(axis=1);ii,jj=self.indices.T
        gaps=np.maximum(np.maximum(lo[ii]-hi[jj],lo[jj]-hi[ii]),0.)
        # Exact intersections need overlapping AABBs; positive clearance is also recorded.
        selected=np.flatnonzero(np.sum(gaps*gaps,axis=1)<=1e-12)
        for obj,t in zip(self.shapes,transforms):obj.setTransform(fcl.Transform(t[:3,:3],t[:3,3]))
        collisions=[];contacts=[]
        for index in selected:
            i,j=self.pairs[index];a,b=self.meshes[i],self.meshes[j]
            hit,depth=self._query_collision_hit_depth(index,i,j,transforms)
            if not hit:continue
            reason=self._contact_reason(a,b,initial,depth)
            row=dict(mesh_a=a['prim'],mesh_b=b['prim'],body_a=a['body'],body_b=b['body'],depth_m=depth,
                allowed_contact_reason=reason)
            if reason:contacts.append(row)
            elif depth>1e-6:collisions.append(row)
        lower=np.sqrt(np.sum(gaps*gaps,axis=1))
        return dict(collisions=collisions,allowed_contacts=contacts,checked_pair_count=len(self.pairs),
            exact_overlap_candidates=len(selected),minimum_AABB_clearance_m=float(lower.min()) if len(lower) else None)

    def _retain_rejected_command(self,context,exc):
        """Serialize only existing per-call values; failure cannot replace the guard error."""
        result=dict(schema='stool_rejected_batch_v1',invocation_sequence=context['invocation_sequence'],
            availability='partial',guard_stage=context.get('guard_stage'),
            original_error=repr(exc),publication_status='rejected before guard return; SDK evidence belongs to worker',
            missing=[],errors=[])
        fields=('phase','task_step','physics_stamp','robot_names','incoming_actions',
            'joint_names','native_joint_positions','bounded_actions','final_model_joint_positions',
            'native_body_world_matrices','model_start_body_world_matrices','failed_sample')
        def array(value):
            if isinstance(value,np.ndarray):return value.tolist()
            if isinstance(value,np.generic):return value.item()
            raise TypeError('unsupported diagnostic value '+type(value).__name__)
        for name in fields:
            value=context.get(name)
            if value is None:
                result[name]=None;result['missing'].append(name);continue
            try:result[name]=json.loads(json.dumps(value,default=array,allow_nan=False))
            except Exception as error:
                result[name]=None;result['missing'].append(name)
                result['errors'].append(dict(field=name,error=repr(error)))
        essential=('phase','task_step','physics_stamp','robot_names','incoming_actions',
            'joint_names','native_joint_positions','bounded_actions','final_model_joint_positions')
        if all(result.get(name) is not None for name in essential):
            result['availability']='complete_command'
        self.last_rejection_evidence=result

    def __call__(self,actions):
        sequence=getattr(self,'_rejection_evidence_sequence',0)+1
        self._rejection_evidence_sequence=sequence;self.last_rejection_evidence=None
        context=dict(invocation_sequence=sequence,guard_stage='entered_guard',incoming_actions=actions)
        self._rejection_evidence_context=context
        try:
            with self._exact_query_scope():return self._guard_action(actions)
        except (ValueError,RuntimeError) as exc:
            try:self._retain_rejected_command(context,exc)
            except Exception as error:
                self.last_rejection_evidence=dict(schema='stool_rejected_batch_v1',
                    invocation_sequence=sequence,availability='unavailable',original_error=repr(exc),
                    diagnostic_error=repr(error))
            raise
        finally:self._rejection_evidence_context=None

    def _map_robot_target(self,name,action,actual_q,active,previous,limits):
        """Pure target math shared by the final guard and closure preview.

        Inputs are already sampled native q, limits and prior accepted targets;
        this method does not read physics, publish, trace or change guard state.
        """
        robot=self.task.robots[name]
        action=copy.deepcopy(action or {})
        if 'arm_ik_controller' in action and 'arm_joint_controller' not in action:
            raise ValueError('hidden SDK IK outlet cannot enter final stool geometry sweep')
        action.pop('arm_ik_controller',None)
        names=self.data['robots'][name]['joint_names'];arm_indices=[names.index(n) for n in ARM]
        q=np.asarray(actual_q,float);arm=q[arm_indices];target_q=q.copy()
        requested=np.asarray(action.get('arm_joint_controller',[arm])[0],float)
        if requested.shape!=(6,) or not np.all(np.isfinite(requested)):raise ValueError('invalid stool native arm target')
        limits=np.asarray(limits,float)
        requested=np.asarray([min((v+2*math.pi*k for k in range(-4,5) if limits[i,0]<=v+2*math.pi*k<=limits[i,1]),key=lambda v:abs(v-arm[i]),default=np.nan) for i,v in enumerate(requested)])
        if not np.all(np.isfinite(requested)):raise ValueError('stool arm target has no valid native branch')
        spec=active if active.get('robot')==name else {}
        step=float(spec.get('max_command_joint_step',spec.get('max_joint_step',self.contract['max_joint_step_rad'])))
        tracking=float(spec.get('max_command_tracking_error',self.contract['max_tracking_error_rad']))
        if step<=0 or tracking<=0:raise ValueError('stool joint envelope must be positive')
        anchor=np.asarray(previous.get(name,arm),float)
        final=np.clip(requested,anchor-step,anchor+step)
        final=np.clip(final,arm-tracking,arm+tracking)
        final=np.asarray(final,dtype=np.float32).astype(float)
        if np.any(final<limits[:,0]) or np.any(final>limits[:,1]):raise ValueError('stool final float32 target exceeds native limits')
        target_q[arm_indices]=final;action['arm_joint_controller']=[final.tolist()]
        opening=action.get('gripper_controller')
        if opening is None:
            driver=q[names.index(robot.config.gripper_dof_name)]
            opening=[(driver-robot.config.gripper_closed_position)/(robot.config.gripper_open_position-robot.config.gripper_closed_position)]
        opening=np.asarray(opening,float)
        if opening.shape!=(1,) or not np.all(np.isfinite(opening)) or not 0<=opening[0]<=1:
            raise ValueError('stool final gripper command is invalid')
        action['gripper_controller']=opening.tolist()
        minimum=float(getattr(robot.config,'gripper_close_openness',0.) or 0.)
        openness=max(minimum,float(opening[0]));driver=robot.config.gripper_dof_name
        goal=robot.config.gripper_closed_position+openness*(robot.config.gripper_open_position-robot.config.gripper_closed_position)
        change=goal-q[names.index(driver)]
        if driver!='finger_joint' or set(MIMIC)-set(names):raise ValueError('unsupported native gripper linkage')
        for joint,sign in MIMIC.items():target_q[names.index(joint)]=q[names.index(joint)]+sign*change
        clamp=dict(robot=name,max_target_change_rad=float(np.max(abs(final-arm))),step_limit_rad=step,tracking_limit_rad=tracking)
        return dict(action=action,target_q=target_q,clamp=clamp)

    def preview_robot_target(self,name,action,actual_q):
        """Read-only mapping of supplied q; never invoke the production sweep.

        The ordinary guard has already populated the exact native limit cache.
        A preview cannot initialize that cache or sample another native state.
        """
        task=self.task
        if name not in task.robots or name not in self.data['robots']:
            raise ValueError('stool target preview references an unknown robot')
        q=np.asarray(actual_q,float)
        if q.shape!=(len(self.data['robots'][name]['joint_names']),) or not np.all(np.isfinite(q)):
            raise ValueError('stool target preview requires the complete finite supplied native joint vector')
        stamp=task._beam_physics_stamp()
        if stamp.get('valid') is not True or type(stamp.get('epoch')) is not int:
            raise ValueError('stool target preview lacks a valid physics epoch')
        articulation=task.robots[name].articulation
        view=articulation._articulation_view
        identity=(id(articulation),id(view),stamp['epoch'])
        cached=getattr(task,'_assisted_arm_limits_cache',{}).get(name)
        if cached is None or cached.get('identity')!=identity:
            raise ValueError('stool target preview lacks the existing native arm-limit cache identity')
        phase=task.get_current_phase_spec() or {};active=phase.get('local_skill') or {}
        previous=getattr(task,'_assisted_published_q',{}) or {}
        return self._map_robot_target(name,action,q,active,previous,cached['limits'])

    def _guard_action(self,actions):
        started=time.perf_counter();task=self.task;stamp=task._beam_physics_stamp()
        diagnostic=getattr(self,'_rejection_evidence_context',None)
        if diagnostic is not None:diagnostic.update(physics_stamp=stamp,phase=getattr(task,'phase',None),
            task_step=getattr(task,'step_counter',None),robot_names=list(task.robots),guard_stage='native_clock_admission')
        if stamp.get('valid') is not True:raise ValueError('stool final sweep lacks native clock')
        if set(actions)!=set(task.robots):raise ValueError('stool final sweep lacks complete dual-arm batch')
        phase=task.get_current_phase_spec() or {};active=phase.get('local_skill') or {}
        actual_q={name:np.asarray(robot.articulation.get_joint_positions(),float) for name,robot in task.robots.items()}
        if diagnostic is not None:diagnostic.update(native_joint_positions=actual_q,guard_stage='native_joint_inputs')
        final_q={name:q.copy() for name,q in actual_q.items()};bounded=copy.deepcopy(actions)
        previous=getattr(task,'_assisted_published_q',{}) or {};clamps=[]
        for name,robot in task.robots.items():
            action=bounded[name] or {};bounded[name]=action
            if 'arm_ik_controller' in action and 'arm_joint_controller' not in action:
                raise ValueError('hidden SDK IK outlet cannot enter final stool geometry sweep')
            action.pop('arm_ik_controller',None)
            names=self.data['robots'][name]['joint_names'];arm_indices=[names.index(n) for n in ARM]
            if diagnostic is not None:diagnostic.setdefault('joint_names',{})[name]=names
            q=actual_q[name];arm=q[arm_indices]
            requested=np.asarray(action.get('arm_joint_controller',[arm])[0],float)
            if requested.shape!=(6,) or not np.all(np.isfinite(requested)):raise ValueError('invalid stool native arm target')
            limits=np.asarray(task._assisted_arm_joint_limits(name),float)
            # Keep the original precondition/native-limit read order above;
            # the shared mapper repeats only these pure input validations.
            mapped=self._map_robot_target(name,action,q,active,previous,limits)
            bounded[name]=mapped['action'];final_q[name]=mapped['target_q'];clamps.append(mapped['clamp'])
        if diagnostic is not None:diagnostic.update(bounded_actions=bounded,final_model_joint_positions=final_q,
            guard_stage='complete_bounded_command')
        native=self.monitor.current_poses();native_scene=self._check_scene(native)
        if diagnostic is not None:diagnostic.update(native_body_world_matrices=native,guard_stage='native_scene_admission')
        if native_scene['collisions']:raise RuntimeError('stool actual native scene mesh overlap: '+repr(native_scene['collisions'][0]))
        origin=self.model.poses(actual_q)
        if diagnostic is not None:diagnostic.update(model_start_body_world_matrices=origin,guard_stage='payload_and_sample_admission')
        corrections={body:native[body]@_inverse(origin[body]) for body in self.robot_bodies}
        from toolkits.constraint_checking.integration.entity_geometry import pose_matrix
        relative={};relation_residuals=[];bridge_details=[]
        for name,state in (getattr(task,'_attachments',{}) or {}).items():
            robot=state.get('robot_name');root=self.data['robots'][robot]['root_path']
            hand=root+'/wrist_3_link';body=self.object_bodies[name]
            if 'hand_object_position' not in state or 'hand_object_orientation' not in state:
                raise ValueError('stool payload lacks frozen captured native hand relation')
            frozen=pose_matrix(state['hand_object_position'],state['hand_object_orientation'])
            expected=native[hand]@frozen
            position_error=float(np.linalg.norm(expected[:3,3]-native[body][:3,3]))
            angle_error=float(np.arccos(np.clip((np.trace(expected[:3,:3].T@native[body][:3,:3])-1)/2,-1,1)))
            attach=state.get('attach_spec',{})
            position_limit=float(attach['position_tolerance']);angle_limit=float(attach['orientation_tolerance'])
            relation_residuals.append(dict(object=name,position_residual_m=position_error,orientation_residual_rad=angle_error,
                position_limit_m=position_limit,orientation_limit_rad=angle_limit,
                numeric_source='original stool attachment qualification pose tolerances',capture_physics_stamp=state.get('capture_physics_stamp')))
            if position_error>position_limit or angle_error>angle_limit:
                raise ValueError('stool native payload drift exceeded original attachment pose envelope: '+repr(relation_residuals[-1]))
            # The fixed joint can have a small native solver residual. Keep its
            # frozen relation and independent drift gate, but start prediction
            # at the actual body and converge to the original frozen endpoint.
            # This temporary measurement is never written to attachment state.
            from scipy.spatial.transform import Rotation,Slerp
            measured=_inverse(native[hand])@native[body]
            interpolate=Slerp([0.,1.],Rotation.from_matrix(np.stack([measured[:3,:3],frozen[:3,:3]])))
            relative[name]=(hand,frozen,measured,interpolate)
            correction_lengths=[]
            for mesh in self.meshes:
                if mesh['object']!=name:continue
                points=np.asarray(mesh['points'],float)
                start=points@measured[:3,:3].T+measured[:3,3]
                end=points@frozen[:3,:3].T+frozen[:3,3]
                correction_lengths.append(float(np.linalg.norm(end-start,axis=1).max()))
            if not correction_lengths:raise ValueError('stool payload bridge lacks complete object CAD')
            bridge_details.append(dict(object=name,hand=hand,body=body,physics_stamp=stamp,
                measured_temporary_hand_object_matrix=measured.tolist(),frozen_hand_object_matrix=frozen.tolist(),
                native_start_body_matrix=native[body].tolist(),temporary_only=True,attachment_state_written=False,
                maximum_relative_CAD_vertex_correction_m=max(correction_lengths),
                relative_rotation_correction_rad=float((Rotation.from_matrix(measured[:3,:3]).inv()*Rotation.from_matrix(frozen[:3,:3])).magnitude()),
                fraction0_exact_native=False,fraction1_exact_old_frozen=False))
        maximum=max(float(np.max(abs(final_q[n]-actual_q[n]))) for n in actual_q)
        # Adaptive finite sampling is tied to this task's original smallest joint increment.
        resolution=float(self.contract['max_joint_step_rad']);count=max(2,int(math.ceil(maximum/resolution))+1)
        if count>512:raise ValueError('stool final sweep exceeds bounded adaptive sample budget')
        original_fractions=np.linspace(0.,1.,count);fractions=original_fractions;bridge_sampling=None
        if relative:
            increments=[]
            for spec in task.phase_specs:
                skill=spec.get('local_skill') or {};value=skill.get('cartesian_position_step')
                if value is None:continue
                if isinstance(value,bool) or not isinstance(value,(int,float)) or not np.isfinite(value) or value<=0.:
                    raise ValueError('stool bridge sampling has an invalid configured Cartesian increment')
                increments.append((spec['name'],float(value)))
            if not increments:raise ValueError('stool bridge sampling lacks configured Cartesian increments')
            position_resolution=min(value for _,value in increments)
            correction_counts=[max(2,int(math.ceil(row['maximum_relative_CAD_vertex_correction_m']/position_resolution))+1,
                int(math.ceil(row['relative_rotation_correction_rad']/resolution))+1) for row in bridge_details]
            correction_count=max(count,*correction_counts)
            if correction_count>512:raise ValueError('stool payload correction exceeds bounded adaptive sample budget')
            fractions=np.union1d(original_fractions,np.linspace(0.,1.,correction_count))
            if len(fractions)>512:raise ValueError('stool original and bridge fraction union exceeds bounded adaptive sample budget')
            bridge_sampling=dict(original_sample_count=count,original_fractions=original_fractions.tolist(),
                evaluated_sample_count=len(fractions),fractions=fractions.tolist(),all_original_fractions_preserved=True,
                correction_sample_count=correction_count,position_resolution_m=position_resolution,
                position_resolution_source='minimum positive explicit cartesian_position_step across actual task.phase_specs',
                attaining_phases=[name for name,value in increments if value==position_resolution],
                angle_resolution_rad=resolution,angle_resolution_source='unchanged task contract max_joint_step_rad',
                interpolation='temporary measured-relative translation linear and rotation shortest SLERP to original frozen relation',
                contact_exemptions_added=False)
        native_fk_errors=[float(np.linalg.norm(native[b][:3,3]-origin[b][:3,3])) for b in self.robot_bodies]
        nonzero_native_q=any(np.max(abs(actual_q[n]-np.asarray(self.data['robots'][n]['joint_positions'],float)))>1e-5 for n in actual_q)
        first_failure=None;last=None
        for fraction in fractions:
            q={n:actual_q[n]+fraction*(final_q[n]-actual_q[n]) for n in actual_q}
            fk=self.model.poses(q);poses=dict(native)
            for body,correction in corrections.items():poses[body]=correction@fk[body]
            for name,(hand,frozen,measured,interpolate) in relative.items():
                body=self.object_bodies[name];detail=next(row for row in bridge_details if row['object']==name)
                poses[body]=_payload_bridge_pose(native[body],poses[hand],frozen,measured,interpolate,float(fraction))
                if fraction==0.:
                    detail['fraction0_exact_native']=bool(np.array_equal(poses[body],native[body]))
                elif fraction==1.:
                    detail['frozen_endpoint_body_matrix']=poses[body].tolist()
                    detail['fraction1_exact_old_frozen']=bool(np.array_equal(poses[body],poses[hand]@frozen))
            last=self._check_scene(poses);self.samples+=1
            if last['collisions']:
                if diagnostic is not None:diagnostic.update(guard_stage='sample_collision',failed_sample=dict(
                    fraction=float(fraction),joint_positions=q,body_world_matrices=poses,collision=last['collisions'][0]))
                first_failure=dict(fraction=float(fraction),collision=last['collisions'][0]);break
        if task._beam_physics_stamp()!=stamp:raise ValueError('native clock changed during stool final batch sweep')
        self.calls+=1
        report=dict(passed=first_failure is None,phase=str(getattr(task,'phase','')),step=int(task.step_counter),physics_stamp=stamp,
            meshes=len(self.meshes),pair_count=len(self.pairs),requested_sample_count=len(fractions),original_requested_sample_count=count,first_failure=first_failure,
            native_actual_scene=native_scene,last_sample=last,clamps=clamps,frozen_payload_native_residuals=relation_residuals,
            payload_bridge_details=bridge_details,payload_bridge_sampling=bridge_sampling,
            global_FK_native_max_position_residual_m=max(native_fk_errors,default=0.),nonzero_native_q_observed=bool(nonzero_native_q),seconds=time.perf_counter()-started,calls=self.calls,
            scope='same-clock final float32 dual-arm targets, all Robotiq mimic joints, held9/installed/fixture/chosen environment',
            limits=['finite FK samples; no between-sample CCD','native solver/cooked/SDF contact differs from authored mesh',
                    'gripper mimic endpoints are predictions; SDK/native feedback is independently required'],
            exact_query_cache=self._exact_query_stats())
        with (self.out/'stool_production_geometry.jsonl').open('a') as stream:stream.write(json.dumps(report)+'\n')
        if first_failure:raise RuntimeError('stool final dual-arm mesh sweep rejected: '+repr(first_failure))
        return bounded


    def support_guard(self,name,position,orientation,stamp):
        with self._exact_query_scope():return self._guard_support(name,position,orientation,stamp)

    def _guard_support(self,name,position,orientation,stamp):
        """Check an installation anchor command before USD joint mutation."""
        from toolkits.constraint_checking.integration.entity_geometry import pose_matrix
        from scipy.spatial.transform import Rotation
        task=self.task
        if task._beam_physics_stamp()!=stamp or stamp.get('valid') is not True:
            raise ValueError('support geometry guard received stale native clock')
        native=self.monitor.current_poses();body=self.object_bodies[name]
        start=native[body];goal=pose_matrix(position,orientation)
        position_length=float(np.linalg.norm(goal[:3,3]-start[:3,3]))
        start_q=Rotation.from_matrix(start[:3,:3]).as_quat()[[3,0,1,2]]
        goal_q=np.asarray(orientation,float);goal_q/=np.linalg.norm(goal_q)
        if np.dot(start_q,goal_q)<0:goal_q=-goal_q
        angle=2*np.arccos(np.clip(np.dot(start_q,goal_q),-1.,1.))
        count=max(2,int(math.ceil(position_length/self.contract['install_position_step_m']))+1,
                    int(math.ceil(angle/self.contract['install_orientation_step_rad']))+1)
        if count>512:raise ValueError('stool support command exceeds finite sweep budget')
        first=None;last=None
        for fraction in np.linspace(0.,1.,count):
            poses=dict(native);q=(1-fraction)*start_q+fraction*goal_q;q/=np.linalg.norm(q)
            poses[body]=pose_matrix(start[:3,3]+fraction*(goal[:3,3]-start[:3,3]),q)
            last=self._check_scene(poses)
            if last['collisions']:
                first=dict(fraction=float(fraction),collision=last['collisions'][0]);break
        report=dict(passed=first is None,object=name,physics_stamp=stamp,samples=count,
            first_failure=first,last_sample=last,scope='native part to proposed installation anchor finite sweep before joint authoring',
            exact_query_cache=self._exact_query_stats())
        with (self.out/'stool_support_geometry.jsonl').open('a') as stream:stream.write(json.dumps(report)+'\n')
        if task._beam_physics_stamp()!=stamp:raise ValueError('native clock changed in stool support sweep')
        if first:raise RuntimeError('stool installation support mesh sweep rejected: '+repr(first))
        return report


def initialize_geometry_guard(task,out):
    """Call once after initialized env.reset, before the first policy action."""
    from toolkits.constraint_checking.integration.entity_geometry import TaskEntityGeometryMonitor
    monitor=TaskEntityGeometryMonitor(task);data=export_geometry(monitor,out)
    guard=StoolMeshGuard(task,monitor,data,out)
    task._fabrica_production_action_guard=guard
    task._fabrica_production_support_guard=guard.support_guard
    task._fabrica_geometry_monitor=monitor
    task._assisted_geometry_snapshot=data
    task._assisted_native_body_readers=monitor._native_readers
    return dict(passed=True,full_stage_export=True,visible_meshes=len(data['visible_meshes']),
        objects=data['object_body_coverage'],robots=list(data['robots']),native_initial=guard.initial_report,
        physics_stamp=task._beam_physics_stamp(),formal_physical_success=False)

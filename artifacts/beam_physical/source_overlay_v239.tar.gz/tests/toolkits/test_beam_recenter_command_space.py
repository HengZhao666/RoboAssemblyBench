"""Real adapter act/gates/limits with an explicit delayed toy plant.

The contact reader and kinematics are doubles. No test qualifies a physical grasp
or substitutes for the native contact/force/geometry acceptance.
"""
import copy
import inspect
import json
from pathlib import Path
import unittest

import numpy as np
import test_beam_weak_side_recenter as replay
from toolkits.factory_dual_franka_assembly.plumbers_block_ur5e_skills import UR5eAssemblyAtomicSkillAdapter as Adapter


class CommandSpaceFeedback(unittest.TestCase):
    def fixture(self, enabled=True, offset=(78e-6,87e-6,305e-6)):
        adapter,task,native,state,act=replay.FinalActionRecenterSafety().fixture(
            initial=0.,consistent=True,feedback=True)
        spec=inspect.getclosurevars(act).nonlocals['spec']
        if enabled:
            spec.update(close_recenter_feedback_command_space=True,
                        close_recenter_feedback_max_tracking_offset=.001)
        raw=task.robots['left'].controllers['arm_ik_controller']._kinematics_solver.get_kinematics_solver()
        raw.compute_inverse_kinematics=lambda frame,position,orientation,**kw:(np.r_[position,np.zeros(3)],True)
        raw.compute_forward_kinematics=lambda frame,q:(np.asarray(q[:3]),np.eye(3))
        pose=lambda:{'position':native['q'][:3].copy(),'orientation':np.array([1.,0.,0.,0.])}
        adapter._current_robot_pose=lambda **kw:pose()
        adapter._target_pose=lambda **kw:pose()
        records=[]
        adapter._debug_close_gate_step=lambda **kw:records.append(copy.deepcopy(kw['detail']))
        act()  # The existing force controller plans a genuine pending micro.
        self.assertEqual(state['force_recenter_pending']['lifecycle'],'planned')
        prior=np.r_[offset,np.zeros(3)]
        state['hold_q']=prior.copy()
        adapter._remember_arm_command(task,'left',prior)
        return adapter,task,native,state,act,spec,records,prior

    def run_plant(self,enabled=True,response=.065,frozen=False):
        adapter,task,native,state,act,spec,records,prior=self.fixture(enabled)
        bias=-prior.copy()
        queued=prior.copy()  # One interval of command delay.
        target=None;history=[]
        for tick in range(101,345):
            task.step_counter=task.phase_step_counter=tick
            action=act()
            pending=state.get('force_recenter_pending')
            if pending is not None and pending.get('lifecycle')=='final_action_issued':
                if target is None:target=pending['motion_target_position_world'].copy()
                np.testing.assert_array_equal(pending['motion_target_position_world'],target)
            if action.get('__local_skill_failure__'):break
            command=np.asarray(action['arm_joint_controller'][0])
            if target is not None:
                residual=native['q'][:3]-target
                history.append({'tick':tick,'command':command.copy(),
                    'axial':abs(float(residual[1])),'lateral':float(np.linalg.norm(residual[[0,2]]))})
            if target is not None and pending is None:break
            if not frozen:native['q']+=response*(queued+bias-native['q'])
            queued=command.copy()
        return dict(adapter=adapter,task=task,native=native,state=state,action=action,
            target=target,history=history,records=records,act=act,prior=prior)

    def test_old_defect_loses_original_pose_gate_and_ratchets_down(self):
        r=self.run_plant(False)
        # At this response rate the unchanged 1 mm pose guard fires before
        # the 240-interval micro timeout. Keep that protective gate intact.
        self.assertEqual(r['action'].get('reason'),'contact_pose_gate_lost')
        self.assertGreater(r['history'][-1]['lateral'],.0001)
        z=np.asarray([x['command'][2] for x in r['history']])
        self.assertLess(z[-1],z[0]-.0001)
        # There is an initial recovery transient; the observed downward drift
        # is a net trend, not a claim of strict per-interval monotonicity.

    def test_old_slower_plant_reaches_micro_timeout(self):
        r=self.run_plant(False,response=.03)
        self.assertEqual(r['action'].get('reason'),'close_recenter_motion_timeout')
        self.assertGreater(r['history'][-1]['lateral'],.0001)

    def test_fixed_path_acknowledges_without_lateral_sag(self):
        for response in [.03,.065,.4]:
            with self.subTest(response=response):
                r=self.run_plant(response=response)
                self.assertNotIn('__local_skill_failure__',r['action'])
                self.assertNotIn('force_recenter_pending',r['state'])
                self.assertLessEqual(max(x['lateral'] for x in r['history']),30e-6)
                self.assertLessEqual(r['history'][-1]['axial'],6.25e-6)
                self.assertLessEqual(len(r['history']),240)
                np.testing.assert_array_equal(r['state']['contact_arm_anchor']['position'],np.zeros(3))
                self.assertLessEqual(r['state']['force_recenter_travel']+r['state']['recenter_feedback_travel'],.002)
                self.assertTrue(any(x.get('feedback_first_tick') for x in r['records']))
                self.assertLessEqual(max(x.get('feedback_lead_m',0) for x in r['records']),.0002+1e-12)

    def test_frozen_feedback_times_out_with_bounded_lead_and_travel(self):
        r=self.run_plant(frozen=True)
        self.assertEqual(r['action'].get('reason'),'close_recenter_motion_timeout')
        self.assertLessEqual(max(x.get('feedback_lead_m',0) for x in r['records']),.0002+1e-12)
        self.assertLessEqual(r['state']['force_recenter_travel']+r['state']['recenter_feedback_travel'],.002)

    def test_offset_above_one_mm_fails_before_new_action(self):
        adapter,task,native,state,act,spec,records,prior=self.fixture(offset=(.0012,0,0))
        task.step_counter=task.phase_step_counter=101
        action=act()
        self.assertEqual(action.get('reason'),'contact_pose_gate_lost')
        self.assertEqual(action['diagnostics']['reason'],'recenter_feedback_tracking_offset_exceeded')
        np.testing.assert_array_equal(adapter._last_command_q(task=task,robot_name='left'),prior)
        self.assertFalse(state.get('recenter_feedback_active',False))

    def test_missing_prior_fk_fails_before_new_action(self):
        adapter,task,native,state,act,spec,records,prior=self.fixture()
        adapter._grasp_command_fk_pose=lambda **kw:None
        task.step_counter=task.phase_step_counter=101
        action=act()
        self.assertEqual(action['diagnostics']['reason'],'recenter_feedback_prior_fk_unavailable')
        np.testing.assert_array_equal(adapter._last_command_q(task=task,robot_name='left'),prior)

    def test_hard_force_and_bilateral_cancel_hold_the_previous_command(self):
        for forces in [(8.,9.),(.3,80.)]:
            with self.subTest(forces=forces):
                adapter,task,native,state,act,spec,records,prior=self.fixture()
                task.step_counter=task.phase_step_counter=101
                action=act();previous=np.asarray(action['arm_joint_controller'][0])
                adapter._grasp_contact_ready=lambda **kw:(False,{'contact_metrics':replay.metrics(*forces)})
                task.step_counter=task.phase_step_counter=102
                action=act()
                self.assertNotIn('force_recenter_pending',state)
                np.testing.assert_allclose(action['arm_joint_controller'][0],previous,atol=1e-12)
                if max(forces)>=40:
                    self.assertLess(.8*(1-action['gripper_controller'][0]),.737)

    def test_second_pending_reestimates_offset_and_charges_published_travel(self):
        adapter,task,native,state,act,spec,records,prior=self.fixture()
        task.step_counter=task.phase_step_counter=101
        action=act()
        old_pending=state['force_recenter_pending']
        old_offset=old_pending['feedback_tracking_offset_world'].copy()
        previous=np.asarray(action['arm_joint_controller'][0]).copy()
        charged=state['recenter_feedback_travel']
        fresh=copy.deepcopy(old_pending)
        fresh.pop('feedback_seeded');fresh.pop('feedback_tracking_offset_world')
        fresh.update(lifecycle='planned',reference_target_consistent=False,
            motion_delta_world=np.array([0.,-25e-6,0.]),offset_before=np.zeros(3),elapsed_steps=0)
        state['force_recenter_pending']=fresh
        native['q'][:3]=[5e-6,3e-6,-4e-6]
        task.step_counter=task.phase_step_counter=102
        action=act()
        pending=state['force_recenter_pending']
        np.testing.assert_allclose(pending['feedback_tracking_offset_world'],previous[:3]-native['q'][:3],atol=1e-14)
        self.assertGreater(np.linalg.norm(pending['feedback_tracking_offset_world']-old_offset),1e-6)
        published=np.asarray(action['arm_joint_controller'][0])
        self.assertAlmostEqual(state['recenter_feedback_travel']-charged,float(np.linalg.norm(published[:3]-previous[:3])))

    def test_nonbool_flag_and_nonfinite_helper_inputs_raise(self):
        adapter,task,native,state,act,spec,records,prior=self.fixture()
        spec['close_recenter_feedback_command_space']='true'
        with self.assertRaises(ValueError):act()
        kwargs=dict(previous_command=np.zeros(3),current_position=np.zeros(3),
            one_step_position=np.zeros(3),tracking_offset=np.zeros(3),max_increment=5e-6,lookahead=.0002)
        for key,value in [('previous_command',[np.nan,0,0]),('tracking_offset',[0,np.inf,0]),('max_increment',0.),('lookahead',np.nan)]:
            with self.subTest(key=key),self.assertRaises(ValueError):
                Adapter._recenter_feedback_command_position(**{**kwargs,key:value})

    def test_round40_first_command_characterization(self):
        data=json.loads((Path(__file__).parent/'fixtures/beam_cc41_recenter_characterization.json').read_text())
        r=data['R52'];issued=r['issued'];prior=np.asarray(r['prior_command_fk'])
        start=np.asarray(issued['motion_start_position_world']);delta=np.asarray(issued['motion_delta_world'])
        np.testing.assert_allclose(issued['issued_command_tcp_position_world'],start+delta,atol=1e-6)
        command,detail=Adapter._recenter_feedback_command_position(previous_command=prior,
            current_position=start,one_step_position=start+delta,tracking_offset=prior-start,
            max_increment=5e-6,lookahead=.0002)
        self.assertLessEqual(np.linalg.norm(command-prior),5e-6+1e-14)
        self.assertGreater(np.linalg.norm(prior-start),.0003)
        first,second=data['D1_first_two_micros']
        np.testing.assert_allclose(first['issued']['issued_command_tcp_position_world'],
            np.asarray(first['issued']['motion_start_position_world'])+first['issued']['motion_delta_world'],atol=1e-6)
        # Compare against the original lead lost at the first micro, which is
        # what the director's D1 characterization calls the pre-existing lead.
        expected=np.asarray(first['gate_before']['command_target_position'])-first['gate_before']['current_position']
        actual=np.asarray(second['issued']['issued_command_tcp_position_world'])-second['issued']['motion_start_position_world']
        self.assertLessEqual(np.linalg.norm(actual-expected),20e-6)


if __name__=='__main__':
    unittest.main()

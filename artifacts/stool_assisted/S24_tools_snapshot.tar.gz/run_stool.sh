#!/usr/bin/env bash
set -eo pipefail
STOOL_VALIDATE=0
if [[ "${1:-}" == --validate ]]; then STOOL_VALIDATE=1; shift; fi
STOOL_MODE=${1:?mode required}
STOOL_RUN=${2:?run name required}
if [[ "$STOOL_MODE" == startup ]]; then
  [[ "$STOOL_RUN" =~ ^G[0-9]{2,}_P[0-9]{2,}$ ]] || exit 2
elif [[ "$STOOL_MODE" == formal ]]; then
  [[ "$STOOL_RUN" =~ ^S[0-9]{2,}$ ]] || exit 2
else
  exit 2
fi
if [[ "$STOOL_VALIDATE" == 1 ]]; then exit 0; fi
# The ledger-bound launcher is the only entry that consumes an authorized round.
[[ "${STOOL_AUTHORIZED_MODE:-}" == "$STOOL_MODE" && "${STOOL_AUTHORIZED_RUN:-}" == "$STOOL_RUN" \
   && "${STOOL_AUTHORIZED_GRANT:-}" =~ ^G[0-9]{2,}$ ]] || exit 2
if [[ "$STOOL_MODE" == startup ]]; then
  [[ "$STOOL_RUN" == "${STOOL_AUTHORIZED_GRANT}_P"* ]] || exit 2
fi
source /home/user/beam_integration_20261010_upstream6f57dae/stool_assisted_20261021/tools/stool_env.sh
if [[ "$STOOL_MODE" == startup ]]; then
  export STOOL_RUN_DIR="$STOOL_ROOT/startup_preflights/$STOOL_RUN" STOOL_STARTUP_ONLY=1
else
  export STOOL_RUN_DIR="$STOOL_ROOT/runs/$STOOL_RUN" STOOL_STARTUP_ONLY=0
fi
export OMNI_KIT_ACCEPT_EULA=YES VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/nvidia_icd.json
export ISAAC_ASSETS_ROOT=https://omniverse-content-production.s3-us-west-2.amazonaws.com/Assets/Isaac/5.1
# Existing diagnostics are task-scoped by the explicit stool contract.
export BEAM_ENTITY_GEOMETRY_CHECK=1 BEAM_VIDEO_CLOCK_TRACE=1 BEAM_POST_FAILURE_VIDEO_SECONDS=2
export BEAM_PHYSICS_DIAGNOSTICS=1 BEAM_PHYSICS_DIAGNOSTICS_UNFILTERED=1
export BEAM_PHYSICS_DIAGNOSTICS_STRIDE=8 BEAM_PHYSICS_DIAGNOSTICS_PHASES='*'
export BEAM_PHYSICS_DIAGNOSTICS_START_STEP=0 BEAM_PHYSICS_DIAGNOSTICS_END_STEP=-1
export BEAM_PHYSICS_DIAGNOSTICS_OBJECTS=fabrica_stool_circular_0,fabrica_stool_circular_1,fabrica_stool_circular_2,fabrica_stool_circular_3,fabrica_stool_circular_4,fabrica_stool_circular_5,fabrica_stool_circular_6,fabrica_stool_circular_7,fabrica_stool_circular_8
export BEAM_ASSISTED_TRACE_PATH="$STOOL_RUN_DIR/assisted_trace.jsonl"
export BEAM_RELEASE_JOINT_TRACE_PATH="$STOOL_RUN_DIR/release_joint_trace.jsonl"
export BEAM_ENTITY_GEOMETRY_TRACE_PATH="$STOOL_RUN_DIR/entity_geometry_trace.jsonl"
export BEAM_PHYSICS_DIAGNOSTICS_PATH="$STOOL_RUN_DIR/physics_boundary_trace.jsonl"
export BEAM_CONTACT_TRACE_PATH="$STOOL_RUN_DIR/contact_trace.jsonl"
export BEAM_CLOSE_CONTROL_TRACE_PATH="$STOOL_RUN_DIR/close_control_trace.jsonl"
export BEAM_CLOSE_GATE_TRACE_PATH="$STOOL_RUN_DIR/close_gate_trace.jsonl"
export BEAM_MOTION_TRACE_PATH="$STOOL_RUN_DIR/motion_trace.jsonl"
export DUAL_FRANKA_ATTACH_DEBUG_PATH="$STOOL_RUN_DIR/attach_debug.jsonl"
set +e
python -u "$STOOL_ROOT/tools/stool_worker.py" --worker-mode collect \
  --worker-recipe fabrica_stool_circular_ur5e_staged \
  --worker-scene-profile taoyuan_grscenes_tabletop \
  --worker-results-path "$STOOL_RUN_DIR/collect_results.json" \
  --worker-seeds 0 --worker-layout-seeds 4906 --max-trials 1 --start-seed 0 \
  --record-live-video --live-video-frame-stride 8 --live-video-fps 30 --keep-video-frames \
  --output-dir "$STOOL_RUN_DIR" --domain-randomization --skip-episode-steps \
  --runtime-constraint-monitor --constraint-check-stride 8 \
  --assembly-sequence-precheck --stage-trajectory-precheck \
  --stage-precheck-stride 64 --stage-precheck-waypoints 4 --headless
STOOL_CODE=$?
printf '%s\n' "$STOOL_CODE" > "$STOOL_RUN_DIR/exit_code"
date -u -Is > "$STOOL_RUN_DIR/finished_at"
exit "$STOOL_CODE"

"""Real __call__ regression on saved S03 native/CAD states, without simulation."""
from __future__ import annotations
import argparse,collections,copy,hashlib,json
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from scipy.spatial.transform import Rotation,Slerp
from stool_geometry_guard import StoolMeshGuard,ARM,_payload_bridge_pose
from stool_sweep_model import SceneModel
from compare_stool_geometry_cache import build_checker,native_matrix,context_for


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def rows(path):return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',type=Path,required=True)
    parser.add_argument('--output-dir',type=Path,required=True);args=parser.parse_args()
    run=args.run.resolve();out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=False)
    report=dict(passed=False,native_physics_executed=0,sdk_commands_published=0,cases=[],errors=[])
    files={name:run/name for name in ('scene_geometry.json','stool_geometry_initial.json','task_config_snapshot.json',
        'stool_production_geometry.jsonl','independent_native_trace.jsonl','assisted_trace.jsonl')}
    report['input_sha256']={name:sha(path) for name,path in files.items()}
    guard_path=Path(__file__).with_name('stool_geometry_guard.py');report['guard_sha256']=sha(guard_path)
    report['tested_control_tools']={'stool_geometry_guard.py':report['guard_sha256']}
    try:
        data=json.loads(files['scene_geometry.json'].read_text());initial=json.loads(files['stool_geometry_initial.json'].read_text())
        config=json.loads(files['task_config_snapshot.json'].read_text());config=config[0] if isinstance(config,list) else config
        phases={value['name']:value for value in config['phase_specs']};configs={value['name']:value for value in config['robots']}
        failure=[row for row in rows(files['stool_production_geometry.jsonl']) if not row['passed']][0]
        raw=rows(files['independent_native_trace.jsonl']);event_rows=rows(files['assisted_trace.jsonl'])
        events=[dict(row=value,source_line=index+1) for index,value in enumerate(event_rows)]
        limits={row['robot']:np.asarray(row['limits_rad'],float) for row in event_rows if row.get('event')=='native_arm_joint_limits'}
        model=SceneModel(files['scene_geometry.json']);checker=build_checker(StoolMeshGuard,data,initial,model)
        checker.robot_bodies={mesh['body'] for mesh in data['visible_meshes'] if mesh['robot']}
        checker.object_bodies={name:data['object_body_coverage'][name][0] for name in data['task_objects']}
        def run_case(name,source,expected,mutate=None,forced_phase=None):
            value=copy.deepcopy(source);value['phase']=forced_phase or value['phase']
            context,_=context_for(value,events,phases);phase=copy.deepcopy(phases[value['phase']])
            attachments={}
            for obj,state in context._attachments.items():
                frozen=state['frozen_hand_object'];capture=[event for event in event_rows if event.get('event')=='attach_measured_pose'
                    and event.get('object')==obj and event['physics_stamp']['index']<=value['physics_stamp']['index']][-1]
                spec=next(item for item in phases[capture['phase']]['attach'] if item['object']==obj)
                attachments[obj]=dict(robot_name=state['robot_name'],hand_object_position=frozen[:3,3].tolist(),
                    hand_object_orientation=Rotation.from_matrix(frozen[:3,:3]).as_quat()[[3,0,1,2]].tolist(),
                    attach_spec=copy.deepcopy(spec),capture_physics_stamp=capture['physics_stamp'])
            native={path:np.asarray(matrix,float) for path,matrix in data['body_rest'].items()}
            native.update({path:native_matrix(entry['transform']) for path,entry in value['bodies'].items()})
            actual={robot:np.asarray(entry['positions'],float) for robot,entry in value['robots'].items()}
            if not checker.robot_bodies<=set(value['bodies']):raise ValueError('case lacks complete raw robot bodies')
            batch=[event for event in event_rows if event.get('event')=='fabrica_final_published_batch' and event.get('physics_stamp',{}).get('valid')
                and event['physics_stamp']['index']<=value['physics_stamp']['index']][-1]
            actions=copy.deepcopy(batch['actions']);state=dict(native=native,q=actual,attachments=attachments,phase=phase,actions=actions,
                phase_specs=copy.deepcopy(config['phase_specs']))
            if mutate:mutate(state)
            task=SimpleNamespace(phase=value['phase'],step_counter=value['task_step'],phase_specs=state['phase_specs'],_attachments=state['attachments'],
                robots={robot:SimpleNamespace(config=SimpleNamespace(**configs[robot]),
                    articulation=SimpleNamespace(get_joint_positions=lambda n=robot:state['q'][n].copy())) for robot in actual},
                _assisted_published_q={robot:entry['arm_joint_controller'][0] for robot,entry in batch['actions'].items()})
            task.get_current_phase_spec=lambda:state['phase'];task._beam_physics_stamp=lambda:copy.deepcopy(value['physics_stamp'])
            task._assisted_arm_joint_limits=lambda robot:limits[robot].copy()
            checker.task=task;checker.monitor=SimpleNamespace(current_poses=lambda:copy.deepcopy(state['native']))
            checker.out=out/name;checker.out.mkdir();checker.calls=0;checker.samples=0
            before=copy.deepcopy(state);error=None;returned=None
            try:returned=checker(state['actions']);accepted=True
            except (ValueError,RuntimeError) as exc:accepted=False;error=repr(exc)
            def serialized(obj):return json.dumps(obj,sort_keys=True,default=lambda array:array.tolist())
            unchanged=serialized(before)==serialized(state)
            path=checker.out/'stool_production_geometry.jsonl';evidence=rows(path)[-1] if path.exists() else None
            case=dict(name=name,accepted=accepted,expected_accept=expected,expectation_met=accepted==expected,
                physics_stamp=value['physics_stamp'],phase=value['phase'],input_native_q_targets_frozen_attachment_unchanged=unchanged,
                original_source_boundary=source['boundary'],evidence=evidence,error=error,returned_actions=returned,
                complete_geometry_mesh_count=len(checker.meshes),complete_pair_count=len(checker.pairs),sampled_scenes=checker.samples)
            if accepted:
                case['bounded_captured_targets_unchanged']=returned==before['actions']
                if not case['bounded_captured_targets_unchanged']:raise ValueError('captured already-bounded target changed: '+name)
                if evidence['requested_sample_count']<evidence['original_requested_sample_count']:raise ValueError('original sample count decreased')
                for detail in evidence['payload_bridge_details']:
                    if not detail['fraction0_exact_native'] or not detail['fraction1_exact_old_frozen']:raise ValueError('bridge endpoint identity failed')
                if evidence['payload_bridge_sampling'] and not evidence['payload_bridge_sampling']['all_original_fractions_preserved']:
                    raise ValueError('original interpolation fractions dropped')
            report['cases'].append(case)
            if accepted!=expected or not unchanged:raise ValueError('case failed: '+name)
            return case
        selected=[];groups=collections.OrderedDict()
        for row in raw:
            if row.get('valid') and row['boundary']=='after_action' and row['phase'].startswith('base_2'):
                groups.setdefault(row['phase'],[]).append(row)
        for values in groups.values():
            selected.append(values[0])
            if len(values)>1:selected.append(values[-1])
        if len(selected)<4:raise ValueError('fewer than four saved original base2 full-native states')
        for index,row in enumerate(selected):run_case('original_base2_'+str(index)+'_'+row['phase'],row,True)
        targets=[]
        for index in (failure['physics_stamp']['index'],failure['physics_stamp']['index']+1):
            value=next(row for row in raw if row.get('valid') and row['physics_stamp']['index']==index)
            targets.append(value);run_case('actual_native_'+str(index),value,True,forced_phase=failure['phase'])
        first=targets[0];part='fabrica_stool_circular_3';holder=phases[failure['phase']]['local_skill']['robot']
        def hold(state):
            names=data['robots'][holder]['joint_names'];indices=[names.index(name) for name in ARM]
            state['actions'][holder]['arm_joint_controller']=[state['q'][holder][indices].tolist()]
        for value in targets:
            negative=run_case('dangerous_frozen_future_'+str(value['physics_stamp']['index']),value,False,hold,failure['phase'])
            if negative['evidence']['first_failure']['fraction']<=0.:raise ValueError('future-overlap negative did not reach positive fraction')
        def drift(state):state['attachments'][part]['hand_object_position'][0]+=.008
        run_case('unchanged_original_position_drift_gate',first,False,drift,failure['phase'])
        def angle_drift(state):
            value=state['attachments'][part]['hand_object_orientation'];rot=Rotation.from_quat(np.asarray(value)[[1,2,3,0]])*Rotation.from_rotvec([.11,0,0])
            state['attachments'][part]['hand_object_orientation']=rot.as_quat()[[3,0,1,2]].tolist()
        run_case('unchanged_original_orientation_drift_gate',first,False,angle_drift,failure['phase'])
        def other(state):
            body=checker.object_bodies[part];target=checker.object_bodies['fabrica_stool_circular_5']
            state['native'][target]=state['native'][body].copy();state['native'][target][0,3]+=.005
        run_case('another_part_actual_collision',first,False,other,failure['phase'])
        def budget(state):
            for spec in state['phase_specs']:
                skill=spec.get('local_skill') or {}
                if skill.get('cartesian_position_step') is not None:skill['cartesian_position_step']=1e-9
        run_case('correction_sampling_budget_fails_closed',first,False,budget,failure['phase'])
        # Exercise the production helper on a nontrivial proper rotation. End-
        # points are exact, intermediate local translation is linear and the
        # rotation follows shortest-SLERP rather than entrywise matrix blending.
        hand=np.eye(4);hand[:3,:3]=Rotation.from_rotvec([.2,-.1,.3]).as_matrix();hand[:3,3]=[.3,.2,1.1]
        measured=np.eye(4);measured[:3,3]=[.02,.01,-.15]
        frozen=measured.copy();frozen[:3,:3]=Rotation.from_rotvec([0,0,.08]).as_matrix();frozen[:3,3]+=[.001,-.002,.003]
        native=hand@measured;native[0,3]=np.nextafter(native[0,3],np.inf)
        interpolation=Slerp([0.,1.],Rotation.from_matrix([measured[:3,:3],frozen[:3,:3]]))
        actual=_payload_bridge_pose(native,hand,frozen,measured,interpolation,.5);expected=np.eye(4)
        expected[:3,:3]=Rotation.from_rotvec([0,0,.04]).as_matrix();expected[:3,3]=(measured[:3,3]+frozen[:3,3])/2
        midpoint_error=float(np.max(abs(actual-hand@expected)))
        rotation_check=dict(name='production_helper_rotation_and_exact_endpoints',expectation_met=midpoint_error<1e-14 and
            np.array_equal(_payload_bridge_pose(native,hand,frozen,measured,interpolation,0.),native) and
            np.array_equal(_payload_bridge_pose(native,hand,frozen,measured,interpolation,1.),hand@frozen),
            midpoint_matrix_max_abs_error=midpoint_error,fixture_class='mathematical interpolation regression, not native execution')
        report['cases'].append(rotation_check)
        if not rotation_check['expectation_met']:raise ValueError('rotation interpolation regression failed')
        report.update(inputs_unchanged=all(sha(path)==report['input_sha256'][name] for name,path in files.items()),
            production_guard_unchanged_during_checks=sha(guard_path)==report['guard_sha256'],
            frozen_state_and_targets_unchanged=all(case.get('input_native_q_targets_frozen_attachment_unchanged',True) and
                case.get('bounded_captured_targets_unchanged',True) for case in report['cases']),
            original_collision_threshold_m=1e-6,new_contact_exemptions=0,base2_saved_state_count=len(selected),
            scope='actual production guard __call__ on complete saved native/CAD fixtures and explicitly labeled counterfactuals; no physics or SDK execution')
        report['passed']=report['inputs_unchanged'] and report['production_guard_unchanged_during_checks'] and report['frozen_state_and_targets_unchanged'] and all(case['expectation_met'] for case in report['cases'])
    except Exception as exc:report['errors'].append(type(exc).__name__+': '+str(exc))
    (out/'payload_bridge_regression.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({key:report.get(key) for key in ('passed','base2_saved_state_count','inputs_unchanged','errors')}))
    return 0 if report['passed'] else 1

if __name__=='__main__':raise SystemExit(main())

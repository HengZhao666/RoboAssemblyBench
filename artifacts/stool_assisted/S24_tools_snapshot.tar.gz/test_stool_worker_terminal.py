"""Real terminal wrapper with mocked external recorder/native services only."""
import ast
import copy
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
from types import MethodType, ModuleType, SimpleNamespace as NS
import unittest
from unittest.mock import Mock, patch
import numpy as np

REPO = Path(__file__).resolve().parents[1] / 'stool_repository'
sys.path.insert(0, str(REPO))


def load_worker(out):
    # Importing the production worker must not construct a simulator in this
    # offline unit test. The actual install_terminal_capture function is used.
    demo = ModuleType('toolkits.factory_dual_franka_assembly.generate_demos')
    demo._build_env = lambda *args, **kwargs: None
    demo.DualFrankaAssemblyDemoPolicy = type('Policy', (), {'act': lambda *args: {}})
    demo.LiveRolloutVideoRecorder = type('Recorder', (), {'__init__': lambda *args, **kwargs: None})
    demo._to_jsonable = lambda value: value
    preflight = ModuleType('toolkits.factory_dual_franka_assembly.fabrica_assisted_preflight')
    preflight.assert_fabrica_assisted_configuration = lambda *args: {}
    modules = {demo.__name__: demo, preflight.__name__: preflight}
    spec = importlib.util.spec_from_file_location('_stool_worker_terminal_test',
        Path(__file__).with_name('stool_worker.py'))
    worker = importlib.util.module_from_spec(spec)
    import toolkits.factory_dual_franka_assembly as package
    with patch.dict(sys.modules, modules), patch.object(package, 'generate_demos', demo, create=True), \
            patch.dict(os.environ, STOOL_RUN_DIR=str(out)):
        spec.loader.exec_module(worker)
    worker.ENV = object()
    worker.ACTIVE_VIDEO = object()
    return worker


def task_and_result():
    result = {'success': True, 'failed': False, 'terminal_reason': 'success-criteria-met',
              'phase_history': ['last_stage', 'complete'], 'original_detail': {'value': 3}}
    task = NS(success=True, failed=False, calculate_metrics=Mock(return_value=result),
              cfg=NS(camera_metadata=[{'name': 'front'}, {'name': 'left'}, {'name': 'right'}]))
    return task, result


def helper_module(capture):
    module = ModuleType('stool_startup_evidence')
    module.capture_startup_evidence = capture
    module.record_initial_video = Mock(return_value={'passed': True})
    return module


STAMP = {'valid': True, 'epoch': 0, 'index': 71, 'time': 71 / 240., 'dt': 1 / 240.}


def report():
    return {'passed': True, 'before': {'physics_stamp': dict(STAMP), 'counters': {'step_counter': 72}}}


class TerminalMetricsRetentionTests(unittest.TestCase):
    def test_success_retains_original_before_capture_and_returns_same_result(self):
        with tempfile.TemporaryDirectory() as directory:
            out = Path(directory)
            worker = load_worker(out)
            task, original = task_and_result()
            def capture(*args, **kwargs):
                self.assertEqual(json.loads((out / 'terminal_original_metrics.json').read_text()), original)
                self.assertTrue(task._stool_terminal_media_capture_attempted)
                self.assertEqual(kwargs, {'prefix': 'terminal', 'orient_wrist': False})
                return report()
            helper = helper_module(Mock(side_effect=capture))
            task._fabrica_independent_raw_sampler = Mock(return_value={'valid': True, 'physics_stamp': dict(STAMP)})
            worker.install_terminal_capture(task)
            with patch.dict(sys.modules, {'stool_startup_evidence': helper}):
                self.assertIs(task.calculate_metrics(), original)
            self.assertTrue(task._stool_terminal_media_captured)
            saved = json.loads((out / 'terminal_media_capture.json').read_text())
            self.assertTrue(saved['passed'])
            self.assertEqual(saved['original_metrics'], 'terminal_original_metrics.json')
            self.assertFalse((out / 'terminal_media_failure.json').exists())

    def test_capture_exception_returns_original_and_is_not_retried(self):
        with tempfile.TemporaryDirectory() as directory:
            out = Path(directory)
            worker = load_worker(out)
            task, original = task_and_result()
            capture = Mock(side_effect=RuntimeError('three-view frame missing'))
            helper = helper_module(capture)
            task._fabrica_independent_raw_sampler = Mock()
            worker.install_terminal_capture(task)
            with patch.dict(sys.modules, {'stool_startup_evidence': helper}):
                self.assertIs(task.calculate_metrics(), original)
                first_bytes = (out / 'terminal_original_metrics.json').read_bytes()
                failure_bytes = (out / 'terminal_media_failure.json').read_bytes()
                self.assertIs(task.calculate_metrics(), original)
            self.assertEqual(capture.call_count, 1)
            self.assertEqual(task._fabrica_independent_raw_sampler.call_count, 0)
            self.assertEqual((out / 'terminal_original_metrics.json').read_bytes(), first_bytes)
            self.assertEqual((out / 'terminal_media_failure.json').read_bytes(), failure_bytes)
            self.assertFalse(json.loads(failure_bytes)['strict_media_qualified'])
            self.assertFalse((out / 'terminal_media_capture.json').exists())

    def test_raw_exception_after_images_preserves_both_original_and_failure(self):
        with tempfile.TemporaryDirectory() as directory:
            out = Path(directory)
            worker = load_worker(out)
            task, original = task_and_result()
            helper = helper_module(Mock(return_value=report()))
            task._fabrica_independent_raw_sampler = Mock(side_effect=RuntimeError('native handle expired'))
            worker.install_terminal_capture(task)
            with patch.dict(sys.modules, {'stool_startup_evidence': helper}):
                self.assertIs(task.calculate_metrics(), original)
                self.assertIs(task.calculate_metrics(), original)
            self.assertEqual(helper.capture_startup_evidence.call_count, 1)
            self.assertEqual(task._fabrica_independent_raw_sampler.call_count, 1)
            failure = json.loads((out / 'terminal_media_failure.json').read_text())
            self.assertIn('native handle expired', failure['message'])
            self.assertEqual(json.loads((out / 'terminal_original_metrics.json').read_text()), original)

    def test_invalid_or_other_tick_raw_cannot_create_passed_media_receipt(self):
        for raw in (None, {'valid': False, 'physics_stamp': dict(STAMP)},
                    {'valid': True, 'physics_stamp': {**STAMP, 'index': 72}}):
            with self.subTest(raw=raw), tempfile.TemporaryDirectory() as directory:
                out = Path(directory)
                worker = load_worker(out)
                task, original = task_and_result()
                helper = helper_module(Mock(return_value=report()))
                task._fabrica_independent_raw_sampler = Mock(return_value=raw)
                worker.install_terminal_capture(task)
                with patch.dict(sys.modules, {'stool_startup_evidence': helper}):
                    self.assertIs(task.calculate_metrics(), original)
                self.assertTrue((out / 'terminal_media_failure.json').exists())
                self.assertFalse((out / 'terminal_media_capture.json').exists())

    def test_preexisting_original_is_not_overwritten_and_capture_is_skipped(self):
        with tempfile.TemporaryDirectory() as directory:
            out = Path(directory)
            original_bytes = b'{"prior_original":true}\n'
            (out / 'terminal_original_metrics.json').write_bytes(original_bytes)
            worker = load_worker(out)
            task, original = task_and_result()
            helper = helper_module(Mock(return_value=report()))
            worker.install_terminal_capture(task)
            with patch.dict(sys.modules, {'stool_startup_evidence': helper}):
                self.assertIs(task.calculate_metrics(), original)
            self.assertEqual((out / 'terminal_original_metrics.json').read_bytes(), original_bytes)
            self.assertEqual(helper.capture_startup_evidence.call_count, 0)
            self.assertEqual(json.loads((out / 'terminal_media_failure.json').read_text())['exception_type'], 'FileExistsError')


class GlobalStepCapRetentionTests(unittest.TestCase):
    def setup_case(self, directory):
        out = Path(directory)
        worker = load_worker(out)
        task, result = task_and_result()
        task.success, task.failed = False, False
        task.policy_evaluation_mode = False
        task.step_counter, task.max_steps = 99, 100
        task.phase, task.phase_index = 'unfinished_stage', 7
        task.phase_history = ['initial', task.phase]
        result.update(success=False, failed=False, terminal_reason=None,
                      phase_history=list(task.phase_history))
        blocked = lambda: Mock(side_effect=AssertionError('evidence wrapper must not execute this action'))
        worker.ENV = NS(step=blocked())
        task.is_done, task._set_terminal_state = blocked(), blocked()
        task.robots = {'left': NS(apply_action=blocked(), _action_batch_sequence=41)}
        task.native_state = {'q': [1.] * 12, 'qd': [0.] * 12, 'target': [2.] * 12}
        task._fabrica_independent_raw_sampler = Mock(return_value={'valid': True, 'physics_stamp': dict(STAMP)})
        helper = helper_module(Mock(return_value=report()))
        worker.install_terminal_capture(task)
        return out, worker, task, result, helper

    @staticmethod
    def original_is_done():
        # Execute the actual production termination method, isolating only its
        # clock hook. Importing the full task would initialize Isaac modules.
        source = REPO/'internutopia_extension/tasks/factory_dual_franka_assembly_task.py'
        tree = ast.parse(source.read_text())
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef)
                   and any(isinstance(m, ast.FunctionDef) and m.name == 'is_done' for m in n.body))
        fn = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == 'is_done')
        namespace = {}
        exec(compile(ast.Module(body=[fn], type_ignores=[]), str(source), 'exec'), namespace)
        return namespace['is_done']

    def assert_no_execution(self, worker, task):
        worker.ENV.step.assert_not_called()
        task.is_done.assert_not_called()
        task._set_terminal_state.assert_not_called()
        task.robots['left'].apply_action.assert_not_called()
        self.assertEqual(task.robots['left']._action_batch_sequence, 41)

    def test_real_nonpolicy_done_at_cap_captures_exactly_once_without_changing_original(self):
        for step, new_tick in ((99, True), (100, False), (101, False)):
            with self.subTest(step=step, new_tick=new_tick), tempfile.TemporaryDirectory() as directory:
                out, worker, task, original, helper = self.setup_case(directory)
                task.step_counter = step
                task._beam_task_clock_event = Mock(return_value=new_tick)
                self.assertTrue(self.original_is_done()(task))
                before = copy.deepcopy((task.success, task.failed, task.step_counter, task.phase,
                                        task.phase_index, task.phase_history, task.native_state, original))
                with patch.dict(sys.modules, {'stool_startup_evidence': helper}):
                    self.assertIs(task.calculate_metrics(), original)
                    retained = (out/'terminal_original_metrics.json').read_bytes()
                    self.assertIs(task.calculate_metrics(), original)
                self.assertEqual((out/'terminal_original_metrics.json').read_bytes(), retained)
                self.assertEqual(before, (task.success, task.failed, task.step_counter, task.phase,
                                         task.phase_index, task.phase_history, task.native_state, original))
                helper.capture_startup_evidence.assert_called_once()
                task._fabrica_independent_raw_sampler.assert_called_once_with('terminal')
                task._beam_task_clock_event.assert_called_once_with('done')
                saved = json.loads((out/'terminal_media_capture.json').read_text())
                self.assertEqual(saved['capture_trigger'], 'nonpolicy_global_max_steps')
                self.assertEqual(saved['step_counter'], task.step_counter)
                self.assertEqual(saved['max_steps'], 100)
                self.assertEqual(json.loads(retained), original)
                self.assert_no_execution(worker, task)

    def test_below_cap_policy_mode_or_incomplete_threshold_does_not_capture_early(self):
        cases = ({}, {'step_counter': 100, 'policy_evaluation_mode': True},
                 {'step_counter': 100, 'policy_evaluation_mode': None},
                 {'step_counter': 100, 'policy_evaluation_mode': 'false'},
                 {'step_counter': 100., 'max_steps': 100},
                 {'step_counter': 100, 'max_steps': 100.},
                 {'step_counter': 100, 'max_steps': None})
        for updates in cases:
            with self.subTest(updates=updates), tempfile.TemporaryDirectory() as directory:
                out, worker, task, original, helper = self.setup_case(directory)
                task.__dict__.update(updates)
                with patch.dict(sys.modules, {'stool_startup_evidence': helper}):
                    self.assertIs(task.calculate_metrics(), original)
                helper.capture_startup_evidence.assert_not_called()
                task._fabrica_independent_raw_sampler.assert_not_called()
                self.assertFalse(list(out.iterdir()))
                self.assert_no_execution(worker, task)

    def test_absent_mode_or_threshold_has_no_assumed_default(self):
        for missing in ('policy_evaluation_mode', 'step_counter', 'max_steps'):
            with self.subTest(missing=missing), tempfile.TemporaryDirectory() as directory:
                out, worker, task, original, helper = self.setup_case(directory)
                task.step_counter = 100
                delattr(task, missing)
                with patch.dict(sys.modules, {'stool_startup_evidence': helper}):
                    self.assertIs(task.calculate_metrics(), original)
                helper.capture_startup_evidence.assert_not_called()
                self.assertFalse(list(out.iterdir()))
                self.assert_no_execution(worker, task)

    def test_cap_capture_failure_is_retained_once_and_keeps_original_failure_flags_false(self):
        with tempfile.TemporaryDirectory() as directory:
            out, worker, task, original, helper = self.setup_case(directory)
            task.step_counter = 100
            helper.capture_startup_evidence.side_effect = RuntimeError('render unavailable at global cap')
            with patch.dict(sys.modules, {'stool_startup_evidence': helper}):
                self.assertIs(task.calculate_metrics(), original)
                retained = (out/'terminal_media_failure.json').read_bytes()
                self.assertIs(task.calculate_metrics(), original)
            self.assertEqual((out/'terminal_media_failure.json').read_bytes(), retained)
            helper.capture_startup_evidence.assert_called_once()
            task._fabrica_independent_raw_sampler.assert_not_called()
            self.assertEqual(json.loads(retained)['capture_trigger'], 'nonpolicy_global_max_steps')
            self.assertFalse(task.success or task.failed)
            self.assertFalse((out/'terminal_media_capture.json').exists())
            self.assert_no_execution(worker, task)

    def test_existing_success_and_failure_paths_keep_original_receipt_shape(self):
        for success, failed in ((True, False), (False, True)):
            with self.subTest(success=success), tempfile.TemporaryDirectory() as directory:
                out, worker, task, original, helper = self.setup_case(directory)
                task.success, task.failed = success, failed
                with patch.dict(sys.modules, {'stool_startup_evidence': helper}):
                    self.assertIs(task.calculate_metrics(), original)
                    self.assertIs(task.calculate_metrics(), original)
                helper.capture_startup_evidence.assert_called_once()
                self.assertNotIn('capture_trigger', json.loads((out/'terminal_media_capture.json').read_text()))
                self.assert_no_execution(worker, task)


class PreCloseStatusRetentionTests(unittest.TestCase):
    @staticmethod
    def original_vec_close():
        source = REPO/'internutopia/core/vec_env.py'
        tree = ast.parse(source.read_text())
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef)
                   and any(isinstance(m, ast.FunctionDef) and m.name == 'close' for m in n.body))
        fn = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == 'close')
        namespace = {}
        exec(compile(ast.Module(body=[fn], type_ignores=[]), str(source), 'exec'), namespace)
        return namespace['close']

    def test_actual_vec_close_receives_durable_status_before_nonreturning_sdk_shutdown(self):
        with tempfile.TemporaryDirectory() as directory:
            out = Path(directory)
            worker = load_worker(out)
            (out/'collect_results.json').write_text('[{"success":false}]')
            def shutdown():
                saved = json.loads((out/'worker_result_status.json').read_text())
                self.assertEqual(saved['status_capture_boundary'], 'pre_env_close')
                self.assertEqual(saved['episode_count'], 1)
                self.assertNotIn('process_finished_at_utc', saved['timing'])
                self.assertIn('engine shutdown excluded', saved['timing']['instrumented_wall_scope'])
                raise SystemExit(37)  # Simulates a close that never returns normally.
            sdk_close = Mock(side_effect=shutdown)
            env = NS(is_remote=False,
                _runner_list=[NS(runner=NS(simulation_app=NS(close=sdk_close)))],
                step=Mock(side_effect=AssertionError('shutdown must not step')))
            env.close = MethodType(self.original_vec_close(), env)
            worker.install_pre_close_status(env)
            with self.assertRaises(SystemExit) as caught:
                env.close()
            self.assertEqual(caught.exception.code, 37)
            sdk_close.assert_called_once_with()
            env.step.assert_not_called()
            before = (out/'worker_result_status.json').read_bytes()
            self.assertFalse(worker.retain_worker_result_status('worker_finally_fallback'))
            self.assertEqual((out/'worker_result_status.json').read_bytes(), before)

    def test_hook_is_idempotent_and_preserves_close_arguments_return_and_saved_original(self):
        with tempfile.TemporaryDirectory() as directory:
            out = Path(directory)
            worker = load_worker(out)
            result = object()
            original_close = Mock(return_value=result)
            env = NS(close=original_close)
            worker.install_pre_close_status(env)
            worker.install_pre_close_status(env)
            self.assertIs(env.close('argument', flag=True), result)
            original_close.assert_called_once_with('argument', flag=True)
            before = (out/'worker_result_status.json').read_bytes()
            worker.TIMING['policy_calls'] = 500
            self.assertFalse(worker.retain_worker_result_status('worker_finally_fallback'))
            self.assertEqual((out/'worker_result_status.json').read_bytes(), before)

    def test_status_io_failure_does_not_replace_original_close_exception(self):
        for operation in ('exists', 'open'):
            with self.subTest(operation=operation), tempfile.TemporaryDirectory() as directory:
                worker = load_worker(Path(directory))
                failure = RuntimeError('original shutdown error')
                original_close = Mock(side_effect=failure)
                env = NS(close=original_close)
                worker.install_pre_close_status(env)
                with patch.object(Path, operation, side_effect=OSError('status storage unavailable')), \
                        patch('builtins.print', side_effect=BrokenPipeError('closed logging stream')), \
                        self.assertRaises(RuntimeError) as caught:
                    env.close()
                self.assertIs(caught.exception, failure)
                original_close.assert_called_once_with()

    def test_finally_fallback_keeps_legacy_fields_with_explicit_timestamp_scope(self):
        with tempfile.TemporaryDirectory() as directory:
            out = Path(directory)
            worker = load_worker(out)
            self.assertTrue(worker.retain_worker_result_status('worker_finally_fallback'))
            saved = json.loads((out/'worker_result_status.json').read_text())
            self.assertFalse(saved['original_results_present'])
            self.assertIsNone(saved['episode_count'])
            self.assertEqual(saved['timing']['status_recorded_at_utc'], saved['timing']['process_finished_at_utc'])
            self.assertIn('not verified process completion', saved['timing']['process_finished_at_utc_semantics'])


class StartupDryNativeInvarianceTests(unittest.TestCase):
    def setup_case(self, directory):
        worker = load_worker(Path(directory))
        task = NS(robots={'left': NS(_action_batch_sequence=0), 'right': NS(_action_batch_sequence=0)},
            _assisted_arm_joint_limits=lambda name: np.tile([[-6.28, 6.28]], (6, 1)),
            native_state={'physics_stamp': dict(STAMP),
                'robots': {'left': {'positions': [[0.] * 12], 'velocities': [[0.] * 12], 'targets': [[0.] * 12]}},
                'body_paths': ['/body'], 'transforms_xyzw': {'/body': [0., 0., 0., 0., 0., 0., 1.]},
                'velocities': {'/body': [0.] * 6},
                'counters': {'step_counter': 0, 'phase_index': 0, 'phase_entry_step': 0, 'success': False, 'failed': False},
                'phase_transition_history': []})
        helper = ModuleType('stool_startup_evidence')
        class Reader:
            instances = []
            def __init__(self, selected):
                self.selected, self.calls = selected, 0
                self.instances.append(self)
            def snapshot(self):
                self.calls += 1
                return json.loads(json.dumps(self.selected.native_state))
        helper.NativeStartupReader = Reader
        return worker, task, helper, Reader

    def test_complete_snapshot_is_retained_and_python_compute_cache_is_explicitly_allowed(self):
        with tempfile.TemporaryDirectory() as directory:
            worker, task, helper, reader_type = self.setup_case(directory)
            def compute(policy, selected):
                selected.compute_cache = {'candidate': True}
                return {'left': {'arm_joint_controller': [[0.] * 6]}}
            worker.original_act = compute
            with patch.dict(sys.modules, {'stool_startup_evidence': helper}):
                result = worker.startup_dry_action(object(), task)
            self.assertEqual(result['native_before'], result['native_after'])
            self.assertIn('velocities', result['native_before']['robots']['left'])
            self.assertIn('targets', result['native_before']['robots']['left'])
            self.assertIn('computation caches', result['allowed_side_effects'])
            self.assertFalse(result['action_submitted'])
            self.assertEqual(len(reader_type.instances), 1)
            self.assertEqual(reader_type.instances[0].calls, 2)

    def test_velocity_target_history_or_terminal_flag_mutation_is_rejected(self):
        changes = (
            lambda t: t.native_state['robots']['left']['velocities'][0].__setitem__(0, .1),
            lambda t: t.native_state['robots']['left']['targets'][0].__setitem__(0, .1),
            lambda t: t.native_state['phase_transition_history'].append({'transition': 'unexpected'}),
            lambda t: t.native_state['counters'].__setitem__('success', True),
        )
        for change in changes:
            with tempfile.TemporaryDirectory() as directory:
                worker, task, helper, _ = self.setup_case(directory)
                def compute(policy, selected):
                    change(selected)
                    return {}
                worker.original_act = compute
                with patch.dict(sys.modules, {'stool_startup_evidence': helper}), \
                        self.assertRaisesRegex(RuntimeError, 'full native q/qd/targets/body/task state'):
                    worker.startup_dry_action(object(), task)

    def test_sdk_submission_is_rejected_even_when_native_buffers_are_unchanged(self):
        with tempfile.TemporaryDirectory() as directory:
            worker, task, helper, _ = self.setup_case(directory)
            def compute(policy, selected):
                selected.robots['left']._action_batch_sequence += 1
                return {}
            worker.original_act = compute
            with patch.dict(sys.modules, {'stool_startup_evidence': helper}), \
                    self.assertRaisesRegex(RuntimeError, 'submitted an SDK batch'):
                worker.startup_dry_action(object(), task)


class ControlFailureRetentionTests(unittest.TestCase):
    def test_early_guard_rejection_retains_actual_failure_clock_before_terminal(self):
        # S04 failed off the stride cadence at native5063; terminal5064 was
        # not a replacement for the rejected command's state.
        stamp = dict(STAMP, index=5063, time=5063/240.)
        for raw_mode in ('same_clock', 'next_clock', 'reader_failure'):
            with self.subTest(raw_mode=raw_mode), tempfile.TemporaryDirectory() as directory:
                out = Path(directory)
                worker = load_worker(out)
                worker.save = lambda name, value: (out/name).write_text(json.dumps(value))
                task = NS(_stool_worker_ready=True, phase_index=16,
                    phase='assemble_00_part_3_lift', step_counter=5060,
                    robots={'left': NS(_action_batch_sequence=5060)},
                    _beam_physics_stamp=lambda: dict(stamp))
                raw = dict(valid=True, physics_stamp=dict(stamp), sequence=19)
                if raw_mode == 'next_clock':
                    raw['physics_stamp']['index'] += 1
                task._fabrica_independent_raw_sampler = Mock(return_value=raw,
                    side_effect=RuntimeError('expired native reader') if raw_mode == 'reader_failure' else None)
                def terminal(*args, **kwargs):
                    self.assertEqual(task._fabrica_independent_raw_sampler.call_count, 1)
                    self.assertEqual(json.loads((out/'production_control_failure.json').read_text())['physics_stamp'], stamp)
                task._set_terminal_state = terminal
                worker.original_act = Mock(side_effect=RuntimeError('actual native mesh overlap'))
                self.assertEqual(worker.act(object(), task), {})
                task._fabrica_independent_raw_sampler.assert_called_once_with('control_failure')
                saved = json.loads((out/'production_control_failure.json').read_text())
                self.assertEqual(saved['failure_clock_raw_complete'], raw_mode == 'same_clock')
                self.assertTrue(saved['no_new_sdk_batch'])
                self.assertEqual(worker.TIMING['policy_calls'], 1)


if __name__ == '__main__':
    unittest.main()

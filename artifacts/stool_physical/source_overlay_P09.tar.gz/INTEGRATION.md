# Rebuilt assembly integration — 2026-11-12

Upstream main was checked live and pinned to `9ce8cd93cf28bb9e33ac1218db2304239ebb7da6`.
The HF dataset revision remains `deb4e524199ca529466eea0f0e2d0c23f63f4e8e`.
The lost integrated branch is not represented as restored. This is a new branch with
real shallow upstream Git ancestry and a sparse published-source checkout.
Unrelated historical outputs/assets remain promised Git objects, not an offline archive.
Required simulation assets are bound to the surviving authoritative trees and checked separately.

`compat/` contains isolated current source/tool snapshots for Beam assisted v35,
Stool S24, Cooling C29 (with C27 preserved in its authority), and Beam physical v215.
`integration/legacy_routes.json` binds hashes and authority paths. The original
working trees and ledgers are unchanged; this task does not authorize their simulation.
Run `python integration/assembly.py ROUTE` to check a legacy snapshot.

Plumbers uses the unchanged published reference recipe/profile, seed/layout 4906,
original three checkpoints, 10fps / stride24 streaming video, and original acceptance.
The first new experiment changes the numerical package stack to the repository pins
and adds a read-only phase-boundary observer. It does not enable temporary left support,
modify object poses, loosen corridor limits, or replace contact with fixed joints.
SDK 5.1 and its compiled PyTorch remain the installed simulator distribution; the private
package pins are a numerical-environment comparison, not proof of an identical author VM.
T1 is preserved on the server, but this first new comparison uses the original visual scene
because both earlier backgrounds failed at 46420 and T1 carries additional static colliders.

From this independent project root:

```bash
source integration/runtime_env.sh
/Embodied_AI/miniconda3/envs/internutopia311/bin/python -B integration/preflight.py
# Full from-initial-scene run, only after frozen source and required preflights:
/Embodied_AI/miniconda3/envs/internutopia311/bin/python -B integration/launch_reproduction.py
```

`outputs/plumbers_reproduction/current_run.json` is the sole live run record.
A normal worker exit, CPU test, nominal closure preflight or intermediate phase does not
establish complete assembly. The final verdict must include both pins, releases,
both-arm home, and 30 native ticks of unloaded settling under published tolerances.

Only small code/configuration/hash/summary/handoff artifacts are retained on the Mac.
Video, full traces, dependency wheels and large simulation outputs stay on the server.
The integration Git metadata/code backup is exported before the first full run.

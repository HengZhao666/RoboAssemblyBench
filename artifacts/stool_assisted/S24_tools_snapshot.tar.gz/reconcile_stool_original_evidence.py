"""Read-only original-summary retention check and unresolved coverage index.

This does not call the official auditor, resolve physical gaps, waive an
original warning, execute CAD, or authorize a run. Use a completed full run.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path


def sha(path):
    result=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):result.update(block)
    return result.hexdigest()


def canonical(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def require(condition,reason):
    if not condition:raise ValueError(reason)


def under(path,root):
    return isinstance(path,str) and (path==root or path.startswith(root+'/'))


def reconcile(run,scene_geometry=None,exact_pair_witness=None):
    run=Path(run).resolve();inputs={};checks={};state={}
    report=dict(schema='stool_original_evidence_reconciliation/v1',run_directory=str(run),
        official_audit_executed=False,original_reports_modified=False,
        coverage_resolved=None,assembly_success_claimed=False,checks=checks,input_sha256=inputs,
        scope='retention arithmetic and explicit evidence index only; original physical/missing/skip conclusions retained')
    def load(path):
        path=Path(path);inputs[str(path)]=sha(path);return json.loads(path.read_text())
    def check(name,fn):
        try:checks[name]=dict(passed=True,detail=fn())
        except FileNotFoundError as exc:checks[name]=dict(passed=None,missing=str(exc))
        except Exception as exc:checks[name]=dict(passed=False,error=type(exc).__name__+': '+str(exc))
    def originals():
        closed=load(run/'formal_closure.json');require(closed.get('closed') is True,'run is not explicitly closed')
        metrics=load(run/'collect_results.json')
        require(isinstance(metrics,list) and len(metrics)==1,'original primary metrics must have exactly one episode')
        metrics=metrics[0];state['metrics']=metrics
        require(all(isinstance(metrics.get(k),dict) for k in ('runtime_constraint_monitor',
            'assembly_sequence_precheck','stage_trajectory_precheck')),'required original report section is absent')
        if (run/'independent_audit.json').exists():inputs[str(run/'independent_audit.json')]=sha(run/'independent_audit.json')
        return dict(original_success=metrics.get('success'),original_failed=metrics.get('failed'),
            steps=metrics.get('steps'),terminal_reason=metrics.get('terminal_reason'),
            original_phase_history=metrics.get('phase_history'),original_audit_preserved=True)
    check('completed_original_report_identity',originals)
    def retention():
        metrics=state['metrics'];monitor=metrics['runtime_constraint_monitor'];summary=monitor['entity_geometry']
        path=run/'entity_geometry_trace.jsonl';file_hash=hashlib.sha256();events=[];steps=[];minimum=None;minima={};witness=[]
        with path.open('rb') as stream:
            for number,line in enumerate(stream,1):
                file_hash.update(line)
                if not line.strip():continue
                row=json.loads(line);step=row.get('step');require(type(step) is int,'uncapped event row lacks integer step')
                require(isinstance(row.get('events'),list),'uncapped event list is missing')
                require(row.get('pose_source')=='live_exact_robot_wrappers; existing_object_rigid_wrappers; static_xform; no_hold_validation_getter',
                    'uncapped geometry pose source differs from original production reader')
                steps.append(step)
                for event in row['events']:
                    require(isinstance(event,dict) and event.get('step')==step
                            and isinstance(event.get('distance'),(int,float)) and math.isfinite(event['distance'])
                            and event.get('collider_a') and event.get('collider_b'),'malformed uncapped event')
                    key=event['collider_a']+' | '+event['collider_b']
                    if key not in minima or event['distance']<minima[key]['distance']:minima[key]=event
                    if step==1112 and {event.get('entity_a'),event.get('entity_b')}=={
                        'franka_right/Gripper/Robotiq_2F_85/right_inner_knuckle','fabrica_stool_circular_5'}:
                        witness.append(dict(original_line=number,original_line_sha256=hashlib.sha256(line).hexdigest(),
                            event=event,body_poses_sha256=canonical(row.get('body_poses')),
                            own_native_stamp_recorded='physics_stamp' in row,
                            native_join_and_exact_CAD_classification=None))
                events.extend(row['events'])
                closest=row.get('closest_nonexempt_pair')
                if closest and (minimum is None or closest['distance']<minimum['distance']):minimum=closest
        inputs[str(path)]=file_hash.hexdigest()
        require(len(steps)==summary.get('sampled_checks')==monitor.get('checks'),'uncapped row/check counts differ')
        stride=monitor.get('check_stride');observed=monitor.get('observed_steps')
        require(type(stride) is int and stride>0 and type(observed) is int,'original sampling cadence is missing')
        require(steps==list(range(stride,observed+1,stride)),'uncapped steps are missing, duplicated, or out of production order')
        kept=summary.get('events');dropped=summary.get('events_dropped_from_summary')
        require(isinstance(kept,list) and type(dropped) is int and dropped>=0,'original retention counters missing')
        require(len(events)==len(kept)+dropped,'uncapped event count differs from retained plus summary-dropped count')
        require(events[dropped:]==kept,'retained original summary is not the exact uncapped suffix')
        original_minima=summary.get('pair_minima')
        require(isinstance(original_minima,list) and len(original_minima)==len(minima)
                and {e['collider_a']+' | '+e['collider_b']:e for e in original_minima}==minima,
                'uncapped recomputed pair minima differ from original summary')
        require(minimum==summary.get('minimum_nonexempt_pair'),'uncapped minimum differs from original summary')
        report['step1112_pair_event_index']=dict(events=witness,expected_pair_present=bool(witness),
            physical_classification_resolved=None,exact_CAD_tool='check_stool_exact_pair_witness.py',
            scope='original approximate-enclosure candidate only; same-clock raw/triangle witness is a separate artifact')
        return dict(stream_sha256=inputs[str(path)],stream_rows=len(steps),first_step=steps[0] if steps else None,
            last_step=steps[-1] if steps else None,original_retained_events=len(kept),
            original_events_dropped_from_summary=dropped,complete_stream_events=len(events),
            original_summary_suffix_exact=True,pair_minima_exact=True,
            summary_is_capped_but_events_retained_in_original_stream=True,
            event_classifications_physically_resolved=False)
    check('uncapped_original_events_reconcile_with_capped_summary',retention)
    def coverage():
        metrics=state['metrics'];stage=metrics['stage_trajectory_precheck'];runtime=metrics['runtime_constraint_monitor']
        scene=load(scene_geometry or run/'scene_geometry.json')
        require(isinstance(scene.get('visible_meshes'),list) and isinstance(scene.get('colliders'),list)
                and isinstance(scene.get('roots'),list),'original complete scene export schema is missing')
        def meshes(root,body_only=False):
            return [dict(prim=m.get('prim'),body=m.get('body'),rendered=m.get('rendered'),
                enabled_collider=m.get('enabled_collider'),geometry_domain=m.get('geometry_domain'))
                for m in scene['visible_meshes'] if (m.get('body')==root if body_only else under(m.get('prim'),root))]
        grippers=[]
        for robot,item in stage.get('frame_coverage',{}).items():
            root=runtime.get('registered_robots',{}).get(robot)
            for link in item.get('missing_model_frames',[]):
                require(isinstance(root,str) and root.startswith('/'),'original registered robot root missing')
                body=root+'/'+link
                grippers.append(dict(robot=robot,original_missing_model_frame=link,body_path=body,
                    original_gripper_articulation_swept=item.get('gripper_articulation_swept'),
                    scene_visible_mesh_members=meshes(body,True),
                    complete_command_gripper_sweep_verified=None,coverage_resolved=None))
        objects={};unindexed=[]
        for section,entity in (('runtime_constraint_monitor',runtime.get('entity_geometry',{})),
                               ('stage_trajectory_precheck',stage.get('entity_geometry_coverage',{}))):
            for gap in entity.get('missing',[]):
                root=gap.get('root')
                if not isinstance(root,str) or not root.startswith('/'):
                    unindexed.append(dict(report_section=section,original_value=gap,coverage_resolved=None));continue
                item=objects.setdefault(root,dict(root=root,original_gaps=[],coverage_resolved=None,
                    original_USD_collider_absence_verified=None))
                item['original_gaps'].append(dict(report_section=section,original_value=gap))
        skipped=scene.get('collision_inventory_gaps',{}).get('skipped',[])
        for root,item in objects.items():
            item.update(root_explicitly_enumerated_in_scene=any(r and r[0]==root for r in scene['roots']),
                scene_visible_mesh_members=meshes(root),
                scene_enabled_supported_colliders=[dict(prim=c.get('prim'),body=c.get('body'),approximation=c.get('approximation'))
                    for c in scene['colliders'] if under(c.get('prim'),root)],
                original_export_skipped_colliders=[s for s in skipped if under(s.get('prim'),root)])
        for name in ('stool_geometry_initial.json','stool_production_geometry.jsonl'):
            if (run/name).exists():inputs[str(run/name)]=sha(run/name)
        report['original_coverage_evidence_index']=dict(gripper_frames=grippers,object_roots=list(objects.values()),
            unindexed_original_gaps=unindexed,
            gripper_frame_count=len(grippers),object_root_count=len(objects),
            original_all_skips=dict(runtime=runtime.get('entity_geometry',{}).get('skipped'),
                stage=stage.get('entity_geometry_coverage',{}).get('skipped')),
            no_gap_automatically_waived=True,
            required_followup='validate each source gap against exact source-bound full-scene coverage and actual final gripper/arm command sweeps; mesh presence alone is not sweep proof')
        return dict(indexed_missing_gripper_frames=len(grippers),indexed_object_roots=len(objects),
            original_geometry_gap_list=scene.get('gaps'),original_collider_gap_inventory=scene.get('collision_inventory_gaps'),
            physical_missing_coverage_resolved=None)
    check('original_coverage_index_readable',coverage)
    if exact_pair_witness is not None:
        def witness_reference():
            value=load(exact_pair_witness)
            return dict(path=str(Path(exact_pair_witness).resolve()),sha256=inputs[str(Path(exact_pair_witness))],
                original_receipt=value,physical_gap_automatically_resolved=False)
        check('separate_exact_pair_witness_receipt_retained',witness_reference)
    report['unresolved_checks']=[name for name,value in checks.items() if value['passed'] is not True]
    report['status']='missing_or_inconsistent' if report['unresolved_checks'] else 'retention_checked_coverage_still_unresolved'
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run',type=Path);parser.add_argument('--scene-geometry',type=Path)
    parser.add_argument('--exact-pair-witness',type=Path);parser.add_argument('--output',type=Path)
    args=parser.parse_args();result=reconcile(args.run,args.scene_geometry,args.exact_pair_witness)
    text=json.dumps(result,indent=2)+'\n'
    if args.output:
        if args.output.resolve().is_relative_to(args.run.resolve()):parser.error('write diagnostic output outside the immutable run directory')
        with args.output.open('x') as stream:stream.write(text)
    else:print(text,end='')
    return 2 if result['unresolved_checks'] else 0


if __name__=='__main__':raise SystemExit(main())

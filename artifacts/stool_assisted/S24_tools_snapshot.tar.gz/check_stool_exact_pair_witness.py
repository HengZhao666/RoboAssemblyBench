"""Bind the original step1112 convex candidate to raw native poses and real CAD.

Retains the original report; checks only the named candidate at its measured
clock. Authored triangle/convex evidence does not recreate PhysX cooked SDFs or
prove native pair forces. No simulator is imported or started.
"""
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
import numpy as np
import fcl
from compare_stool_geometry_cache import native_matrix
from toolkits.constraint_checking.integration.entity_geometry import Collider,EntityGeometryChecker


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',type=Path,required=True)
    parser.add_argument('--output-dir',type=Path,required=True);args=parser.parse_args()
    run=args.run.resolve();out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=False)
    report=dict(passed=False,native_physics_executed=0,original_reports_modified=False,errors=[])
    paths={name:run/name for name in ('scene_geometry.json','entity_geometry_trace.jsonl','independent_native_trace.jsonl')}
    report['input_sha256']={name:sha(path) for name,path in paths.items()}
    try:
        data=json.loads(paths['scene_geometry.json'].read_text());matches=[]
        for number,line in enumerate(paths['entity_geometry_trace.jsonl'].open('rb'),1):
            value=json.loads(line)
            if value.get('step')!=1112:continue
            for event in value['events']:
                names={event['entity_a'],event['entity_b']}
                if names=={'franka_right/Gripper/Robotiq_2F_85/right_inner_knuckle','fabrica_stool_circular_5'}:
                    matches.append((value,event,number,hashlib.sha256(line).hexdigest()))
        if len(matches)!=1:raise ValueError('expected exactly one original uncapped step1112 candidate')
        trace,event,trace_line,trace_sha=matches[0]
        prims=[event['collider_a'],event['collider_b']]
        meshes=[next(mesh for mesh in data['visible_meshes'] if mesh['prim']==prim) for prim in prims]
        dynamic={mesh['body'] for mesh in data['visible_meshes'] if mesh['robot'] or mesh['object'] in data['task_objects']}
        dynamic_trace=set(trace['body_poses'])&dynamic;raw_matches=[];candidate_clocks=[]
        for number,line in enumerate(paths['independent_native_trace.jsonl'].open('rb'),1):
            raw=json.loads(line)
            if raw.get('valid') is not True or raw.get('task_step')!=1112:continue
            missing=sorted(dynamic_trace-set(raw['bodies']))
            errors={path:float(np.max(abs(native_matrix(raw['bodies'][path]['transform'])-np.asarray(trace['body_poses'][path],float))))
                for path in dynamic_trace if path in raw['bodies']}
            maximum=max(errors.values(),default=float('inf'))
            joined=not missing and len(errors)==len(dynamic_trace) and maximum<=1e-12
            candidate_clocks.append(dict(physics_stamp=raw['physics_stamp'],boundary=raw['boundary'],
                missing_dynamic_paths=missing,compared_dynamic_paths=len(errors),matrix_max_abs_error=maximum,matched=joined))
            if joined:raw_matches.append((raw,number,hashlib.sha256(line).hexdigest(),errors))
        clock_keys={(raw['physics_stamp']['epoch'],raw['physics_stamp']['index']) for raw,_,_,_ in raw_matches}
        if len(clock_keys)!=1:raise ValueError('legacy candidate does not have a unique full-dynamic-state raw clock join')
        raw,raw_line,raw_sha,errors=raw_matches[-1]
        poses={path:np.asarray(matrix,float) for path,matrix in data['body_rest'].items()}
        poses.update({path:native_matrix(value['transform']) for path,value in raw['bodies'].items()})
        shapes=[]
        for mesh in meshes:
            points=np.asarray(mesh['points'],float);faces=np.asarray(mesh['triangles'],np.int32)
            shape=fcl.BVHModel();shape.beginModel(len(faces),len(points));shape.addSubModel(points,faces);shape.endModel()
            matrix=poses[mesh['body']];shapes.append(fcl.CollisionObject(shape,fcl.Transform(matrix[:3,:3],matrix[:3,3])))
        result=fcl.CollisionResult();hit=fcl.collide(*shapes,fcl.CollisionRequest(num_max_contacts=8,enable_contact=True),result)
        depth=max((float(contact.penetration_depth) for contact in result.contacts),default=0.)
        distance=None if hit else float(fcl.distance(*shapes,fcl.DistanceRequest(),fcl.DistanceResult()))
        colliders=[Collider(**next(value for value in data['colliders'] if value['prim']==prim)) for prim in prims]
        convex=EntityGeometryChecker(colliders)
        for value,(shape,_) in zip(colliders,convex.shapes):
            matrix=poses[value.body];shape.setTransform(fcl.Transform(matrix[:3,:3],matrix[:3,3]))
        convex_result=fcl.CollisionResult();convex_hit=fcl.collide(convex.shapes[0][0],convex.shapes[1][0],
            fcl.CollisionRequest(num_max_contacts=1,enable_contact=True),convex_result)
        convex_distance=(-max((float(c.penetration_depth) for c in convex_result.contacts),default=0.) if convex_hit else
            float(fcl.distance(convex.shapes[0][0],convex.shapes[1][0],fcl.DistanceRequest(),fcl.DistanceResult())))
        report.update(original_candidate=event,trace_binding=dict(path=str(paths['entity_geometry_trace.jsonl']),line=trace_line,line_sha256=trace_sha),
            raw_clock_join=dict(passed=True,physics_stamp=raw['physics_stamp'],candidate_clocks=candidate_clocks,
                dynamic_body_paths=sorted(dynamic_trace),per_body_matrix_max_abs_error=errors,
                raw_source_line=raw_line,raw_line_sha256=raw_sha,matching_boundaries=[value['boundary'] for value,_,_,_ in raw_matches]),
            exact_mesh=dict(prims=prims,bodies=[mesh['body'] for mesh in meshes],hit=int(hit),max_depth_m=depth,separation_distance_m=distance,
                triangle_counts=[len(mesh['triangles']) for mesh in meshes],
                contacts=[dict(depth_m=float(c.penetration_depth),position=np.asarray(c.pos).tolist(),normal=np.asarray(c.normal).tolist()) for c in result.contacts]),
            convex_reproduction=dict(hit=int(convex_hit),distance_m=convex_distance,original_distance_m=event['distance'],
                error_m=abs(convex_distance-event['distance'])),
            scope='same-native-clock original authored triangle geometry and original convex candidate; no PhysX cooked/SDF or pair-force claim')
        report['inputs_unchanged']=all(sha(path)==report['input_sha256'][name] for name,path in paths.items())
        report['passed']=report['inputs_unchanged'] and report['convex_reproduction']['error_m']<1e-10
    except Exception as exc:report['errors'].append(type(exc).__name__+': '+str(exc))
    (out/'exact_pair_witness.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({key:report.get(key) for key in ('passed','inputs_unchanged','errors')}))
    return 0 if report['passed'] else 1

if __name__=='__main__':raise SystemExit(main())

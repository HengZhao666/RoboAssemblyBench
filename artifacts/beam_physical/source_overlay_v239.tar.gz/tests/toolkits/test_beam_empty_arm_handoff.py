"""Release ownership and empty retreat regression against the v201 failure.

These are real policy/skill dispatch checks with a controlled joint/IK fixture;
they do not certify physical tracking or collision clearance.
"""
import importlib.util
from pathlib import Path
from types import SimpleNamespace as NS
import unittest
import tempfile
import json
from unittest.mock import patch

import numpy as np

from toolkits.factory_dual_franka_assembly.plumbers_block_ur5e_skills import (
    UR5eAssemblyAtomicSkillAdapter as Adapter,
)

ROOT = Path(__file__).resolve().parents[2]
module_spec = importlib.util.spec_from_file_location(
    'beam_release_fixture', ROOT / 'tests/toolkits/test_beam_release_joint_branch.py')
fixture = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(fixture)
ARM = 'arm_joint_controller'


class ReleaseOwnership(unittest.TestCase):
    def setUp(self):
        base = fixture.NativeReleaseBranch()
        base.setUp()
        self.task, self.policy = base.task, base.policy
        self.task.tracking['left']['position'] = [.75, 0., 1.05]
        self.policy._other_robot_name = lambda *a: 'right'
        self.policy._robot_has_active_phase_work = lambda **kw: True
        self.policy._side_sign = lambda *a: -1.
        self.policy._robot_base_y_abs = lambda *a: .65
        self.policy._robot_base_position = lambda **kw: np.array([0., -.65, .7])

    def clearance(self):
        return self.policy._idle_clearance_pose(
            task=self.task, robot_name='left', phase_spec=self.task.spec,
            tracked_robots=self.task.tracking, tracked_objects=self.task.objects)

    def test_release_retains_ownership_after_object_detaches(self):
        self.task.objects = self.task._attachments = {}
        self.assertIsNone(self.clearance())
        self.task.spec['detach'] = []
        self.assertIsNotNone(self.clearance())  # The old clearance path really is reachable.

    def test_continuous_policy_calls_never_publish_the_full_turn(self):
        self.task.objects = self.task._attachments = {}
        with patch.dict('os.environ', {'BEAM_IDLE_HOLD_ANCHOR': '0'}, clear=True):
            for _ in range(110):
                measured = self.task.subset.q.copy()
                action = self.policy.act(self.task)['left']
                np.testing.assert_array_equal(action[ARM][0], measured)
                self.assertEqual(action['gripper_controller'], [1.])
                self.task.subset.q += np.array([0., .00002, 0., 0., 0., -.00001])
                self.task.step_counter += 1

    def test_staged_profile_idle_owner_suppresses_generic_clearance(self):
        self.task.spec['detach'] = []
        self.task.objects = self.task._attachments = {}
        self.task.spec.update(beam_physical_acceptance_profile='plumbers_staged_v1',
                              beam_idle_hold_anchor=True)
        with patch.dict('os.environ', {'BEAM_IDLE_HOLD_ANCHOR': '1'}, clear=True):
            self.assertIsNone(self.clearance())
        with patch.dict('os.environ', {'BEAM_IDLE_HOLD_ANCHOR': '0'}, clear=True):
            self.assertIsNotNone(self.clearance())


class EmptyArmHandoff(unittest.TestCase):
    def setUp(self):
        self.task = fixture.Task()
        self.task.phase_index, self.task.phase_entry_step = 47, 26478
        self.task.step_counter, self.task.phase_step_counter = 26480, 2
        self.task.phase = 'hold_3_approach_clearance'
        self.task.robots['left'].config = NS(preserve_continuous_arm_joints=True)
        self.task.subset.q = np.array([1.768818, -1.725269, 2.194154, -1.895796, -2.542994, -2.935969])
        self.adapter = Adapter({})
        self.old = np.array([1.419895, -.676754, 1.590896, -2.745235, -2.609508, -3.441505])
        self.adapter._remember_arm_command(self.task, 'left', self.old)
        self.spec = dict(name='ur5e_retreat_vertical', robot='left',
                         relative_to_current_tcp=True, offset=[0., 0., -.12], offset_frame='tcp',
                         lock_target_position=True, lock_target_orientation=True,
                         empty_arm_phase_handoff=True, gripper_command='open',
                         continuous_physics=True, cartesian_servo=True,
                         cartesian_position_step=.001, cartesian_orientation_step=.004,
                         max_command_joint_step=.006, max_joint_step=.006,
                         use_arm_ik_controller=False, guard_ik_branch_jump=True,
                         ik_branch_jump_limit=.15, require_warm_start_ik=True)
        self.ik_calls = []

        def failed_ik(**kw):
            self.ik_calls.append(kw)
            return None

        self.adapter._solve_ik = failed_ik

    def act(self):
        return self.adapter.act(task=self.task, robot_name='left', phase_spec=self.task.spec,
                                skill_spec=self.spec, tracked_robots=self.task.tracking,
                                tracked_objects=self.task.objects)

    def test_real_ik_failure_dispatch_cannot_republish_v201_old_cache(self):
        measured = self.task.subset.q.copy()
        self.assertGreater(np.max(abs(self.old - measured)), 1.)
        action = self.act()
        self.assertGreater(len(self.ik_calls), 0)
        np.testing.assert_array_equal(action[ARM][0], measured)
        np.testing.assert_array_equal(self.ik_calls[0]['warm_start'], measured)
        self.assertEqual(action['gripper_controller'], [1.])

    def test_empty_motion_trace_preserves_action_and_never_requests_a_grasp_probe(self):
        self.adapter._solve_ik=lambda **kw:self.task.subset.q.copy()+.0002
        self.task._gripper_contact_metrics=lambda *a,**kw:(_ for _ in ()).throw(
            AssertionError('An unloaded trace queried target-object contacts'))
        with patch.dict('os.environ',{},clear=True):baseline=self.act()
        with tempfile.TemporaryDirectory()as d:
            p=Path(d)/'motion.jsonl'
            with patch.dict('os.environ',{'BEAM_MOTION_TRACE_PATH':str(p)},clear=True):
                observed=self.act()
            self.assertEqual(observed,baseline)
            rows=[json.loads(x)for x in p.read_text().splitlines()]
            self.assertEqual(len(rows),1)
            np.testing.assert_allclose(rows[0]['command_q'],observed[ARM][0])
            self.assertEqual(rows[0]['phase'],self.task.phase)

    def test_110_evolving_calls_keep_current_phase_command_and_fixed_endpoint(self):
        self.act()
        key = next(iter(self.adapter._phase_locks))
        endpoint = self.adapter._phase_locks[key]['position'].copy()
        for i in range(110):
            self.task.step_counter += 1
            self.task.phase_step_counter += 1
            self.task.tracking['left']['position'][2] += .00001
            self.task.subset.q[1] += .00001
            self.act()
            np.testing.assert_array_equal(self.adapter._phase_locks[key]['position'], endpoint)
        self.assertGreater(len(self.ik_calls), 110)

    def test_bad_cache_inside_phase_is_rejected_without_slow_return(self):
        self.act()
        self.adapter._remember_arm_command(self.task, 'left', self.old)
        action = self.act()
        np.testing.assert_array_equal(action[ARM][0], self.task.subset.q)

    def test_valid_tracking_bias_is_retained_in_same_phase(self):
        self.act()
        biased = self.task.subset.q + .002
        self.adapter._remember_arm_command(self.task, 'left', biased)
        np.testing.assert_array_equal(self.act()[ARM][0], biased)

    def test_other_arm_and_new_phase_are_independent(self):
        self.adapter._remember_arm_command(self.task, 'right', self.old)
        self.act()
        self.task.phase_index += 1
        self.task.phase_entry_step += 100
        self.task.step_counter += 100
        self.task.subset.q[0] += .02
        np.testing.assert_array_equal(self.act()[ARM][0], self.task.subset.q)
        np.testing.assert_array_equal(self.adapter._last_command_q(task=self.task, robot_name='right'), self.old)

    def test_misconfigured_or_still_loaded_handoff_fails_before_ik(self):
        self.spec['requires_held_object'] = True
        with self.assertRaises(ValueError):
            self.act()
        self.spec['requires_held_object'] = False
        self.task._attachments = {'part': {'robot_name': 'left', 'mode': 'pure_physical_grasp'}}
        with self.assertRaises(RuntimeError):
            self.act()
        self.assertFalse(self.ik_calls)


if __name__ == '__main__':
    unittest.main()

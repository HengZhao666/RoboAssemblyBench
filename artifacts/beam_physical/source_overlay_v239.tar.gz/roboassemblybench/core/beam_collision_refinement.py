"""Offline, conforming midpoint refinement of existing collision triangles.

This changes tessellation only: no smoothing, projection, hole filling, hulls,
physics parameters, or runtime state access. Parent indices support independent
surface/mass checks before a generated asset is admitted.
"""
from numbers import Real
import math
import numpy as np


def refine_collision_triangles(points, faces, max_edge, *, max_faces=500_000):
    if isinstance(max_edge, (bool, np.bool_)) or not isinstance(max_edge, Real):
        raise ValueError('max_edge must be a finite positive real')
    if not math.isfinite(max_edge) or max_edge <= 0:
        raise ValueError('max_edge must be a finite positive real')
    if type(max_faces) is not int or max_faces < 1:
        raise ValueError('max_faces must be a positive integer')
    vertices = np.asarray(points, dtype=float)
    triangles = np.asarray(faces)
    if (vertices.ndim != 2 or vertices.shape[1] != 3 or not len(vertices)
            or not np.all(np.isfinite(vertices))):
        raise ValueError('Expected finite Nx3 vertices')
    if (triangles.ndim != 2 or triangles.shape[1] != 3 or not len(triangles)
            or not np.issubdtype(triangles.dtype, np.integer)
            or triangles.min() < 0 or triangles.max() >= len(vertices)):
        raise ValueError('Expected valid integer Mx3 triangle indices')
    if len(triangles) > max_faces:
        raise ValueError('Input already exceeds max_faces')
    v = vertices[triangles]
    if np.any(np.linalg.norm(np.cross(v[:, 1]-v[:, 0], v[:, 2]-v[:, 0]), axis=1) <= 1e-20):
        raise ValueError('Degenerate input triangles')
    vertices = vertices.copy()
    triangles = triangles.astype(np.int64, copy=True)
    parents = np.arange(len(triangles), dtype=np.int64)
    rounds = 0
    for _ in range(32):
        long_edges = set()
        for a, b in ((0, 1), (1, 2), (2, 0)):
            edges = triangles[:, [a, b]]
            mask = np.linalg.norm(vertices[edges[:, 0]]-vertices[edges[:, 1]], axis=1) > max_edge
            long_edges.update(tuple(sorted(map(int, e))) for e in edges[mask])
        if not long_edges:
            return dict(points=vertices, faces=triangles, parent_faces=parents, rounds=rounds)
        masks = []
        expected = 0
        for a, b, c in triangles:
            marked = [tuple(sorted((int(a), int(b)))) in long_edges,
                      tuple(sorted((int(b), int(c)))) in long_edges,
                      tuple(sorted((int(c), int(a)))) in long_edges]
            masks.append(marked)
            expected += 1 + sum(marked)
        if expected > max_faces:
            raise ValueError('Refinement exceeds max_faces')
        # One shared midpoint per undirected edge; both incident faces split it.
        ordered = sorted(long_edges)
        midpoints = {edge: len(vertices)+i for i, edge in enumerate(ordered)}
        extra = np.array([(vertices[a]+vertices[b])/2 for a, b in ordered])
        vertices = np.vstack([vertices, extra])
        new_faces, new_parents = [], []
        for face, marked, parent in zip(triangles, masks, parents):
            a, b, c = map(int, face)
            count = sum(marked)
            if count == 0:
                pieces = [(a, b, c)]
            elif count == 3:
                ab, bc, ca = (midpoints[tuple(sorted(e))] for e in [(a,b),(b,c),(c,a)])
                pieces = [(a,ab,ca),(ab,b,bc),(ca,bc,c),(ab,bc,ca)]
            else:
                # Rotate without reversing winding. One edge -> AB; two -> AB,BC.
                start = marked.index(True) if count == 1 else next(i for i in range(3) if marked[i] and marked[(i+1)%3])
                a, b, c = (a,b,c)[start:]+(a,b,c)[:start]
                ab = midpoints[tuple(sorted((a,b)))]
                if count == 1:
                    pieces = [(a,ab,c),(ab,b,c)]
                else:
                    bc = midpoints[tuple(sorted((b,c)))]
                    if np.linalg.norm(vertices[a]-vertices[bc]) <= np.linalg.norm(vertices[ab]-vertices[c]):
                        pieces = [(ab,b,bc),(a,ab,bc),(a,bc,c)]
                    else:
                        pieces = [(ab,b,bc),(a,ab,c),(ab,bc,c)]
            new_faces.extend(pieces)
            new_parents.extend([parent]*len(pieces))
        triangles = np.asarray(new_faces, dtype=np.int64)
        parents = np.asarray(new_parents, dtype=np.int64)
        rounds += 1
    raise ValueError('Refinement did not converge within 32 rounds')

"""Media-verifier orchestration tests with mocked codecs; no real media decoded."""
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
import copy,json,tempfile
import check_stool_media as checker


def main():
    cases=[]
    def check(name,predicate):assert predicate,name;cases.append(dict(name=name,passed=True))
    with tempfile.TemporaryDirectory(prefix='stool_media_test_') as temporary:
        root=Path(temporary).resolve()
        def create(name,missing=None):
            run=root/name;folder=run/'episode_0000_live_videos';folder.mkdir(parents=True)
            for key,filename in checker.EXPECTED.items():
                if key!=missing:(folder/filename).write_bytes(b'unit-test-placeholder-not-a-real-MP4:'+key.encode())
            keys=list(checker.EXPECTED);metadata=dict(camera_metadata=[dict(video_key='observation.images.isaac_3d' if key.endswith('.front') else key,resolution=[640,480]) for key in keys],recorded_videos={key:str(folder/filename) for key,filename in checker.EXPECTED.items()})
            (run/'episode_0000.json').write_text(json.dumps(metadata))
            with (run/'video_frame_clock.jsonl').open('w') as stream:
                for key in keys:stream.write(json.dumps(dict(camera=key,frame_index=0,physics_stamp=dict(valid=True),render_reference_time=dict(valid=True)))+'\n')
            return run
        calls=[];fail_camera=None
        def codec(arguments,**kwargs):
            calls.append(arguments);program=Path(arguments[0]).name
            if program=='ffprobe':
                data=dict(packets=[dict(pts_time='0',dts_time='0',duration_time='0.033333')]) if '-show_packets' in arguments else dict(streams=[dict(width=640,height=480,nb_frames='1',duration='0.033333',start_time='0',codec_name='h264',time_base='1/15360',avg_frame_rate='30/1')],format=dict(duration='0.033333'))
                return SimpleNamespace(returncode=0,stdout=json.dumps(data),stderr='')
            if '-h' in arguments:return SimpleNamespace(returncode=0,stdout='-fps_mode  set framerate mode',stderr='')
            path=arguments[arguments.index('-i')+1]
            if fail_camera and fail_camera in path:return SimpleNamespace(returncode=1,stdout='frame=0\nprogress=end\n',stderr='synthetic decode error')
            return SimpleNamespace(returncode=0,stdout='frame=1\nout_time_us=33333\nprogress=end\n',stderr='')
        with patch.object(checker,'ffmpeg_paths',lambda *a,**kw:dict(ffmpeg='/fake/ffmpeg',ffprobe='/fake/ffprobe')),patch.object(checker.subprocess,'run',codec):
            run=create('single_frame_diagnostic');report=checker.verify_media(run)
            check('three_originals_decode_and_sha',report['all_three_original_videos_decoded'] and report['sha256_verified'] and report['status']=='passed')
            check('startup_oneframe_explicit_diagnostic',report['diagnostic_only'] and not report['assembly_outcome_proven'])
            check('exactly_one_full_decode_each',len([c for c in calls if Path(c[0]).name=='ffmpeg' and '-i' in c])==3)
            check('ffprobe_metadata_and_all_timestamps',len([c for c in calls if Path(c[0]).name=='ffprobe'])==6)
            check('raw_clock_counts_match',all(row['clock_count_matches_decoded'] for row in report['files']))
            before=len(calls)
            try:checker.verify_media(run);check('exclusive_report_rejects_rerun',False)
            except FileExistsError:check('exclusive_report_rejects_rerun',len(calls)==before)
            original_receipt=(run/'media_verification.json').read_bytes()
            retry=checker.verify_media(run,output_name='media_verification_retry_01.json')
            check('retry_retains_original_receipt_and_logs',retry['status']=='passed' and (run/'media_verification.json').read_bytes()==original_receipt and (run/'media_verification_retry_01_logs').is_dir())
            check('actual_help_capability_checked',retry['binary_capabilities']['fps_mode_supported'])
            missing=create('missing_original',missing='observation.images.right_wrist');start=len(calls);report=checker.verify_media(missing)
            check('missing_original_reported',not report['all_three_original_videos_decoded'] and report['status']=='failed_or_incomplete')
            check('only_existing_originals_decoded',len([c for c in calls[start:] if Path(c[0]).name=='ffmpeg' and '-i' in c])==2)
            failed=create('decode_failure');fail_camera='left_wrist';report=checker.verify_media(failed);fail_camera=None
            check('decoder_error_preserved_and_rejected',not report['all_three_original_videos_decoded'] and any((r.get('decode') or {}).get('stderr') for r in report['files']))
            duplicate=create('duplicate_alias');metadata=json.loads((duplicate/'episode_0000.json').read_text());metadata['camera_metadata'].append(dict(video_key='observation.images.front'))
            (duplicate/'episode_0000.json').write_text(json.dumps(metadata));report=checker.verify_media(duplicate)
            check('duplicate_alias_rejects_membership',not report['original_membership_passed'] and not report['all_three_original_videos_decoded'])
            bad_sha=create('expected_sha_mismatch');manifest=root/'expected.json';manifest.write_text(json.dumps(dict(files={filename:dict(sha256='0'*64) for filename in checker.EXPECTED.values()})))
            report=checker.verify_media(bad_sha,expected_manifest=manifest)
            check('expected_sha_mismatch_rejected',not report['sha256_verified'] and report['all_three_original_videos_decoded'])
    print(json.dumps(dict(passed=True,count=len(cases),cases=cases,native_physics_executed=0,
        scope='mocked ffprobe/ffmpeg control flow and identity/missing/error/exclusive-report assertions; actual codec decode remains a real-run check')))

if __name__=='__main__':main()

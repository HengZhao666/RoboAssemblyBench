"""Differentiate active support, unloaded rest and the retained legacy score."""
import copy
import unittest
import numpy as np

from toolkits.factory_dual_franka_assembly.beam_support_state import BeamSupportState
from roboassemblybench.core.beam_staged_physical import _apply_empty_retreat_budget


class EmptyRetreatBudget(unittest.TestCase):
    def test_deadline_only_keeps_goal_and_all_convergence_checks(self):
        phase=dict(timeout_steps=3000,advance=dict(type='local_skill_complete',min_steps=1))
        skill=dict(name='ur5e_retreat_vertical',empty_arm_phase_handoff=True,
            gripper_command='open',relative_to_current_tcp=True,offset=[0,0,-.12],
            lock_target_position=True,lock_target_orientation=True,
            position_tolerance=.002,orientation_tolerance=.025,max_joint_step=.006)
        original=copy.deepcopy(skill);advance=copy.deepcopy(phase['advance'])
        self.assertTrue(_apply_empty_retreat_budget(phase,skill))
        self.assertEqual(phase['timeout_steps'],6960)
        self.assertEqual(skill,original);self.assertEqual(phase['advance'],advance)
        phase['timeout_steps']=8000;_apply_empty_retreat_budget(phase,skill)
        self.assertEqual(phase['timeout_steps'],8000)

    def test_closed_loaded_unknown_ownership_and_home_do_not_get_retreat_budget(self):
        base=dict(name='ur5e_retreat_vertical',empty_arm_phase_handoff=True,gripper_command='open')
        for change in [dict(requires_held_object=True),dict(gripper_command='close'),
                dict(empty_arm_phase_handoff=False),dict(name='move_arm_to_joint_positions')]:
            with self.subTest(change=change):
                phase=dict(timeout_steps=3000)
                self.assertFalse(_apply_empty_retreat_budget(phase,{**base,**change}))
                self.assertEqual(phase['timeout_steps'],3000)


class StagedContract(unittest.TestCase):
    def setUp(self):
        self.task = BeamSupportState()
        self.task.phase_index, self.task.phase_entry_step = 17, 8494
        self.task.phase = 'base_6_set_down'
        self.task.step_counter = 8500
        self.task._attachments = {'fabrica_beam_6': {'robot_name': 'right', 'mode': 'pure_physical_grasp'}}
        self.task._beam_shared_grasps = {}
        self.task._locked_targets = {}
        self.sample = dict(valid=True, motion_valid=True, physics_stamp_valid=True,
                           physics_epoch=1, physics_step_index=0, physics_time=0., physics_dt=1/240,
                           position=[.7, -.1, 1.], orientation=[1., 0., 0., 0.],
                           linear_speed=.015, angular_speed=.5, vertical_force=2.4525, bottom_gap=0.,
                           support_object_names=['board'])
        self.task._beam_table_observation = lambda **kw: copy.deepcopy(self.sample)
        self.gate = dict(stable_steps=96, minimum_vertical_force=1.962,
                         verification_mode='active_support',
                         position_drift_tolerance=.0005, orientation_drift_tolerance=.008726646259971648)

    def tick(self, **changes):
        self.sample['physics_step_index'] += 1
        self.sample['physics_time'] = self.sample['physics_step_index']/240
        self.sample.update(changes)
        self.task.step_counter += 1
        return self.task._beam_table_supported(self.gate)

    def test_supported_pose_can_qualify_despite_solver_velocity_oscillation(self):
        for i in range(95):
            self.assertFalse(self.tick(position=[.7 + .00005*np.sin(i), -.1, 1.]))
        self.assertTrue(self.tick())
        self.assertEqual(self.task._beam_support_stability['legacy_max_count'], 0)

    def test_real_support_and_physical_grasp_remain_required(self):
        for _ in range(95): self.tick()
        self.assertFalse(self.tick(vertical_force=0.))
        self.assertEqual(self.task._beam_support_stability['count'], 0)
        self.sample['vertical_force'] = 2.4525
        self.task._attachments.clear()
        for _ in range(100): self.assertFalse(self.tick())

    def test_drift_cannot_qualify_by_reanchoring_every_sample(self):
        for i in range(120):
            self.assertFalse(self.tick(position=[.7 + i*.00001, -.1, 1.]))

    def test_duplicate_samples_do_not_advance_or_gap_fill_the_window(self):
        self.tick()
        for _ in range(200): self.assertFalse(self.task._beam_table_supported(self.gate))
        self.assertEqual(self.task._beam_support_stability['count'], 1)
        self.sample['physics_step_index'] += 10
        self.tick()
        self.assertEqual(self.task._beam_support_stability['count'], 1)

    def test_legacy_gate_remains_independently_strict(self):
        self.gate = dict(stable_steps=96, minimum_vertical_force=1.962)
        for _ in range(120): self.assertFalse(self.tick())
        for _ in range(95): self.assertFalse(self.tick(linear_speed=0., angular_speed=0.))
        self.assertTrue(self.tick())

    def test_final_table_gate_keeps_load_gap_and_requested_velocity_limits(self):
        self.task.phase = 'beam_final_unloaded_verification'
        self.gate = dict(stable_steps=1, minimum_vertical_force=9.81,
                         verification_mode='unloaded', linear_velocity_threshold=.01,
                         angular_velocity_threshold=.1)
        self.assertFalse(self.tick(vertical_force=12.2625))  # Initial speed is too high.
        self.assertTrue(self.tick(linear_speed=.005, angular_speed=.05))
        self.assertFalse(self.tick(bottom_gap=.01))

    def test_unloaded_body_check_rejects_residual_grasp_lock_and_movement(self):
        self.task._beam_object_pose_sample = lambda name: copy.deepcopy(self.sample)
        gate = dict(objects=['fabrica_beam_6'], require_unloaded=True,
                    linear_velocity_threshold=.01, angular_velocity_threshold=.1,
                    position_drift_tolerance=.002, orientation_drift_tolerance=.03)
        self.sample.update(linear_speed=.005, angular_speed=.05)
        self.assertFalse(self.task._beam_staged_objects_stable(gate))
        self.task._attachments.clear()
        self.assertTrue(self.task._beam_staged_objects_stable(gate))
        self.assertFalse(self.task._beam_staged_motion_latest['legacy_raw_static'])
        self.task._locked_targets['fabrica_beam_6'] = 'target'
        self.assertFalse(self.task._beam_staged_objects_stable(gate))
        self.task._locked_targets.clear()
        self.sample.update(physics_step_index=1, physics_time=1/240, position=[.71, -.1, 1.])
        self.assertFalse(self.task._beam_staged_objects_stable(gate))


if __name__ == '__main__':
    unittest.main()

"""Recenter decisions on the observed r30 force cycle, with synthetic pad geometry.

The recorded forces are replayed unchanged; no physical response or grasp is
predicted. Existing adapter limit/feedback regressions cover command issuance.
"""
import copy
import unittest
import numpy as np
from test_beam_weak_side_recenter import metrics
from toolkits.factory_dual_franka_assembly.plumbers_block_ur5e_skills import (
    UR5eAssemblyAtomicSkillAdapter as Adapter,
)


class CaptureBalanceBand(unittest.TestCase):
    # Native r30 steps15660--15672, original close_control_trace forces.
    cycle = [
        (4.209083772202936, 13.005067401616435),
        (3.8699569693657154, 13.101124745448063),
        (3.4615861657637614, 12.971646596771704),
        (2.965347131887271, 12.63927812537806),
        (2.3957138357975567, 12.032714250321598),
        (1.857358328681141, 11.349093814640879),
        (1.7582360895182938, 10.504852348048766),
        (1.8931654216139984, 10.171280813834644),
        (2.1507343972016226, 10.109438260566652),
        (2.5269417076382332, 10.408689935326452),
        (2.9644366931643127, 10.772096374956172),
        (3.5288503852594624, 11.362830289622204),
        (4.057686549807056, 11.979886247946961),
    ]

    def spec(self, target):
        return dict(close_force_recenter_track_weak_side=True,
            close_force_recenter_single_contact_full_step=True,
            physical_contact_axes='y', close_force_balance_min=target,
            close_force_balance_peak=4., close_force_high=12.,
            close_force_limit=40., contact_force_threshold=.1,
            close_gate_recenter_stable_steps=4, close_force_balance_step=.000025,
            close_gate_recenter_step=.0002, close_gate_recenter_max_offset=.002,
            close_force_recenter_measure_progress=True,
            close_force_recenter_stop_on_bilateral=True)

    def replay(self, target, sequence):
        state={'close_tcp_position_world':np.zeros(3)};out=[]
        for tick,(left,right) in enumerate(sequence,15660):
            state['force_recenter_observation_step']=tick
            result=Adapter._update_force_recenter(state=state,
                spec=self.spec(target),metrics=metrics(left,right))
            out.append(result)
            if result.get('updated'):break
        return state,out

    def test_original_two_newton_target_discards_three_sample_margin_window(self):
        state,out=self.replay(2.,self.cycle)
        self.assertFalse(any(x['updated'] for x in out))
        self.assertEqual([x.get('confirmation_steps') for x in out[5:8]],[1,2,3])
        self.assertEqual(out[8]['reason'],'bilateral')
        self.assertNotIn('force_recenter_pending',state)

    def test_interior_target_preserves_confirmation_through_soft_unloading(self):
        state,out=self.replay(8.,self.cycle)
        self.assertTrue(out[-1]['updated'])
        self.assertEqual(len(out),6)
        self.assertTrue(all(not x['updated'] for x in out[:5]))
        self.assertEqual(out[-1]['motion_mode'],'force_margin')
        np.testing.assert_allclose(out[-1]['motion_delta_world'],[0.,-.000025,0.])
        self.assertLessEqual(state['force_recenter_travel'],.002)

    def test_balanced_interior_and_hard_overload_issue_no_translation(self):
        for forces in [(8.1,8.2),(1.,41.)]:
            with self.subTest(forces=forces):
                state,out=self.replay(8.,[forces]*8)
                self.assertFalse(any(x['updated'] for x in out))
                self.assertNotIn('force_recenter_pending',state)

    def test_force_regulation_and_capture_band_are_unmodified(self):
        spec=dict(close_force_low=4.,close_force_high=12.,close_force_limit=40.,
            close_force_weak_side_preload=True,close_force_max_seek=.03,
            close_force_joint_rate=.025,close_force_max_command_lead=.001)
        state=dict(contact_control_active=True,contact_capture_closure=.70,
            contact_command_closure=.715)
        before=copy.deepcopy(spec)
        for left,right in [(3.9,11.),(8.,8.),(8.,12.1),(8.,41.)]:
            result=Adapter._contact_close_control(state=copy.deepcopy(state),spec=spec,
                metrics=metrics(left,right),gripper_q=.715,open_q=0.,closed_q=.8,
                requested_openness=.1,min_openness=0.)
            self.assertEqual(result['clamp_force_ready'],4.<=min(left,right) and max(left,right)<=12.)
        self.assertEqual(spec,before)


if __name__=='__main__':unittest.main()

"""Offline contract regressions; these do not certify native physics."""
import copy
import sys
import unittest
from types import SimpleNamespace as NS
from unittest.mock import patch

import numpy as np

from toolkits.factory_dual_franka_assembly.beam_assisted_state import BeamAssistedState, consecutive_native_gate


def stamp(index):
    return {'valid': True, 'epoch': 0, 'index': index, 'time': index / 240., 'dt': 1 / 240.}


class Task(BeamAssistedState):
    def __init__(self):
        self.clock = stamp(1)
        self._beam_assisted_enabled = True
        self._fabrica_assisted_contract = {
            'adapter': 'stool_circular_ur5e_v1', 'objects': ['part'],
            'final_phase_name': 'stool_final', 'final_target_names': {'part': 'goal'},
            'install_position_step_m': .00025, 'install_orientation_step_rad': .012,
            'contact_stable_physics_steps': 12, 'release_stable_physics_steps': 72,
            'final_stable_physics_steps': 72, 'stable_position_drift_m': .002,
            'stable_orientation_drift_rad': .05, 'gripper_open_joint_tolerance_rad': .02}
        self.robots = {name: NS(_action_batch_sequence=5) for name in ('left', 'right')}
        self._attachments = {}
        self.events = []

    def _beam_physics_stamp(self):
        return dict(self.clock)

    def _assisted_event(self, event, **detail):
        self.events.append((event, detail))

    @staticmethod
    def actions():
        return {name: {'arm_joint_controller': [[0.] * 6], 'gripper_controller': [1.]}
                for name in ('left', 'right')}


class RuntimeContractTests(unittest.TestCase):
    @staticmethod
    def installation_task_and_usd():
        task = Task()
        task.step_counter = 8
        task._assisted_install_alignment = {'part': {
            'complete': False, 'joint_path': '/support', 'release_robot': None,
            'position': np.zeros(3), 'orientation': np.array([1., 0., 0., 0.]),
            'target_position': np.array([.001, 0., 0.]),
            'target_orientation': np.array([1., 0., 0., 0.])}}
        writes = []
        joint = NS(GetLocalPos1Attr=lambda: NS(Set=lambda value: writes.append(('position', value))),
                   GetLocalRot1Attr=lambda: NS(Set=lambda value: writes.append(('orientation', value))))
        external_modules = {'pxr': NS(
            Gf=NS(Vec3f=lambda *values: tuple(values), Quatf=lambda *values: tuple(values)),
            UsdPhysics=NS(FixedJoint=NS(Get=lambda *args: joint))),
            'isaacsim.core.utils.stage': NS(get_current_stage=lambda: object())}
        return task, writes, external_modules

    def test_real_support_guard_detail_logs_once_and_advances_anchor(self):
        task, writes, modules = self.installation_task_and_usd()
        # This matches StoolMeshGuard.support_guard's actual returned fields,
        # including its own object identity that previously duplicated kwargs.
        detail = {'passed': True, 'object': 'part', 'physics_stamp': dict(task.clock),
                  'samples': 2, 'first_failure': None, 'last_sample': {'collisions': []},
                  'scope': 'native part to proposed installation anchor finite sweep before joint authoring'}
        task._fabrica_production_support_guard = lambda *args: detail
        with patch.dict(sys.modules, modules):
            task._assisted_update_install_alignment()
        self.assertEqual(len(writes), 2)
        np.testing.assert_allclose(task._assisted_install_alignment['part']['position'], [.00025, 0., 0.])
        events = [payload for event, payload in task.events if event == 'fabrica_installation_support_guard']
        self.assertEqual(events, [detail])
        self.assertEqual(detail['object'], 'part')

    def test_support_guard_identity_or_clock_mismatch_cannot_write_anchor(self):
        for override in ({'object': 'wrong_part'}, {'physics_stamp': stamp(2)}, {'passed': False}):
            task, writes, modules = self.installation_task_and_usd()
            detail = {'passed': True, 'object': 'part', 'physics_stamp': dict(task.clock), **override}
            task._fabrica_production_support_guard = lambda *args: detail
            with patch.dict(sys.modules, modules), self.assertRaisesRegex(RuntimeError, 'rejected or stale'):
                task._assisted_update_install_alignment()
            self.assertEqual(writes, [])
            np.testing.assert_array_equal(task._assisted_install_alignment['part']['position'], np.zeros(3))

    def test_all_stool_body_rewrites_are_rejected_but_untracked_environment_is_not(self):
        t = Task()
        for operation in ('pose write', 'velocity reset', 'collision disable', 'gravity disable'):
            with self.assertRaises(RuntimeError):
                t._assisted_forbid_body_rewrite('part', operation)
        t._assisted_forbid_body_rewrite('environment', 'pose write')

    def test_missing_geometry_guard_fails_closed(self):
        with self.assertRaisesRegex(RuntimeError, 'production geometry guard'):
            Task()._assisted_guard_actions(Task.actions())

    def test_changed_native_tick_during_guard_rejects_batch(self):
        t = Task()
        def guard(actions):
            t.clock = stamp(2)
            return actions
        t._fabrica_production_action_guard = guard
        with self.assertRaisesRegex(RuntimeError, 'stale batch'):
            t._assisted_guard_actions(t.actions())

    def test_held_gripper_uses_captured_command_and_expected_sdk_identity(self):
        t = Task()
        t._attachments = {'part': {'robot_name': 'left', 'assisted_hold_openness': .37}}
        t._fabrica_production_action_guard = lambda actions: actions
        actions = t._assisted_guard_actions(t.actions())
        self.assertEqual(actions['left']['gripper_controller'], [.37])
        self.assertEqual(t._fabrica_final_gripper_commands['left']['expected_sdk_batch_sequence'], 6)

    def test_ik_only_or_missing_gripper_batches_are_rejected(self):
        for mutate in (lambda a: a['left'].pop('gripper_controller'),
                       lambda a: a['left'].update(arm_ik_controller=[[0., 0., 0.]])):
            t = Task()
            t._fabrica_production_action_guard = lambda actions: actions
            actions = t.actions()
            mutate(actions)
            with self.assertRaises(RuntimeError):
                t._assisted_guard_actions(actions)

    def test_task_stability_budget_is_explicit_and_same_tick_never_advances(self):
        pose = {'part': {'position': [0., 0., 0.], 'orientation': [1., 0., 0., 0.],
                         'body_path': '/part', 'motion_view_id': 3}}
        state = {}
        for _ in range(80):
            self.assertFalse(consecutive_native_gate(state, stamp(1), True, 2,
                pose, position_drift_limit=.002, orientation_drift_limit=.05))
        shifted = copy.deepcopy(pose)
        shifted['part']['position'][0] = .001
        self.assertTrue(consecutive_native_gate(state, stamp(2), True, 2,
            shifted, position_drift_limit=.002, orientation_drift_limit=.05))
        legacy = {}
        consecutive_native_gate(legacy, stamp(1), True, 2, pose)
        self.assertFalse(consecutive_native_gate(legacy, stamp(2), True, 2, shifted))

    def test_attachment_freezes_distinct_hand_and_tcp_frames_without_body_setters(self):
        t = Task()
        def forbidden(*args, **kwargs):
            raise AssertionError('body pose/velocity setter was called')
        body = NS(get_pose=lambda: (np.array([3., 1., 0.]), np.array([1., 0., 0., 0.])),
            set_pose=forbidden, set_linear_velocity=forbidden, set_angular_velocity=forbidden)
        hand = NS(get_pose=lambda: (np.array([1., 0., 0.]), np.array([1., 0., 0., 0.])))
        t._gripper_contact_metrics = lambda *args, **kw: {}
        t._strict_physical_grasp_contact = lambda *args, **kw: {'physical_contact_ready': True}
        t._assisted_body_path = lambda *args: (body, '/part')
        t._get_robot_hand_rigid_body = lambda *args: hand
        t._get_robot_task_pose = lambda *args: (np.array([2., 0., 0.]), np.array([1., 0., 0., 0.]))
        t.robots['left'].articulation = NS(get_joint_positions=lambda: np.zeros(12))
        t.robots['left'].last_action_controller_names = ['arm_joint_controller', 'gripper_controller']
        t._fabrica_final_gripper_commands = {'left': {'gripper_openness': .37, 'expected_sdk_batch_sequence': 5}}
        t._attachment_joint_path = lambda *args: '/joint'
        t._assisted_joint = lambda *args, **kw: '/joint'
        t._attachment_joints = {}
        t._locked_targets = {}
        t._frozen_lock_poses = {}
        t._locked_collision_states = {}
        t.step_counter = 12
        t.phase_index, t.phase_entry_step = 3, 0
        t._fabrica_contact_gates = {(3, 0, 'part', 'left'): {'previous': dict(t.clock), 'count': 12}}
        t._assisted_attach('part', 'left', {'name': 'close'}, {'beam_assisted': True})
        captured = t._attachments['part']
        np.testing.assert_allclose(captured['hand_object_position'], [2., 1., 0.])
        np.testing.assert_allclose(captured['hand_tcp_position'], [1., 0., 0.])
        np.testing.assert_allclose(captured['position'], [1., 1., 0.])
        self.assertFalse(captured['collision_disabled'])
        self.assertEqual(captured['assisted_hold_openness'], .37)
        # A stale request must never be substituted for a completed SDK batch.
        t.robots['left']._action_batch_sequence = 6
        with self.assertRaisesRegex(RuntimeError, 'completed final gripper SDK command'):
            t._assisted_attach('part', 'left', {'name': 'close'}, {'beam_assisted': True})

    def test_measured_base_rebase_preserves_relative_rotation_without_setters(self):
        t = Task()
        t._as_list = lambda value: [] if value is None else value if isinstance(value, list) else [value]
        t._locked_targets = {}
        t._lock_pin_pose = {}
        t._locked_collision_states = {}
        t._frozen_lock_poses = {}
        t.target_poses = {
            'goal': {'position': np.array([0., 0., 0.]), 'orientation': np.array([1., 0., 0., 0.])},
            'other': {'position': np.array([1., 0., 0.]), 'orientation': np.array([1., 0., 0., 0.])}}
        q = np.array([2 ** -.5, 0., 0., 2 ** -.5])
        body = NS(get_pose=lambda: (np.array([2., 3., 4.]), q))
        t._assisted_body_path = lambda name: (body, '/part')
        t._remove_attachment_joint = lambda name: None
        t._attachment_joint_path = lambda name: '/joint'
        created = []
        t._assisted_joint = lambda *args, **kwargs: created.append(args)
        t._assisted_lock('part', 'goal', {'rebase_targets': ['other']})
        np.testing.assert_allclose(t.target_poses['other']['position'], [2., 4., 4.], atol=1e-12)
        np.testing.assert_allclose(t.target_poses['goal']['position'], [2., 3., 4.], atol=1e-12)
        self.assertFalse(t._lock_pin_pose['part'])
        self.assertEqual(len(created), 1)
        self.assertTrue(any(event == 'rebase_targets' for event, _ in t.events))

    def test_original_nonstatic_condition_is_not_overridden_by_native_pose(self):
        t = Task()
        t.cfg = NS(success_criteria=[{'object': 'part', 'target': 'goal',
            'position_tolerance': .019, 'orientation_tolerance': .15, 'require_static': True,
            'linear_velocity_threshold': .05, 'angular_velocity_threshold': 2.}])
        t._assisted_install_alignment = {'part': {'complete': True, 'joint_path': '/support'}}
        t._locked_targets = {'part': 'goal'}
        t.target_poses = {'goal': {'position': [0., 0., 0.], 'orientation': [1., 0., 0., 0.]}}
        t._assisted_native_body_motion = lambda *args: {
            'position': [0., 0., 0.], 'orientation': [1., 0., 0., 0.], 'body_path': '/part'}
        t._assisted_support_joint_live = lambda *args: True
        t._target_tolerances = lambda **kw: (kw['default_position_tolerance'], kw['default_orientation_tolerance'])
        t._object_velocity_metrics = lambda *args, **kwargs: {'valid': True, 'is_static': False}
        sample = t._assisted_installation_sample(['part'], t.clock, final=True)
        self.assertFalse(sample['ready'])
        self.assertFalse(sample['objects']['part']['ready'])

    def test_nine_part_final_certificate_requires_full_native_window_and_same_tick(self):
        t = Task()
        names = ['fabrica_stool_circular_' + str(i) for i in range(9)]
        t._fabrica_assisted_contract['objects'] = names
        t.cfg = NS(success_criteria=[{'object': n, 'target': n + '_goal'} for n in names])
        t.target_poses = {n + '_goal': {'position': [0., 0., 0.], 'orientation': [1., 0., 0., 0.]}
                          for n in names}
        final = {'name': 'stool_final', 'advance': {'physics_stable_steps': 72},
                 'gripper_commands': {'left': 'open', 'right': 'open'},
                 'beam_assisted_installed_parts': names}
        t.phase_specs = [final]
        t.phase, t.phase_index, t.phase_entry_step = 'stool_final', 0, 1
        t._assisted_robot_gripper_is_open = lambda name: True
        poses = {name: {'position': [0., 0., 0.], 'orientation': [1., 0., 0., 0.],
                       'body_path': '/' + name, 'motion_view_id': index + 1}
                 for index, name in enumerate(names)}
        sample = {'ready': True, 'objects': poses}
        t._assisted_installation_sample = lambda *args, **kwargs: copy.deepcopy(sample)
        for index in range(1, 73):
            t.clock, t.step_counter = stamp(index), index
            sample['physics_stamp'] = dict(t.clock)
            t._assisted_install_gate_sample = copy.deepcopy(sample)
            qualified = t._assisted_conditions_stable(final['advance'], True)
            self.assertEqual(qualified, index == 72)
        self.assertEqual(set(t._assisted_final_certificate['native_poses']), set(names))
        self.assertTrue(t._assisted_final_success_ready())
        sample['objects'][names[-1]]['position'][0] = .000001
        self.assertFalse(t._assisted_final_success_ready())


if __name__ == '__main__':
    unittest.main()

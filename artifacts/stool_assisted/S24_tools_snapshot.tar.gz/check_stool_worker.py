"""Actual worker build and actual framework alias mapping, without a simulator."""
from pathlib import Path
import copy
import json
from toolkits.factory_dual_franka_assembly.generate_demos import _build_collect_worker_task_configs
from toolkits.factory_dual_franka_assembly.fabrica_assisted_preflight import assert_fabrica_assisted_configuration
from internutopia.core.task_config_manager.base import setup_offset_for_assets

configs = _build_collect_worker_task_configs(recipes=['fabrica_stool_circular_ur5e_staged'],
    seeds=[0], layout_seeds=[4906], scene_profile='taoyuan_grscenes_tabletop',
    attach_runtime_cameras=True, domain_randomization_enabled=True, control_fps=240)
config = configs[0]
if len(configs) != 1 or any(not r.preserve_continuous_arm_joints for r in config.robots):
    raise RuntimeError('Stool requires one episode and native SDK branch preservation on both robots')
report = assert_fabrica_assisted_configuration(config)
rows = []
for index in (0, 1):
    mapped = copy.deepcopy(config)
    setup_offset_for_assets(mapped, index, [0., 0., 0.])
    rows.append(dict(env_id=index, report=assert_fabrica_assisted_configuration(mapped)))
root = Path(__file__).resolve().parents[1]
(root/'worker_preflight.json').write_text(json.dumps(dict(passed=True, worker=report,
    framework_mapping=rows, simulation_initialized=False), indent=2)+'\n')
(root/'reviewed_worker_config.json').write_text(json.dumps(
    config.model_dump(mode='python', serialize_as_any=True), indent=2)+'\n')
print(json.dumps(dict(passed=True, phase_count=report['phase_count'],
    configuration_signature=report['configuration_signature'], actual_worker=True,
    actual_setup_offset_envs=[0, 1], simulation_initialized=False)))

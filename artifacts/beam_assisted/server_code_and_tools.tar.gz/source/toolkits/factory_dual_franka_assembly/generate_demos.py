from __future__ import annotations

import argparse
import os
import inspect
import json
import re
import shutil
import subprocess
import sys
import time
import traceback
from pathlib import Path
from typing import Any

import cv2
import numpy as np

from internutopia.core.config import Config, SimConfig
from internutopia.core.util import has_display
from internutopia.core.vec_env import Env
from internutopia_extension import import_fabrica_assembly_extensions
from roboassemblybench.datasets.cartesian_episode import CompactCartesianEpisodeRecorder
from roboassemblybench.core.domain_randomization import RANDOMIZATION_PROFILE_CHOICES
from toolkits.constraint_checking.integration.pipeline import (
    RuntimeConstraintEpisodeHook,
)
from toolkits.constraint_checking.integration.precheck_pipeline import (
    PassivePrecheckEpisodeHook,
)
from toolkits.factory_dual_franka_assembly.demo_policy import (
    DualFrankaAssemblyDemoPolicy,
)
from toolkits.factory_dual_franka_assembly.scene_builder import (
    build_dual_franka_assembly_episode,
    build_dual_franka_assembly_batch,
)
from toolkits.factory_dual_franka_assembly.scene_profiles import (
    DEFAULT_SCENE_PROFILE,
    list_scene_profiles,
)
from toolkits.factory_dual_franka_assembly.task_specs import (
    list_task_recipes,
    load_task_recipe,
)

RUNTIME_CAMERA_WARMUP_RENDER_STEPS = 8


def _to_jsonable(value: Any):
    if isinstance(value, dict):
        return {key: _to_jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_jsonable(item) for item in value]
    if hasattr(value, 'tolist'):
        return value.tolist()
    return value


def _sanitize_episode_value(value: Any, *, array_size_limit: int = 64):
    if isinstance(value, dict):
        return {key: _sanitize_episode_value(item, array_size_limit=array_size_limit) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        if len(value) > array_size_limit and all(isinstance(item, (int, float, bool, np.number)) for item in value):
            return {
                '__type__': 'sequence',
                'length': len(value),
                'preview': _to_jsonable(list(value[: min(8, len(value))])),
            }
        return [_sanitize_episode_value(item, array_size_limit=array_size_limit) for item in value]
    if isinstance(value, np.ndarray):
        if value.size > array_size_limit:
            return {
                '__type__': 'ndarray',
                'shape': list(value.shape),
                'dtype': str(value.dtype),
            }
        return value.tolist()
    if hasattr(value, 'shape') and hasattr(value, 'dtype') and getattr(value, 'size', 0) > array_size_limit:
        return {
            '__type__': type(value).__name__,
            'shape': list(getattr(value, 'shape', ())),
            'dtype': str(getattr(value, 'dtype', 'unknown')),
        }
    return _to_jsonable(value)


def _task_export_metadata(task) -> dict:
    config = task.config
    return {
        'prompt': config.prompt,
        'task_description': getattr(config, 'task_description', '') or config.prompt,
        'annotation_name': getattr(config, 'annotation_name', ''),
        'annotation_path': getattr(config, 'annotation_path', None),
        'annotation_title': getattr(config, 'annotation_title', ''),
        'annotation_summary': getattr(config, 'annotation_summary', ''),
        'annotation_description': getattr(config, 'annotation_description', ''),
        'annotation_tags': _to_jsonable(getattr(config, 'annotation_tags', [])),
        'annotation_metadata': _to_jsonable(getattr(config, 'annotation_metadata', {})),
        'annotation_object_roles': _to_jsonable(getattr(config, 'annotation_object_roles', {})),
        'annotation_target_roles': _to_jsonable(getattr(config, 'annotation_target_roles', {})),
        'annotation_phase_notes': _to_jsonable(getattr(config, 'annotation_phase_notes', [])),
        'target_annotations': _to_jsonable(getattr(config, 'target_annotations', {})),
        'phase_annotations': _to_jsonable(getattr(config, 'phase_annotations', [])),
        'metadata': _to_jsonable(getattr(config, 'benchmark_metadata', {})),
        'task_metadata': _to_jsonable(getattr(config, 'task_metadata', {})),
        'scene_profile_metadata': _to_jsonable(getattr(config, 'scene_profile_metadata', {})),
        'source_benchmark': getattr(config, 'source_benchmark', 'factory_dual_franka_assembly'),
        'source_config_path': getattr(config, 'source_config_path', None),
        'camera_metadata': _to_jsonable(getattr(config, 'camera_metadata', [])),
        'robot_metadata': _to_jsonable(getattr(config, 'robot_metadata', [])),
        'object_metadata': _to_jsonable(getattr(config, 'object_metadata', [])),
        'domain_randomization': _to_jsonable(getattr(config, 'domain_randomization', {})),
        'layout_seed': int(config.seed if getattr(config, 'layout_seed', None) is None else config.layout_seed),
    }


def _attach_policy_diagnostics(metrics: dict, policy: DualFrankaAssemblyDemoPolicy) -> dict:
    diagnostics = getattr(policy, 'local_skill_diagnostics', [])
    if diagnostics:
        metrics = dict(metrics)
        metrics['local_skill_diagnostics'] = _to_jsonable(diagnostics)
    return metrics


class EpisodeRecorder:
    def __init__(self, output_dir: Path, *, record_steps: bool = True):
        self.output_dir = output_dir.resolve()
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.record_steps = bool(record_steps)
        self.steps = []

    def record(self, task, obs: dict, actions: dict):
        if not self.record_steps:
            return
        self.steps.append(
            {
                'phase': task.phase,
                'actions': _sanitize_episode_value(actions),
                'observations': _sanitize_episode_value(obs),
                'objects': _sanitize_episode_value(task.get_tracked_object_states()),
            }
        )

    def save(
        self,
        task,
        episode_idx: int,
        metrics: dict,
        *,
        recorded_videos: dict[str, str] | None = None,
        recorded_video_summaries: dict[str, dict] | None = None,
        recorded_video_mode: str | None = None,
        recorded_frames: dict[str, str] | None = None,
        recorded_frame_summaries: dict[str, dict] | None = None,
        recorded_frame_mode: str | None = None,
        recorded_dataset: dict | None = None,
    ):
        payload = {
            'episode_idx': episode_idx,
            'seed': task.config.seed,
            'layout_seed': int(
                task.config.seed if getattr(task.config, 'layout_seed', None) is None else task.config.layout_seed
            ),
            'recipe': task.config.recipe,
            'prompt': task.config.prompt,
            'task_description': getattr(task.config, 'task_description', '') or task.config.prompt,
            'scene_profile': getattr(task.config, 'scene_profile', '') or None,
            'spec_path': getattr(task.config, 'spec_path', None),
            'scene_profile_path': getattr(task.config, 'scene_profile_path', None),
            'scene_asset_path': task.config.scene_asset_path,
            'workspace_offset': _to_jsonable(getattr(task.config, 'workspace_offset', [])),
            'asset_references': _to_jsonable(getattr(task.config, 'asset_references', [])),
            **_task_export_metadata(task),
            'phase_blueprint': [phase_spec.get('name') for phase_spec in task.config.phase_specs],
            'metrics': _to_jsonable(metrics),
            'recorded_videos': _to_jsonable(recorded_videos or {}),
            'recorded_video_summaries': _to_jsonable(recorded_video_summaries or {}),
            'recorded_video_mode': recorded_video_mode,
            'recorded_frames': _to_jsonable(recorded_frames or {}),
            'recorded_frame_summaries': _to_jsonable(recorded_frame_summaries or {}),
            'recorded_frame_mode': recorded_frame_mode,
            'recorded_dataset': _to_jsonable(recorded_dataset or {}),
            'steps': self.steps,
        }
        path = self.output_dir / f'episode_{episode_idx:04d}.json'
        path.write_text(json.dumps(payload, indent=2), encoding='utf-8')


class LiveRolloutVideoRecorder:
    def __init__(
        self,
        *,
        output_dir: Path,
        episode_idx: int,
        task,
        fps: int,
        frame_stride: int,
        keep_frames: bool = False,
    ):
        self.output_dir = output_dir.resolve()
        self.episode_idx = int(episode_idx)
        self.keep_frames = keep_frames
        self.frame_stride = max(int(frame_stride), 1)
        self.requested_fps = max(float(fps), 1.0)
        self.fps = self.requested_fps
        self.frames_root_dir = self.output_dir / f'episode_{self.episode_idx:04d}_live_frames'
        self.frames_root_dir.mkdir(parents=True, exist_ok=True)

        from toolkits.factory_dual_franka_assembly.export_lerobot import (
            RunningImageStats,
            _episode_camera_specs,
        )

        self._running_image_stats_cls = RunningImageStats
        self.camera_specs = _episode_camera_specs(
            {
                'camera_metadata': _to_jsonable(getattr(task.config, 'camera_metadata', [])),
                'robot_metadata': _to_jsonable(getattr(task.config, 'robot_metadata', [])),
                'steps': [],
            },
            video_mode='isaac_replay',
            default_width=960,
            default_height=540,
            video_key=None,
        )
        self._image_stats = {}
        self._frame_dirs: dict[str, Path] = {}
        self._written_png_counts: dict[str, int] = {}
        self._frame_shapes: dict[str, tuple[int, int]] = {}
        self._sampled_steps: list[dict] = []
        self._camera_bindings = {
            camera_spec['video_key']: {
                'robot_name': str(camera_spec.get('owner') or camera_spec.get('robot') or 'franka_left'),
                'sensor_name': str(camera_spec.get('name') or ''),
            }
            for camera_spec in self.camera_specs
        }

    @staticmethod
    def _to_uint8_rgb(frame) -> np.ndarray | None:
        if frame is None:
            return None
        frame_array = np.asarray(frame)
        if frame_array.size == 0 or frame_array.ndim < 3:
            return None
        if frame_array.shape[-1] >= 4:
            frame_array = frame_array[..., :3]
        elif frame_array.shape[-1] == 1:
            frame_array = np.repeat(frame_array, 3, axis=-1)
        if np.issubdtype(frame_array.dtype, np.floating):
            if float(np.nanmax(frame_array)) <= 1.0 + 1e-6:
                frame_array = frame_array * 255.0
        frame_array = np.nan_to_num(frame_array, nan=0.0, posinf=255.0, neginf=0.0)
        return np.clip(frame_array, 0.0, 255.0).astype(np.uint8)

    def _sensor_frame_from_obs(self, obs: dict, *, camera_video_key: str) -> np.ndarray | None:
        binding = self._camera_bindings.get(camera_video_key, {})
        robot_name = binding.get('robot_name')
        sensor_name = binding.get('sensor_name')
        if not robot_name or not sensor_name:
            return None

        robot_obs = obs.get(robot_name)
        if not isinstance(robot_obs, dict):
            return None
        sensor_obs = (robot_obs.get('sensors') or {}).get(sensor_name)
        if not isinstance(sensor_obs, dict):
            return None
        return self._to_uint8_rgb(sensor_obs.get('rgba'))

    def record(self, task, obs: dict, *, step_index: int, post_failure: bool = False,
               failure_task_step: int | None = None):
        if step_index % self.frame_stride != 0:
            return

        step_payload = {
            'observations': _sanitize_episode_value(obs),
            'objects': None if post_failure else _sanitize_episode_value(task.get_tracked_object_states()),
            'capture_segment': 'post_failure' if post_failure else 'rollout',
        }
        captured_any = False
        for camera_spec in self.camera_specs:
            camera_video_key = camera_spec['video_key']
            frame_rgb = self._sensor_frame_from_obs(obs, camera_video_key=camera_video_key)
            if frame_rgb is None:
                continue

            frame_dir = self._frame_dirs.get(camera_video_key)
            if frame_dir is None:
                frame_dir = self.frames_root_dir / camera_video_key.replace('.', '_')
                frame_dir.mkdir(parents=True, exist_ok=True)
                self._frame_dirs[camera_video_key] = frame_dir
                self._image_stats[camera_video_key] = self._running_image_stats_cls()
                self._written_png_counts[camera_video_key] = 0
                self._frame_shapes[camera_video_key] = (int(frame_rgb.shape[1]), int(frame_rgb.shape[0]))

            self._image_stats[camera_video_key].update(frame_rgb)
            frame_index = self._written_png_counts[camera_video_key]
            frame_path = frame_dir / f'frame_{frame_index:05d}.png'
            cv2.imwrite(str(frame_path), cv2.cvtColor(frame_rgb, cv2.COLOR_RGB2BGR))
            if os.environ.get('BEAM_VIDEO_CLOCK_TRACE') == '1':
                from toolkits.factory_dual_franka_assembly.beam_video_clock import video_frame_clock
                binding = self._camera_bindings[camera_video_key]
                sensor_observation = ((obs.get(binding['robot_name']) or {}).get('sensors') or {}).get(
                    binding['sensor_name'], {})
                clock = video_frame_clock(task, step=step_index, camera=camera_video_key,
                    frame_index=frame_index, sensor_observation=sensor_observation)
                clock['image_path'] = str(frame_path.relative_to(self.output_dir))
                clock['capture_segment'] = 'post_failure' if post_failure else 'rollout'
                if post_failure:
                    clock['failure_task_step'] = int(task.step_counter) if failure_task_step is None else int(failure_task_step)
                    clock['capture_entry_task_step'] = int(task.step_counter)
                with (self.output_dir / 'video_frame_clock.jsonl').open('a') as handle:
                    handle.write(json.dumps(clock, allow_nan=False) + '\n')
            self._written_png_counts[camera_video_key] += 1
            captured_any = True

        if captured_any:
            self._sampled_steps.append(step_payload)

    def finalize(self):
        from toolkits.factory_dual_franka_assembly.export_lerobot import (
            _encode_mp4_from_pngs,
        )

        videos = {}
        summaries = {}
        video_root_dir = self.output_dir / f'episode_{self.episode_idx:04d}_live_videos'
        video_root_dir.mkdir(parents=True, exist_ok=True)
        for camera_video_key, frame_dir in list(self._frame_dirs.items()):
            width, height = self._frame_shapes.get(camera_video_key, (0, 0))
            video_path = video_root_dir / f'{camera_video_key.replace(".", "_")}.mp4'
            encode_start = time.monotonic()
            print(f'[video-encode] event=start camera={camera_video_key} '
                  f'frames={self._written_png_counts[camera_video_key]}', flush=True)
            encode_summary = _encode_mp4_from_pngs(frame_dir, video_path, self.fps,
                precomputed_image_stats=self._image_stats[camera_video_key].to_dict())
            encode_elapsed = time.monotonic()-encode_start
            print(f'[video-encode] event=end camera={camera_video_key} '
                  f'elapsed_s={encode_elapsed:.6f}', flush=True)
            videos[camera_video_key] = str(video_path)
            summaries[camera_video_key] = {
                'frames_dir': str(frame_dir),
                'video_path': str(video_path),
                'fps': float(self.fps),
                'requested_fps': float(self.requested_fps),
                'frame_stride': int(self.frame_stride),
                'width': int(encode_summary.get('width', width)),
                'height': int(encode_summary.get('height', height)),
                'renderer': 'live_rollout_frame_capture',
                'frame_count': int(self._written_png_counts.get(camera_video_key, 0)),
                'image_stats': encode_summary.get('image_stats', self._image_stats[camera_video_key].to_dict()),
                'encode_elapsed_s': encode_elapsed,
            }
            if not self.keep_frames:
                shutil.rmtree(frame_dir, ignore_errors=True)
        if not self.keep_frames:
            try:
                self.frames_root_dir.rmdir()
            except OSError:
                pass
        return {
            'videos': videos,
            'summaries': summaries,
            'video_mode': 'live_rollout_mp4',
            'frames': {key: str(path) for key, path in self._frame_dirs.items()},
            'frame_summaries': summaries,
            'frame_mode': 'live_rollout_frames',
        }


def _write_json(path: Path, payload: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(_to_jsonable(payload), indent=2), encoding='utf-8')


def _runtime_failed_results(results: list[dict]) -> list[dict]:
    failed_results = []
    for result in results:
        runtime_report = result.get('runtime_robochecker') or {}
        has_runtime_feedback = bool(runtime_report.get('feedback_count') or runtime_report.get('feedback'))
        if not result.get('success') and has_runtime_feedback:
            failed_results.append(result)
    return failed_results


def _build_env(
    task_configs,
    headless: bool,
    *,
    rendering_fps: int | None = None,
    rendering_interval: int | None = None,
):
    simulation_fps = 240 if rendering_fps is None else max(int(rendering_fps), 1)
    rendering_dt = 1 / simulation_fps
    if rendering_interval is not None and int(rendering_interval) < 0:
        raise ValueError('rendering_interval must be non-negative.')
    config = Config(
        simulator=SimConfig(
            physics_dt=1 / simulation_fps,
            rendering_dt=rendering_dt,
            rendering_interval=None if rendering_interval is None else int(rendering_interval),
            use_fabric=False,
            headless=headless,
            native=False,
            webrtc=False,
        ),
        env_num=1,
        metrics_save_path='none',
        task_configs=task_configs,
    )
    robot_platforms = {
        'ur5e' if str(getattr(robot, 'type', '')).lower().startswith('ur5e') else 'franka'
        for task_config in task_configs
        for robot in task_config.robots
    }
    if len(robot_platforms) != 1:
        raise ValueError(f'One simulator process cannot mix Fabrica robot platforms: {sorted(robot_platforms)}')
    import_fabrica_assembly_extensions(robot_platforms.pop())
    return Env(config)


def _warm_up_runtime_cameras(env, *, steps: int = RUNTIME_CAMERA_WARMUP_RENDER_STEPS):
    """Converge newly composed RTX camera history without advancing physics."""
    env.warm_up(steps=max(int(steps), 1), render=True, physics=False)
    return env.get_observations()


def _run_task_sequence(
    task_configs,
    headless: bool,
    output_dir: Path | None = None,
    results_output_path: Path | None = None,
    *,
    record_live_video: bool = False,
    live_video_fps: int = 30,
    live_video_frame_stride: int = 8,
    keep_video_frames: bool = False,
    runtime_robochecker: bool = False,
    runtime_feedback_path: Path | None = None,
    runtime_observation_dir: Path | None = None,
    runtime_checker_stride: int = 8,
    runtime_stop_on_violation: bool = True,
    runtime_capture_rgb: bool = True,
    runtime_rgb_frame_stride: int = 24,
    runtime_constraint_monitor: bool = False,
    constraint_check_stride: int = 8,
    constraint_threshold: float | None = None,
    constraint_include_ground: bool = False,
    constraint_ignore_pairs: list[str] | None = None,
    assembly_sequence_precheck: bool = False,
    stage_trajectory_precheck: bool = False,
    stage_precheck_stride: int = 64,
    stage_precheck_waypoints: int = 8,
    record_episode_steps: bool = True,
    record_lerobot_raw: bool = False,
    record_trajectory_only: bool = False,
    dataset_fps: int = 30,
    dataset_frame_stride: int = 8,
    video_codec: str = 'h264',
    video_crf: int = 23,
    video_preset: str = 'veryfast',
    depth_compression_level: int = 5,
    rendering_fps: int | None = None,
    rendering_interval_override: int | None = None,
):
    simulation_fps = 240 if rendering_fps is None else max(int(rendering_fps), 1)
    if record_live_video and (int(live_video_fps) < 1 or int(live_video_frame_stride) < 1):
        raise ValueError('Live video fps and frame stride must be positive.')
    if record_trajectory_only and not record_lerobot_raw:
        raise ValueError('Trajectory-only recording requires record_lerobot_raw=True.')
    dataset_rendering_interval = max(int(dataset_frame_stride), 1) - 1 if record_lerobot_raw else None
    requires_runtime_rendering = bool(
        record_live_video
        or (record_lerobot_raw and not record_trajectory_only)
        or (runtime_robochecker and runtime_capture_rgb)
    )
    rollout_rendering_interval = (
        dataset_rendering_interval
        if record_lerobot_raw and not record_trajectory_only
        else (
            int(live_video_frame_stride) - 1
            if record_live_video
            else (None if requires_runtime_rendering else simulation_fps - 1)
        )
    )
    if rendering_interval_override is not None:
        if requires_runtime_rendering:
            raise ValueError('A rendering interval override cannot be used while runtime image capture is enabled.')
        rollout_rendering_interval = max(int(rendering_interval_override), 0)
    env = _build_env(
        task_configs=task_configs,
        headless=headless,
        rendering_fps=rendering_fps,
        rendering_interval=rollout_rendering_interval,
    )
    policy = DualFrankaAssemblyDemoPolicy()
    obs_list, task_cfgs = env.reset()
    if requires_runtime_rendering and task_cfgs and task_cfgs[0] is not None:
        obs_list = _warm_up_runtime_cameras(env)
    results = []
    if results_output_path is not None:
        _write_json(results_output_path, results)
    episode_idx = 0
    recorder = None
    video_recorder = None
    runtime_checker = None
    dataset_recorder = None
    constraint_hook = RuntimeConstraintEpisodeHook(
        enabled=runtime_constraint_monitor,
        check_stride=constraint_check_stride,
        threshold=constraint_threshold,
        include_ground=constraint_include_ground,
        ignore_pairs=constraint_ignore_pairs,
    )
    precheck_hook = PassivePrecheckEpisodeHook(
        sequence_enabled=assembly_sequence_precheck,
        stage_enabled=stage_trajectory_precheck,
        stage_check_stride=stage_precheck_stride,
        stage_waypoints=stage_precheck_waypoints,
        threshold=constraint_threshold,
        include_ground=constraint_include_ground,
        ignore_pairs=constraint_ignore_pairs,
    )
    last_task = None
    rollout_started_at = time.monotonic()
    rollout_loop_entered = False
    initial_tasks = getattr(env.runner, 'current_tasks', {})
    if initial_tasks:
        last_task = next(iter(initial_tasks.values()))
    if runtime_robochecker:
        # RoboChecker is a Stage-1 live-rollout monitor. Keep it out of the
        # import path for Stage-2 kinematic replay workers.
        from roboassemblybench.robobrain.runtime_monitor import RuntimeRoboChecker

        runtime_checker = RuntimeRoboChecker(
            output_dir=runtime_observation_dir
            or ((output_dir / 'runtime_observations') if output_dir is not None else None),
            feedback_path=runtime_feedback_path,
            check_stride=runtime_checker_stride,
            capture_rgb=runtime_capture_rgb,
            rgb_frame_stride=runtime_rgb_frame_stride,
            stop_on_violation=runtime_stop_on_violation,
        )

    try:
        # In headless Isaac workers, `SimulationApp.is_running()` may flip to
        # false immediately after reset even though stepping the world still
        # works. Drive rollouts from active tasks instead of viewport state.
        while task_cfgs and task_cfgs[0] is not None and not env.finished():
            task_name = next(iter(env.runner.current_tasks.keys()))
            task = env.runner.current_tasks[task_name]
            last_task = task
            if not rollout_loop_entered:
                phase_spec = task.get_current_phase_spec()
                phase_timeout = (
                    task._phase_timeout_steps(phase_spec)
                    if hasattr(task, '_phase_timeout_steps')
                    else phase_spec.get('timeout_steps')
                )
                robot_metadata = list(getattr(task.cfg, 'robot_metadata', []) or [])
                print(
                    '[rollout-progress] event=loop_enter ' f'task={task_name} step={int(task.step_counter)}',
                    flush=True,
                )
                print(
                    '[rollout-runtime] '
                    f'task_class_file={inspect.getfile(type(task))} '
                    f'phase={getattr(task, "phase", None)} '
                    f'phase_timeout={phase_timeout} '
                    f'robot_types={[entry.get("type") for entry in robot_metadata]} '
                    f'robot_usd_paths={[entry.get("usd_path") for entry in robot_metadata]} '
                    f'end_effectors={[entry.get("end_effector_prim_name") for entry in robot_metadata]}',
                    flush=True,
                )
                rollout_loop_entered = True
            if output_dir is not None and recorder is None:
                recorder = EpisodeRecorder(
                    output_dir=output_dir,
                    record_steps=record_episode_steps,
                )
            if record_live_video and video_recorder is None:
                if not (record_lerobot_raw and not record_trajectory_only):
                    # Runner reset keeps its render trigger. Align a new live
                    # episode with its own sample steps without advancing physics.
                    env.runner.render_trigger = int(task.step_counter) % int(live_video_frame_stride)
                video_recorder = LiveRolloutVideoRecorder(
                    output_dir=output_dir or Path.cwd(),
                    episode_idx=episode_idx,
                    task=task,
                    fps=live_video_fps,
                    frame_stride=live_video_frame_stride,
                    keep_frames=keep_video_frames,
                )
            if record_lerobot_raw and dataset_recorder is None:
                dataset_recorder = CompactCartesianEpisodeRecorder(
                    output_dir=output_dir or Path.cwd(),
                    episode_idx=episode_idx,
                    task=task,
                    fps=dataset_fps,
                    frame_stride=dataset_frame_stride,
                    simulation_fps=simulation_fps,
                    rendering_interval=dataset_rendering_interval,
                    record_media=not record_trajectory_only,
                    video_codec=video_codec,
                    video_crf=video_crf,
                    video_preset=video_preset,
                    depth_compression_level=depth_compression_level,
                )

            step_started_at = time.monotonic()
            env_actions = policy.act(task)
            precheck_hook.observe_before_step(task, env_actions)
            if dataset_recorder is not None:
                dataset_recorder.record(task=task, obs=obs_list[0], actions=env_actions)
            obs_list, _, terminated, _, _ = env.step([env_actions])
            constraint_hook.observe(task)
            # Runner cleanup can remove a successful task before VecEnv exposes
            # its terminal flag.  Promote the runner's finished metrics to a
            # normal termination so recorders are finalized as successful.
            finished_metrics = list(getattr(env.runner, 'last_finished_task_metrics', []) or [])
            runner_completed = bool(
                finished_metrics
                and (
                    task_name not in getattr(env.runner, 'current_tasks', {})
                    or env.finished()
                )
            )
            if runner_completed and not terminated[0]:
                terminated = list(terminated)
                terminated[0] = True
            completed_step = int(task.step_counter)
            if completed_step <= 5 or completed_step % 60 == 0:
                elapsed = max(time.monotonic() - rollout_started_at, 1e-9)
                current_phase_spec = task.get_current_phase_spec()
                current_phase_timeout = (
                    task._phase_timeout_steps(current_phase_spec)
                    if hasattr(task, '_phase_timeout_steps')
                    else current_phase_spec.get('timeout_steps')
                )
                print(
                    '[rollout-progress] event=step_complete '
                    f'task={task_name} step={completed_step} '
                    f'phase={getattr(task, "phase", None)} '
                    f'phase_index={int(getattr(task, "phase_index", -1))} '
                    f'phase_step={int(getattr(task, "phase_step_counter", -1))} '
                    f'phase_timeout={current_phase_timeout} '
                    f'step_wall_seconds={time.monotonic() - step_started_at:.3f} '
                    f'average_steps_per_second={completed_step / elapsed:.3f}',
                    flush=True,
                )

            if recorder is not None:
                recorder.record(task, obs_list[0], env_actions)
            if video_recorder is not None:
                video_recorder.record(task, obs_list[0], step_index=int(task.step_counter))
            if runtime_checker is not None:
                runtime_result = runtime_checker.observe(
                    task=task,
                    obs=obs_list[0],
                    actions=env_actions,
                    episode_idx=episode_idx,
                )
                if runtime_result.get('blocking'):
                    detail = {
                        'runtime_robochecker': runtime_result.get('feedback', []),
                        'snapshot': runtime_result.get('snapshot', {}),
                    }
                    if hasattr(task, '_set_terminal_state'):
                        task._set_terminal_state(
                            'failed',
                            reason='runtime-robochecker-violation',
                            status='failed',
                            detail=detail,
                        )
                    else:
                        task.failed = True
                        task.success = False
                        task.terminal_reason = 'runtime-robochecker-violation'
                    terminated = list(terminated)
                    terminated[0] = True

            if terminated[0]:
                metrics = _attach_policy_diagnostics(
                    finished_metrics[-1] if runner_completed else task.calculate_metrics(),
                    policy,
                )
                from copy import deepcopy
                metrics = deepcopy(metrics)
                if runtime_checker is not None:
                    metrics['runtime_robochecker'] = runtime_checker.finalize()
                constraint_hook.attach_metrics(metrics)
                precheck_hook.attach_metrics(metrics)
                results.append(metrics)
                if results_output_path is not None:
                    _write_json(results_output_path, results)
                recorded_videos = {}
                recorded_video_summaries = {}
                recorded_video_mode = None
                recorded_frames = {}
                recorded_frame_summaries = {}
                recorded_frame_mode = None
                recorded_dataset = {}
                if video_recorder is not None:
                    from toolkits.factory_dual_franka_assembly.beam_failure_video import record_failure_tail
                    tail = record_failure_tail(env, task, video_recorder, metrics)
                    if tail is not None:
                        metrics['post_failure_recording'] = tail
                        if results_output_path is not None:
                            _write_json(results_output_path, results)
                    live_video_output = video_recorder.finalize()
                    recorded_videos = live_video_output.get('videos', {})
                    recorded_video_summaries = live_video_output.get('summaries', {})
                    recorded_video_mode = live_video_output.get('video_mode')
                    recorded_frames = live_video_output.get('frames', {})
                    recorded_frame_summaries = live_video_output.get('frame_summaries', {})
                    recorded_frame_mode = live_video_output.get('frame_mode')
                if dataset_recorder is not None:
                    recorded_dataset = dataset_recorder.finalize(task=task, metrics=metrics)
                if recorder is not None:
                    recorder.save(
                        task=task,
                        episode_idx=episode_idx,
                        metrics=metrics,
                        recorded_videos=recorded_videos,
                        recorded_video_summaries=recorded_video_summaries,
                        recorded_video_mode=recorded_video_mode,
                        recorded_frames=recorded_frames,
                        recorded_frame_summaries=recorded_frame_summaries,
                        recorded_frame_mode=recorded_frame_mode,
                        recorded_dataset=recorded_dataset,
                    )
                episode_idx += 1
                recorder = None
                video_recorder = None
                dataset_recorder = None
                constraint_hook.reset_episode()
                precheck_hook.reset_episode()
                obs_list, task_cfgs = env.reset([0])
                if requires_runtime_rendering and task_cfgs and task_cfgs[0] is not None:
                    obs_list = _warm_up_runtime_cameras(env)
                if not task_cfgs or task_cfgs[0] is None:
                    break
        if not results:
            try:
                finished_metrics = getattr(env.runner, 'last_finished_task_metrics', [])
                if finished_metrics:
                    results.extend(finished_metrics)
                active_tasks = getattr(env.runner, 'current_tasks', {})
                task = next(iter(active_tasks.values())) if active_tasks else last_task
                if not results and task is not None:
                    metrics = _attach_policy_diagnostics(task.calculate_metrics(), policy)
                    constraint_hook.attach_metrics(metrics)
                    precheck_hook.attach_metrics(metrics)
                    metrics.setdefault('terminal_reason', 'rollout-ended-without-termination')
                    results.append(metrics)
            except Exception:
                pass
        if results_output_path is not None:
            _write_json(results_output_path, results)
    finally:
        exc_type, exc_value, _ = sys.exc_info()
        if runtime_checker is not None:
            try:
                runtime_checker.finalize()
            except Exception:
                pass
        constraint_monitor_metrics = constraint_hook.finalize() if recorder is not None else None
        live_video_output = None
        raw_dataset_output = None
        if video_recorder is not None:
            try:
                live_video_output = video_recorder.finalize()
            except Exception:
                pass
        if dataset_recorder is not None and last_task is not None:
            try:
                interrupted_metrics = _attach_policy_diagnostics(last_task.calculate_metrics(), policy)
                interrupted_metrics['success'] = False
                interrupted_metrics.setdefault('terminal_reason', 'rollout-interrupted-before-normal-termination')
                raw_dataset_output = dataset_recorder.finalize(task=last_task, metrics=interrupted_metrics)
            except Exception:
                print('[demo-debug] raw dataset finalization failed:', flush=True)
                traceback.print_exc()
        if recorder is not None and last_task is not None:
            try:
                metrics = _attach_policy_diagnostics(last_task.calculate_metrics(), policy)
            except Exception:
                metrics = {}
            if constraint_monitor_metrics is not None:
                metrics['runtime_constraint_monitor'] = constraint_monitor_metrics
            precheck_hook.attach_metrics(metrics)
            metrics['success'] = False
            metrics.setdefault('status', 'failed')
            if not metrics.get('terminal_reason'):
                metrics['terminal_reason'] = 'rollout-interrupted-before-normal-termination'
            if exc_value is not None:
                print('[demo-debug] rollout interrupted by exception:', flush=True)
                traceback.print_exception(exc_type, exc_value, exc_value.__traceback__)
                metrics['exception'] = {
                    'type': exc_type.__name__ if exc_type is not None else type(exc_value).__name__,
                    'message': str(exc_value),
                }
            recorded_videos = {}
            recorded_video_summaries = {}
            recorded_video_mode = None
            recorded_frames = {}
            recorded_frame_summaries = {}
            recorded_frame_mode = None
            if isinstance(live_video_output, dict):
                recorded_videos = live_video_output.get('videos', {})
                recorded_video_summaries = live_video_output.get('summaries', {})
                recorded_video_mode = live_video_output.get('video_mode')
                recorded_frames = live_video_output.get('frames', {})
                recorded_frame_summaries = live_video_output.get('frame_summaries', {})
                recorded_frame_mode = live_video_output.get('frame_mode')
            try:
                recorder.save(
                    task=last_task,
                    episode_idx=episode_idx,
                    metrics=metrics,
                    recorded_videos=recorded_videos,
                    recorded_video_summaries=recorded_video_summaries,
                    recorded_video_mode=recorded_video_mode,
                    recorded_frames=recorded_frames,
                    recorded_frame_summaries=recorded_frame_summaries,
                    recorded_frame_mode=recorded_frame_mode,
                    recorded_dataset=raw_dataset_output or {},
                )
                if results_output_path is not None and not results:
                    _write_json(results_output_path, [metrics])
            except Exception:
                pass
        env.close()

    return results


def search_successful_seeds(
    recipe: str,
    scene_profile: str | None,
    num_demos: int,
    start_seed: int,
    max_trials: int,
    headless: bool,
):
    candidate_seeds = list(range(start_seed, start_seed + max_trials))
    results = _run_task_sequence(
        task_configs=build_dual_franka_assembly_batch(
            recipe=recipe,
            seeds=candidate_seeds,
            scene_profile=scene_profile,
            attach_runtime_cameras=False,
        ),
        headless=headless,
    )
    success_seeds = [result['seed'] for result in results if result['success']]
    return success_seeds[:num_demos]


def collect_demos(recipe: str, scene_profile: str | None, seeds, output_dir: Path, headless: bool):
    task_configs = build_dual_franka_assembly_batch(
        recipe=recipe,
        seeds=seeds,
        scene_profile=scene_profile,
        attach_runtime_cameras=False,
    )
    return _run_task_sequence(task_configs=task_configs, headless=headless, output_dir=output_dir)


def _build_collect_worker_task_configs(
    *,
    recipes: list[str],
    seeds: list[int],
    layout_seeds: list[int] | None,
    scene_profile: str | None,
    attach_runtime_cameras: bool,
    domain_randomization_enabled: bool | None,
    randomization_profile: str | None = None,
    control_fps: int = 240,
):
    """Build a serial episode queue, including heterogeneous recipes."""
    recipes = [str(recipe) for recipe in recipes]
    seeds = [int(seed) for seed in seeds]
    if not recipes:
        raise ValueError('Collect worker requires at least one recipe.')
    if not seeds:
        raise ValueError('Collect worker requires at least one seed.')

    if len(recipes) == 1:
        episode_recipes = recipes * len(seeds)
    elif len(seeds) == 1:
        episode_recipes = recipes
        seeds = seeds * len(recipes)
    elif len(recipes) == len(seeds):
        episode_recipes = recipes
    else:
        raise ValueError(
            'A multi-recipe collect worker requires either one shared seed or one seed per recipe.'
        )

    if layout_seeds is None:
        resolved_layout_seeds = list(seeds)
    else:
        resolved_layout_seeds = [int(seed) for seed in layout_seeds]
        if len(resolved_layout_seeds) == 1 and len(episode_recipes) > 1:
            resolved_layout_seeds *= len(episode_recipes)
        if len(resolved_layout_seeds) != len(episode_recipes):
            raise ValueError(
                'Collect worker requires one shared layout seed or one --worker-layout-seeds value per episode.'
            )

    return [
        build_dual_franka_assembly_episode(
            recipe=recipe,
            seed=seed,
            layout_seed=layout_seed,
            episode_idx=episode_idx,
            scene_profile=scene_profile,
            attach_runtime_cameras=attach_runtime_cameras,
            domain_randomization_enabled=domain_randomization_enabled,
            randomization_profile=randomization_profile,
            control_fps=control_fps,
        )
        for episode_idx, (recipe, seed, layout_seed) in enumerate(
            zip(episode_recipes, seeds, resolved_layout_seeds)
        )
    ]


def _limit_worker_episode_steps(task_configs, max_steps: int | None) -> None:
    if max_steps is None:
        return
    if int(max_steps) <= 0:
        raise ValueError('--worker-max-steps must be positive.')
    for task_config in task_configs:
        task_config.max_steps = min(int(task_config.max_steps), int(max_steps))


def _apply_kinematic_replay_frame(task, trajectory, frame_index: int) -> None:
    robot_names = [str(value) for value in np.asarray(trajectory['replay_robot_names']).tolist()]
    joint_widths = [int(value) for value in np.asarray(trajectory['replay_joint_widths']).tolist()]
    joint_values = np.asarray(trajectory['replay_joint_state'][frame_index], dtype=np.float32)
    if len(robot_names) != len(joint_widths) or sum(joint_widths) != len(joint_values):
        raise ValueError('Invalid robot replay joint schema.')
    for robot_name, values in zip(robot_names, np.split(joint_values, np.cumsum(joint_widths)[:-1])):
        robot = getattr(task, 'robots', {}).get(robot_name)
        articulation = getattr(robot, 'articulation', None)
        if articulation is None:
            raise KeyError(f'Replay task is missing robot {robot_name!r}.')
        articulation.set_joint_positions(np.asarray(values, dtype=np.float32))
        try:
            articulation.set_joint_velocities(np.zeros(len(values), dtype=np.float32))
        except Exception:
            pass

    object_names = [str(value) for value in np.asarray(trajectory['tracked_object_names']).tolist()]
    positions = np.asarray(trajectory['tracked_object_position'][frame_index], dtype=np.float32)
    orientations = np.asarray(trajectory['tracked_object_orientation'][frame_index], dtype=np.float32)
    if positions.shape != (len(object_names), 3) or orientations.shape != (len(object_names), 4):
        raise ValueError('Invalid tracked-object replay pose schema.')
    for object_name, position, orientation in zip(object_names, positions, orientations):
        resolved_object = task._resolve_object(object_name)
        offset = getattr(resolved_object, 'offset', None)
        world_position = np.asarray(position, dtype=np.float32)
        if offset is not None:
            world_position = world_position + np.asarray(offset, dtype=np.float32)
        resolved_object.set_world_pose(world_position, orientation)


def _render_kinematic_replay_frame(env, task, trajectory, frame_index: int):
    """Publish one authoritative replay pose to RTX cameras."""

    _apply_kinematic_replay_frame(task, trajectory, frame_index)
    # SingleArticulation.set_joint_positions updates the PhysX tensor state.
    # A physics tick is required to propagate that state to Fabric/Replicator;
    # render-only ticks otherwise keep returning the first camera frame.
    env.warm_up(steps=1, render=True, physics=True)
    return env.get_observations()


def _run_replay_sequence(
    task_configs,
    source_metadata_paths: list[Path],
    *,
    headless: bool,
    output_dir: Path,
    results_output_path: Path,
    video_codec: str,
    video_crf: int,
    video_preset: str,
    depth_compression_level: int,
    allow_recipe_fingerprint_mismatch: bool,
) -> list[dict[str, Any]]:
    if len(task_configs) != len(source_metadata_paths):
        raise ValueError('Replay requires exactly one task config per source trajectory.')
    if not task_configs:
        raise ValueError('Replay source list is empty.')

    first_metadata = json.loads(Path(source_metadata_paths[0]).read_text(encoding='utf-8'))
    simulation_fps = int(first_metadata['simulation_fps'])
    env = _build_env(
        task_configs=task_configs,
        headless=headless,
        rendering_fps=simulation_fps,
        rendering_interval=0,
    )
    obs_list, active_configs = env.reset()
    results: list[dict[str, Any]] = []
    _write_json(results_output_path, results)
    for episode_idx, source_metadata_path in enumerate(source_metadata_paths):
        if not active_configs or active_configs[0] is None:
            raise RuntimeError(f'Replay environment ended before source {source_metadata_path}.')
        task_name = next(iter(env.runner.current_tasks))
        task = env.runner.current_tasks[task_name]
        source_metadata = json.loads(Path(source_metadata_path).read_text(encoding='utf-8'))
        if int(task.config.seed) != int(source_metadata['seed']):
            raise RuntimeError('Replay task seed does not match its authoritative trajectory.')
        source_trajectory_path = Path(source_metadata['trajectory_path'])
        recorder = CompactCartesianEpisodeRecorder(
                output_dir=output_dir,
                episode_idx=episode_idx,
                task=task,
                fps=int(source_metadata['fps']),
                frame_stride=int(source_metadata['frame_stride']),
                simulation_fps=int(source_metadata['simulation_fps']),
                rendering_interval=int(source_metadata['frame_stride']) - 1,
                record_media=True,
                video_codec=video_codec,
                video_crf=video_crf,
                video_preset=video_preset,
                depth_compression_level=depth_compression_level,
                allow_replay_recipe_fingerprint_mismatch=allow_recipe_fingerprint_mismatch,
        )
        frame_count = recorder.prepare_replay_source(Path(source_metadata_path))
        with np.load(source_trajectory_path) as trajectory:
            # Replicator cameras need several render-only ticks after reset. Set
            # the authoritative first pose before warming up so frame 0 is not
            # rendered from the recipe's nominal initial state.
            _apply_kinematic_replay_frame(task, trajectory, 0)
            obs_list = _warm_up_runtime_cameras(env)
            for frame_index in range(frame_count):
                if frame_index > 0:
                    obs_list = _render_kinematic_replay_frame(
                        env,
                        task,
                        trajectory,
                        frame_index,
                    )
                if not obs_list or not recorder.record_replay_frame(
                    obs=obs_list[0],
                    frame_index=frame_index,
                ):
                    raise RuntimeError(
                        f'Replay camera observations are unavailable at frame {frame_index}.'
                    )
                if frame_index == 0 or (frame_index + 1) % 100 == 0 or frame_index + 1 == frame_count:
                    print(
                        '[replay-progress] '
                        f'episode={episode_idx} frame={frame_index + 1}/{frame_count}',
                        flush=True,
                    )
        source_metrics = dict(source_metadata.get('metrics') or {})
        source_metrics['replay'] = {
            'mode': 'kinematic_visual_replay',
            'source_metadata_path': str(Path(source_metadata_path).resolve()),
            'frame_count': frame_count,
            'recipe_fingerprint_mismatch_allowed': bool(allow_recipe_fingerprint_mismatch),
        }
        recorded_dataset = recorder.finalize(task=task, metrics=source_metrics)
        result = dict(source_metrics)
        result['seed'] = int(source_metadata['seed'])
        result['layout_seed'] = int(source_metadata['layout_seed'])
        result['recorded_dataset'] = recorded_dataset
        results.append(_to_jsonable(result))
        _write_json(results_output_path, results)
        obs_list, active_configs = env.reset([0])
        if active_configs and active_configs[0] is not None:
            obs_list = _warm_up_runtime_cameras(env)
    return results


def _worker_mode(args, *, headless: bool):
    scene_profile = None if args.worker_scene_profile in {None, '', 'raw', 'none'} else args.worker_scene_profile
    worker_recipes = list(args.worker_recipes or [])
    if args.worker_recipe is not None:
        if worker_recipes:
            raise ValueError('Use either --worker-recipe or --worker-recipes, not both.')
        worker_recipes = [args.worker_recipe]
    if not worker_recipes:
        raise ValueError('Worker mode requires --worker-recipe or --worker-recipes.')
    if args.worker_mode == 'replay':
        source_metadata_paths = [Path(value).resolve() for value in (args.worker_replay_sources or [])]
        if not source_metadata_paths:
            raise ValueError('Replay worker mode requires --worker-replay-sources.')
        source_metadata = [json.loads(path.read_text(encoding='utf-8')) for path in source_metadata_paths]
        if len(worker_recipes) == 1:
            replay_recipes = worker_recipes * len(source_metadata)
        elif len(worker_recipes) == len(source_metadata):
            replay_recipes = worker_recipes
        else:
            raise ValueError('Replay requires one shared recipe or one recipe per source trajectory.')
        task_configs = _build_collect_worker_task_configs(
            recipes=replay_recipes,
            seeds=[int(item['seed']) for item in source_metadata],
            layout_seeds=[int(item['layout_seed']) for item in source_metadata],
            scene_profile=scene_profile,
            attach_runtime_cameras=True,
            domain_randomization_enabled=True,
            randomization_profile=args.randomization_profile,
            control_fps=max(int(args.rendering_fps), 1) if int(args.rendering_fps) > 0 else 80,
        )
        _run_replay_sequence(
            task_configs,
            source_metadata_paths,
            headless=headless,
            output_dir=Path(args.output_dir).resolve(),
            results_output_path=Path(args.worker_results_path).resolve(),
            video_codec=args.video_codec,
            video_crf=args.video_crf,
            video_preset=args.video_preset,
            depth_compression_level=args.depth_compression_level,
            allow_recipe_fingerprint_mismatch=bool(args.worker_allow_replay_fingerprint_mismatch),
        )
        return
    if args.worker_mode == 'search':
        if len(worker_recipes) != 1:
            raise ValueError('Search worker mode supports exactly one recipe.')
        task_configs = build_dual_franka_assembly_batch(
            recipe=worker_recipes[0],
            seeds=list(range(args.start_seed, args.start_seed + args.max_trials)),
            scene_profile=scene_profile,
            attach_runtime_cameras=bool(
                args.record_live_video
                or (args.record_lerobot_raw and not args.record_trajectory_only)
                or args.runtime_capture_rgb
            ),
            domain_randomization_enabled=True if args.domain_randomization else None,
            randomization_profile=args.randomization_profile,
            control_fps=max(int(args.rendering_fps), 1) if int(args.rendering_fps) > 0 else 240,
        )
        _limit_worker_episode_steps(task_configs, args.worker_max_steps)
        _run_task_sequence(
            task_configs=task_configs,
            headless=headless,
            results_output_path=Path(args.worker_results_path).resolve(),
            output_dir=Path(args.output_dir).resolve(),
            record_live_video=bool(args.record_live_video),
            live_video_fps=max(int(args.live_video_fps), 1),
            live_video_frame_stride=max(int(args.live_video_frame_stride), 1),
            keep_video_frames=bool(args.keep_video_frames),
            runtime_robochecker=bool(args.runtime_robochecker),
            runtime_feedback_path=None
            if args.runtime_feedback_path is None
            else Path(args.runtime_feedback_path).resolve(),
            runtime_observation_dir=None
            if args.runtime_observation_dir is None
            else Path(args.runtime_observation_dir).resolve(),
            runtime_checker_stride=max(int(args.runtime_checker_stride), 1),
            runtime_stop_on_violation=bool(args.runtime_stop_on_violation),
            runtime_capture_rgb=bool(args.runtime_capture_rgb),
            runtime_rgb_frame_stride=max(int(args.runtime_rgb_frame_stride), 1),
            runtime_constraint_monitor=bool(args.runtime_constraint_monitor),
            constraint_check_stride=max(int(args.constraint_check_stride), 1),
            constraint_threshold=args.constraint_threshold,
            constraint_include_ground=bool(args.constraint_include_ground),
            constraint_ignore_pairs=list(args.constraint_ignore_pair or []),
            assembly_sequence_precheck=bool(args.assembly_sequence_precheck),
            stage_trajectory_precheck=bool(args.stage_trajectory_precheck),
            stage_precheck_stride=max(int(args.stage_precheck_stride), 1),
            stage_precheck_waypoints=max(int(args.stage_precheck_waypoints), 2),
            record_episode_steps=not bool(args.skip_episode_steps or args.record_lerobot_raw),
            record_lerobot_raw=bool(args.record_lerobot_raw),
            record_trajectory_only=bool(args.record_trajectory_only),
            dataset_fps=max(int(args.dataset_fps), 1),
            dataset_frame_stride=max(int(args.dataset_frame_stride), 1),
            video_codec=args.video_codec,
            video_crf=args.video_crf,
            video_preset=args.video_preset,
            depth_compression_level=args.depth_compression_level,
            rendering_fps=(
                max(int(args.rendering_fps), 1)
                if int(args.rendering_fps) > 0
                else (240 if args.record_lerobot_raw else None)
            ),
            rendering_interval_override=args.worker_rendering_interval,
        )
        return

    if args.worker_mode != 'collect':
        raise ValueError(f'Unsupported worker mode: {args.worker_mode!r}')

    task_configs = _build_collect_worker_task_configs(
        recipes=worker_recipes,
        seeds=[int(seed) for seed in (args.worker_seeds or [])],
        layout_seeds=None
        if not args.worker_layout_seeds
        else [int(seed) for seed in args.worker_layout_seeds],
        scene_profile=scene_profile,
        attach_runtime_cameras=bool(
            args.record_live_video
            or (args.record_lerobot_raw and not args.record_trajectory_only)
            or args.runtime_capture_rgb
        ),
        domain_randomization_enabled=True if args.domain_randomization else None,
        randomization_profile=args.randomization_profile,
        control_fps=max(int(args.rendering_fps), 1) if int(args.rendering_fps) > 0 else 240,
    )
    _limit_worker_episode_steps(task_configs, args.worker_max_steps)
    _run_task_sequence(
        task_configs=task_configs,
        headless=headless,
        output_dir=Path(args.output_dir).resolve(),
        results_output_path=Path(args.worker_results_path).resolve(),
        record_live_video=bool(args.record_live_video),
        live_video_fps=max(int(args.live_video_fps), 1),
        live_video_frame_stride=max(int(args.live_video_frame_stride), 1),
        keep_video_frames=bool(args.keep_video_frames),
        runtime_robochecker=bool(args.runtime_robochecker),
        runtime_feedback_path=None
        if args.runtime_feedback_path is None
        else Path(args.runtime_feedback_path).resolve(),
        runtime_observation_dir=None
        if args.runtime_observation_dir is None
        else Path(args.runtime_observation_dir).resolve(),
        runtime_checker_stride=max(int(args.runtime_checker_stride), 1),
        runtime_stop_on_violation=bool(args.runtime_stop_on_violation),
        runtime_capture_rgb=bool(args.runtime_capture_rgb),
        runtime_rgb_frame_stride=max(int(args.runtime_rgb_frame_stride), 1),
        runtime_constraint_monitor=bool(args.runtime_constraint_monitor),
        constraint_check_stride=max(int(args.constraint_check_stride), 1),
        constraint_threshold=args.constraint_threshold,
        constraint_include_ground=bool(args.constraint_include_ground),
        constraint_ignore_pairs=list(args.constraint_ignore_pair or []),
        assembly_sequence_precheck=bool(args.assembly_sequence_precheck),
        stage_trajectory_precheck=bool(args.stage_trajectory_precheck),
        stage_precheck_stride=max(int(args.stage_precheck_stride), 1),
        stage_precheck_waypoints=max(int(args.stage_precheck_waypoints), 2),
        record_episode_steps=not bool(args.skip_episode_steps or args.record_lerobot_raw),
        record_lerobot_raw=bool(args.record_lerobot_raw),
        record_trajectory_only=bool(args.record_trajectory_only),
        dataset_fps=max(int(args.dataset_fps), 1),
        dataset_frame_stride=max(int(args.dataset_frame_stride), 1),
        video_codec=args.video_codec,
        video_crf=args.video_crf,
        video_preset=args.video_preset,
        depth_compression_level=args.depth_compression_level,
        rendering_fps=(
            max(int(args.rendering_fps), 1)
            if int(args.rendering_fps) > 0
            else (240 if args.record_lerobot_raw else None)
        ),
        rendering_interval_override=args.worker_rendering_interval,
    )


def _invoke_worker(
    *,
    mode: str,
    recipe: str,
    scene_profile: str | None,
    headless: bool,
    output_dir: Path,
    results_path: Path,
    start_seed: int,
    max_trials: int,
    seeds: list[int] | None = None,
    record_live_video: bool = False,
    live_video_fps: int = 30,
    live_video_frame_stride: int = 8,
    keep_video_frames: bool = False,
    runtime_robochecker: bool = False,
    runtime_feedback_path: Path | None = None,
    runtime_observation_dir: Path | None = None,
    runtime_checker_stride: int = 8,
    runtime_stop_on_violation: bool = True,
    runtime_capture_rgb: bool = True,
    runtime_rgb_frame_stride: int = 24,
    runtime_constraint_monitor: bool = False,
    constraint_check_stride: int = 8,
    constraint_threshold: float | None = None,
    constraint_include_ground: bool = False,
    constraint_ignore_pairs: list[str] | None = None,
    assembly_sequence_precheck: bool = False,
    stage_trajectory_precheck: bool = False,
    stage_precheck_stride: int = 64,
    stage_precheck_waypoints: int = 8,
    skip_episode_steps: bool = False,
    record_lerobot_raw: bool = False,
    dataset_fps: int = 30,
    dataset_frame_stride: int = 8,
    rendering_fps: int = 0,
    domain_randomization: bool = False,
    randomization_profile: str = 'mixed',
):
    command = [
        sys.executable,
        str(Path(__file__).resolve()),
        '--worker-mode',
        mode,
        '--worker-recipe',
        recipe,
        '--worker-results-path',
        str(results_path),
        '--output-dir',
        str(output_dir),
        '--start-seed',
        str(start_seed),
        '--max-trials',
        str(max_trials),
    ]
    if headless:
        command.append('--headless')
    if record_live_video:
        command.append('--record-live-video')
        command.extend(['--live-video-fps', str(int(live_video_fps))])
        command.extend(['--live-video-frame-stride', str(int(live_video_frame_stride))])
    if keep_video_frames:
        command.append('--keep-video-frames')
    if skip_episode_steps:
        command.append('--skip-episode-steps')
    if record_lerobot_raw:
        command.append('--record-lerobot-raw')
        command.extend(['--dataset-fps', str(int(dataset_fps))])
        command.extend(['--dataset-frame-stride', str(int(dataset_frame_stride))])
    if int(rendering_fps) > 0:
        command.extend(['--rendering-fps', str(int(rendering_fps))])
    if domain_randomization:
        command.append('--domain-randomization')
        command.extend(['--randomization-profile', str(randomization_profile)])
    if runtime_robochecker:
        command.append('--runtime-robochecker')
        command.extend(['--runtime-checker-stride', str(int(runtime_checker_stride))])
        command.extend(['--runtime-rgb-frame-stride', str(int(runtime_rgb_frame_stride))])
        if runtime_feedback_path is not None:
            command.extend(['--runtime-feedback-path', str(runtime_feedback_path)])
        if runtime_observation_dir is not None:
            command.extend(['--runtime-observation-dir', str(runtime_observation_dir)])
        if runtime_stop_on_violation:
            command.append('--runtime-stop-on-violation')
        if runtime_capture_rgb:
            command.append('--runtime-capture-rgb')
    if runtime_constraint_monitor:
        command.append('--runtime-constraint-monitor')
        command.extend(['--constraint-check-stride', str(int(constraint_check_stride))])
        if constraint_threshold is not None:
            command.extend(['--constraint-threshold', str(float(constraint_threshold))])
        if constraint_include_ground:
            command.append('--constraint-include-ground')
        for pair in constraint_ignore_pairs or []:
            command.extend(['--constraint-ignore-pair', str(pair)])
    if assembly_sequence_precheck:
        command.append('--assembly-sequence-precheck')
    if stage_trajectory_precheck:
        command.append('--stage-trajectory-precheck')
        command.extend(['--stage-precheck-stride', str(int(stage_precheck_stride))])
        command.extend(['--stage-precheck-waypoints', str(int(stage_precheck_waypoints))])
    if scene_profile is not None:
        command.extend(['--worker-scene-profile', scene_profile])
    if seeds:
        command.extend(['--worker-seeds', *[str(seed) for seed in seeds]])
    subprocess.run(command, check=True)


def _results_from_worker(
    *,
    mode: str,
    recipe: str,
    scene_profile: str | None,
    output_dir: Path,
    worker_dir: Path,
    headless: bool,
    start_seed: int,
    max_trials: int,
    seeds: list[int] | None = None,
    record_live_video: bool = False,
    live_video_fps: int = 30,
    live_video_frame_stride: int = 8,
    keep_video_frames: bool = False,
    runtime_robochecker: bool = False,
    runtime_feedback_path: Path | None = None,
    runtime_observation_dir: Path | None = None,
    runtime_checker_stride: int = 8,
    runtime_stop_on_violation: bool = True,
    runtime_capture_rgb: bool = True,
    runtime_rgb_frame_stride: int = 24,
    runtime_constraint_monitor: bool = False,
    constraint_check_stride: int = 8,
    constraint_threshold: float | None = None,
    constraint_include_ground: bool = False,
    constraint_ignore_pairs: list[str] | None = None,
    assembly_sequence_precheck: bool = False,
    stage_trajectory_precheck: bool = False,
    stage_precheck_stride: int = 64,
    stage_precheck_waypoints: int = 8,
    skip_episode_steps: bool = False,
    record_lerobot_raw: bool = False,
    dataset_fps: int = 30,
    dataset_frame_stride: int = 8,
    rendering_fps: int = 0,
    domain_randomization: bool = False,
    randomization_profile: str = 'mixed',
) -> list[dict]:
    worker_dir.mkdir(parents=True, exist_ok=True)
    results_path = worker_dir / (
        f'{_safe_filename_component(_output_profile_name(scene_profile))}'
        f'__{_safe_filename_component(recipe)}__{mode}_results.json'
    )
    if results_path.exists():
        results_path.unlink()
    _invoke_worker(
        mode=mode,
        recipe=recipe,
        scene_profile=scene_profile,
        headless=headless,
        output_dir=output_dir,
        results_path=results_path,
        start_seed=start_seed,
        max_trials=max_trials,
        seeds=seeds,
        record_live_video=record_live_video,
        live_video_fps=live_video_fps,
        live_video_frame_stride=live_video_frame_stride,
        keep_video_frames=keep_video_frames,
        runtime_robochecker=runtime_robochecker,
        runtime_feedback_path=runtime_feedback_path,
        runtime_observation_dir=runtime_observation_dir,
        runtime_checker_stride=runtime_checker_stride,
        runtime_stop_on_violation=runtime_stop_on_violation,
        runtime_capture_rgb=runtime_capture_rgb,
        runtime_rgb_frame_stride=runtime_rgb_frame_stride,
        runtime_constraint_monitor=runtime_constraint_monitor,
        constraint_check_stride=constraint_check_stride,
        constraint_threshold=constraint_threshold,
        constraint_include_ground=constraint_include_ground,
        constraint_ignore_pairs=constraint_ignore_pairs,
        assembly_sequence_precheck=assembly_sequence_precheck,
        stage_trajectory_precheck=stage_trajectory_precheck,
        stage_precheck_stride=stage_precheck_stride,
        stage_precheck_waypoints=stage_precheck_waypoints,
        skip_episode_steps=skip_episode_steps,
        record_lerobot_raw=record_lerobot_raw,
        dataset_fps=dataset_fps,
        dataset_frame_stride=dataset_frame_stride,
        rendering_fps=rendering_fps,
        domain_randomization=domain_randomization,
        randomization_profile=randomization_profile,
    )
    if not results_path.exists():
        raise RuntimeError(
            f'Worker {mode!r} for recipe {recipe!r} and scene profile {_output_profile_name(scene_profile)!r} '
            f'did not write expected results file: {results_path}'
        )
    return json.loads(results_path.read_text(encoding='utf-8'))


def _normalize_requested_items(requested_items, available_items, default_items):
    if not requested_items:
        return list(default_items)

    normalized = []
    for item in requested_items:
        if item in {'all', '*'}:
            return list(available_items)
        if item in {'none', 'raw'}:
            normalized.append(None)
            continue
        normalized.append(item)
    return normalized


def _output_profile_name(scene_profile: str | None) -> str:
    return scene_profile or 'raw'


def _safe_filename_component(value: str | None) -> str:
    value = str(value or 'raw').replace('\\', '/').rstrip('/')
    if '/' in value:
        path = Path(value)
        parent_name = path.parent.name
        value = f'{parent_name}_{path.stem}' if parent_name else path.stem
    value = re.sub(r'[^A-Za-z0-9_.-]+', '_', value).strip('._')
    return value or 'raw'


def main():
    parser = argparse.ArgumentParser(description='Generate dual-Franka assembly demos in InternUtopia.')
    parser.add_argument('--recipes', nargs='+', default=None)
    parser.add_argument('--scene-profiles', nargs='+', default=None)
    parser.add_argument('--num-demos', type=int, default=2)
    parser.add_argument('--start-seed', type=int, default=0)
    parser.add_argument('--max-trials', type=int, default=20)
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--worker-mode', choices=['search', 'collect', 'replay'], default=None)
    parser.add_argument('--worker-recipe', type=str, default=None)
    parser.add_argument('--worker-recipes', nargs='+', default=None)
    parser.add_argument('--worker-scene-profile', type=str, default=None)
    parser.add_argument('--worker-results-path', type=str, default=None)
    parser.add_argument('--worker-seeds', nargs='*', default=None)
    parser.add_argument('--worker-layout-seeds', nargs='*', default=None)
    parser.add_argument('--worker-replay-sources', nargs='*', default=None)
    parser.add_argument(
        '--worker-allow-replay-fingerprint-mismatch',
        '--worker-allow-recipe-fingerprint-mismatch',
        dest='worker_allow_replay_fingerprint_mismatch',
        action='store_true',
        help='Accept the deprecated worker flag spelling for old replay supervisors.',
    )
    parser.add_argument(
        '--worker-rendering-interval',
        type=int,
        default=None,
        help='Override sparse rendering for worker-only, non-image debug rollouts.',
    )
    parser.add_argument(
        '--worker-max-steps',
        type=int,
        default=None,
        help='Cap each worker episode for lifecycle smoke tests; omitted for full collection.',
    )
    parser.add_argument('--record-live-video', action='store_true')
    parser.add_argument('--live-video-fps', type=int, default=30)
    parser.add_argument('--live-video-frame-stride', type=int, default=8)
    parser.add_argument('--keep-video-frames', action='store_true')
    parser.add_argument('--record-lerobot-raw', action='store_true')
    parser.add_argument(
        '--record-trajectory-only',
        action='store_true',
        help='Record synchronized replay state without runtime cameras or RGB-D media.',
    )
    parser.add_argument('--dataset-fps', type=int, default=30)
    parser.add_argument('--dataset-frame-stride', type=int, default=8)
    parser.add_argument('--video-codec', choices=['h264', 'h265'], default='h264')
    parser.add_argument('--video-crf', type=int, default=23)
    parser.add_argument('--video-preset', default='veryfast')
    parser.add_argument('--depth-compression-level', type=int, default=5)
    parser.add_argument('--rendering-fps', type=int, default=0)
    parser.add_argument('--domain-randomization', action='store_true')
    parser.add_argument(
        '--randomization-profile',
        choices=RANDOMIZATION_PROFILE_CHOICES,
        default='mixed',
        help='Select one recorded domain-randomization subset; mixed preserves the legacy behavior.',
    )
    parser.add_argument(
        '--skip-episode-steps',
        action='store_true',
        help='Write metrics without retaining per-step observations; useful for low-memory debug runs.',
    )
    parser.add_argument('--runtime-robochecker', action='store_true')
    parser.add_argument('--runtime-feedback-path', type=str, default=None)
    parser.add_argument('--runtime-observation-dir', type=str, default=None)
    parser.add_argument('--runtime-checker-stride', type=int, default=8)
    parser.add_argument('--runtime-stop-on-violation', action='store_true')
    parser.add_argument('--runtime-capture-rgb', action='store_true')
    parser.add_argument('--runtime-rgb-frame-stride', type=int, default=24)
    parser.add_argument(
        '--runtime-constraint-monitor',
        action='store_true',
        help='Record passive runtime collision metrics without changing rollout behavior.',
    )
    parser.add_argument('--constraint-check-stride', type=int, default=8)
    parser.add_argument('--constraint-threshold', type=float, default=None)
    parser.add_argument('--constraint-include-ground', action='store_true')
    parser.add_argument(
        '--constraint-ignore-pair',
        action='append',
        default=[],
        metavar='A:B',
        help='Ignore a symmetric entity substring pair; may be repeated.',
    )
    parser.add_argument(
        '--assembly-sequence-precheck',
        action='store_true',
        help='Passively validate the complete phase sequence before rollout.',
    )
    parser.add_argument(
        '--stage-trajectory-precheck',
        action='store_true',
        help='Passively precheck commanded joint segments before env.step().',
    )
    parser.add_argument('--stage-precheck-stride', type=int, default=64)
    parser.add_argument('--stage-precheck-waypoints', type=int, default=8)
    parser.add_argument(
        '--output-dir',
        type=str,
        default=str(Path(__file__).resolve().parent / 'outputs' / 'factory_dual_franka_assembly'),
    )
    parser.add_argument('--headless', action='store_true')
    args = parser.parse_args()

    if args.record_live_video and (args.live_video_fps < 1 or args.live_video_frame_stride < 1):
        parser.error('Live video fps and frame stride must be positive.')

    headless = args.headless or not has_display()
    output_root = Path(args.output_dir).resolve()
    output_root.mkdir(parents=True, exist_ok=True)

    if args.worker_mode is not None:
        _worker_mode(args, headless=headless)
        return

    recipes = _normalize_requested_items(
        requested_items=args.recipes,
        available_items=list_task_recipes(),
        default_items=list_task_recipes(),
    )
    scene_profiles = _normalize_requested_items(
        requested_items=args.scene_profiles,
        available_items=list_scene_profiles(),
        default_items=[DEFAULT_SCENE_PROFILE],
    )

    overall_manifest = {}
    for scene_profile in scene_profiles:
        profile_key = _output_profile_name(scene_profile)
        overall_manifest[profile_key] = {}
        for recipe in recipes:
            recipe_spec = load_task_recipe(recipe, scene_profile=scene_profile)
            recipe_name = recipe_spec['task_name']
            recipe_dir = output_root / profile_key / recipe_name
            recipe_dir.mkdir(parents=True, exist_ok=True)

            manifest_path = recipe_dir / 'manifest.json'
            if args.resume and manifest_path.exists():
                existing_manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
                if existing_manifest.get('num_collected', 0) >= args.num_demos:
                    overall_manifest[profile_key][recipe_name] = existing_manifest
                    continue

            worker_dir = output_root / '_worker'
            search_results = _results_from_worker(
                mode='search',
                recipe=recipe,
                scene_profile=scene_profile,
                output_dir=recipe_dir,
                worker_dir=worker_dir,
                headless=headless,
                start_seed=args.start_seed,
                max_trials=args.max_trials,
                runtime_robochecker=bool(args.runtime_robochecker),
                runtime_feedback_path=None
                if args.runtime_feedback_path is None
                else Path(args.runtime_feedback_path).resolve(),
                runtime_observation_dir=None
                if args.runtime_observation_dir is None
                else Path(args.runtime_observation_dir).resolve(),
                runtime_checker_stride=max(int(args.runtime_checker_stride), 1),
                runtime_stop_on_violation=bool(args.runtime_stop_on_violation),
                runtime_capture_rgb=bool(args.runtime_capture_rgb),
                runtime_rgb_frame_stride=max(int(args.runtime_rgb_frame_stride), 1),
                runtime_constraint_monitor=bool(args.runtime_constraint_monitor),
                constraint_check_stride=max(int(args.constraint_check_stride), 1),
                constraint_threshold=args.constraint_threshold,
                constraint_include_ground=bool(args.constraint_include_ground),
                constraint_ignore_pairs=list(args.constraint_ignore_pair or []),
                assembly_sequence_precheck=bool(args.assembly_sequence_precheck),
                stage_trajectory_precheck=bool(args.stage_trajectory_precheck),
                stage_precheck_stride=max(int(args.stage_precheck_stride), 1),
                stage_precheck_waypoints=max(int(args.stage_precheck_waypoints), 2),
                skip_episode_steps=bool(args.skip_episode_steps),
                domain_randomization=bool(args.domain_randomization),
                randomization_profile=args.randomization_profile,
            )
            successful_seeds = [result['seed'] for result in search_results if result.get('success')][: args.num_demos]
            if not successful_seeds:
                raise RuntimeError(
                    f'No successful seeds found for recipe {recipe_name!r} with scene profile {profile_key!r}. '
                    'Increase max_trials or inspect the task specification.'
                )

            (recipe_dir / 'seed.txt').write_text(' '.join(str(seed) for seed in successful_seeds), encoding='utf-8')
            results = _results_from_worker(
                mode='collect',
                recipe=recipe,
                scene_profile=scene_profile,
                output_dir=recipe_dir,
                worker_dir=worker_dir,
                headless=headless,
                start_seed=args.start_seed,
                max_trials=args.max_trials,
                seeds=successful_seeds,
                record_live_video=bool(args.record_live_video),
                live_video_fps=max(int(args.live_video_fps), 1),
                live_video_frame_stride=max(int(args.live_video_frame_stride), 1),
                keep_video_frames=bool(args.keep_video_frames),
                runtime_robochecker=bool(args.runtime_robochecker),
                runtime_feedback_path=None
                if args.runtime_feedback_path is None
                else Path(args.runtime_feedback_path).resolve(),
                runtime_observation_dir=None
                if args.runtime_observation_dir is None
                else Path(args.runtime_observation_dir).resolve(),
                runtime_checker_stride=max(int(args.runtime_checker_stride), 1),
                runtime_stop_on_violation=bool(args.runtime_stop_on_violation),
                runtime_capture_rgb=bool(args.runtime_capture_rgb),
                runtime_rgb_frame_stride=max(int(args.runtime_rgb_frame_stride), 1),
                runtime_constraint_monitor=bool(args.runtime_constraint_monitor),
                constraint_check_stride=max(int(args.constraint_check_stride), 1),
                constraint_threshold=args.constraint_threshold,
                constraint_include_ground=bool(args.constraint_include_ground),
                constraint_ignore_pairs=list(args.constraint_ignore_pair or []),
                assembly_sequence_precheck=bool(args.assembly_sequence_precheck),
                stage_trajectory_precheck=bool(args.stage_trajectory_precheck),
                stage_precheck_stride=max(int(args.stage_precheck_stride), 1),
                stage_precheck_waypoints=max(int(args.stage_precheck_waypoints), 2),
                skip_episode_steps=bool(args.skip_episode_steps),
                record_lerobot_raw=bool(args.record_lerobot_raw),
                dataset_fps=max(int(args.dataset_fps), 1),
                dataset_frame_stride=max(int(args.dataset_frame_stride), 1),
                rendering_fps=max(int(args.rendering_fps), 0),
                domain_randomization=bool(args.domain_randomization),
                randomization_profile=args.randomization_profile,
            )
            runtime_failed_results = _runtime_failed_results(results) if args.runtime_robochecker else []
            if runtime_failed_results:
                _write_json(recipe_dir / 'runtime_failed_results.json', runtime_failed_results)
                failed_seeds = [result.get('seed') for result in runtime_failed_results]
                raise RuntimeError(
                    f'Runtime RoboChecker rejected collected demos for recipe {recipe_name!r}; '
                    f'failed seeds: {failed_seeds}. Inspect runtime_feedback.json and runtime_observations.'
                )
            manifest = {
                'recipe': recipe_name,
                'recipe_request': recipe,
                'scene_profile': scene_profile,
                'scene_profile_key': profile_key,
                'spec_path': recipe_spec.get('spec_path'),
                'scene_profile_path': recipe_spec.get('scene_profile_path'),
                'prompt': recipe_spec.get('prompt'),
                'task_description': recipe_spec.get('task_description') or recipe_spec.get('prompt'),
                'annotation_name': recipe_spec.get('annotation_name', ''),
                'annotation_path': recipe_spec.get('annotation_path'),
                'annotation_title': recipe_spec.get('annotation_title', ''),
                'annotation_summary': recipe_spec.get('annotation_summary', ''),
                'annotation_description': recipe_spec.get('annotation_description', ''),
                'annotation_tags': _to_jsonable(recipe_spec.get('annotation_tags', [])),
                'annotation_metadata': _to_jsonable(recipe_spec.get('annotation_metadata', {})),
                'annotation_object_roles': _to_jsonable(recipe_spec.get('annotation_object_roles', {})),
                'annotation_target_roles': _to_jsonable(recipe_spec.get('annotation_target_roles', {})),
                'annotation_phase_notes': _to_jsonable(recipe_spec.get('annotation_phase_notes', [])),
                'target_annotations': _to_jsonable(recipe_spec.get('target_annotations', {})),
                'phase_annotations': _to_jsonable(recipe_spec.get('phase_annotations', [])),
                'workspace_offset': recipe_spec.get('workspace_offset', [0.0, 0.0, 0.0]),
                'num_requested': args.num_demos,
                'num_collected': len(results),
                'headless': headless,
                'record_live_video': bool(args.record_live_video),
                'live_video_fps': max(int(args.live_video_fps), 1),
                'live_video_frame_stride': max(int(args.live_video_frame_stride), 1),
                'runtime_robochecker': bool(args.runtime_robochecker),
                'runtime_feedback_path': args.runtime_feedback_path,
                'runtime_observation_dir': args.runtime_observation_dir,
                'runtime_checker_stride': max(int(args.runtime_checker_stride), 1),
                'runtime_stop_on_violation': bool(args.runtime_stop_on_violation),
                'runtime_capture_rgb': bool(args.runtime_capture_rgb),
                'runtime_rgb_frame_stride': max(int(args.runtime_rgb_frame_stride), 1),
                'record_lerobot_raw': bool(args.record_lerobot_raw),
                'dataset_fps': max(int(args.dataset_fps), 1),
                'dataset_frame_stride': max(int(args.dataset_frame_stride), 1),
                'domain_randomization': bool(args.domain_randomization),
                'randomization_profile': args.randomization_profile,
                'successful_seeds': successful_seeds,
                'asset_references': _to_jsonable(recipe_spec.get('asset_references', [])),
                'metadata': _to_jsonable(recipe_spec.get('metadata', {})),
                'results': _to_jsonable(results),
            }
            manifest_path.write_text(json.dumps(manifest, indent=2), encoding='utf-8')
            overall_manifest[profile_key][recipe_name] = manifest

    (output_root / 'manifest.json').write_text(json.dumps(overall_manifest, indent=2), encoding='utf-8')
    print(json.dumps(overall_manifest, indent=2))


if __name__ == '__main__':
    main()

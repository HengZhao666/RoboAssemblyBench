"""Read-only S03 first-failure CAD witness; no simulator or production edits.

This deliberately analyzes the named fixture/held-part pair, with the original
full-scene checker also evaluated at the reconstructed failed sweep endpoints.
It does not certify a changed controller or grant a collision exemption.
"""
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import fcl
from stool_geometry_guard import StoolMeshGuard,ARM,_inverse
from stool_sweep_model import SceneModel
from compare_stool_geometry_cache import build_checker,native_matrix
from toolkits.constraint_checking.integration.entity_geometry import pose_matrix


def load(path):return json.loads(path.read_text())
def lines(path):return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',type=Path,required=True)
    parser.add_argument('--output-dir',type=Path,required=True)
    args=parser.parse_args();run=args.run.resolve();out=args.output_dir.resolve()
    out.mkdir(parents=True,exist_ok=False)
    report=dict(passed=False,native_physics_executed=0,production_control_modified=False,errors=[])
    paths={name:run/name for name in ('scene_geometry.json','stool_geometry_initial.json',
        'task_config_snapshot.json','production_control_failure.json','stool_production_geometry.jsonl',
        'independent_native_trace.jsonl','assisted_trace.jsonl','motion_trace.jsonl')}
    report['input_sha256']={name:sha(path) for name,path in paths.items()}
    try:
        data=load(paths['scene_geometry.json']);initial=load(paths['stool_geometry_initial.json'])
        config=load(paths['task_config_snapshot.json']);config=config[0] if isinstance(config,list) else config
        phases={row['name']:row for row in config['phase_specs']}
        failure=load(paths['production_control_failure.json'])
        failed=[row for row in lines(paths['stool_production_geometry.jsonl']) if not row['passed']][0]
        if failure['physics_stamp']!=failed['physics_stamp']:raise ValueError('failure native stamp mismatch')
        stamp=failed['physics_stamp'];collision=failed['first_failure']['collision']
        part=next(mesh['object'] for mesh in data['visible_meshes'] if mesh['prim']==collision['mesh_b'])
        pair=[next(mesh for mesh in data['visible_meshes'] if mesh['prim']==collision[key]) for key in ('mesh_a','mesh_b')]
        if part!='fabrica_stool_circular_3' or failed['first_failure']['fraction']!=0:
            raise ValueError('utility only diagnoses the actual S03 part3 fraction0 witness')
        events=lines(paths['assisted_trace.jsonl'])
        attach=[row for row in events if row.get('event')=='attach_measured_pose' and row.get('object')==part
                and row['physics_stamp']['index']<=stamp['index']][-1]
        frozen=_inverse(pose_matrix(attach['native_hand_position'],attach['native_hand_orientation']))@pose_matrix(attach['position'],attach['orientation'])
        holder=attach['robot'];hand=data['robots'][holder]['root_path']+'/wrist_3_link';body=data['object_body_coverage'][part][0]
        model=SceneModel(paths['scene_geometry.json']);checker=build_checker(StoolMeshGuard,data,initial,model)
        checker.task=SimpleNamespace(_attachments={part:dict(robot_name=holder)})
        checker.task.get_current_phase_spec=lambda:phases[failed['phase']]
        shapes=[]
        for mesh in pair:
            points=np.asarray(mesh['points'],float);faces=np.asarray(mesh['triangles'],np.int32)
            shape=fcl.BVHModel();shape.beginModel(len(faces),len(points));shape.addSubModel(points,faces);shape.endModel()
            shapes.append(fcl.CollisionObject(shape))
        def pair_check(poses):
            for obj,mesh in zip(shapes,pair):
                matrix=poses[mesh['body']];obj.setTransform(fcl.Transform(matrix[:3,:3],matrix[:3,3]))
            result=fcl.CollisionResult();hit=fcl.collide(*shapes,fcl.CollisionRequest(num_max_contacts=8,enable_contact=True),result)
            return dict(hit=int(hit),max_depth_m=max((float(c.penetration_depth) for c in result.contacts),default=0.),
                contacts=[dict(depth_m=float(c.penetration_depth),position=np.asarray(c.pos).tolist(),normal=np.asarray(c.normal).tolist()) for c in result.contacts])
        raw=lines(paths['independent_native_trace.jsonl']);unique={}
        for row in raw:
            if row.get('valid') and row['physics_stamp']['epoch']==stamp['epoch']:
                unique[row['physics_stamp']['index']]=row
        exact=[row for row in raw if row.get('valid') and row['physics_stamp']==stamp]
        if not exact:raise ValueError('no complete native raw body/q snapshot at first-failure clock')
        report.update(first_failure=failed,initial_support_pair=[row for row in initial['baseline_support_pairs'] if row['part']==part],
            attach_capture={key:attach[key] for key in ('step','phase','physics_stamp','robot','position','orientation','native_hand_position','native_hand_orientation')},
            frozen_hand_object_matrix=frozen.tolist(),same_clock_raw_boundaries=[row['boundary'] for row in exact])
        history=[];previous=None;failed_poses=None;pred0=None;native0=None;actual_q0=None
        # Six prior retained physical samples and one subsequent retained sample.
        indices=[i for i in sorted(unique) if i<=stamp['index']][-7:]+[i for i in sorted(unique) if i>stamp['index']][:1]
        for index in indices:
            row=unique[index];native={path:np.asarray(value,float) for path,value in data['body_rest'].items()}
            native.update({path:native_matrix(value['transform']) for path,value in row['bodies'].items()})
            actual_q={name:np.asarray(value['positions'],float) for name,value in row['robots'].items()}
            origin=model.poses(actual_q);robot_bodies={mesh['body'] for mesh in data['visible_meshes'] if mesh['robot']}
            poses=dict(native)
            for path in robot_bodies:poses[path]=(native[path]@_inverse(origin[path]))@origin[path]
            poses[body]=poses[hand]@frozen
            error=poses[body][:3,3]-native[body][:3,3]
            angle=float(np.arccos(np.clip((np.trace(poses[body][:3,:3].T@native[body][:3,:3])-1)/2,-1,1)))
            entry=dict(native_stamp=row['physics_stamp'],task_step=row['task_step'],phase=row['phase'],boundary=row['boundary'],
                native_part_matrix=native[body].tolist(),native_hand_matrix=native[hand].tolist(),predicted_fraction0_part_matrix=poses[body].tolist(),
                predicted_minus_native_translation_m=error.tolist(),position_residual_m=float(np.linalg.norm(error)),orientation_residual_rad=angle,
                native_velocity=row['bodies'][body]['velocity'],native_pair=pair_check(native),predicted_fraction0_pair=pair_check(poses),
                retained_sample_delta_ticks=None if previous is None else index-previous[0],
                native_part_translation_since_prior_retained_m=None if previous is None else (native[body][:3,3]-previous[1]).tolist())
            previous=(index,native[body][:3,3]);history.append(entry)
            if index==stamp['index']:failed_poses=poses;pred0=poses[body];native0=native;actual_q0=actual_q
        if failed_poses is None:raise ValueError('missing reconstructed failed scene')
        report['retained_native_history']=history
        report['history_scope']='nearest six prior retained samples plus failure and next retained sample; raw cadence is 8, so absent physical ticks are not inferred'
        report['full_scene_failed_fraction0_replay']=checker._check_scene(failed_poses)
        report['full_scene_native_replay']=checker._check_scene(native0)
        report['reported_depth_reproduced_error_m']=abs(pair_check(failed_poses)['max_depth_m']-collision['depth_m'])
        motion=[row for row in lines(paths['motion_trace.jsonl']) if row['step']==failed['step'] and row['robot']==holder][-1]
        final={name:q.copy() for name,q in actual_q0.items()};names=data['robots'][holder]['joint_names'];arm=[names.index(name) for name in ARM]
        request=np.asarray(motion['command_q'],float);final[holder][arm]=request.astype(np.float32).astype(float)
        origin=model.poses(actual_q0);fk=model.poses(final);endpoint=dict(native0)
        for path in {mesh['body'] for mesh in data['visible_meshes'] if mesh['robot']}:
            endpoint[path]=(native0[path]@_inverse(origin[path]))@fk[path]
        endpoint[body]=endpoint[hand]@frozen
        points=np.asarray(pair[1]['points'],float);v0=points@pred0[:3,:3].T+pred0[:3,3];v1=points@endpoint[body][:3,:3].T+endpoint[body][:3,3]
        report['requested_active_arm_endpoint']=dict(motion=motion,
            reconstruction_scope='float32 active arm motion_trace command; no new SDK action or physics; passive robot held at current q for this diagnostic',
            arm_delta_rad=(final[holder][arm]-actual_q0[holder][arm]).tolist(),
            part_world_translation_m=(endpoint[body][:3,3]-pred0[:3,3]).tolist(),
            part_all_cad_vertex_z_delta_range_m=[float((v1-v0)[:,2].min()),float((v1-v0)[:,2].max())],
            part_all_cad_vertex_max_displacement_m=float(np.linalg.norm(v1-v0,axis=1).max()),
            pair=pair_check(endpoint),full_scene=checker._check_scene(endpoint),
            predicted_part_matrix=endpoint[body].tolist())
        probes=[]
        for delta in (-.0001,-.00001,-.000005,-.000001,0.,.000001,.000005,.00001,.0001):
            poses=dict(failed_poses);matrix=pred0.copy();matrix[2,3]+=delta;poses[body]=matrix
            probes.append(dict(world_z_delta_m=delta,pair=pair_check(poses)))
        report['fraction0_world_z_translation_probes']=probes
        report['inputs_unchanged']=all(sha(path)==report['input_sha256'][name] for name,path in paths.items())
        report['passed']=report['inputs_unchanged'] and report['reported_depth_reproduced_error_m']<1e-10
    except Exception as exc:report['errors'].append(type(exc).__name__+': '+str(exc))
    (out/'support_exit_analysis.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({key:report.get(key) for key in ('passed','reported_depth_reproduced_error_m','inputs_unchanged','errors')}))
    return 0 if report['passed'] else 1

if __name__=='__main__':raise SystemExit(main())

"""Build and record the original real stool worker configuration; no simulator."""
import json
import sys
from pathlib import Path
from toolkits.factory_dual_franka_assembly.generate_demos import _build_collect_worker_task_configs

configs = _build_collect_worker_task_configs(
    recipes=['fabrica_stool_circular_ur5e_staged'], seeds=[0], layout_seeds=[4906],
    scene_profile='taoyuan_grscenes_tabletop', attach_runtime_cameras=True,
    domain_randomization_enabled=True, control_fps=240)
path = Path('../baseline/original_worker_config.json')
data = [c.model_dump(mode='python', serialize_as_any=True) for c in configs]
path.write_text(json.dumps(data, indent=2, default=str) + '\n')
print(json.dumps(dict(passed=True, config_path=str(path.resolve()), configs=len(configs),
    phase_count=len(configs[0].phase_specs), python=sys.executable,
    max_steps=configs[0].max_steps, simulator_created=False), default=str))

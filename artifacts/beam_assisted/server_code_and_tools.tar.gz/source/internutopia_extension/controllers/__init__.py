import os


if os.environ.get('INTERNUTOPIA_EXTENSION_PROFILE', '').endswith('_assembly'):
    from internutopia_extension.controllers import gripper_controller, ik_controller, joint_controller
else:
    from internutopia_extension.controllers import (
        aliengo_move_by_speed_controller,
        dd_controller,
        franka_mocap_teleop_controller,
        g1_move_by_speed_controller,
        gr1_move_by_speed_controller,
        gr1_teleop_controller,
        gripper_controller,
        h1_move_by_speed_controller,
        ik_controller,
        joint_controller,
        layout_edit_mocap_controller,
        move_along_path_points_controller,
        move_to_point_by_speed_controller,
        move_to_point_oracle_controller,
        recover_controller,
        rmpflow_controller,
        rotate_controller,
        rotate_oracle,
    )

"""Verify the three original stool MP4s once; never edit or re-encode media.

Creates media_verification.json exclusively. ffprobe preserves container/packet
clock evidence and ffmpeg performs one complete decode per existing original.
SHA verification binds the same original bytes before/after that decode; an
optional transfer manifest additionally binds the expected source SHA.
"""
from __future__ import annotations
import argparse,collections,datetime,hashlib,json,math,os,shutil,subprocess,sys
from pathlib import Path

EXPECTED={
    'observation.images.front':'observation_images_front.mp4',
    'observation.images.left_wrist':'observation_images_left_wrist.mp4',
    'observation.images.right_wrist':'observation_images_right_wrist.mp4',
}


def video_key(value):
    return 'observation.images.front' if value in {'observation.images.isaac_3d','observation.images.third_person'} else value


def digest(path):
    result=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):result.update(block)
    return result.hexdigest()


def finite(value):
    try:
        number=float(value)
        return number if math.isfinite(number) else None
    except (TypeError,ValueError):return None


def integer(value):
    try:return int(value)
    except (TypeError,ValueError):return None


def read_json(path,errors,label):
    try:return json.loads(path.read_text())
    except (OSError,ValueError) as exc:errors.append(label+': '+repr(exc));return None


def ffmpeg_paths(run,requested=None):
    candidates=[]
    if requested:candidates.append(Path(requested))
    elif os.environ.get('STOOL_FFMPEG_BIN'):candidates.append(Path(os.environ['STOOL_FFMPEG_BIN']))
    else:
        candidates.extend(parent/'runtime_tools'/'bin' for parent in (run,*run.parents))
    for directory in candidates:
        if (directory/'ffmpeg').is_file() and (directory/'ffprobe').is_file():
            return dict(ffmpeg=str((directory/'ffmpeg').resolve()),ffprobe=str((directory/'ffprobe').resolve()))
    if requested or os.environ.get('STOOL_FFMPEG_BIN'):
        raise FileNotFoundError('Requested runtime_tools/bin does not contain ffmpeg and ffprobe')
    found={name:shutil.which(name) for name in ('ffmpeg','ffprobe')}
    if not all(found.values()):raise FileNotFoundError('No existing ffmpeg/ffprobe pair; pass --ffmpeg-bin runtime_tools/bin')
    return found


def discover_originals(run):
    errors=[];episode_paths=sorted(run.glob('episode_[0-9][0-9][0-9][0-9].json'))
    metadata=None;metadata_path=None
    if len(episode_paths)>1:errors.append('more than one episode metadata file; original media membership is ambiguous')
    if len(episode_paths)==1:
        metadata_path=episode_paths[0];metadata=read_json(metadata_path,errors,'episode metadata')
    camera_rows=[dict(row,video_key=video_key(row.get('video_key'))) for row in (metadata or {}).get('camera_metadata',[])]
    if len({row.get('video_key') for row in camera_rows})!=len(camera_rows):errors.append('duplicate production-normalized camera aliases')
    if camera_rows and {row.get('video_key') for row in camera_rows}!=set(EXPECTED):
        errors.append('episode camera metadata does not contain exactly the expected three stool video keys')
    declared_raw=(metadata or {}).get('recorded_videos') or {}
    declared={video_key(key):value for key,value in declared_raw.items()}
    if len(declared)!=len(declared_raw):errors.append('duplicate production-normalized recorded video aliases')
    if declared and set(declared)!=set(EXPECTED):errors.append('recorded_videos membership differs from expected three originals')
    summaries={video_key(key):value for key,value in ((metadata or {}).get('recorded_video_summaries') or {}).items()}
    roots=sorted(path for path in run.glob('episode_[0-9][0-9][0-9][0-9]_live_videos') if path.is_dir())
    observed=sorted(path for root in roots for path in root.glob('*.mp4'))
    if len(observed)!=3:errors.append('original live-video directories contain '+str(len(observed))+' MP4s; exactly three required')
    unexpected=[str(path.relative_to(run)) for path in observed if path.name not in set(EXPECTED.values())]
    if unexpected:errors.append('unexpected MP4s in original live-video directories: '+repr(unexpected))
    rows=[]
    for camera,filename in EXPECTED.items():
        candidates=[path for path in observed if path.name==filename]
        row=dict(camera=camera,expected_filename=filename,declared_path=declared.get(camera),
            declared_summary=summaries.get(camera),expected_resolution=next((c.get('resolution') for c in camera_rows if c.get('video_key')==camera),None))
        if len(candidates)!=1:
            row.update(path=None,error='original missing or ambiguous',matching_paths=[str(p.relative_to(run)) for p in candidates])
            errors.append(camera+': original missing or ambiguous')
        else:
            row['path']=str(candidates[0].relative_to(run))
            if not candidates[0].resolve().is_relative_to(run):
                errors.append(camera+': original file symlink escapes this run');row['error']='original escapes run'
            if declared.get(camera) and Path(declared[camera]).name!=filename:
                errors.append(camera+': metadata filename does not identify the expected original')
        rows.append(row)
    return rows,errors,dict(episode_metadata=str(metadata_path.relative_to(run)) if metadata_path else None,
        recorded_video_mode=(metadata or {}).get('recorded_video_mode'),
        original_mp4_paths=[str(p.relative_to(run)) for p in observed],unexpected_mp4s=unexpected,
        production_video_key_aliases={'observation.images.isaac_3d':'observation.images.front','observation.images.third_person':'observation.images.front'},
        discovery='exact expected filenames within original episode_*_live_videos directories; copied metadata absolute paths never dereferenced outside run')


def run_command(arguments,log_prefix,timeout):
    result=dict(command=arguments,exit_code=None,timeout=False)
    try:
        completed=subprocess.run(arguments,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=timeout,check=False)
        result.update(exit_code=completed.returncode,stdout=completed.stdout,stderr=completed.stderr)
    except subprocess.TimeoutExpired as exc:
        stdout=exc.stdout or '';stderr=exc.stderr or ''
        result.update(timeout=True,stdout=stdout.decode(errors='replace') if isinstance(stdout,bytes) else stdout,
            stderr=stderr.decode(errors='replace') if isinstance(stderr,bytes) else stderr,error=repr(exc))
    except OSError as exc:result.update(stdout='',stderr='',error=repr(exc))
    Path(str(log_prefix)+'.stdout.txt').write_text(result.get('stdout',''))
    Path(str(log_prefix)+'.stderr.txt').write_text(result.get('stderr',''))
    return result


def probe_original(path,binaries,logs,timeout):
    metadata=run_command([binaries['ffprobe'],'-v','error','-select_streams','v:0','-show_streams','-show_format','-of','json',str(path)],logs/'ffprobe_metadata',timeout)
    packets=run_command([binaries['ffprobe'],'-v','error','-select_streams','v:0','-show_packets','-show_entries','packet=pts_time,dts_time,duration_time','-of','json',str(path)],logs/'ffprobe_packets',timeout)
    result=dict(passed=False,metadata_exit_code=metadata['exit_code'],packet_probe_exit_code=packets['exit_code'],
        metadata_stderr=metadata.get('stderr',''),packet_probe_stderr=packets.get('stderr',''),
        metadata_command=metadata['command'],packet_command=packets['command'],
        note='packet PTS/DTS are container sample timestamps; decoded frame count is independently provided by the single full ffmpeg decode')
    try:
        if metadata['exit_code']!=0 or packets['exit_code']!=0:raise RuntimeError('ffprobe metadata/packet query failed or timed out')
        info=json.loads(metadata['stdout']);packet_rows=json.loads(packets['stdout']).get('packets',[])
        streams=info.get('streams',[])
        if len(streams)!=1:raise RuntimeError('expected exactly one selected video stream')
        stream=streams[0];container=info.get('format',{})
        result.update(width=integer(stream.get('width')),height=integer(stream.get('height')),
            codec=stream.get('codec_name'),stream_frame_count=integer(stream.get('nb_frames')),
            stream_duration_s=finite(stream.get('duration')),container_duration_s=finite(container.get('duration')),
            start_time_s=finite(stream.get('start_time',container.get('start_time'))),time_base=stream.get('time_base'),
            avg_frame_rate=stream.get('avg_frame_rate'),r_frame_rate=stream.get('r_frame_rate'),container=container,stream=stream)
        pts=[finite(p.get('pts_time')) for p in packet_rows];dts=[finite(p.get('dts_time')) for p in packet_rows]
        durations=[finite(p.get('duration_time')) for p in packet_rows]
        valid_pts=[x for x in pts if x is not None];valid_dts=[x for x in dts if x is not None]
        ordered=sorted(valid_pts)
        result['timestamps']=dict(packet_count=len(packet_rows),finite_pts_count=len(valid_pts),finite_dts_count=len(valid_dts),
            first_packet_pts_s=pts[0] if pts else None,last_packet_pts_s=pts[-1] if pts else None,
            minimum_pts_s=min(valid_pts) if valid_pts else None,maximum_pts_s=max(valid_pts) if valid_pts else None,
            first_packet_dts_s=dts[0] if dts else None,last_packet_dts_s=dts[-1] if dts else None,
            dts_nondecreasing=all(b>=a for a,b in zip(valid_dts,valid_dts[1:])),
            duplicate_presentation_timestamps=len(ordered)-len(set(ordered)),
            minimum_positive_presentation_step_s=min((b-a for a,b in zip(ordered,ordered[1:]) if b>a),default=None),
            packet_duration_min_s=min((x for x in durations if x is not None),default=None),
            packet_duration_max_s=max((x for x in durations if x is not None),default=None),
            complete_raw_timestamps='ffprobe_packets.stdout.txt')
        if not result['width'] or not result['height'] or result['width']<=0 or result['height']<=0:raise RuntimeError('invalid video dimensions')
        if not result['container_duration_s'] or result['container_duration_s']<=0:raise RuntimeError('video container duration missing/nonpositive')
        if not packet_rows or len(valid_pts)!=len(packet_rows):raise RuntimeError('video packet presentation timestamps missing/nonfinite')
        if result['timestamps']['duplicate_presentation_timestamps']:raise RuntimeError('duplicate packet presentation timestamps')
        result['passed']=True
    except (ValueError,KeyError,TypeError,RuntimeError) as exc:result['error']=repr(exc)
    return result


def decode_original(path,binaries,logs,timeout):
    result=run_command([binaries['ffmpeg'],'-hide_banner','-v','error','-nostats','-xerror','-err_detect','explode',
        '-progress','pipe:1','-i',str(path),'-map','0:v:0','-an','-fps_mode','passthrough','-f','null','-'],logs/'full_decode',timeout)
    progress={}
    for line in result.get('stdout','').splitlines():
        if '=' in line:
            key,value=line.split('=',1);progress[key.strip()]=value.strip()
    frames=integer(progress.get('frame'))
    return dict(passed=result['exit_code']==0 and not result.get('stderr','').strip()
        and progress.get('progress')=='end' and frames is not None and frames>0,
        exit_code=result['exit_code'],timeout=result['timeout'],stderr=result.get('stderr',''),
        frame_count=frames,progress=progress,command=result['command'],
        scope='one full ffmpeg video-stream decode from beginning through EOF; no re-encode or clip sampling')


def clock_counts(run):
    path=run/'video_frame_clock.jsonl';counts=collections.Counter();indices={k:[] for k in EXPECTED}
    valid_native=collections.Counter();valid_reference=collections.Counter();segments=collections.Counter();errors=[]
    if not path.is_file():return dict(passed=False,errors=['video_frame_clock.jsonl missing'],frame_counts={k:0 for k in EXPECTED})
    with path.open() as stream:
        for number,line in enumerate(stream,1):
            if not line.strip():continue
            try:
                row=json.loads(line);camera=video_key(row.get('camera'))
                if camera not in EXPECTED:raise ValueError('unexpected camera '+str(camera))
                counts[camera]+=1;indices[camera].append(row.get('frame_index'))
                valid_native[camera]+=row.get('physics_stamp',{}).get('valid') is True
                valid_reference[camera]+=row.get('render_reference_time',{}).get('valid') is True
                segments[str(row.get('capture_segment','unknown'))]+=1
            except (ValueError,TypeError) as exc:errors.append(dict(line=number,error=repr(exc)))
    for camera in EXPECTED:
        if indices[camera]!=list(range(counts[camera])):errors.append(camera+': clock frame_index is not consecutive from zero')
    return dict(passed=not errors,errors=errors,frame_counts={k:counts[k] for k in EXPECTED},
        valid_native_clock_counts={k:valid_native[k] for k in EXPECTED},
        valid_reference_time_counts={k:valid_reference[k] for k in EXPECTED},capture_segments=dict(segments),
        raw_clock_sha256=digest(path),scope='raw retained clock-line membership/count/index; physical terminal clock join is a separate audit')


def expected_hashes(path,run):
    if path is None:return {},None
    manifest=json.loads(Path(path).read_text());rows=manifest.get('files',manifest) if isinstance(manifest,dict) else manifest
    hashes={}
    if isinstance(rows,dict):
        for key,row in rows.items():
            if isinstance(row,dict) and row.get('sha256'):hashes[str(key)]=row['sha256']
    elif isinstance(rows,list):
        for row in rows:
            if isinstance(row,dict) and row.get('sha256'):
                key=row.get('relative_path') or row.get('path')
                if key:hashes[str(key)]=row['sha256']
    if not hashes:raise ValueError('Expected manifest has no file SHA256 records')
    return hashes,dict(path=str(Path(path).resolve()),sha256=digest(path))


def verify_media(run,*,ffmpeg_bin=None,expected_manifest=None,timeout=1800,output_name='media_verification.json'):
    run=Path(run).resolve()
    if not run.is_dir():raise NotADirectoryError(run)
    if Path(output_name).name!=output_name or not output_name.endswith('.json'):
        raise ValueError('output_name must be one JSON basename within the run')
    output=run/output_name
    initial=dict(status='running',all_three_original_videos_decoded=False,sha256_verified=False,
        started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),run=str(run),report_file=output_name,files=[],errors=[])
    # Reserve this one-shot report before any decode. A previous report is never overwritten.
    with output.open('x') as destination:
        destination.write(json.dumps(initial,indent=2)+'\n');destination.flush()
        report=initial
        try:
            binaries=ffmpeg_paths(run,ffmpeg_bin);report['binaries']=binaries
            rows,errors,discovery=discover_originals(run);report['errors'].extend(errors);report['discovery']=discovery;report['original_membership_passed']=not errors
            hashes,manifest_binding=expected_hashes(expected_manifest,run);report['expected_manifest']=manifest_binding
            logs_root=run/(Path(output_name).stem+'_logs');logs_root.mkdir(exist_ok=False)
            capability=run_command([binaries['ffmpeg'],'-hide_banner','-h','full'],logs_root/'ffmpeg_help',min(timeout,60))
            report['binary_capabilities']=dict(help_exit_code=capability['exit_code'],
                fps_mode_supported='-fps_mode' in (capability.get('stdout','')+capability.get('stderr','')),
                help_log=str((logs_root/'ffmpeg_help.stdout.txt').relative_to(run)),
                synchronization='-fps_mode passthrough; do not synthesize/drop decoded output frames')
            if capability['exit_code']!=0 or not report['binary_capabilities']['fps_mode_supported']:
                raise RuntimeError('actual FFmpeg help does not advertise required -fps_mode; no decode attempted')
            for row in rows:
                if not row.get('path') or row.get('error'):
                    row.update(decoded=False,sha256_verified=False);report['files'].append(row);continue
                path=run/row['path'];logs=logs_root/row['camera'].replace('.','_');logs.mkdir(exist_ok=True)
                row.update(size_bytes=path.stat().st_size,sha256_before=digest(path),logs=str(logs.relative_to(run)))
                row['probe']=probe_original(path,binaries,logs,timeout)
                row['decode']=decode_original(path,binaries,logs,timeout)
                row['sha256']=digest(path);row['sha256_after']=row['sha256']
                matched=[value for key,value in hashes.items() if key==row['path'] or Path(key).name==path.name]
                row['expected_sha256']=matched[0] if len(matched)==1 else None
                if hashes and len(matched)!=1:report['errors'].append(row['camera']+': expected manifest missing or ambiguous SHA')
                row['sha256_verified']=bool(row['sha256_before']==row['sha256_after'] and row['size_bytes']>0
                    and (not hashes or (len(matched)==1 and matched[0]==row['sha256_after'])))
                row['decoded']=row['decode']['passed']
                if row['probe'].get('stream_frame_count') is not None:
                    row['decoded_count_matches_container']=row['decode']['frame_count']==row['probe']['stream_frame_count']
                    if not row['decoded_count_matches_container']:report['errors'].append(row['camera']+': decoded/container frame counts differ')
                if row.get('expected_resolution'):
                    row['dimensions_match_metadata']=[row['probe'].get('width'),row['probe'].get('height')]==row['expected_resolution']
                    if not row['dimensions_match_metadata']:report['errors'].append(row['camera']+': video dimensions differ from camera metadata')
                if not row['probe']['passed']:report['errors'].append(row['camera']+': ffprobe validation failed')
                if not row['decoded']:report['errors'].append(row['camera']+': full decode failed')
                if not row['sha256_verified']:report['errors'].append(row['camera']+': SHA before/after/expected verification failed')
                report['files'].append(row)
            clocks=clock_counts(run);report['raw_clock']=clocks;report['errors'].extend(clocks['errors'])
            for row in report['files']:
                decoded=(row.get('decode') or {}).get('frame_count');count=clocks['frame_counts'].get(row['camera'],0)
                row['raw_clock_frame_count']=count;row['clock_count_matches_decoded']=decoded==count
                if decoded!=count:report['errors'].append(row['camera']+': raw clock/decoded frame counts differ')
                summary=row.get('declared_summary') or {}
                if 'frame_count' in summary:
                    row['episode_count_matches_decoded']=summary['frame_count']==decoded
                    if not row['episode_count_matches_decoded']:report['errors'].append(row['camera']+': episode/decoded frame counts differ')
            complete=len(report['files'])==3 and {r['camera'] for r in report['files']}==set(EXPECTED)
            report['all_three_original_videos_decoded']=bool(report['original_membership_passed'] and complete and all(r.get('decoded') for r in report['files'])
                and len(discovery['original_mp4_paths'])==3 and not discovery.get('unexpected_mp4s'))
            report['sha256_verified']=bool(complete and all(r.get('sha256_verified') for r in report['files']))
            frames=[(r.get('decode') or {}).get('frame_count') for r in report['files']]
            report['diagnostic_only']=bool(complete and all(count==1 for count in frames))
            report['content_classification']='three one-frame startup diagnostic videos' if report['diagnostic_only'] else 'retained original rollout or failure videos; task outcome requires independent audit'
            report['assembly_outcome_proven']=False
            report['sha256_verified_scope']='same original file bytes before/after full decode'+('; additionally compared with supplied expected manifest' if hashes else '; transfer SHA identity is separate')
            report['status']='passed' if not report['errors'] and report['all_three_original_videos_decoded'] and report['sha256_verified'] else 'failed_or_incomplete'
        except Exception as exc:
            report['errors'].append(type(exc).__name__+': '+str(exc));report['status']='failed_or_incomplete'
        report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        destination.seek(0);destination.write(json.dumps(report,indent=2,allow_nan=False)+'\n');destination.truncate();destination.flush();os.fsync(destination.fileno())
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('run',type=Path)
    parser.add_argument('--ffmpeg-bin',type=Path);parser.add_argument('--expected-manifest',type=Path)
    parser.add_argument('--timeout-s',type=float,default=1800)
    parser.add_argument('--output-name',default='media_verification.json',help='exclusive report basename; use a new name to retain a failed prior receipt')
    args=parser.parse_args()
    report=verify_media(args.run,ffmpeg_bin=args.ffmpeg_bin,expected_manifest=args.expected_manifest,timeout=args.timeout_s,output_name=args.output_name)
    print(json.dumps(dict(status=report['status'],all_three_original_videos_decoded=report['all_three_original_videos_decoded'],
        sha256_verified=report['sha256_verified'],diagnostic_only=report.get('diagnostic_only'),report=str(args.run.resolve()/args.output_name))))
    return 0 if report['status']=='passed' else 1

if __name__=='__main__':sys.exit(main())

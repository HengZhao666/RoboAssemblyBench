"""Create the isolated server stool checkout without changing the Beam baseline."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import tarfile

WORKSPACE = Path('/home/user/beam_integration_20261010_upstream6f57dae')
BASE = WORKSPACE / 'beam_assisted_20261015/assisted_repository'
ROOT = WORKSPACE / 'stool_assisted_20261021'
DEST = ROOT / 'stool_repository'


def inventory(root):
    files, links = {}, []
    for directory, dirs, names in os.walk(root, followlinks=False):
        dirs[:] = [n for n in dirs if n not in {'.git', 'outputs', '__pycache__', '.pytest_cache'}]
        for name in dirs + names:
            path = Path(directory) / name
            relative = str(path.relative_to(root))
            if path.is_symlink():
                links.append(dict(path=relative, target=os.readlink(path),
                                  resolved=str(path.resolve()), exists=path.exists()))
            elif path.is_file():
                files[relative] = hashlib.sha256(path.read_bytes()).hexdigest()
    return dict(files=files, links=links)


before = inventory(BASE)
assert all(row['exists'] for row in before['links']), 'Broken baseline resource link'
assert not DEST.exists(), 'Refuse to overwrite an existing stool checkout'
ROOT.mkdir(exist_ok=True)
(ROOT / 'tools').mkdir(exist_ok=True)
(ROOT / 'baseline').mkdir(exist_ok=True)
archive = ROOT / 'baseline/source_before.tar.gz'
with tarfile.open(archive, 'x:gz') as stream:
    for name in before['files']:
        stream.add(BASE / name, arcname=name, recursive=False)
    for row in before['links']:
        stream.add(BASE / row['path'], arcname=row['path'], recursive=False)
shutil.copytree(BASE, DEST, symlinks=True,
                ignore=shutil.ignore_patterns('.git', 'outputs', '__pycache__', '.pytest_cache'))
after = inventory(DEST)
assert before == after, 'Checkout/resource identity changed during copy'
assert all(os.stat(BASE / name).st_ino != os.stat(DEST / name).st_ino
           for name in before['files']), 'Source file is hardlinked'
assert inventory(BASE) == before, 'Beam baseline changed'
report = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              baseline=str(BASE), working_copy=str(DEST), source=before,
              archive=str(archive), archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
              ordinary_files_independent=True, baseline_unchanged=True,
              resource_links_preserved=True, native_started=False)
(ROOT / 'baseline/bootstrap.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))

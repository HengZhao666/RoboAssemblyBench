"""Actual P05/S03 matrix fixtures plus negative cases; no physics/render calls.

The captured SDK receipt is real installed Gf output. These local tests do not
pretend that Gf is available on the laptop or that fixtures are new native runs.
"""
import copy
import json
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
import stool_startup_evidence as helper

FIXTURES=Path(__file__).parent/'fixtures/stool_usd_alignment'


class NativeUsdDualTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases=json.loads((FIXTURES/'P05_S03_rows.json').read_text())['cases']
        cls.probe=json.loads((FIXTURES/'actual_sdk_probe.json').read_text())

    def sdk(self,case):
        return next(r for r in self.probe['rows'] if r['run']==case['run'] and r['body']==case['original_row']['body'])

    def compare(self,case,**updates):
        old=case['original_row'];sdk=self.sdk(case)
        args=dict(path=old['body'],transform=case['transform_xyzw'],physical_native=old['native_world_matrix'],
                  observed_usd=old['usd_world_matrix'],expected_usd=sdk['expected_usd_world_matrix'],
                  receipt=sdk['conversion_receipt'])
        args.update(updates)
        return helper.compare_native_usd_row(**args)

    def test_actual_P05_S03_old_physical_fields_are_preserved(self):
        for case in self.cases:
            with self.subTest(run=case['run'],body=case['original_row']['body']):
                row=self.compare(case);old=case['original_row']
                for key in ('passed','matrix_max_abs_error','tolerance','position_error_m','angle_error_rad',
                            'native_world_matrix','usd_world_matrix'):
                    self.assertEqual(row[key],old[key],key)
                self.assertTrue(row['publication_passed'])
                self.assertEqual(row['conversion_receipt']['actual_sdk_called'],True)
                self.assertEqual(row['raw_native_quaternion_xyzw'],case['transform_xyzw'][3:])

    def test_S03_representation_delta_explains_only_the_failed_native_rotation(self):
        case=next(c for c in self.cases if c['run']=='S03' and c['original_row']['passed'] is False)
        row=self.compare(case)
        self.assertFalse(row['passed'])
        self.assertTrue(row['publication_passed'])
        self.assertEqual(row['publication_matrix_max_abs_error'],0.)
        self.assertGreater(row['representation_delta_rad'],5.6e-6)
        self.assertLess(row['representation_delta_rad'],5.7e-6)
        self.assertEqual(row['position_error_m'],0.)
        self.assertEqual(row['tolerance'],case['original_row']['tolerance'])

    def test_independent_math_matches_actual_installed_Gf_and_UsdGeom(self):
        self.assertIn('no SimulationApp',self.probe['scope'])
        self.assertEqual(len(self.probe['sdk_binary_sha256']),64)
        for case in self.cases:
            sdk=self.sdk(case)
            self.assertLess(np.max(abs(helper.gf_rotation_matrix_math(case['transform_xyzw'])-
                                       np.asarray(sdk['expected_usd_world_matrix']))),1.e-12)
            self.assertLess(sdk['in_memory_usd_orient_rotation_max_abs_error'],1.e-12)

    def test_actual_Gf_zero_axis_and_float32_scalar_endpoint_branches(self):
        for item in self.probe['near_zero_axis_probes']:
            value=[0.,0.,0.]+item['raw_native_quaternion_xyzw']
            result=helper.gf_rotation_matrix_math(value)[:3,:3]
            self.assertLess(np.max(abs(result-np.asarray(item['expected_rotation']))),1.e-12)
        self.assertTrue(any(r['angle_deg']==0. and r['raw_native_quaternion_xyzw'][0]==0.
                            for r in self.probe['near_zero_axis_probes']))

    def test_stale_translation_and_rotation_still_fail_original_32eps_gate(self):
        case=self.cases[-1]
        for kind in ('translation','rotation'):
            observed=np.array(self.sdk(case)['expected_usd_world_matrix'])
            if kind=='translation':observed[0,3]+=.001
            else:
                angle=.001;rotation=np.array([[np.cos(angle),-np.sin(angle),0.],
                                               [np.sin(angle),np.cos(angle),0.],[0.,0.,1.]])
                observed[:3,:3]=rotation@observed[:3,:3]
            row=self.compare(case,observed_usd=observed)
            self.assertFalse(row['publication_passed'])
            self.assertGreater(row['publication_matrix_max_abs_error'],row['tolerance'])

    def test_normalized_native_cannot_be_substituted_as_the_expected_USD(self):
        case=next(c for c in self.cases if c['run']=='S03' and not c['original_row']['passed'])
        with self.assertRaisesRegex(ValueError,'SDK conversion matrix'):
            self.compare(case,expected_usd=case['original_row']['native_world_matrix'])

    def test_raw_pose_requires_lossless_float32_and_native_quaternion_domain(self):
        case=self.cases[0]
        value=case['transform_xyzw'].copy();value[0]+=1.e-12
        with self.assertRaisesRegex(ValueError,'float32'):self.compare(case,transform=value)
        for bad in ([0.,0.,0.,0.], [0.,0.,0.,float(np.nextafter(np.float32(1.),np.float32(2.)))],
                    [0.,0.,0.,float(np.nextafter(np.float32(-1.),np.float32(-2.)))], [0.,0.,0.,.5]):
            with self.subTest(q=bad),self.assertRaisesRegex(ValueError,'quaternion'):
                helper.validated_native_pose([0.,0.,0.]+bad)

    def test_nan_shape_reflection_singularity_shear_scale_and_nonaffine_reject(self):
        case=self.cases[0];base=np.array(self.sdk(case)['expected_usd_world_matrix'])
        bads=[]
        bad=base.copy();bad[0,0]=np.nan;bads.append(bad)
        bad=base.copy();bad[:3,0]*=-1;bads.append(bad)
        bad=base.copy();bad[:3,0]=0;bads.append(bad)
        bad=base.copy();bad[:3,1]+=.1*bad[:3,0];bads.append(bad)
        bad=base.copy();bad[:3,0]*=1.1;bads.append(bad)
        bad=base.copy();bad[3,0]=.1;bads.append(bad)
        bads.append(base[:3,:3])
        for bad in bads:
            with self.subTest(shape=bad.shape),self.assertRaises(ValueError):
                self.compare(case,observed_usd=bad)

    def test_forged_receipt_or_inconsistent_native_matrix_reject(self):
        case=self.cases[0];receipt=copy.deepcopy(self.sdk(case)['conversion_receipt'])
        receipt['actual_sdk_called']=False
        with self.assertRaisesRegex(ValueError,'receipt'):self.compare(case,receipt=receipt)
        native=np.array(case['original_row']['native_world_matrix']);native[0,3]+=.001
        with self.assertRaisesRegex(ValueError,'physical-native matrix'):self.compare(case,physical_native=native)

    def test_missing_duplicate_inventory_and_wrong_prim_identity_reject(self):
        fake_pxr=SimpleNamespace(UsdGeom=SimpleNamespace(XformCache=lambda:None),Gf=SimpleNamespace())
        case=self.cases[0];path=case['original_row']['body']
        with patch.dict(sys.modules,{'pxr':fake_pxr}):
            for paths,values in (([],{}),([path,path],{path:case['transform_xyzw']}),([path],{})):
                with self.assertRaisesRegex(ValueError,'body identity inventory'):
                    helper.compare_native_usd(None,dict(body_paths=paths,transforms_xyzw=values))
            wrong=SimpleNamespace(IsValid=lambda:True,GetPath=lambda:'/another_body')
            stage=SimpleNamespace(GetPrimAtPath=lambda path:wrong)
            with self.assertRaisesRegex(RuntimeError,'body identity mismatch'):
                helper.compare_native_usd(stage,dict(body_paths=[path],transforms_xyzw={path:case['transform_xyzw']}))


if __name__=='__main__':unittest.main()

"""Replay recorded r27 controller inputs; no simulated response is inferred."""
import copy
import json
from pathlib import Path
from types import SimpleNamespace as NS
import unittest

import numpy as np

from toolkits.factory_dual_franka_assembly.plumbers_block_ur5e_skills import (
    UR5eAssemblyAtomicSkillAdapter as Adapter,
)

FIXTURE = Path(__file__).parent/'fixtures/beam_v202_r27_close_failure.json'


class WeakSidePreload(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.recorded = json.loads(FIXTURE.read_text())

    def setUp(self):
        self.spec = copy.deepcopy(self.recorded['phase_spec']['local_skill'])
        self.spec.update(close_force_weak_side_preload=True, close_force_require_clamp_band=True)
        self.failure = self.recorded['failure']
        self.metrics = copy.deepcopy(self.failure['contact_detail']['contact_metrics'])
        self.q = self.failure['gripper_joint_position']
        self.previous = self.failure['control']['command_q']
        self.state = dict(contact_control_active=True,
                          contact_capture_closure=self.recorded['first_contact']['gripper_q'],
                          contact_command_closure=self.previous)

    def control(self, *, state=None, spec=None, metrics=None, q=None):
        return Adapter._contact_close_control(
            state=self.state if state is None else state,
            spec=self.spec if spec is None else spec,
            metrics=self.metrics if metrics is None else metrics,
            gripper_q=self.q if q is None else q,
            open_q=0., closed_q=.8, requested_openness=0., min_openness=.08)

    def test_recorded_single_contact_hold_is_replaced_by_bounded_weak_side_preload(self):
        legacy = {k:v for k,v in self.spec.items() if k not in (
            'close_force_weak_side_preload', 'close_force_require_clamp_band')}
        old = self.control(state=copy.deepcopy(self.state), spec=legacy)
        self.assertEqual(old['mode'], 'single_contact_hold')
        self.assertEqual(old['command_q'], self.previous)
        new = self.control()
        self.assertEqual(new['mode'], 'preload')
        self.assertEqual(new['preload_basis'], 'weak_side')
        self.assertAlmostEqual(new['command_q']-self.previous, .025/240)
        self.assertFalse(new['clamp_force_ready'])

    def test_real_evolving_recorded_history_preserves_rate_and_lead_limits(self):
        state = copy.deepcopy(self.state)
        state['contact_command_closure'] = self.recorded['close_controls'][0]['control']['command_q']
        for row in self.recorded['close_controls']:
            metrics = copy.deepcopy(self.metrics)
            for side, force in zip(('left_finger','right_finger'),row['control']['forces']):
                metrics[side]['force'] = force
            previous = state['contact_command_closure']
            new = self.control(state=state, metrics=metrics, q=row['gripper_q'])
            self.assertGreaterEqual(new['command_q'], previous)
            self.assertLessEqual(new['command_q']-previous, .025/240+1e-12)
            if previous > row['gripper_q']+.001:
                self.assertEqual(new['command_q'], previous)
            self.assertFalse(new['clamp_force_ready'])
        self.assertEqual(len(self.recorded['close_controls']), 241)

    def test_soft_and_hard_peak_limits_take_priority_over_missing_weak_contact(self):
        for peak, mode in [(13.,'unload'), (45.,'force_limit_unload')]:
            metrics = copy.deepcopy(self.metrics)
            metrics['right_finger']['force'] = peak
            new = self.control(state=copy.deepcopy(self.state), metrics=metrics)
            self.assertEqual(new['mode'], mode)
            self.assertLess(new['command_q'], self.previous)
            self.assertFalse(new['clamp_force_ready'])

    def test_unknown_probe_never_requests_more_closure(self):
        for invalid in [{}, {'force_probe_valid':False,'force':0.},
                        {'force_probe_valid':True,'force':float('nan')}]:
            metrics = copy.deepcopy(self.metrics)
            metrics['left_finger'] = invalid
            new = self.control(state=copy.deepcopy(self.state), metrics=metrics)
            self.assertLessEqual(new['command_q'], self.previous)
            self.assertFalse(new['clamp_force_ready'])

    def test_recorded_bilateral_base_force_is_an_in_band_positive_case(self):
        row = self.recorded['positive_base_close_control']
        metrics = copy.deepcopy(self.metrics)
        for side,force in zip(('left_finger','right_finger'),row['control']['forces']):
            metrics[side]['force'] = force
        result = self.control(metrics=metrics)
        self.assertTrue(result['clamp_force_ready'])
        self.assertEqual(result['mode'], 'bilateral_hold')

    def test_invalid_opt_in_is_rejected(self):
        for value in ['true', 1, None]:
            spec = dict(self.spec, close_force_weak_side_preload=value)
            with self.assertRaises(ValueError):
                self.control(spec=spec)

    def test_actual_close_dispatch_publishes_new_gripper_command_without_qualifying_grasp(self):
        adapter = Adapter({})
        gate = self.recorded['close_gates'][-1]
        robot = self.spec['robot']
        task = NS(phase_index=22, phase_entry_step=13886, phase_step_counter=715,
                  step_counter=14601, phase=self.recorded['phase_spec']['name'],
                  robots={robot:NS(config=NS(gripper_close_openness=.08))})
        completions = []
        task.mark_local_skill_complete = lambda *args,**kwargs: completions.append((args,kwargs))
        phase_key = (id(task),22,13886,robot,'ur5e_close_gripper')
        state = copy.deepcopy(self.state)
        state.update(hold_q=np.array(gate['command_q']), close_started_step=109,
                     close_contact_observation=(14601,(False,{'contact_metrics':self.metrics})))
        adapter._close_gate_state[phase_key] = state
        adapter._current_arm_q = lambda *args: np.array(gate['current_q'])
        # Reuse the recorded upstream pose-gate result. IK and native response
        # are outside this controller-boundary replay, never forced to succeed.
        adapter._hold_joint_action = lambda **kw: {'arm_joint_controller':[gate['command_q']]}
        adapter._close_pose_gate_action = lambda **kw: (gate['gate_ready'],{},gate)
        adapter._current_gripper_q = lambda **kw: self.q
        adapter._gripper_open_closed_q = lambda **kw: (0.,.8)
        adapter._debug_close_step = lambda **kw: None
        action = adapter.act(task=task,robot_name=robot,phase_spec=self.recorded['phase_spec'],
                             skill_spec=self.spec,tracked_robots={},tracked_objects={})
        self.assertNotIn('__local_skill_failure__',action)
        self.assertAlmostEqual(.8*(1-action['gripper_controller'][0]),self.previous+.025/240)
        self.assertEqual(completions,[])
        self.assertEqual(state['close_contact_stable_steps'],0)


if __name__ == '__main__':
    unittest.main()

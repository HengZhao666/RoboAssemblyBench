"""Synthetic dangerous-boundary tests; no decoding, simulation or original run reads."""
from pathlib import Path
import copy, json, tempfile, tarfile
import pack_stool_media as pack


def fixture(root):
    run=root/'runs/S05';run.mkdir(parents=True)
    save=lambda n,v:(run/n).write_text(json.dumps(v))
    for name in pack.REQUIRED: (run/name).write_text('{}')
    save('formal_closure.json',dict(id='S05',grant='G03',closed=True,accepted_full_assembly=False,strict_independent_audit=False,main_task_success=False))
    save('collect_results.json',[dict(success=False)])
    cameras=('third_person_front','left_wrist','right_wrist')
    save('expected_runtime_config.json',dict(camera_metadata=[dict(name=n) for n in cameras]))
    save('independent_audit.json',dict(run_directory=str(run),accepted_full_assembly=False,strict_independent_audit_passed=False,original_main_report=dict(reported_success=False)))
    binding=dict(run='S05',mode='formal',passed=True,run_directory=str(run),configuration_signature='cfg')
    save('source_binding.json',binding);digest=pack.sha(run/'source_binding.json')
    save('runtime_source_binding.json',dict(binding,launch_source_binding_sha256=digest))
    save('launch_receipt.json',dict(run='S05',mode='formal',output=str(run),source_binding_sha256=digest))
    (root/'execution_ledger.json').write_text(json.dumps(dict(execution=dict(attempts=[dict(id='S05',grant='G03',closed=True)]))))
    (run/'finished_at').write_text('2026-10-22T00:00:00Z');(run/'exit_code').write_text('0')
    (run/'episode_0000_live_videos').mkdir();rows=[]
    for camera in sorted(pack.CAMERAS):
        path='episode_0000_live_videos/'+camera.replace('.','_')+'.mp4';p=run/path;p.write_bytes(b'synthetic fixture; not real MP4')
        rows.append(dict(camera=camera,path=path,decoded=True,decode=dict(passed=True),sha256_verified=True,
            size_bytes=p.stat().st_size,sha256=pack.sha(p),sha256_before=pack.sha(p),sha256_after=pack.sha(p)))
    save('media_verification.json',dict(run=str(run),status='passed',all_three_original_videos_decoded=True,
        sha256_verified=True,original_membership_passed=True,diagnostic_only=False,errors=[],files=rows))
    for prefix in ('startup','terminal'):
        images=[]
        for camera in cameras:
            p=run/(prefix+'_'+camera+'.png');p.write_bytes(b'synthetic PNG fixture')
            images.append(dict(camera=camera,path=p.name,sha256=pack.sha(p)))
        save(prefix+'_images_ready.json',dict(passed=True,images=images))
    (run/'scene_geometry.json').write_text('large geometry excluded')
    (run/'independent_native_trace.jsonl').write_text('raw stays server')
    (run/'source_snapshot.tar.gz').write_bytes(b'original source stays server')
    frames=run/'episode_0000_live_frames';frames.mkdir();(frames/'frame.png').write_bytes(b'frame stays server')
    return run


def main():
    checks=[]
    def check(name,predicate):assert predicate,name;checks.append(name)
    def reject(name,callback):
        try:callback()
        except (ValueError,FileExistsError):checks.append(name)
        else:raise AssertionError(name)
    with tempfile.TemporaryDirectory(prefix='stool_pack_') as temp:
        root=Path(temp).resolve();run=fixture(root)
        manifest=pack.plan(root,'S05','G03')
        check('default_plan_creates_nothing',not (root/'deliveries').exists())
        excluded={r['path'] for r in manifest['excluded']}
        check('required_large_originals_remain_excluded',{'scene_geometry.json','independent_native_trace.jsonl','source_snapshot.tar.gz','episode_0000_live_frames/'}<=excluded)
        reject('path_traversal_run_rejected',lambda:pack.plan(root,'../../S05','G03'))
        reject('wrong_grant_rejected',lambda:pack.plan(root,'S05','G04'))
        reject('output_outside_deliveries_rejected',lambda:pack.plan(root,'S05','G03',root/'runs/overwrite.tar.gz'))
        media_path=run/'media_verification.json';original=media_path.read_text();media=json.loads(original)
        media['files'][0]['decoded']=False;media_path.write_text(json.dumps(media))
        reject('missing_prior_decode_rejected',lambda:pack.plan(root,'S05','G03'));media_path.write_text(original)
        video=run/media['files'][0]['path'];old=video.read_bytes();video.write_bytes(old+b'changed')
        reject('changed_original_video_rejected',lambda:pack.plan(root,'S05','G03'));video.write_bytes(old)
        media=json.loads(original);media['files'][0]['path']='../outside.mp4';media_path.write_text(json.dumps(media))
        reject('media_member_path_traversal_rejected',lambda:pack.plan(root,'S05','G03'));media_path.write_text(original)
        required=run/'runtime_source_binding.json';old=required.read_bytes();required.unlink();required.symlink_to(run/'source_binding.json')
        reject('selected_source_symlink_rejected',lambda:pack.plan(root,'S05','G03'));required.unlink();required.write_bytes(old)
        closure=run/'formal_closure.json';old=closure.read_text();data=json.loads(old);data['closed']=False;closure.write_text(json.dumps(data))
        reject('unclosed_run_rejected',lambda:pack.plan(root,'S05','G03'));closure.write_text(old)
        png=run/'startup_third_person_front.png';png.rename(run/'startup_front.png')
        reject('wrong_actual_front_PNG_name_rejected',lambda:pack.plan(root,'S05','G03'));(run/'startup_front.png').rename(png)
        old=png.read_bytes();png.write_bytes(old+b'changed')
        reject('PNG_differs_from_capture_receipt_rejected',lambda:pack.plan(root,'S05','G03'));png.write_bytes(old)
        ready=run/'terminal_images_ready.json';old=ready.read_text();ready.unlink()
        reject('terminal_receipt_absence_requires_failure_record',lambda:pack.plan(root,'S05','G03'))
        (run/'terminal_media_failure.json').write_text(json.dumps(dict(passed=False)))
        check('explicit_terminal_failure_preserved_without_qualifying_PNGs',pack.plan(root,'S05','G03')['terminal_PNG_capture_receipt_verified'] is False)
        ready.write_text(old);(run/'terminal_media_failure.json').unlink()
        manifest=pack.plan(root,'S05','G03');result=pack.create(root,manifest)
        with tarfile.open(result['path']) as archive:
            members=archive.getnames();sealed=json.load(archive.extractfile('G03/S05/MANIFEST.json'))
            check('archive_has_only_planned_members',set(members)=={'G03/S05/'+r['path'] for r in sealed['included']}|{'G03/S05/MANIFEST.json'})
            check('every_archived_member_matches_manifest_SHA',all(pack.hashlib.sha256(archive.extractfile('G03/S05/'+r['path']).read()).hexdigest()==r['sha256'] for r in sealed['included']))
        reject('existing_archive_never_overwritten',lambda:pack.plan(root,'S05','G03'))
        check('original_big_files_untouched',(run/'scene_geometry.json').read_text()=='large geometry excluded')
    print(json.dumps(dict(passed=True,count=len(checks),checks=checks,scope='synthetic archive fixtures only; no live run packing or decoding')))

if __name__=='__main__':main()

"""Visible-CAD pinch qualification for the explicitly assisted Beam route."""
from __future__ import annotations
import numpy as np
import fcl
from scipy.spatial.transform import Rotation
from .beam_assisted_ik import bounded_local_ik

def matrix(position,quat):
    w,x,y,z=quat;T=np.eye(4);T[:3,:3]=Rotation.from_quat([x,y,z,w]).as_matrix();T[:3,3]=position
    return T

class VisiblePinchGeometry:
    def __init__(self,data):
        self.data=data;self.rest={k:np.asarray(v,float) for k,v in data['body_rest'].items()};self.edges={};self.shapes={}
        for robot,info in data['robots'].items():
            indexes={n:i for i,n in enumerate(info['joint_names'])};entries=[]
            for j in data['joints']:
                if j['robot']!=robot or not j['enabled'] or len(j['parent'])!=1 or len(j['child'])!=1:continue
                parent,child=j['parent'][0],j['child'][0]
                if parent not in self.rest or child not in self.rest:raise ValueError('visual pinch lacks native joint body')
                anchor=matrix(j['pos0'],[j['rot0'][3],*j['rot0'][:3]])
                index=indexes.get(j['path'].rsplit('/',1)[-1])
                if j['type']=='PhysicsRevoluteJoint' and index is None:raise ValueError('visual pinch lacks native joint name')
                entries.append((parent,child,index,j['axis'],anchor,np.linalg.inv(anchor),np.linalg.inv(self.rest[parent])@self.rest[child]))
            self.edges[robot]=entries
        task_objects=set(data.get('task_objects', []))
        # Legacy Beam snapshots predate an explicit task object inventory.
        if not task_objects:
            task_objects={str(mesh['object']) for mesh in data['visible_meshes']
                          if str(mesh['object']).startswith('fabrica_beam_')}
        for mesh in data['visible_meshes']:
            if not (mesh['object'] in task_objects or mesh['body'].endswith(('/left_inner_finger','/right_inner_finger'))):continue
            points=np.asarray(mesh['points'],float);faces=np.asarray(mesh['triangles'],np.int32)
            shape=fcl.BVHModel();shape.beginModel(len(faces),len(points));shape.addSubModel(points,faces);shape.endModel()
            self.shapes.setdefault(mesh['body'],[]).append((mesh,fcl.CollisionObject(shape)))

    def poses(self,robot,q):
        result=dict(self.rest);initial=np.asarray(self.data['robots'][robot]['joint_positions'])
        entries=self.edges[robot];done=set(result)-{j[1] for j in entries};pending=list(entries)
        while pending:
            progressed=False
            for entry in pending[:]:
                parent,child,index,axis,A,Ai,relative=entry
                if parent not in done:continue
                delta=np.eye(4)
                if index is not None:
                    v=np.eye(3)['XYZ'.index(axis)]*(q[index]-initial[index]);delta[:3,:3]=Rotation.from_rotvec(v).as_matrix()
                result[child]=result[parent]@A@delta@Ai@relative;done.add(child);pending.remove(entry);progressed=True
            if not progressed:raise ValueError('unresolved visual joint graph')
        return result

    def gaps(self,robot,part,poses):
        root=self.data['robots'][robot]['root_path'];part_body=next(k for k in self.shapes if k.endswith('/'+part))
        values=[]
        for finger in ('left_inner_finger','right_inner_finger'):
            body=root+'/Gripper/Robotiq_2F_85/'+finger;minimum=np.inf;intersect=False
            for mesh,obj in self.shapes[body]+self.shapes[part_body]:
                T=poses[mesh['body']];obj.setTransform(fcl.Transform(T[:3,:3],T[:3,3]))
            for _,a in self.shapes[body]:
                for _,b in self.shapes[part_body]:
                    r=fcl.CollisionResult();hit=fcl.collide(a,b,fcl.CollisionRequest(num_max_contacts=8,enable_contact=True),r)
                    if hit:
                        intersect=True;distance=-max((float(c.penetration_depth) for c in r.contacts),default=0.)
                    else:distance=float(fcl.distance(a,b,fcl.DistanceRequest(),fcl.DistanceResult()))
                    minimum=min(minimum,distance)
            values.append({'finger':finger,'gap':minimum,'intersect':intersect})
        return values

    def goal(self,robot,part,q,part_pose,clearance=.00023):
        info=self.data['robots'][robot];names=info['joint_names'];driver=names.index('finger_joint')
        signs={'finger_joint':1,'right_outer_knuckle_joint':1,'left_inner_finger_joint':-1,'right_inner_finger_joint':1,'left_inner_finger_knuckle_joint':-1,'right_inner_finger_knuckle_joint':-1}
        part_body=next(k for k in self.shapes if k.endswith('/'+part))
        def evaluate(value):
            trial=np.asarray(q,float).copy();change=value-q[driver]
            for name,sign in signs.items():trial[names.index(name)]+=sign*change
            poses=self.poses(robot,trial);poses[part_body]=part_pose
            return self.gaps(robot,part,poses)
        low=0.;g=evaluate(low)
        if any(x['intersect'] or x['gap']<clearance for x in g):raise ValueError('open visible fingers intersect the grasp target')
        high=None
        for value in np.linspace(.025,.8,32):
            g=evaluate(value)
            if any(x['intersect'] or x['gap']<clearance for x in g):high=float(value);break
            low=float(value)
        if high is None:raise ValueError('target does not fit inside a visible pinch')
        for _ in range(20):
            middle=(low+high)/2;g=evaluate(middle)
            if any(x['intersect'] or x['gap']<clearance for x in g):high=middle
            else:low=middle
        return low,evaluate(low)

    def center_shift(self,robot,part,q,part_pose,goal):
        names=self.data['robots'][robot]['joint_names'];trial=np.asarray(q,float).copy()
        change=goal-q[names.index('finger_joint')]
        for name,sign in {'finger_joint':1,'right_outer_knuckle_joint':1,'left_inner_finger_joint':-1,'right_inner_finger_joint':1,'left_inner_finger_knuckle_joint':-1,'right_inner_finger_knuckle_joint':-1}.items():trial[names.index(name)]+=sign*change
        poses=self.poses(robot,trial);body=next(k for k in self.shapes if k.endswith('/'+part));poses[body]=part_pose
        root=self.data['robots'][robot]['root_path']+'/Gripper/Robotiq_2F_85/'
        fingers=[root+'left_inner_finger',root+'right_inner_finger']
        axis=poses[fingers[0]][:3,3]-poses[fingers[1]][:3,3];axis/=np.linalg.norm(axis)
        def imbalance(distance):
            shifted=dict(poses)
            for finger in fingers:
                shifted[finger]=poses[finger].copy();shifted[finger][:3,3]+=axis*distance
            g=self.gaps(robot,part,shifted);return g[0]['gap']-g[1]['gap']
        epsilon=.00002;gradient=(imbalance(epsilon)-imbalance(-epsilon))/(2*epsilon)
        if not np.isfinite(gradient) or abs(gradient)<.2:raise ValueError('visible pinch centering has no reliable surface gradient')
        return axis*float(np.clip(-imbalance(0.)/gradient,-.00025,.00025))

def geometry(task):
    if not hasattr(task,'_assisted_visible_pinch'):
        data=getattr(task,'_assisted_geometry_snapshot',None)
        if data is None:raise RuntimeError('assisted route requires its native geometry initialization')
        task._assisted_visible_pinch=VisiblePinchGeometry(data)
    return task._assisted_visible_pinch

def native_gaps(task,robot,part):
    if _stool_contract(task):return _stool_native_gaps(task,robot,part)
    model=geometry(task);root=model.data['robots'][robot]['root_path'];poses={}
    p,Q=task._resolve_object(part).get_pose();body=next(k for k in model.shapes if k.endswith('/'+part));poses[body]=matrix(p,Q)
    for finger in ('left_inner_finger','right_inner_finger'):
        path=root+'/Gripper/Robotiq_2F_85/'+finger
        reader=getattr(task,'_assisted_native_body_readers',{}).get(path)
        if reader is None:reader=(getattr(task.robots[robot],'_rigid_body_map',{}) or {}).get(path)
        if reader is None or str(reader.unwrap().prim_path)!=path:raise RuntimeError('missing full-path visible finger native reader')
        p,Q=reader.get_pose();poses[path]=matrix(p,Q)
    return model.gaps(robot,part,poses),poses

def close_action(task,adapter,robot,part,action):
    if _stool_contract(task):return _stool_close_action(task,adapter,robot,part,action)
    model=geometry(task);key=(task.phase_index,task.phase_entry_step,robot,part)
    states=getattr(task,'_assisted_visual_close_states',None)
    if states is None:states={};task._assisted_visual_close_states=states
    q=np.asarray(task.robots[robot].articulation.get_joint_positions(),float)
    driver=model.data['robots'][robot]['joint_names'].index('finger_joint')
    state=states.get(key)
    if state is None:
        anchor=np.asarray(action['arm_joint_controller'][0],float).copy()
        state={'arm_anchor':anchor,'stable':0,'centering_count':0,'last_plan':-1000,'hold_openness':1-q[driver]/.8,'ready':False};states[key]=state
    actual,poses=native_gaps(task,robot,part)
    if any(x['intersect'] for x in actual):
        raise RuntimeError('actual visible finger/part surfaces intersect')
    part_body=next(k for k in model.shapes if k.endswith('/'+part))
    if 'goal_q' not in state or (task.step_counter-state['last_plan']>=48):
        goal,predicted=model.goal(robot,part,q,poses[part_body]);state.update(goal_q=goal,predicted=predicted,last_plan=task.step_counter)
        task._assisted_event('visual_pinch_plan',robot=robot,object=part,goal_q=goal,predicted=predicted)
        if max(x['gap'] for x in predicted)>.00025:
            if state['centering_count']>=12:raise RuntimeError('visual pinch could not center both finger faces')
            shift=model.center_shift(robot,part,q,poses[part_body],goal)
            control=task.robots[robot].controllers['arm_ik_controller'];base=control.get_ik_base_world_pose();wrapper=control._kinematics_solver
            wrapper.set_robot_base_pose(robot_position=base[0]/control._robot_scale,robot_orientation=base[1])
            raw=wrapper.get_kinematics_solver();frame=wrapper.get_end_effector_frame();forward=lambda x:raw.compute_forward_kinematics(frame,x)
            p,R=forward(state['arm_anchor']);quat=Rotation.from_matrix(R).as_quat()[[3,0,1,2]]
            new,detail=bounded_local_ik(forward,state['arm_anchor'],p+shift,quat)
            if new is None:raise RuntimeError('visual pinch centering inverse failed')
            state['arm_anchor']=new;state['centering_count']+=1;state['goal_q']=min(state['goal_q'],q[driver]);state['last_plan']=task.step_counter-24
            task._assisted_event('visual_pinch_center',robot=robot,object=part,shift=shift,detail=detail)
    goal=float(state['goal_q'])
    previous=float(state.get('driver_command',q[driver]))
    gap=min(x['gap'] for x in actual)
    # Close from measured surfaces; a settled driver bias must not push
    # through the visible clearance while chasing an ideal drive target.
    increment=min(goal-previous,(gap-.00023)/.15)
    requested=previous+float(np.clip(increment,-.001,.001))
    lead=float(np.clip((gap-.00004)/.15,0.,.01))
    command=float(np.clip(requested,q[driver]-.01,q[driver]+lead))
    command=float(np.clip(command,0,min(.8,goal)))
    state['driver_command']=command;openness=1-command/.8
    state['hold_openness']=openness
    ready=(all(not x['intersect'] and .000005<=x['gap']<=.00025 for x in actual)
           and abs(q[driver]-state.get('previous_driver_q',q[driver]))<.00005)
    stamp=task._beam_physics_stamp()
    if not stamp.get('valid'):raise RuntimeError('visual pinch requires the native physics clock')
    clock=(stamp.get('epoch'),stamp.get('index'))
    if state.get('clock')!=clock:
        state['stable']=state['stable']+1 if ready else 0;state['clock']=clock
        state['previous_driver_q']=float(q[driver])
    state['ready']=state['stable']>=12
    if task.step_counter%8==0:task._assisted_event('visual_pinch_observation',robot=robot,object=part,gaps=actual,actual_driver_q=q[driver],command_driver_q=command,max_driver_lead_rad=lead,stable=state['stable'],ready=state['ready'])
    return {'arm_joint_controller':[state['arm_anchor'].tolist()],'gripper_controller':[openness]},state['ready'],{'qualification':'dual_visible_CAD_surfaces','gaps':actual,'stable_physics_steps':state['stable']}

def ready(task,robot,part):
    if _stool_contract(task):
        key=(task.phase_index,task.phase_entry_step,robot,part)
        state=getattr(task,'_assisted_visual_close_states',{}).get(key,{})
        return bool(state.get('ready')) and _stool_qualified(task,robot,part,native_gaps(task,robot,part)[0])
    key=(task.phase_index,task.phase_entry_step,robot,part);state=getattr(task,'_assisted_visual_close_states',{}).get(key,{})
    if not state.get('ready'):return False
    gaps,_=native_gaps(task,robot,part)
    return all(not x['intersect'] and .000005<=x['gap']<=.00025 for x in gaps)

def hold_command(task,robot,part):
    key=(task.phase_index,task.phase_entry_step,robot,part)
    return getattr(task,'_assisted_visual_close_states',{}).get(key,{}).get('hold_openness')


# Stool reuses the native readers, triangle meshes and local IK mechanism above.
# Its geometry/driver/window numbers come exclusively from its explicit contract.
def _stool_contract(task):
    c=getattr(task,'_fabrica_assisted_contract',{})
    if not c:return None
    p=c.get('cad_pinch',{})
    if p.get('schema')!='stool_visible_pad_near_fit_v1':
        raise RuntimeError('stool requires its explicit visible pad near-fit contract')
    return p

def _stool_row(task,robot,part):
    p=_stool_contract(task);r=p['objects'][part]
    phase=(task.get_current_phase_spec() if hasattr(task,'get_current_phase_spec') else {}) or {}
    role=phase.get('fabrica_base_support')
    if role:
        if task._assisted_base_support_role()!=role:
            raise RuntimeError('stool support CAD role is outside its active installation cycle')
        contract=getattr(task,'_fabrica_assisted_contract',{}).get('base_support',{})
        if (role.get('schema') not in {'stool_install_cycle_support_v2','stool_continuous_base_support_v3'}
                or role.get('robot')!=contract.get('robot') or role.get('object')!=contract.get('object')
                or role.get('role')!=contract.get('role') or role.get('stage') not in
                   {'initial_park','enter','acquire','hold','open','exit'}):
            raise RuntimeError('stool base support role identity is invalid')
        if robot==role['robot'] and part==role['object']:r=contract['cad_row']
    if r['robot']!=robot:raise RuntimeError('stool CAD grasp robot mismatch')
    return p,r

def _stool_pad(model,robot,side):
    body=model.data['robots'][robot]['root_path']+'/Gripper/Robotiq_2F_85/'+side+'_inner_finger'
    entries=[v for v in model.shapes[body] if 'fingertipsstep' in v[0]['prim'].lower()]
    if len(entries)!=1:raise RuntimeError('stool requires one exact visible fingertip pad per side')
    return body,entries[0]

def _stool_query(task,robot,part,poses):
    model=geometry(task);p,row=_stool_row(task,robot,part)
    part_bodies=[k for k in model.shapes if k.endswith('/'+part)]
    if len(part_bodies)!=1:raise RuntimeError('ambiguous stool CAD object body')
    part_body=part_bodies[0];values=[]
    for mesh,obj in model.shapes[part_body]:
        T=poses[part_body];obj.setTransform(fcl.Transform(T[:3,:3],T[:3,3]))
    for side in ('left','right'):
        body,(pad,obj)=_stool_pad(model,robot,side);T=poses[body]
        # All inner-finger meshes, including its non-pad body, must be clear.
        intersects=False;minimum=np.inf;nearest=None
        for mesh,a in model.shapes[body]:
            a.setTransform(fcl.Transform(T[:3,:3],T[:3,3]))
            for _,b in model.shapes[part_body]:
                cr=fcl.CollisionResult()
                hit=fcl.collide(a,b,fcl.CollisionRequest(num_max_contacts=8,enable_contact=True),cr)
                intersects=intersects or bool(hit)
                if mesh['prim']!=pad['prim']:continue
                if hit:d=-max((float(x.penetration_depth) for x in cr.contacts),default=0.)
                else:
                    dr=fcl.DistanceResult();d=float(fcl.distance(a,b,fcl.DistanceRequest(enable_nearest_points=True),dr))
                if d<minimum:
                    minimum=d;nearest=None if hit else [np.asarray(v,float) for v in dr.nearest_points]
        pts=np.asarray(pad['points'],float);lo=pts.min(0);hi=pts.max(0)
        plane=hi[1] if side=='left' else lo[1]
        tol=32*np.finfo(np.float32).eps*max(1.,float(np.max(np.abs(pts))))
        face=pts[np.abs(pts[:,1]-plane)<=tol]
        if len(face)<3:raise RuntimeError('actual stool pad inner face is missing')
        low=face.min(0);high=face.max(0);normal=T[:3,:3]@np.array([0.,1. if side=='left' else -1.,0.])
        point_on_face=False;direction=False;tangent=np.zeros(3)
        if nearest is not None:
            local=(np.linalg.inv(T)@np.r_[nearest[0],1.])[:3]
            point_on_face=bool(abs(local[1]-plane)<=tol and np.all(local[[0,2]]>=low[[0,2]]-tol) and np.all(local[[0,2]]<=high[[0,2]]+tol))
            separation=nearest[1]-nearest[0]
            direction=bool(minimum>0 and np.dot(separation,normal)/minimum>=np.cos(row['max_grasp_orientation_error_rad']))
            tangent=separation-normal*np.dot(separation,normal)
        values.append(dict(finger=side+'_inner_finger',gap=minimum,intersect=intersects,
            pad_prim=pad['prim'],pad_body=body,point_on_actual_inner_face=point_on_face,
            separation_along_inward_normal=direction,nearest_points=None if nearest is None else [v.tolist() for v in nearest],
            inner_normal_world=normal.tolist(),tangential_separation_world=tangent.tolist(),
            actual_inner_face_bounds_local=[low.tolist(),high.tolist()],representation_tolerance_m=tol))
    return values

def _stool_native_gaps(task,robot,part):
    stamp=task._beam_physics_stamp();model=geometry(task);poses={}
    body=next(k for k in model.shapes if k.endswith('/'+part))
    pos,quat=task._resolve_object(part).get_pose();poses[body]=matrix(pos,quat)
    for side in ('left','right'):
        path,_=_stool_pad(model,robot,side)
        reader=getattr(task,'_assisted_native_body_readers',{}).get(path)
        if reader is None or str(reader.unwrap().prim_path)!=path:
            raise RuntimeError('stool CAD pinch lacks exact full-path native finger reader')
        pos,quat=reader.get_pose();poses[path]=matrix(pos,quat)
    hand=task._get_robot_hand_rigid_body(robot)
    hand_path=model.data['robots'][robot]['root_path']+'/wrist_3_link'
    if hand is None or str(hand.unwrap().prim_path)!=hand_path:raise RuntimeError('stool CAD pinch lacks exact-path native hand')
    pos,quat=hand.get_pose();poses[model.data['robots'][robot]['root_path']+'/wrist_3_link']=matrix(pos,quat)
    gaps=_stool_query(task,robot,part,poses)
    if stamp.get('valid') is not True or task._beam_physics_stamp()!=stamp:
        raise RuntimeError('native clock changed while reading stool CAD fit')
    return gaps,poses

def _stool_qualified(task,robot,part,gaps,*,_region_sample=None,_poses=None):
    p,row=_stool_row(task,robot,part)
    if not all(not x['intersect'] and 0<x['gap']<=p['max_gap_m'] and
        x['point_on_actual_inner_face'] and x['separation_along_inward_normal'] for x in gaps):return False
    # This is an explicit catalog grasp-frame region, not a broad OBB surface.
    model=geometry(task)
    if _poses is None:_,poses=_stool_native_gaps(task,robot,part)
    else:poses=_poses
    H=poses[model.data['robots'][robot]['root_path']+'/wrist_3_link']
    P=poses[next(k for k in model.shapes if k.endswith('/'+part))]
    if p.get('grasp_region_frame')!='native_wrist_3_link':raise RuntimeError('stool CAD grasp region frame is unspecified')
    relative=np.linalg.inv(H)@P
    nominal=matrix(row['object_in_hand_position'],row['object_in_hand_orientation'])
    qualified = bool(np.linalg.norm(relative[:3,3]-nominal[:3,3])<=row['max_grasp_position_error_m'] and
        Rotation.from_matrix(relative[:3,:3]@nominal[:3,:3].T).magnitude()<=row['max_grasp_orientation_error_rad'])
    if _region_sample is not None:
        # Reuse the pose read already required by the original region gate.
        _region_sample.update(hand_matrix=H.copy(),object_matrix=P.copy())
    return qualified

def stool_base_support_sample(task,robot,part):
    """Strict non-attached support; world support never bypasses CAD qualification."""
    stamp=task._beam_physics_stamp();gaps,poses=_stool_native_gaps(task,robot,part)
    region={};qualified=_stool_qualified(task,robot,part,gaps,_region_sample=region,_poses=poses)
    if stamp.get('valid') is not True or task._beam_physics_stamp()!=stamp:
        raise RuntimeError('stool base support native sample changed clock')
    return dict(ready=bool(qualified),physics_stamp=stamp,gaps=gaps,
        hand_matrix=None if not region else region['hand_matrix'].tolist(),
        object_matrix=None if not region else region['object_matrix'].tolist(),
        qualification='dual_native_visible_pad_CAD_near_fit',force_support_claimed=False)

def _stool_diagnostic_plain(value):
    # Diagnostics must remain strict JSON even if a failed measurement is NaN.
    if isinstance(value,np.ndarray):return _stool_diagnostic_plain(value.tolist())
    if isinstance(value,np.generic):return _stool_diagnostic_plain(value.item())
    if isinstance(value,float) and not np.isfinite(value):return {'nonfinite':repr(value)}
    if isinstance(value,dict):return {str(k):_stool_diagnostic_plain(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [_stool_diagnostic_plain(v) for v in value]
    if value is None or isinstance(value,(str,int,float,bool)):return value
    return repr(value)

def _stool_held_fit_failure_event(task,robot,part,gaps,poses,supported,clock_before,region_sample):
    policy,row=_stool_row(task,robot,part);model=geometry(task)
    hand=model.data['robots'][robot]['root_path']+'/wrist_3_link'
    body=next(k for k in poses if k.endswith('/'+part))
    H=region_sample.get('hand_matrix',poses[hand]);P=region_sample.get('object_matrix',poses[body])
    relative=np.linalg.inv(H)@P;nominal=matrix(row['object_in_hand_position'],row['object_in_hand_orientation'])
    dp=float(np.linalg.norm(relative[:3,3]-nominal[:3,3]))
    dr=float(Rotation.from_matrix(relative[:3,:3]@nominal[:3,:3].T).magnitude())
    predicates=[]
    for gap in gaps:
        checks={'no_mesh_intersection':not gap['intersect'],
            'strict_positive_gap':0<gap['gap'],'gap_within_original_maximum':gap['gap']<=policy['max_gap_m'],
            'actual_inner_face_ROI':gap['point_on_actual_inner_face'],
            'separation_along_original_inward_normal':gap['separation_along_inward_normal']}
        angle=None
        if gap.get('nearest_points') is not None and gap['gap']>0:
            separation=np.asarray(gap['nearest_points'][1])-np.asarray(gap['nearest_points'][0])
            angle=float(np.arccos(np.clip(np.dot(separation,gap['inner_normal_world'])/gap['gap'],-1.,1.)))
        predicates.append({'finger':gap['finger'],'checks':checks,
            'failed_predicates':[name for name,passed in checks.items() if not passed],
            'normal_separation_angle_rad':angle,'original_normal_angle_limit_rad':row['max_grasp_orientation_error_rad']})
    clock_after=task._beam_physics_stamp()
    def valid_clock(c):
        try:return (isinstance(c,dict) and c.get('valid') is True and type(c.get('epoch')) is int and c['epoch']>=0
            and type(c.get('index')) is int and c['index']>=0 and np.isfinite(float(c['time'])) and float(c['time'])>=0
            and np.isfinite(float(c['dt'])) and float(c['dt'])>0)
        except (KeyError,TypeError,ValueError):return False
    state=(getattr(task,'_attachments',{}) or {}).get(part,{})
    receipt=(getattr(task,'_fabrica_final_gripper_commands',{}) or {}).get(robot,{})
    robot_state=(getattr(task,'robots',{}) or {}).get(robot)
    hold=state.get('assisted_hold_openness');derived_driver=None
    try:
        if hold is not None:derived_driver=row['driver_closed_rad']+float(hold)*(row['driver_open_rad']-row['driver_closed_rad'])
    except (KeyError,TypeError,ValueError):pass
    detail={'schema':'stool_held_fit_failure_diagnostic_v1','qualification':'native visible pad CAD near-fit, not force contact',
        'clock_before_measurement':clock_before,'clock_after_measurement':clock_after,
        'same_full_native_clock':bool(valid_clock(clock_before) and valid_clock(clock_after) and clock_before==clock_after),
        'supported':supported,'region_gate_evaluated':bool(region_sample),
        'grasp_region_frame':policy['grasp_region_frame'],'hand_body_path':hand,'object_body_path':body,
        'native_hand_matrix':H,'native_object_matrix':P,'native_hand_object_matrix':relative,
        'region_position_error_m':dp,'region_position_limit_m':row['max_grasp_position_error_m'],
        'region_orientation_error_rad':dr,'region_orientation_limit_rad':row['max_grasp_orientation_error_rad'],
        'region_position_passed':dp<=row['max_grasp_position_error_m'],'region_orientation_passed':dr<=row['max_grasp_orientation_error_rad'],
        'original_max_gap_m':policy['max_gap_m'],'already_computed_native_gaps':gaps,'predicate_breakdown':predicates,
        'closest_point_semantics':'FCL returned world nearest points [pad,object]; inner normal and tangent are world vectors; not force observations',
        'attachment_identity':{k:state.get(k) for k in ('mode','robot_name','joint_path','attach_step','capture_physics_stamp')},
        'saved_hold_openness':hold,'driver_target_derived_from_saved_hold_rad':derived_driver,
        'native_driver_state_resampled':False,'previous_final_gripper_receipt':receipt,
        'actual_robot_SDK_sequence':getattr(robot_state,'_action_batch_sequence',None),
        'last_action_controller_names':getattr(robot_state,'last_action_controller_names',None)}
    task._assisted_event('stool_held_CAD_fit_failed',robot=robot,object=part,diagnosis=_stool_diagnostic_plain(detail))

def verify_stool_held_fit(task,robot,part):
    try:clock_before=dict(task._beam_physics_stamp())
    except Exception:clock_before=None
    gaps,poses=native_gaps(task,robot,part)
    supported=part in getattr(task,'_assisted_world_joints',{})
    region_sample={}
    if any(x['intersect'] for x in gaps) or (not supported and not _stool_qualified(task,robot,part,gaps,_region_sample=region_sample)):
        try:_stool_held_fit_failure_event(task,robot,part,gaps,poses,supported,clock_before,region_sample)
        except Exception:pass  # A logger/diagnostic failure cannot replace the original stop.
        raise RuntimeError('held stool part lost its native visible pad CAD near-fit')
    return gaps

def _stool_close_action(task,adapter,robot,part,action):
    p,row=_stool_row(task,robot,part);model=geometry(task)
    key=(task.phase_index,task.phase_entry_step,robot,part)
    states=getattr(task,'_assisted_visual_close_states',None)
    if states is None:states={};task._assisted_visual_close_states=states
    q=np.asarray(task.robots[robot].articulation.get_joint_positions(),float)
    names=model.data['robots'][robot]['joint_names'];driver=names.index('finger_joint')
    lo=row['driver_open_rad'];mechanical_hi=row['driver_closed_rad'];stroke=mechanical_hi-lo
    hi=mechanical_hi+row['minimum_sdk_openness']*(lo-mechanical_hi)
    if not stroke>0:raise RuntimeError('stool CAD driver stroke must be positive')
    arm=np.asarray(action['arm_joint_controller'][0],float)
    if key not in states:
        anchor=q[:6].copy()
        states[key]=dict(arm_anchor=anchor,stable=0,ready=False,center_offset=np.zeros(3))
    state=states[key]
    role=((task.get_current_phase_spec() if hasattr(task,'get_current_phase_spec') else {}) or {}).get('fabrica_base_support') or {}
    support_acquire=bool(role.get('stage')=='acquire' and role.get('robot')==robot and role.get('object')==part)
    precise_support_centering=bool(support_acquire and role.get('schema')=='stool_continuous_base_support_v3'
        and robot=='franka_right' and part==getattr(task,'_fabrica_assisted_contract',{}).get('base_object'))
    if support_acquire and getattr(task,'_fabrica_base_support_pending',None) is not None:
        retained=task._assisted_base_support_pending_action()
        return retained,True,dict(qualification='dual_native_visible_pad_CAD_near_fit',
            acquisition_drive_retained=True,force_support_claimed=False)
    actual,native=native_gaps(task,robot,part)
    if any(x['intersect'] for x in actual):raise RuntimeError('actual stool inner-finger/part visible meshes intersect')
    hand_path=model.data['robots'][robot]['root_path']+'/wrist_3_link'
    # Recalibrate FK increments to this tick's native hand. No attachment or
    # native body relation is written; the fixed-joint capture occurs later.
    calibration=native[hand_path]@np.linalg.inv(model.poses(robot,q)[hand_path])
    part_body=next(k for k in model.shapes if k.endswith('/'+part))
    def predict(value):
        if precise_support_centering:
            guard=getattr(task,'_fabrica_production_action_guard',None)
            preview=getattr(guard,'preview_robot_target',None)
            if not callable(preview):raise RuntimeError('stool support close lacks shared final target preview')
            candidate={'arm_joint_controller':[np.asarray(state['arm_anchor']).tolist()],
                'gripper_controller':[1.-(value-lo)/stroke]}
            trial=np.asarray(preview(robot,candidate,q)['target_q'],float)
            if trial.shape!=q.shape or not np.all(np.isfinite(trial)):
                raise RuntimeError('stool support close preview lacks complete finite native target')
        else:
            trial=q.copy();delta=value-q[driver]
            for name,sign in {'finger_joint':1,'right_outer_knuckle_joint':1,'left_inner_finger_joint':-1,'right_inner_finger_joint':1,'left_inner_finger_knuckle_joint':-1,'right_inner_finger_knuckle_joint':-1}.items():trial[names.index(name)]+=sign*delta
        poses=model.poses(robot,trial)
        poses={k:(calibration@v if k.startswith(model.data['robots'][robot]['root_path']+'/') else v) for k,v in poses.items()}
        poses[part_body]=native[part_body]
        return _stool_query(task,robot,part,poses)
    # Tangential nearest-point displacement exposes short/incorrect grasp depth.
    # Centering holds driver position and keeps full orientation unchanged.
    tangent=np.mean([np.asarray(x['tangential_separation_world']) for x in actual],axis=0)
    shift=np.zeros(3)
    if any(not x['separation_along_inward_normal'] for x in actual) and np.linalg.norm(tangent)>p['target_gap_m']:
        shift=tangent*min(1.,p['max_center_step_m']/np.linalg.norm(tangent))
    else:
        imbalance=actual[0]['gap']-actual[1]['gap']
        axis=np.asarray(actual[0]['inner_normal_world'])
        shift=axis*float(np.clip(imbalance/2.,-p['max_center_step_m'],p['max_center_step_m']))
        if abs(imbalance)<=p['target_gap_m']:shift[:]=0.
    command=float(state.get('driver_command',q[driver]));centered=not np.any(shift)
    if np.any(shift):
        control=task.robots[robot].controllers['arm_ik_controller']
        if precise_support_centering:
            model_scale=np.asarray(control._robot_scale,dtype=float)
            if (model_scale.shape not in ((),(3,)) or not np.all(np.isfinite(model_scale))
                    or not np.all(model_scale>0.)):
                raise ValueError('stool support centering requires positive finite scalar or xyz robot scale')
            tolerance_scale=float(np.max(model_scale))
        base=control.get_ik_base_world_pose();wrapper=control._kinematics_solver
        wrapper.set_robot_base_pose(robot_position=base[0]/control._robot_scale,robot_orientation=base[1])
        raw=wrapper.get_kinematics_solver();frame=wrapper.get_end_effector_frame();forward=lambda x:raw.compute_forward_kinematics(frame,x)
        anchor=np.asarray(state['arm_anchor']);pos,R=forward(anchor);current_pos,_=forward(q[:6])
        # A finite measured-command lead accommodates loaded steady bias.
        # Shrink the next accepted increment; never require zero tracking error.
        tracking=float(np.linalg.norm((np.asarray(pos)-current_pos)*control._robot_scale))
        available=p['max_center_tracking_lead_m']-tracking
        if precise_support_centering:
            task._assisted_event('stool_support_center_tracking',robot=robot,object=part,
                arm_anchor_q=anchor,current_arm_q=q[:6],robot_scale=model_scale,
                anchor_fk_position_model=np.asarray(pos),current_fk_position_model=np.asarray(current_pos),
                scaled_fk_tracking_delta_m=(np.asarray(pos)-current_pos)*control._robot_scale,
                tracking_norm_m=tracking,available_lead_m=available,
                tracking_lead_limit_m=p['max_center_tracking_lead_m'],
                proposed_center_shift_world=shift,
                source='existing internal-anchor/current-q FK evaluations before lead gate; not SDK target',
                force_support_claimed=False)
        if available>0.:
            shift=shift*min(1.,available/max(np.linalg.norm(shift),1e-15))
            total=np.asarray(state['center_offset'])+shift
            if np.linalg.norm(total)>row['max_center_total_m']:raise RuntimeError('stool CAD fit exceeds original grasp position region')
            quat=Rotation.from_matrix(R).as_quat()[[3,0,1,2]]
            tolerance=p['target_gap_m']/4.
            if precise_support_centering:
                tolerance=float(min(tolerance,np.linalg.norm(shift)/4.)/tolerance_scale)
            new,detail=bounded_local_ik(forward,anchor,np.asarray(pos)+shift/control._robot_scale,quat,
                position_tolerance=tolerance,orientation_tolerance=p['target_gap_m'],radius=p['max_joint_step_rad'])
            if new is None:raise RuntimeError('stool CAD local centering IK failed')
            if precise_support_centering:
                accepted_pos,_=forward(new)
                accepted_shift=(np.asarray(accepted_pos)-np.asarray(pos))*control._robot_scale
                if (not np.all(np.isfinite(accepted_shift)) or
                        np.linalg.norm(shift-accepted_shift)>=np.linalg.norm(shift)):
                    raise RuntimeError('stool support centering IK made no Cartesian progress')
                # Allow only floating-point coordinate subtraction roundoff;
                # this does not enlarge the physical motion/lead budgets.
                roundoff=64.*np.finfo(float).eps*max(1.,
                    np.linalg.norm(np.asarray(accepted_pos)*control._robot_scale),
                    np.linalg.norm(np.asarray(current_pos)*control._robot_scale),
                    np.linalg.norm(np.asarray(pos)*control._robot_scale))
                accepted_lead=np.linalg.norm((np.asarray(accepted_pos)-current_pos)*control._robot_scale)
                if np.linalg.norm(accepted_shift)>p['max_center_step_m']+roundoff:
                    raise RuntimeError('stool support centering IK exceeds original Cartesian step bound')
                if accepted_lead>p['max_center_tracking_lead_m']+roundoff:
                    raise RuntimeError('stool support centering IK exceeds original tracking lead bound')
                total=np.asarray(state['center_offset'])+accepted_shift
                if np.linalg.norm(total)>row['max_center_total_m']:raise RuntimeError('stool CAD fit exceeds original grasp position region')
                detail=dict(detail,requested_shift_world=shift,accepted_fk_shift_world=accepted_shift,
                    solver_position_tolerance=tolerance)
            state.update(arm_anchor=new,center_offset=total)
            task._assisted_event('stool_CAD_fit_center',robot=robot,object=part,shift_world=shift,center_offset=total,detail=detail)
        command=min(command,float(q[driver]))
    elif centered:
        # Preserve the original controller ramp bound, then reduce it further
        # with actual-pad FK queries. Each final batch is also swept in full.
        step=min(p['max_joint_step_rad'],stroke*(row['source_preclose_openness']-row['source_closed_openness'])/row['source_close_ramp_steps'])
        low=float(q[driver]);high=min(hi,command+step,low+p['max_driver_lead_rad'])
        trial=predict(high)
        if any(x['intersect'] or x['gap']<p['target_gap_m'] for x in trial):
            for _ in range(20):
                mid=(low+high)/2.;trial=predict(mid)
                if any(x['intersect'] or x['gap']<p['target_gap_m'] for x in trial):high=mid
                else:low=mid
            high=low
        command=float(high)
    command=float(np.clip(command,lo,hi));state['driver_command']=command
    openness=1.-(command-lo)/stroke;state['hold_openness']=openness
    qualified=_stool_qualified(task,robot,part,actual)
    stamp=task._beam_physics_stamp();clock=(stamp.get('epoch'),stamp.get('index'))
    if state.get('clock')!=clock:
        previous=state.get('previous_driver_q')
        probe=min(p['max_joint_step_rad'],max(hi-q[driver],q[driver]-lo))
        signed=probe if q[driver]+probe<=hi else -probe
        moved=q.copy()
        for name,sign in {'finger_joint':1,'right_outer_knuckle_joint':1,'left_inner_finger_joint':-1,'right_inner_finger_joint':1,'left_inner_finger_knuckle_joint':-1,'right_inner_finger_knuckle_joint':-1}.items():moved[names.index(name)]+=sign*signed
        pose0=model.poses(robot,q);pose1=model.poses(robot,moved);slope=0.
        for side in ('left','right'):
            b,(mesh,_)=_stool_pad(model,robot,side);pts=np.asarray(mesh['points'])
            a=pts@pose0[b][:3,:3].T+pose0[b][:3,3];b1=pts@pose1[b][:3,:3].T+pose1[b][:3,3]
            slope=max(slope,float(np.max(np.linalg.norm(b1-a,axis=1)))/probe)
        settled=previous is not None and slope>0 and abs(q[driver]-previous)*slope<=p['target_gap_m']
        consecutive=state.get('clock') is None or (clock[0]==state['clock'][0] and clock[1]==state['clock'][1]+1)
        state['stable']=state['stable']+1 if qualified and settled and consecutive else 0
        state.update(clock=clock,previous_driver_q=float(q[driver]))
    state['ready']=state['stable']>=p['stable_native_ticks']
    if task.step_counter%8==0 or state['ready']:
        metrics=task._gripper_contact_metrics(part,robot,attach_spec={'measure_force_contact':True,'contact_force_threshold':row['source_force_threshold_newtons']})
        task._assisted_event('stool_CAD_fit_observation',robot=robot,object=part,qualification='CAD near-fit, not force contact',gaps=actual,
            actual_driver_q=float(q[driver]),command_driver_q=command,stable=state['stable'],ready=state['ready'],center_offset=state['center_offset'],
            force_feedback_is_independent=True,force_feedback={side:metrics.get(side+'_finger',{}).get('force_observation') for side in ('left','right')})
    return {'arm_joint_controller':[np.asarray(state['arm_anchor']).tolist()],'gripper_controller':[openness]},state['ready'],dict(qualification='dual_native_visible_pad_CAD_near_fit',gaps=actual,stable_physics_steps=state['stable'])


def validate_stool_geometry(task):
    """Fail before actions if the selected real CAD/native bindings are incomplete."""
    model=geometry(task);p=_stool_contract(task);rows=[]
    if set(model.data.get('task_objects',[]))!=set(p['objects']):
        raise RuntimeError('stool CAD task object inventory differs from reviewed grasp contract')
    for part,row in p['objects'].items():
        robot=row['robot'];bodies=[b for b in model.shapes if b.endswith('/'+part)]
        if len(bodies)!=1 or not model.shapes[bodies[0]]:raise RuntimeError('missing/ambiguous actual stool CAD mesh')
        for mesh,_ in model.shapes[bodies[0]]:
            pts=np.asarray(mesh['points']);tri=np.asarray(mesh['triangles'])
            if pts.ndim!=2 or pts.shape[1]!=3 or not len(tri) or not np.all(np.isfinite(pts)):
                raise RuntimeError('invalid actual stool triangle geometry')
        gaps,_=_stool_native_gaps(task,robot,part)
        rows.append(dict(object=part,robot=robot,pads=[v['pad_prim'] for v in gaps],
            actual_inner_face_bounds_local=[v['actual_inner_face_bounds_local'] for v in gaps]))
    return dict(passed=True,schema=p['schema'],objects=rows,
        scope='actual nine CAD meshes, exact two-pad native readers and local inner-face regions; startup need not be grasped',
        physics_stamp=task._beam_physics_stamp())

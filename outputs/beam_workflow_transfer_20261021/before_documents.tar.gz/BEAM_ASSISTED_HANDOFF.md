# Beam 辅助路线当前交接

2026-10-21，W05.6。D28/A44以v35普通从头完成五件辅助装配、三段回位与原五件/双臂home共同240tick，原success/assisted_success=true；独立终态raw native缺帧，final_home_review=false，accepted_full_assembly=false，不能称全部后审通过。新三原片各7445帧/30fps/248.166667s、服务器完整解码通过；本机下载逐SHA及9点AVFoundation播放通过，7组同钟三视图已实际审看。本轮已完成闭环并暂停；实时状态、次数和权限只读[唯一账本](outputs/beam_assisted_20261015/repair_batch_D_20261016.json)，本页不提供启动授权。最新人类指令仅授权本轮；D27/A43启动失败原件与计数保留。

共用方法按真实记录离线排错→必要时独立短物理筛选→有希望候选从头验收→固定后审/完整原片下载执行。本次授权不含额外短物理，仅离线筛选后做一次普通从头验收。历史独立短场景显式设置新episode初态，不恢复旧接触、速度、求解器或控制隐藏状态，不称断点等价；其先前零件为初始已安装条件，不能记为该轮新完成装配。

## 本轮变更与验收边界

- v35仅2文件修复真实框架env0/env1逻辑名/运行时名映射，66项受影响检查通过，保留A43完整配置与精确home六轴目标。D28/A44实际从头完成原五件与新增回位；封存source889/tools20在运行后差异均为空。资格与动态结果分别引用`D28_work/alias_fix_qualification.json`及`D28_conclusions.json`。
- 已资格部署v34，翻转左右腕相机各自光轴180度，并在原右臂撤离后追加“左臂回初始→右肩先抬离→右臂回初始”。相机位置不变，滚转只改变成像；本轮启动同钟三原图已实际查看，两腕夹爪在画面下方后才ACK。右肩抬离量固定为`shoulder_lift -0.24rad`，其余五轴保留阶段入场实测值，不能下发A42旧关节常数。两臂初始六轴目标读取实际配置，不按视频外观或阶段名称判断回位。
- 可证伪假设：只改变腕相机画面滚转，不改变前段装配控制；末段先定向抬离再回位，可保持五件装配结果并避开已安装件。最终两臂实测home误差须≤0.01rad，阶段各取得8个独立native tick；原五件释放/目标及共同240tick合同保留，最终窗口还须两臂实际保持home。进入回位阶段、发布目标或exit0都不算到位。
- 空手回位的最终生产指令仍经双臂实际状态、最终限幅后完整54可见网格/self检查；包含两臂、完整夹爪、全部已装件和导出环境，不因空手而跳过，也不改原豁免、1um交叠判定或成功门。主执行链后审true/errors=[]；299个存档回位/终态命令批、1495个有限full54/self样本均通过，原empty-CAD/native-limit拒绝为0。这不等于逐步独立覆盖或连续CCD；终态独立raw采集缺口见下。
- 已完成精确`-0.24rad`名义路径离线筛查：以A42 task57408/native57411同钟44实体和实际夹爪开度校准，左home/右抬离/右home共512姿态、单轴间隔≤0.01rad，完整54/self未发现超过原1um判定的交叠；对已装件最小间隙分别159.512mm、4.861mm、139.861mm。原件见`P/D27_work/return_geometry_delta024.json`，SHA`9722632f061551e834150c5ff0fcbb46b8d6cedba5bcd6e7cd92666445ffafdf`。这是有限运动学代理，不证明实际跟踪、动力学或样本间连续安全。
- 邻近抬离量`-0.2386591434rad`的独立扰动仅作参考，原件`D27_work/return_geometry_final.json`；不能冒充精确`-0.24rad`的扰动覆盖。原起点elbow增加0.03rad可与第五件交叠约2.499mm，故初始狭窄区必须保留其余轴实测值并逐批检查实际到最终命令的扫掠。直接右回home的名义路径最小仅3.839mm，作为较差候选保留，不采用。
- 资格证据只引用`D27_work/source_qualification.json`、`authority_configuration_binding.json`和`formal_gate_spec.json`。48项预检模块新跑通过，另368项按生产源不变及测试仅98→101阶段数期望的精确差异复用，共416不同检查；初次407/9、第二次414/2、第三次415/1原件均保留。四实际布局只新增三段回位、注册接口、派生阶段注释及最终home要求，原98阶段/目标/物理/五件成功条件不变。真实A42 task57408非零跟踪偏差，经生产adapter→最终双臂限幅→实际空手完整54/self guard，2147合法批次/10735有限几何样本完成三阶段及8tick门；危险elbow+.03负例首采样拒绝、零发布。显式0.08响应代理不是动力学。本轮新增实测结果只引用D28原件，不复用A42结果；离线资格不扩大为完整误差包络。

## 最新证据与验证边界

- 原runtime link-origin capsule442项、stage capsule376项为粗近似提示，不作为实际mesh碰撞证据；原sequence含release_without_attach10条/errors0，其模型不识别assisted生命周期，实际新capture/release原件另保留。原警告不删除、不改判为无警告。

- D28/A44原collect_results为59567步，末任务索引59566/native59570；五件、左home→右肩抬离→右home与共同240/240tick主判定通过。左右实际六轴最大home误差为0.0051313592121/0.00480947596952rad（原门0.01rad）；三段历时589/112/1450 native tick。主execution_evidence_checks_passed=true，但final_home_review=false：证书59570缺同钟独立raw，最新after_physics/observation59564早6tick，最后action/三视图/entity59563早7tick；240窗口仅60个raw时钟索引可见，其余180不回填。故accepted_full_assembly=false/all_postreview=false。原结论只引用`D28_conclusions.json`、`D28_work/final_home_independent_read_review.json`及原报告；这是辅助条件下的主任务和运动成功，独立验收仍有缺测。

- D27/A43唯一启动失败结论`P_local/D27_conclusions.json` SHA`eaf7bd8820eac4ed835ecf021ff1388c2f6b8cc24865b1395fd54e362bf7ee9c`；22个实际原件已下载逐SHA核验，见`D27_local_evidence_review.json`。未构建环境、无新动作/图/视频/5秒尾录；不作为相机或回位动态测试，不用A42视频冒充新视频。
- D26/A42以v33普通从头完成五件抓取、搬运、插入、松夹、双臂撤回及原共同240tick，原success/assisted_success=true，57416步。第四件共用turn回归与第五件整流程实际通过；第五件搬运290有限样本中右臂最小可见净空33.026mm。原执行链7176/7177组独立对齐；末相机/五件证书同native57419，但完整独立native快照早7tick，原执行后审false保留；部分stride8插入准入缺测不回填。三完整原片已下载并逐SHA/9点本机播放校验，16组三视图实际审看。唯一结论/复盘/媒体及限制只引用`D26_conclusions.json`、`D26_retrospective.json`、`D26_local_media_review.json`。这是固定连接与安装世界支撑的辅助成功，不是自然抓稳或撤除支撑后的稳定证明。

- 最新空间复算见`analysis_20261020/A38_part0_right_arm_visible_gap.json`：95个原实录几何样本中第五件持续靠近右腕2，末样本间隙2.257668mm；实际碰撞为腕凸分解/零件SDF，导出contact offset缺失，不能虚构安全裕量或冲击力。新候选先审本件路径，原生短筛不称从头续跑。

- A38/v32普通从头首次实际完成第四件全部10段插入、松夹、退避和park，随后第五件捕获/抬升/pickup_clearance通过，在assembly_clearance触发原模型角度门（1.560262mrad>1.5mrad，位置38.9101um未超100um）。第五件插入与最终共同240tick未到，原success/assisted_success=false。结论、提前新瓶颈复盘和证据范围只引用`D22_conclusions.json`、`D22_retrospective.json`。
- 第五件155个同钟记录中，模型与独立native腕×float32关节锚点误差最大相差约.297um/.000429mrad；最后配对native50939比失败边界50944早5tick，不能用采样最大.760548mrad否定缺口内的瞬态，也未确认FK标定或求解迭代是根因。rot0=identity由已核生产构造器赋值，旧事件未独立读回。保留原保护，不复制第四件参数试错；当前后续权限只读账本。

- 六次短物理尝试的机器结案为`P/D12_probe_review.json`至`D17_probe_review.json`，前两次、第四次及第五/六次复盘分别见`D13_retrospective.json`、`D15_retrospective.json`、`D16_terminal_lead_diagnosis.json`、`D17_retrospective.json`。原件不覆盖；当前次数不在本页复制。
- A28/A29保留完整最终SE3后仍触发约100um模型门。独立native腕×固定关节float32锚点与native零件比较，确认主要是实际固定连接的求解误差，不能归为腕FK标定错误。A30将part1位置迭代16→64后，旧初态的右扶资格先失败；保留该反例。A31在新数值条件下实际执行原右扶资格，再抓第四件，抬升通过；不能据此唯一分离初态与迭代数的因果贡献。
- A32通过抬升和转正，但在turn卡住：运动中的暂时超前量累积进最终高度，实际高度超原阶段目标约1.45mm，超过原1mm换段门。转向阶段没有高度纠正，继续等候不能消除该错误。`D16_terminal_lead_diagnosis.json`与`D17_work/terminal_lead_counterexample_before.json`保留实际和离线反例。
- A33在新episode中实际完成第四件lift/turn/transfer/lower，按原阶段完成条件转入transport_hover，于task6095有界停止。原生独立4664样本、无缺腕；完整clearance最大位置29.8391um、角度.541803mrad，低于原100um/1.5mrad门。完整assembly/严格插入/第四件释放/第五件/共同240tick未由短筛验证；原结果success=false，不冒充全装配成功。
- A33原报告164个实录候选有限精确CAD复核通过，最小约-.149012um数值表面交叠原样保留；预测stage候选、10条序列警告、缺几何/原stage夹爪frame缺口和采样间隙不抹掉。完整54网格/self/双臂与持件运行guard保留；不扩大为连续CCD、warehouse全场或cooked接触证明。引用`D17_original_candidates_review.json`、`D17_execution_evidence.json`、原postreview与visible_mesh报告。
- A34/v30普通从头完成第四件lift/turn/transfer/lower及transport_hover，insert_00原3600tick超时，原结果41762步/success=false。4668独立native腕锚样本、无缺腕，clearance最大30.21665um/.52840mrad，原模型门未超限。完整后审、真实1200tick尾录和三完整原片已闭环；结论仅引用`D18_conclusions.json`、`D18_retrospective.json`。
- A34新瓶颈为插入仍读取求解器原始角速度：末段约.304—.307rad/s，而连续native COM位姿差分最大约.00172rad/s；这属于先前抓取停稳修复的插入覆盖遗漏。v31复用原COM差分器，保留原.02m/s/.2rad/s、暖态轴向.05m/s、150um/1mrad/12tick。真实973样本中task38191首次取得12tick，旧门同刻仍拒绝；不插补缺tick。
- v31在实际task38200同钟44实体/三相机输入经生产adapter→最终限幅→完整54/self检查，27次/135有限网格样本通过；旧版hold，候选取得资格并下发插入。该回放重复静态观测、声明非线性FK/IK代理，不证明改变轨迹后的动力学。从头资格原件为`D19_work/formal_gate_spec.json`及`launch_gates/A35_beam_full.json`。A35启动后在环境构造前因原场景URL的TLS握手15秒超时退出，wrapper36.9577s/返回1；worker退出文件0不能算成功。无实际动作、图像、任务结果、视频或5秒物理尾段，v31动力学没有得到验证。结案/八轮复盘只引用`D19_conclusions.json`、`D19_retrospective.json`；当时按旧上限停，最新续授权只读账本。

- A36/v31原普通从头结案见`D20_conclusions.json`、`D20_retrospective.json`。前两根立柱的新COM准入/插入/释放/撤回实际通过，第四件初始抬升和切换通过，但turn因“incoming final publication exceeds original clearance lead envelope”失败，未到第四件插入；原结果35981步/success=false，比A34更早停止，不称新装配进展。独立2812腕锚样本无缺腕，第四件clearance最大30.1374um/.38471mrad，原模型门未超。完整1200tick尾录和三原片已下载核验。
- 新瓶颈证据：第四件预对齐240tick结束时腕轴距原配置0仍约2.34rad，随后IK选择负侧分支；转向时实测腕3停在native float32(-2pi)，原生目标约-6.3028755rad。离线读取实际组合USD资产得腕3限位±360度、肘关节±180度，其余臂关节±360度；旧原生限位数值未被采集，不能伪称已有native limits读回。见`D20_work/asset_joint_limits.json`及原motion/physics/SDK记录。
- v32由`P/D21_work/candidate`资格后部署到权威A；889源SHA`3f27dea63c0e3477eb22323bb16449c2e69a7645f5eda8b15b0e44547a72cc5f`，只改compiler/state及原测试模块。复用现有预对齐到位和原生角度选项，让第四/第五件抓前按原0.05rad和原3600tick阶段预算实际回到指定分支；新增最终native joint limits读取/拒绝，不改物理限位、速度、抓取、模型、超前或成功门。528相关回归新跑通过，四实际布局除98限位flag和两处预对齐策略外全字段相同。
- 原始初态44实体/三视图的运动学回放：旧240tick后仍差2.311rad；候选1048tick达到原0.05rad范围，5240有限完整54/self扫掠样本通过。0.08跟踪响应明确取自原预对齐记录，只作显式运动学反事实，不证明动力学。该反事实不代替后述A37短物理验证；当前运行与授权只读账本。

- A37已在新episode中重新完成原右扶资格、空手原生分支回正、第四件捕获及lift/turn/transfer/lower，9377步转入transport_hover后有界停。原预对齐1050tick后实测最大误差.047910rad；双臂原生限位实际读回，未有非法命令拒绝。独立4672腕锚样本无缺腕，clearance最大31.4630um/.529394mrad；原165候选有限精确复核通过，最小-.625849um数值接触保留。前三件是短场景已安装初态，不计本轮装配进展；插入/第五件/最终释放240tick未验证。结论和两轮复盘只引用`D21_conclusions.json`、`D21_retrospective.json`。
- 新增限位保护的前段适用域按A36实际最终命令核对：两臂各4168条均在A37实测范围内。主USD根与保留资产记录、两轮实际导出的机器人joint字段和语义映射相同；不冒称完整传递资产封存或A36已有原生限位读回。部署后四实际布局与候选全字段绑定通过，原成功条件不变；普通从头资格见`D21_work/formal_gate_spec.json`，仍须实际从头执行。

## 权威、候选和回退

- 本机L=`/Users/zhaoheng/Desktop/PCL work/Beam修复/RoboAssemblyBench`；P_local=`L/outputs/beam_assisted_20261015`；A_L=`P_local/assisted_repository`为副本。W=`L/submission/beam_upstream_integration_2026-10-10`保留既有脏树，不reset/clean/add-A，不自动更新PR。
- 服务器`pcl-server`；R=`/home/user/beam_integration_20261010_upstream6f57dae`；P=`R/beam_assisted_20261015`；权威A=`P/assisted_repository`，无Git。原始运行在`P/runs/<run>`；v33已验私有候选保留`P/D24_work/candidate`，本轮资格候选在`P/D27_work/candidate`，v34及其v35映射修复均按下列封存保留。
- 当前v35为889源/20关键工具：源清单SHA`6fb47c35bccf5be5fdd854d17c1bfe825dc59d9722708c15510e1217d9fd4fd7`；关键工具清单SHA`1b17561c813c4c77b0f5d383d62058c801df7ed64a704beab1e9af8d03af5218`（工具未变）。封存`P/A44_beam_full_sealed_version.json`，源包SHA`677a9855adf3bd9200940032c628c9917d019a00f0cc3c7e8a350a5f7d494bd1`、工具包SHA`b196332c33a82647608245c60271820b99e844f941683a5f330ad3427830d574`。资格`P/D28_work/alias_fix_qualification.json` SHA`751d3b1a4c8c74772219944d8d0192d143d9d7f1eb902452481a2a0a7b5c9249`；相机实图、三段回位与原五件/home共同240tick已由A44主判定达到；独立末帧raw缺口及原false保留，见D28结论。
- 历史v34/A43启动失败版为889源/20关键工具：源清单SHA`75c627bd7ea35f392d39ec58e8ef5ced2cc627d6e06c4465465a11340e9c88d6`，关键工具清单SHA`1b17561c813c4c77b0f5d383d62058c801df7ed64a704beab1e9af8d03af5218`。相对v33改10源（含四测试与一个既有joint技能注册）和worker/workflow/geometry三个关键工具；原夹持、约束、solver、持件servo与成功阈值不改。源包SHA`1066f94b0783c8049cee1ed8a1a80984d3e3f8ec87df33f9ae354e2faa415adc`、20工具包SHA`1fb75e957c1cafefa4469eec290667572219bbf6f01672424de1e6b7792d79d4`，封存`P/A43_beam_full_sealed_version.json`。v33十源/清单回退在`P/D27_work/before_authority`，工具原件在`before_tools`；本机旧副本保留`D27_work/before_local_authority.tar.gz`。四布局505实际签名`b38c34c0b0bb61b8b9b66315778566fc74595fffff0839f1b2d164e6baf7eeb8`。资格未宣称native或完整装配通过。
- 上一版已冻结部署v33，889源清单`P/tools/assisted_manifest.json` SHA`476bee3ba19a5c3daa107e6058080e6be9e5715dc6dede48ee34c401477e22e7`；20关键工具清单SHA`4ca6f0c32f07f541fd7b56b5f6661266eb6df4a090f284f76b03ba3ae34dbc17`。相对v32只改compiler/servo/原测试三源：第五件复用共用分段搬运，turn只回撤实测多余向上超前；169受影响检查、四布局精确投影、A40完整搬运与A41第五件插入释放短筛已验。原solver/速度/模型/抓取/成功门不变。源包SHA`05d69f28e24c37c2cfefccc66655d57231cef6a3fc4ed68b00cd9ae27034b5ed`，工具包SHA`3f3788d36058f45dbb4256827e810307d3d5ecddf98796b8124ff043c588412c`，封存见`P/A42_beam_full_sealed_version.json`；v32三源/清单回退在`P/D24_work/before_authority`，本机在`D25_work/before_local_authority`。身份按清单核对，不按目录/Git猜测。
- v31/A36历史封存`P/A36_beam_full_sealed_version.json`：源889与A35完全相同；工具20中仅`beam_workflow.py`扩展显式20轮授权守卫，SHA`b178526933dc9993611a024fba7de0995cebea94c475495910c418e26b1e1a30`。辅助网络helper及普通launcher增加同URL/内容SHA的领取次数前预检与最多3次有限重试；场景loader/physics未改，14项离线负正例通过。旧工具和扩展前27文档保留`D20_work/before_tools`及`before_extension_documents.tar.gz`。启动资格只引用`D20_work/formal_gate_spec.json`与`formal_reuse_certificate.json`，未重跑未改的生产测试或四布局。
- v32封存`P/A38_beam_full_sealed_version.json`：源包SHA`5eb34b26f096110807d34426aacc85090ca41bcb92dd7b0752b1e1e259536d92`、20工具包SHA`7568c364d45b03f6027c32a301c6e5eaf2fa823e8d07be2f1836654168265b64`。仅compiler/state/原测试模块三源变，关键20工具未变；部署前v31三源和清单保留`D21_work/before_authority`，本机在`D21_work/before_local_authority`。四布局505签名`c6bb7a0c93d512023025d2086db881e712771c76ab3186bfa1a6c837de51f9be`。
- v31/A35历史封存`P/A35_beam_full_sealed_version.json`：源SHA`0af99e7c4440012b5d50bb46610cc14047754eadc50cb63589498f42ead9d289`；20工具SHA`2faa3527ccfc6783ba1fbdea685534bd033e7ab11e6f7e753fcd7c62a154d678`。相对v30仅六源变化：插入COM测量、读取选项、编译合同、预检及两测试模块。152受影响检查新跑通过，另364项按全源/单私有测试fixture AST一致复用，共516不同检查，不能称新跑516。初次宽回归515过/1 fixture失败原件保留。资格及复用只引用`D19_work/source_qualification.json`、`related_suite_reuse_certificate.json`；四实际布局505签名`537b668ed1f508f313cbf04dae3fd9ed8c3997f0074cd32b1554df7b36df1c8a`。
- v30历史回退封存`P/A34_beam_full_sealed_version.json`：源`versions/assisted_v30_before_A34_beam_full.tar.gz` SHA`f9de8cf46e6f0c16dd7fc907112b6c51ecbd285e96a0bb869a3b7e5ff1f54836`；20工具`versions/assisted_v30_tools_before_A34_beam_full.tar.gz` SHA`bfa88e30e6761f8f4dc51b1bd7f94b1280c7f6fc6f7ce67b9e0ff5d401704988`。附加场景传输helper独立封存`D17_work/v30_auxiliary_tools.tar.gz`并绑定启动门，不改20文件清单范围。
- v30相对v28只改4源：compiler、servo、adapter及原object-servo测试模块。冻结阶段入口原有负载偏移，将运动中的暂时超前量与其分开；完整SE3连续，终点限制为阶段目标加该固定负载偏移。仅part1位置迭代16→64，速度迭代不变；USD读回64/4，native有效island迭代数读回未取得，不夸大已测范围。
- v30历史130项受影响模块通过；数值配置变化时先完成487项相关宽回归，后续终点控制修改只重跑130项，并按AST/源SHA复用未改领域；不能说新分支重新跑了487项。证据`source_qualification.json`、`terminal_cap_reuse_certificate.json`与`before_terminal_cap/broad_suite_result.json`。
- v30历史四实际生产布局全模型、原成功条件和部署配置逐字段相等；路径派生recipe指纹独立重算。505签名`59d1baa6cd553d4d9841b5ea91fd19eb8cec7413c23b2e2598f53bc66657b146`。初次绑定器错误解析资产符号链接字符串的工具/完整配置已保留`D17_work/validation_errors/authority_path_normalization/`；只修核验器，不豁免生产字段。
- A27真实输入离线链与原危险负例保留；A33 task6088同钟44实体/三视图输入补查下一transport_hover入口，27次最终双臂guard/135有限54CAD-self扫掠通过。该点早于真实换段6tick，属于明确标识的静态反事实，不补造缺失终止实体帧、不证明PhysX切换效果。见`D17_work/adjacent_control_replay.json`。
- v31部署前六源及清单在`D19_work/before_authority`，本机旧源在`D19_work/before_local_authority`；v30权威部署前4源、旧清单/worker/gate工具在`D17_work/before_authority`；本机旧源在`D17_work/before_local_authority`。主要回退v28/A27源封存SHA`0ed00fa7164bdfa779fd76b7810cc573cb89940abd5ad8b9338e71c03a3cf194`、工具封存SHA`ddec4039a272e43af66133e79aaa3ef23ec5195d4e892c4671ad9a8823679354`；八轮授权窗口扩展前工具另外保留`D12_work/critical_tools_before_window_extension.tar.gz`。不要用旧授权状态覆盖最新人类指令。更早回退按保留的整理前交接/各sealed_version原件检索。

## 不变合同与执行入口

- 原双侧可见pad gap5—250um、无交叠、12独立native tick后按实测位姿创建dynamic fixed joint，6DOF捕获关系冻结。生产不写零件位姿/速度、不清速度、不切kinematic、不关碰撞。辅助固定不称自然抓稳或承力。
- 右臂全开→近夹底梁→视觉保持→最后撤回，保留同run/epoch最新最终发布目标。严格插入150um/1mrad/12tick；模型100um/1.5mrad；冷世界轴、120um横向积分、500um实际冷高度、原速度和24tick换段均不放宽。
- 安装上方3mm世界支撑，六夹爪实际全开≤.05rad后按原≤.1mm/.2mrad每物理步缓落。最终五件夹爪释放（安装世界支撑仍保留）、原目标3mm/.04rad、共同240独立native tick及原全序列完成才接受。
- 每轮读`BEAM_REVIEW_CHECKLIST.md`和`beam_routes/assisted/CHECKLIST.md`。固定工具在`P/tools`：真实回放`replay_assisted_transition.py`，独立短筛`assisted_probe.py`/`launch_assisted_probe.py`，短筛后审`close_assisted_probe.py`，普通从头入口`launch_reviewed_run.py`，完整后审`review_run.py`。ACK/STOP始终用共享原子publisher；实际看过本进程三原图后才ACK。
- 六项门绑定当前源/工具/配置和历史适用域；启动后必须确认首动作与native/entity/CAD实际增长。完整最终限幅后双臂、完整夹爪/持件扫掠不省略。原首失败及5秒物理尾录、缺测、原报告覆盖和三视图同钟不省略。
- 每两次原生复盘，新瓶颈提前触发；两次无改善停止同类局部试错，取得判别证据后再走下一机制。可分别验证且无干扰的修复可以合并，不重复全仓回归。不得把短筛或exit0写为全装配成功。

## 媒体、计时和同步

- D28/A44新媒体只引用`D28_work/D28_local_media_review.json`与新三原片目录；新三原片各7445帧/30fps/248.166667s，合计73461022字节，服务器完整解码通过；包102209761字节/SHA`1c880f612388b1429cc9fbde33720faadd5ec53fd74e98680a638386310ab456`。本机原片位于`P_local/D28_work/A44_media/episode_0000_live_videos/`，全部60传输文件SHA及3原片9点AVFoundation播放通过，7组回位首末/末帧三视图已实际审看且各offset0；回位短片289帧/9.633333s，终态短片38帧/1.266667s；原片帧数不补终态raw native缺口。旧A42媒体不替代本轮。结案前27文本备份为本机`D28_work/before_local_D28_closed_documents.tar.gz`及服务器本轮同步stage备份；本轮同步证书只引用`outputs/beam_assisted_D28_closed_20261021/sync_verification.json`，缺失即pending。

- A42三完整原片在`P_local/D26_work/A42_media/episode_0000_live_videos/`，每路7177帧/239.233333s；只在服务器完整解码一次，本机78传输文件逐SHA及9点原生播放通过，16组同钟关键三视图已审。最后PNG与五件证书同native57419；缺完整独立raw native末帧，原错误不覆盖。媒体只引用`D26_local_media_review.json`；本次整理前27文档在本机`D26_work/before_local_closure_documents.tar.gz`和服务器`D26_work/before_server_closure_documents.tar.gz`。
- D27准备前完整文档保留在本机`D27_work/before_local_round_documents.tar.gz`及服务器`D27_work/before_server_round_documents.tar.gz`。本次准备同步按27文件清单执行，凭`D27_work/docs_ready_sync_verification.json`核验；未取得新证书前为sync_pending，旧D26证书不覆盖本次编辑。

- A38三完整原片在`P_local/A38_evidence/episode_0000_live_videos/`，每路6517帧/217.233333s，包含真实1200tick/5秒失败观察尾段。服务器完整解码一次、本机大小/SHA和9点原生播放通过，12组同钟关键三视图已实际审看。失败PNG晚3tick、末PNG比尾段终点早5tick；第五件左腕局部受臂遮挡，不由画面判微米误差。只引用`D22_local_media_review.json`。

- A37三完整原片在`P_local/D21_work/A37_media/episode_0000_live_videos/`，六组同钟关键三视图已实际审看，逐大小/SHA和本机9点播放通过；末PNG native9379比短筛边界9380早1tick。wrapper1253.2355s，分项保留在原`short_segment_timing.json`，嵌套时间不相加。媒体记录只引用`D21_local_media_review.json`。

- A36三完整原片在`P_local/A36_evidence/episode_0000_live_videos/`，六组同钟关键三视图已实际审看；首次失败PNG比native失败晚3tick，末PNG比尾段终点早5tick，缺口原样保留。服务器完整解码一次，本机SHA及9点原生播放通过，三个聚焦短片SHA相同。见`D20_local_media_review.json`。
- A35启动失败21份原件已下载并逐SHA核对，包`P_local/D19_work/A35_beam_full_startup_failure_evidence.tar.gz`；零视频为未生成，不能由旧片补代。见`D19_local_evidence_review.json`。
- A34三完整原片已下载`P_local/A34_evidence/episode_0000_live_videos/`，5370帧/每视角，179s；服务器完整解码一次，本机逐SHA一致及9点原生播放。8组同钟关键三视图已实际审看，首次失败与最后PNG比原生边界早2tick，缺口原样保留。见`D18_local_media_review.json`。
- A28—A32三完整原片在`P_local/D12_work/A28_media`至`A32_media`；A33在`P_local/D17_work/A33_media`。传输逐大小/SHA相同，服务器每轮完整解码一次，本机各9点原生播放；实际同钟关键三视图已审，媒体审查记录在各work目录。A33末图native6091，比边界6098早7tick，不当精确终止图。原PNG和服务器完整原生归档保留。
- 网络检查现已置于普通launcher领取原生次数前，同原URL/内容SHA，最多3次请求；失败保留原件且不启动/不计次。runtime检查也最多3次，原场景loader不变，不采用缓存或替代场景。runtime启动失败仍按原计数合同。
- 分项计时见每轮`short_segment_timing.json`，A28缺测明确保留。physics与render由Kit.update合并，不能声称已独立分开GPU耗时；嵌套/并行时间不相加。短筛与完整从头范围不同，不直接报加速倍数。已复用未改回归/固定后审，避免重复完整解码；媒体仅无损压缩打包，未重编码原片；同一主场景URL的有界HTTP存在性检查替代曾阻塞约300秒的SDK检查，原USD loader和场景资产不换。
- 本次结案前完整27文档：本机`D22_work/before_local_closure_documents.tar.gz`、服务器`D22_work/before_closure_documents.tar.gz`；旧结案前原件仍在本机`D19_work/before_local_closure_documents.tar.gz`和服务器`D19_work/before_final_closure_documents.tar.gz`；启动准备前版本仍在对应`before_local_ready_documents.tar.gz`与`before_formal_ready_documents.tar.gz`；v30前版本仍在对应`D17_work`；更早完整交接保留在`D12_work/before_local_continuation_documents.tar.gz`。按`beam_routes/docs_manifest.json`显式27文件，一次同步本机W/A_L及服务器R/C/旧根/A，逐文件SHA。同步证书见该清单receipt字段；缺失/失败即pending，不改源/工具封存。
- 已停止的断点专项不恢复；松散实现/入口/测试已移除，旧checkpoint不等价结论及删除边界见`outputs/beam_output_cleanup_20261019/cleanup_summary.json`与`outputs/beam_checkpoint_code_cleanup_20261019/completion_summary.json`。普通训练checkpoint/路径节点不属该清理。

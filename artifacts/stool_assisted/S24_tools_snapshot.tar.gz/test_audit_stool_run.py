"""Synthetic auditor-contract regression; never evidence of simulation success."""
import copy
import importlib.util
import io
import json
from pathlib import Path
import tarfile
import tempfile


def main():
    script = Path(__file__).with_name('audit_stool_run.py')
    spec = importlib.util.spec_from_file_location('audit_stool', script)
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    def dual_row(body, transform, usd=None):
        native=audit.transform_matrix(transform)
        expected=audit.sdk_usd_matrix(transform,'float32')
        usd=copy.deepcopy(expected if usd is None else usd)
        tolerance=32*2**-23*max(1.,max(abs(v) for r in native for v in r))
        error=audit.matrix_difference(native,usd)
        scalar=abs(transform[6]);bits=audit.struct.unpack('<I',audit.struct.pack('<f',scalar))[0]
        scalar_ulp=audit.struct.unpack('<f',audit.struct.pack('<I',bits+1))[0]-scalar
        method='Gf.Matrix4d.SetRotate(Gf.Rotation(Gf.Quatd(raw_w,raw_xyz)))'
        return dict(body=body,native_world_matrix=native,usd_world_matrix=usd,tolerance=tolerance,
            matrix_max_abs_error=error,position_error_m=audit.distance(transform[:3],[r[3] for r in usd[:3]]),
            angle_error_rad=audit.rotation_distance(native,usd),passed=error<=tolerance,
            publication_passed=True,expected_usd_world_matrix=expected,
            publication_matrix_max_abs_error=audit.matrix_difference(expected,usd),
            raw_native_pose_xyzw=transform,raw_native_quaternion_xyzw=transform[3:],raw_native_dtype='float32',
            raw_quaternion_norm=audit.norm(transform[3:]),
            raw_quaternion_scalar_ulp=scalar_ulp,
            representation_delta_rad=audit.rotation_distance(native,expected),
            representation_matrix_max_abs_error=audit.matrix_difference(native,expected),
            conversion_method=method,conversion_receipt=dict(synthetic_schema_fixture_only=True,
                actual_sdk_called=True,sdk_module_path='/synthetic/fixture/Gf/__init__.py',method=method,
                raw_dtype='float32',native_pose_float32_roundtrip=True,raw_quaternion_norm=audit.norm(transform[3:]),
                quaternion_norm_sanity_atol=64*2**-23,scalar_in_unit_interval=True,
                axis_identity_epsilon=1e-10,sdk_math_matrix_max_abs_error=0.))
    numeric_tests=[]
    sdk_probe=Path(__file__).with_name('fixtures')/'stool_usd_alignment/actual_sdk_probe.json'
    if sdk_probe.is_file():
        for captured in json.loads(sdk_probe.read_text())['rows']:
            assert audit.matrix_difference(audit.sdk_usd_matrix(captured['transform_xyzw'],'float32'),
                captured['expected_usd_world_matrix'])<1e-12
        numeric_tests.append('four_actual_installed_Gf_probe_matrices_match_independent_stdlib_math')
    actual=Path(__file__).parents[1]/'grant02/S03_diagnostic_slice/terminal_capture_diagnostics.json'
    if actual.is_file():
        captured=json.loads(actual.read_text())
        original=next(r for r in captured['stage_native_alignment']['after_render']['rows']
                      if r['body'].endswith('/fabrica_stool_circular_2'))
        transform=captured['before']['transforms_xyzw'][original['body']]
        row=dual_row(original['body'],transform,original['usd_world_matrix'])
        result=audit.native_usd_dual_row(row,transform)
        assert result['normalized_native_alignment_passed'] is False
        assert abs(result['normalized_native_matrix_max_abs_error']-original['matrix_max_abs_error'])<1e-12
        assert abs(result['normalized_native_angle_error_rad']-original['angle_error_rad'])<1e-7
        assert result['normalized_native_matrix_max_abs_error']>row['tolerance']
        assert result['publication_matrix_max_abs_error']<1e-12
        numeric_tests.append('S03_captured_matrix_puremath_SDK_domain_matches_and_original_residual_retained')
        for key in ('matrix_max_abs_error','angle_error_rad'):
            changed=copy.deepcopy(row);changed[key]=0.
            try:audit.native_usd_dual_row(changed,transform)
            except ValueError:pass
            else:raise AssertionError('erasing original residual was accepted: '+key)
            numeric_tests.append('erased_original_'+key+'_rejects')
        changed=copy.deepcopy(row);changed['passed']=True
        try:audit.native_usd_dual_row(changed,transform)
        except ValueError:pass
        else:raise AssertionError('rewriting original native pass/fail accepted')
        numeric_tests.append('rewritten_original_native_failure_rejects')
        for label, mutate in (
            ('actual_sdk_call_receipt_missing',lambda r:r['conversion_receipt'].update(actual_sdk_called=False)),
            ('sdk_conversion_receipt_math_missing',lambda r:r['conversion_receipt'].update(sdk_math_matrix_max_abs_error=None)),
            ('raw_pose_unbound',lambda r:r['raw_native_pose_xyzw'].__setitem__(0,r['raw_native_pose_xyzw'][0]+.01))):
            changed=copy.deepcopy(row);mutate(changed)
            try:audit.native_usd_dual_row(changed,transform)
            except ValueError:pass
            else:raise AssertionError('invalid SDK/raw source receipt accepted: '+label)
            numeric_tests.append(label+'_rejects')
    for label, transform, dtype in (
        ('wrong_dtype',[0.,0.,0.,0.,0.,0.,1.],'float64'),
        ('non_float32_values',[0.,0.,0.,0.123456789,0.,0.,1.],'float32'),
        ('raw_real_outside_acos_domain',[0.,0.,0.,0.,0.,0.,1.0000001192092896],'float32'),
        ('nonunit_raw_quaternion',[0.,0.,0.,.5,.5,.5,.5+2**-10],'float32')):
        try:audit.sdk_usd_matrix(transform,dtype)
        except ValueError:pass
        else:raise AssertionError('invalid raw quaternion accepted: '+label)
        numeric_tests.append(label+'_rejects')
    tiny=audit.struct.unpack('<f',audit.struct.pack('<f',1e-11))[0]
    near_real=audit.struct.unpack('<f',audit.struct.pack('<f',1.-2**-24))[0]
    for sign in (-1.,1.):
        value=audit.sdk_usd_matrix([0.,0.,0.,tiny,0.,0.,sign*near_real],'float32')
        assert audit.matrix_difference(value,[[float(i==j) for j in range(4)] for i in range(4)])==0.
    numeric_tests.append('actual_Gf_nearzero_imag_axis_identity_branch')
    with tempfile.TemporaryDirectory(prefix='stool_auditor_test_') as temp:
        root = Path(temp).resolve()
        objects, robots = sorted(audit.OBJECTS), sorted(audit.ROBOTS)
        names = list(audit.ARM) + ['finger_joint', 'right_outer_knuckle_joint', 'left_inner_finger_joint',
                                 'right_inner_finger_joint', 'left_inner_finger_knuckle_joint',
                                 'right_inner_finger_knuckle_joint']

        def save(name, value):
            (root/name).write_text(json.dumps(value))

        def lines(name, values):
            (root/name).write_text(''.join(json.dumps(value)+'\n' for value in values))

        stamp = lambda i: dict(valid=True, epoch=0, index=i, time=i/240, dt=1/240)
        criteria = [dict(object=name, target='target_'+name, position_tolerance=.02,
                         orientation_tolerance=.15, linear_velocity_threshold=.05,
                         angular_velocity_threshold=2., require_released=True,
                         require_static=True) for name in objects]
        contract = dict(adapter='stool_circular_ur5e_v1', objects=objects,
                        original_success_criteria=criteria, final_stable_physics_steps=72,
                        stable_position_drift_m=.002, stable_orientation_drift_rad=.05,
                        gripper_open_joint_tolerance_rad=.02, max_tracking_error_rad=.12)
        cfg = dict(recipe='fabrica_stool_circular_ur5e_staged', seed=0, layout_seed=4906,
                   benchmark_metadata={'fabrica_assisted_contract': contract},
                   success_criteria=criteria, phase_specs=[{'fabrica_assisted_contract': contract}],
                   camera_metadata=[dict(name='front',video_key='observation.images.isaac_3d'),
                       dict(name='left_wrist',video_key='observation.images.left_wrist'),
                       dict(name='right_wrist',video_key='observation.images.right_wrist')])
        save('task_config_snapshot.json', [cfg])
        save('launch_gate.json', {'configuration_signature': 'prebuild'})
        save('worker_build_preflight.json', {'passed': True, 'report': {'configuration_signature': 'prebuild'}})
        save('runtime_initialization_preflight.json', {'passed': True, 'configuration': {'configuration_signature': 'runtime'}})
        save('runtime_configuration_binding.json', dict(passed=True,
            expected_configuration_signature='runtime', actual_configuration_signature='runtime',
            expected_roots=['left','right'], actual_roots=['left','right'], env_id=0,
            env_offset=[0.,0.,0.], task_count=1))
        poses = {name: dict(body_path='/World/'+name,
                           position=[audit.struct.unpack('<f',audit.struct.pack('<f',i*.1))[0], 0., 0.],
                           orientation=[1.,0.,0.,0.]) for i,name in enumerate(objects)}
        targets = {'target_'+name: {'position': p['position'], 'orientation': p['orientation']}
                   for name,p in poses.items()}
        certificate = dict(physics_stamp=stamp(71), required_stable_physics_steps=72,
                           stable_physics_steps=72, native_poses=poses,
                           identity={'configuration': json.dumps({'targets': targets, 'criteria': criteria})})
        metrics = dict(success=True, failed=False, terminal_reason='success-criteria-met',
            fabrica_assisted_qualification=dict(adapter=contract['adapter'], original_report_success=True,
                original_criteria_passed=True, phase_sequence_completed=True, final_native_qualified=True,
                retained_world_supports={name:'joint_'+name for name in objects},
                terminal_evidence=dict(same_clock=True, wrapper_sample_valid=True,
                                       independent_raw={'valid':True}, physics_stamp=stamp(71))),
            assisted_final_qualification=dict(certificate=certificate, current_native_recheck={'ready':True}))
        metrics.update(
            runtime_constraint_monitor=dict(enabled=True,observed_steps=72,checks=72,
                registered_robots={name:'/World/'+name for name in robots},monitor_error=[],
                missing_prims=[],missing_object_geometry=[],events_dropped=0,violation_total=0),
            assembly_sequence_precheck=dict(enabled=True,feasible=True,phase_count=1,errors=[],warnings=[]),
            stage_trajectory_precheck=dict(enabled=True,observed_steps=72,checks=2,segments_checked=4,
                waypoints_checked=8,frame_coverage={name:{'missing_model_frames':[]} for name in robots},
                skip_reasons={'holding_robot_current_joints':2},monitor_error=[],violation_total=0))
        save('collect_results.json', [metrics])
        raw, wrappers, published = [], [], []
        for index in range(72):
            bodies = {name:dict(path=p['body_path'], transform=p['position']+[0.,0.,0.,1.],
                               velocity=[0.]*6) for name,p in poses.items()}
            raw.append(dict(kind='independent_raw', valid=True,
                source='separate_exact_path_PhysX_tensor_views', body_view_id=1,
                boundary='after_physics', sequence=index, orientation_order='xyzw', pose_frame='world',
                velocity_reference='center_of_mass', physics_stamp=stamp(index), objects=bodies,
                bodies={p['path']:dict(transform=p['transform'],velocity=p['velocity']) for p in bodies.values()},
                robots={name:dict(joint_names=names,positions=[0.]*12,velocities=[0.]*12,
                                  position_targets=[0.]*12) for name in robots}))
            controls = [dict(joint_positions=[0.]*6,joint_indices=list(range(6))),
                        dict(joint_positions=[0.]*6,joint_indices=list(range(6,12)))]
            wrappers.append(dict(boundary='after_physics',clock_valid=True,
                physics_step_index=index,physics_time=index/240,task_constraints={'attachments':{}},
                bodies=[dict(name=name,path=p['body_path'],valid=True,orientation_order='wxyz',
                             positions=[p['position']],orientations=[p['orientation']]) for name,p in poses.items()],
                robots={name:dict(sdk_submission=dict(batch_sequence=index+1,
                    controllers=['arm_joint_controller','gripper_controller'],skipped=[],actions=controls))
                    for name in robots}))
            published.append(dict(event='fabrica_final_published_batch', physics_stamp=stamp(index),
                expected_sdk_batch_sequences={name:index+1 for name in robots},
                actions={name:dict(arm_joint_controller=[[0.]*6],gripper_controller=[1.]) for name in robots}))
        terminal_raw=copy.deepcopy(raw[-1]);terminal_raw.update(boundary='terminal',sequence=72)
        raw.append(terminal_raw)
        lines('independent_native_trace.jsonl',raw)
        lines('physics_boundary_trace.jsonl',wrappers)
        lines('assisted_trace.jsonl',published)
        snapshot=dict(physics_stamp=stamp(71),body_paths=sorted(terminal_raw['bodies']),
            transforms_xyzw={p:b['transform'] for p,b in terminal_raw['bodies'].items()},
            velocities={p:b['velocity'] for p,b in terminal_raw['bodies'].items()},
            object_paths={name:b['path'] for name,b in terminal_raw['objects'].items()},
            robots={name:dict(names=names,positions=[[0.]*12],velocities=[[0.]*12],targets=[[0.]*12])
                    for name in robots},counters=dict(step_counter=72,phase_index=1,phase_entry_step=0,
                        steps=72,success=True,failed=False,work=0),
            phase_transition_history=['synthetic terminal phase'])
        alignment=dict(passed=True,schema_version='native_usd_dual_v1',normalized_native_alignment_passed=True,
            body_paths=snapshot['body_paths'],bodies=len(snapshot['body_paths']),
            rows=[dual_row(p,t)
                  for p,t in snapshot['transforms_xyzw'].items()])
        def references(numerator):
            return [dict(camera=s['name'],reference=dict(valid=True,numerator=numerator,denominator=30))
                    for s in cfg['camera_metadata']]
        proof=dict(passed=True,errors=[],before=snapshot,after=copy.deepcopy(snapshot),
            native_state_exactly_unchanged=True,
            stage_native_alignment=dict(passed=True,native_unchanged=True,
                before_publication=dict(passed=False),after_publication=copy.deepcopy(alignment),
                after_render=copy.deepcopy(alignment)),
            clock_validation=dict(passed=True,errors=[],before_render=references(27),
                render_passes=[dict(pass_index=i,physics_stamp=stamp(71),cameras=references(numerator),
                                   native_state_exactly_unchanged=True)
                               for i,numerator in enumerate([29,30,31,32,32,33,34,35])],after_render=references(35),
                all_three_shared_each_pass=True,nondecreasing_shared_render_stamps=True,
                final_render_stamp_newer_than_before=True,
                native_stamp_preserved_each_pass=True),images=[])
        cameras = []
        identity=[[float(i==j) for j in range(4)] for i in range(4)]
        for camera in cfg['camera_metadata']:
            name=audit.production_video_key(camera)
            payload=('synthetic schema fixture '+name+'; not image or simulation evidence').encode()
            (root/(name+'.png')).write_bytes(payload)
            proof_path='terminal_'+camera['name']+'.png';(root/proof_path).write_bytes(payload)
            sensor='/World/cameras/'+camera['name']
            proof['images'].append(dict(camera=camera['name'],video_key=camera['video_key'],path=proof_path,
                sha256=audit.digest(root/proof_path),physics_stamp=stamp(71),
                raw_reference_time=dict(referenceTimeNumerator=35,referenceTimeDenominator=30),
                camera_identity=dict(passed=True,sensor_path=sensor,backend_path=sensor,
                    render_product_path='/Render/'+camera['name'],render_product_camera_targets=[sensor],
                    usd_camera_world_matrix=identity,renderer_world_to_camera_matrix=identity)))
            cameras.append(dict(camera=name, physics_stamp=stamp(71), frame_index=1,
                image_path=name+'.png',render_reference_time=dict(valid=True,
                    source='same_render_product.ReferenceTime',numerator=35,denominator=30)))
        lines('video_frame_clock.jsonl',cameras)
        save('terminal_capture_diagnostics.json',proof)
        save('terminal_media_capture.json',dict(passed=True,physics_stamp=stamp(71),
            paired_capture='terminal_capture_diagnostics.json',render_only_steps=8,
            independent_raw=dict(valid=True,physics_stamp=stamp(71),sequence=72)))
        save('stool_geometry_initial.json',dict(passed=True,full_stage_export=True,meshes=10,pairs=1))
        lines('stool_production_geometry.jsonl',[dict(passed=True,first_failure=None)])
        source_binding = dict(passed=True,run_directory=str(root),configuration_signature='prebuild',
                              runtime_configuration_signature='runtime')
        for domain,key,hash_key,archive_key in (
                ('source','source_manifest','source_manifest_sha256','source_archive_sha256'),
                ('tools','tools_manifest','tool_manifest_sha256','tools_archive_sha256')):
            payload = (domain+' synthetic source').encode()
            manifest = {'file.py':audit.hashlib.sha256(payload).hexdigest()}
            archive_path = root/(domain+'_snapshot.tar.gz')
            with tarfile.open(archive_path,'w:gz') as stream:
                member = tarfile.TarInfo('file.py');member.size=len(payload)
                stream.addfile(member,io.BytesIO(payload))
            source_binding[key] = manifest
            source_binding[hash_key] = audit.hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
            source_binding[archive_key] = audit.digest(archive_path)
        save('source_binding.json',source_binding)
        (root/'asset.usda').write_text('synthetic composed-layer test fixture')
        assets = [{'identifier':'asset.usda','resolved_path':str(root/'asset.usda'),
                   'sha256':audit.digest(root/'asset.usda')}]
        source_binding.update(asset_manifest=assets,
            asset_manifest_sha256=audit.hashlib.sha256(json.dumps(assets,sort_keys=True).encode()).hexdigest(),
            launch_source_binding_sha256=audit.digest(root/'source_binding.json'))
        save('runtime_source_binding.json',source_binding)
        save('media.json',dict(all_three_original_videos_decoded=True,sha256_verified=True))
        def check():
            return audit.run_audit(root,root/'runtime_source_binding.json',root/'media.json')
        result = check()
        assert result['accepted_full_assembly'],result['checks']
        tests = numeric_tests+['complete72tick_P02_internal_repeat_render_sequence_accepts_legacy_front_alias']
        proof_path=root/'terminal_capture_diagnostics.json'
        proof_path.unlink()
        assert check()['checks']['terminal_three_view_clock_join']['passed'] is None
        tests.append('old_run_without_paired_capture_proof_remains_missing')
        save('terminal_capture_diagnostics.json',proof)
        changed=copy.deepcopy(proof);changed['after']['counters']['step_counter']+=1
        save('terminal_capture_diagnostics.json',changed)
        assert check()['checks']['terminal_three_view_clock_join']['passed'] is False
        tests.append('changed_native_state_during_render_rejects')
        changed=copy.deepcopy(proof)
        changed['clock_validation']['render_passes'][3]['cameras']=references(29)
        save('terminal_capture_diagnostics.json',changed)
        assert check()['checks']['terminal_three_view_clock_join']['passed'] is False
        tests.append('backwards_render_stamp_rejects')
        changed=copy.deepcopy(proof)
        changed['clock_validation']['before_render']=references(35)
        for entry in changed['clock_validation']['render_passes']:
            entry['cameras']=references(35)
        save('terminal_capture_diagnostics.json',changed)
        assert 'final render products are stale' in check()['checks']['terminal_three_view_clock_join']['error']
        tests.append('all_render_products_stale_for_entire_capture_rejects')
        changed=copy.deepcopy(proof)
        changed['clock_validation']['before_render'][0]['reference']['numerator']=26
        save('terminal_capture_diagnostics.json',changed)
        assert check()['checks']['terminal_three_view_clock_join']['passed'] is False
        tests.append('nonshared_initial_render_product_clock_rejects')
        changed=copy.deepcopy(proof)
        changed['clock_validation']['render_passes'][3]['cameras'][0]['reference']['numerator']=99
        save('terminal_capture_diagnostics.json',changed)
        assert check()['checks']['terminal_three_view_clock_join']['passed'] is False
        tests.append('nonshared_render_product_clock_rejects')
        changed=copy.deepcopy(proof)
        changed['clock_validation']['render_passes'][3]['native_state_exactly_unchanged']=False
        save('terminal_capture_diagnostics.json',changed)
        assert check()['checks']['terminal_three_view_clock_join']['passed'] is False
        tests.append('intermediate_native_change_with_restored_final_snapshot_rejects')
        changed=copy.deepcopy(proof)
        changed['stage_native_alignment']['after_render']['rows'][0]['usd_world_matrix'][0][3]+=.01
        save('terminal_capture_diagnostics.json',changed)
        assert check()['checks']['terminal_three_view_clock_join']['passed'] is False
        tests.append('native_usd_body_matrix_mismatch_rejects')
        changed['stage_native_alignment']['after_render']['rows'][0]['tolerance']=1.
        save('terminal_capture_diagnostics.json',changed)
        assert check()['checks']['terminal_three_view_clock_join']['passed'] is False
        tests.append('inflated_stage_native_representation_tolerance_rejects')
        save('terminal_capture_diagnostics.json',proof)
        changed=copy.deepcopy(cfg);changed['camera_metadata'][1]['video_key']='observation.images.front'
        save('task_config_snapshot.json',[changed])
        assert check()['checks']['terminal_three_view_clock_join']['passed'] is False
        tests.append('duplicate_production_camera_alias_rejects')
        save('task_config_snapshot.json',[cfg])
        (root/cameras[0]['image_path']).write_bytes(b'different retained video pixels')
        assert check()['checks']['terminal_three_view_clock_join']['passed'] is False
        tests.append('retained_video_pixels_differ_from_paired_proof_rejects')
        (root/cameras[0]['image_path']).write_bytes((root/proof['images'][0]['path']).read_bytes())
        terminal_raw['physics_stamp']=stamp(70);lines('independent_native_trace.jsonl',raw)
        assert check()['checks']['terminal_three_view_clock_join']['passed'] is False
        tests.append('independent_terminal_raw_native_stamp_mismatch_rejects')
        terminal_raw['physics_stamp']=stamp(71);lines('independent_native_trace.jsonl',raw)
        changed=copy.deepcopy(proof);changed['images'][0]['camera_identity']['renderer_world_to_camera_matrix'][0][3]=.1
        save('terminal_capture_diagnostics.json',changed)
        assert check()['checks']['terminal_three_view_clock_join']['passed'] is False
        tests.append('renderer_sensor_world_matrix_mismatch_rejects')
        save('terminal_capture_diagnostics.json',proof)
        assert check()['accepted_full_assembly']
        metrics['assembly_sequence_precheck']['warnings']=[{'message':'benign declared sampling warning'}]
        save('collect_results.json',[metrics]);assert check()['accepted_full_assembly']
        tests.append('benign_warning_and_checked_hold_skip_preserved_without_failure')
        metrics['stage_trajectory_precheck']['skip_reasons']['unknown_scope_skip']=1
        save('collect_results.json',[metrics])
        assert check()['checks']['required_original_passive_report_coverage']['passed'] is None
        tests.append('ambiguous_skip_scope_is_missing_review_needed')
        metrics['stage_trajectory_precheck']['skip_reasons'].pop('unknown_scope_skip')
        metrics['runtime_constraint_monitor']['monitor_error']=[{'message':'unhandled original monitor failure'}]
        save('collect_results.json',[metrics])
        assert check()['checks']['required_original_passive_report_coverage']['passed'] is False
        tests.append('unhandled_original_error_rejects')
        metrics['runtime_constraint_monitor']['monitor_error']=[]
        saved_section=metrics.pop('stage_trajectory_precheck');save('collect_results.json',[metrics])
        assert check()['checks']['required_original_passive_report_coverage']['passed'] is None
        tests.append('missing_required_original_section_rejects')
        metrics['stage_trajectory_precheck']=saved_section;save('collect_results.json',[metrics])
        save('collect_results.json',[]);save('episode_0000.json',{'metrics':metrics})
        fallback=check()
        assert fallback['original_main_report']['reported_success'] is True
        assert fallback['original_report_sources']['collect_results.json']['reason']=='empty_primary_results_array'
        assert fallback['checks']['primary_collect_results_complete']['passed'] is None
        assert not fallback['accepted_full_assembly']
        tests.append('empty_collect_results_preserves_episode_fallback_and_fails_completeness')
        (root/'episode_0000.json').unlink();save('collect_results.json',[metrics])
        gap = raw.pop(10);lines('independent_native_trace.jsonl',raw)
        assert check()['checks']['independent_raw_native_window']['passed'] is False
        tests.append('missing_native_tick_rejects')
        raw.insert(10,gap);lines('independent_native_trace.jsonl',raw)
        cameras[0]['render_reference_time']['numerator']=0;lines('video_frame_clock.jsonl',cameras)
        assert check()['checks']['terminal_three_view_clock_join']['passed'] is False
        tests.append('stale_camera_rejects')
        cameras[0]['render_reference_time']['numerator']=35;lines('video_frame_clock.jsonl',cameras)
        published[10]['expected_sdk_batch_sequences'][robots[0]]=99999
        lines('assisted_trace.jsonl',published)
        assert check()['checks']['published_sdk_backend_actual_execution']['passed'] is False
        tests.append('SDK_sequence_mismatch_rejects')
        missing = audit.run_audit(root)
        assert missing['checks']['source_tools_assets_launch_binding']['passed'] is None
        assert missing['checks']['full_original_media_delivery']['passed'] is None
        assert not missing['accepted_full_assembly']
        tests.append('missing_source_and_media_are_null_and_reject')
        (root/'asset.usda').write_text('changed after freeze')
        assert check()['checks']['source_tools_assets_launch_binding']['passed'] is False
        tests.append('changed_composed_asset_rejects')
        empty = root/'init_failure';empty.mkdir()
        (empty/'exit_code').write_text('0\n')
        (empty/'runner.log').write_text('Traceback (most recent call last):\n2026-10-21 [Error] [py stderr]: FileNotFoundError: /work/https:/asset.usd\n')
        failed = audit.run_audit(empty)
        assert failed['original_main_report']['reported_success'] is None
        assert failed['process_observation']['exit_code'] == 0
        assert failed['process_observation']['log_exception'] == 'FileNotFoundError: /work/https:/asset.usd'
        assert failed['evidence_presence']['retained_images'] == 0
        assert not failed['accepted_full_assembly']
        tests.append('initialization_exception_exit_zero_no_report_rejects')
        print(json.dumps(dict(passed=True, checks=tests,
            scope='synthetic auditor logic only; no simulation/source/media success evidence'),indent=2))


if __name__ == '__main__':
    main()

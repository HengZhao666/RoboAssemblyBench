"""CC17 measured deadlock regression and bounded object feedback.

Helper tests use original45 step57722, a rigid payload with fixed 2.24mrad
orientation residual and a lagged position response. They do not model contact,
IK/publishing or native dynamics. Compiler/production routing is qualified separately.
"""
import copy
import unittest
from types import SimpleNamespace
import numpy as np
from toolkits.factory_dual_franka_assembly.plumbers_block_ur5e_skills import UR5eAssemblyAtomicSkillAdapter

KEY = 'beam_bar_lateral_alignment_object_feedback'
RECORDED = {'step': 57722, 'position_error_m': 0.0, 'quaternion_component_error': 0.0, 'alignment_active_replayed': True, 'original_motion_offset': 6313586, 'original_contact_offset': 142347, 'contact_validation_stage': 'contact_check', 'contact_physics_step_index': None, 'current_pose': {'position': [0.8292399885384666, -0.09476112023694078, 1.2442766277852924], 'orientation': [0.002227952965287547, 0.707391511924771, -0.7068172196697561, -0.0013050136729843786]}, 'target_pose': {'position': [0.8292366730791039, -0.09475495769124459, 1.235942218003002], 'orientation': [0.0015075462205775658, 0.7074035162292267, -0.706808177585458, -0.0004388954805576018]}, 'recorded_command_pose': {'position': [0.8292366730791039, -0.09475495769124459, 1.2443749019477042], 'orientation': [0.0015075462205775658, 0.7074035162292267, -0.706808177585458, -0.0004388954805576018]}, 'replayed_command_pose': {'position': [0.8292366730791039, -0.09475495769124459, 1.2443749019477042], 'orientation': [0.0015075462205775658, 0.7074035162292267, -0.706808177585458, -0.0004388954805576018]}, 'object_pose': {'position': [0.783826470375061, -0.12061888724565506, 1.0109326839447021], 'orientation': [0.9999987483024597, -5.0086477131117135e-05, 0.0015414183726534247, 0.0003476216515991837], 'attachment': {'mode': 'pure_physical_grasp'}}, 'phase_entry_axial_anchor': -1.0109326839447021}
SPEC = {'name': 'ur5e_move_part_to_staging', 'robot': 'franka_left', 'cartesian_servo': True, 'cartesian_position_step': 0.00025, 'cartesian_orientation_step': 0.012, 'guard_ik_branch_jump': True, 'ik_branch_jump_limit': 0.3, 'default_max_command_joint_step': 0.06, 'default_max_command_wrist_joint_step': 0.04, 'limit_command_to_measured_state': True, 'max_command_tracking_error': 0.12, 'max_wrist_command_tracking_error': 0.1, 'servo_target_object_pose': True, 'object': 'fabrica_beam_1', 'requires_held_object': True, 'target_object_target': 'part_1_assembled', 'gripper_command': 'contact_hold', 'lock_target_orientation': True, 'derive_tcp_orientation_from_target_object': True, 'ik_reference_mode': 'hybrid', 'ik_reference_command_max_tracking_error': 0.12, 'use_command_warm_start': True, 'require_warm_start_ik': True, 'cartesian_orientation_command_warm_start': True, 'cartesian_orientation_command_lookahead': 0.36, 'target_object_use_measured_orientation_for_position_servo': True, 'max_command_joint_step': 0.035, 'target_object_servo_position_command_warm_start': True, 'target_object_servo_position_command_gate_overdrive': True, 'target_object_servo_position_command_lookahead': 0.004, 'target_object_servo_position_command_accumulation_step': 0.0001, 'max_joint_step': 0.08, 'max_object_tcp_slip': 0.04, 'position_tolerance': 0.0015, 'relaxed_position_tolerance': 0.0015, 'relaxed_target_object_position_tolerance': 0.0015, 'relaxed_position_tolerance_after_steps': 600, 'target_object_convergence_axis': [0.0, 0.0, -1.0], 'target_object_lateral_position_tolerance': 0.001, 'target_object_lateral_alignment_cartesian_position_step': 0.00025, 'target_object_lateral_alignment_axial_clearance': 0.03543999991889886, 'target_object_insertion_path_depth': 0.0, 'target_object_lateral_alignment_stable_steps': 8, 'target_object_axial_recovery_cartesian_position_step': 0.001, 'target_object_axial_recovery_deadband': 0.0005, 'target_object_lateral_alignment_enter_tolerance': 0.0005, 'target_object_lateral_alignment_exit_tolerance': 0.001, 'orientation_tolerance': 0.025, 'require_target_object_pose_convergence': True, 'target_object_position_tolerance': 0.0015, 'target_object_orientation_tolerance': 0.025, 'require_target_object_static': True, 'target_object_max_linear_speed': 0.03, 'target_object_max_angular_speed': 2.0, 'target_object_allow_pose_stable_override': True, 'target_object_stable_steps': 8, 'hold_for_target_object_settle': True, 'target_object_settle_hold_steps': 48, 'target_object_settle_retry_servo_steps': 8, 'target_object_final_target': 'part_1_assembled', 'relax_fixed_attachment_within_final_position_tolerance': 0.015, 'relax_fixed_attachment_after_steps': 0, 'relax_fixed_attachment_require_waypoint_proximity': True, 'relax_fixed_attachment_waypoint_position_tolerance': 0.01, 'relax_fixed_attachment_geometric_capture_after_steps': 1200, 'relax_fixed_attachment_minimum_gravity_alignment': 0.7, 'relax_fixed_attachment_waypoint_axial_position_tolerance': 0.01, 'relax_fixed_attachment_waypoint_lateral_position_tolerance': 0.002, 'relax_fixed_attachment_final_orientation_tolerance': 0.15, 'relax_fixed_attachment_max_linear_speed': 0.1, 'relax_fixed_attachment_max_angular_speed': 2.0, 'relax_fixed_attachment_stable_steps': 8, 'relax_fixed_attachment_allow_pose_stable_override': True, 'compliant_servo_pause_linear_speed': 0.2, 'compliant_servo_pause_angular_speed': 5.0, 'compliant_servo_resume_linear_speed': 0.03, 'compliant_servo_resume_angular_speed': 2.0, 'compliant_servo_resume_stable_steps': 8, 'compliant_servo_allow_pose_stable_resume': True, 'target_object_allow_pose_history_velocity_override': True, 'pose_history_velocity_override_position_tolerance': 0.0005, 'pose_history_velocity_override_orientation_tolerance': 0.01, 'compliant_servo_settle_max_linear_speed': 0.1, 'compliant_servo_settle_max_angular_speed': 2.0, 'compliant_servo_settle_stable_steps': 24, 'compliant_servo_velocity_rate_limit': True, 'compliant_servo_minimum_step_scale': 0.2, 'compliant_servo_max_position_step': 0.0005, 'compliant_servo_position_command_warm_start': True, 'compliant_servo_position_command_gate_overdrive': True, 'compliant_servo_position_command_lookahead': 0.004, 'compliant_servo_position_command_accumulation_step': 0.0001, 'compliant_servo_max_lateral_step': 0.0005, 'compliant_servo_max_alignment_retraction': 0.006, 'compliant_servo_max_orientation_step': 0.002, 'compliant_servo_orientation_correction_deadband': 0.005, 'compliant_servo_hold_orientation_during_lateral_alignment': True, 'compliant_servo_track_object_orientation': True, 'target_object_entry_capture_max_steps': 12, 'track_published_grasp_command': True, 'use_arm_ik_controller': False, 'beam_coordinated': True, 'beam_bar_carry_peak_force_band_N': [18.0, 24.0]}
TARGET_OBJECT = {'position': [0.7844409166438082, -0.12056654334103567, 1.0025], 'orientation': [1., 0., 0., 0.]}


class BarInsertAlignment(unittest.TestCase):
    def setUp(self):
        self.adapter = UR5eAssemblyAtomicSkillAdapter({})
        self.spec = copy.deepcopy(SPEC)
        self.current = {k: np.asarray(v, dtype=float) for k, v in RECORDED['current_pose'].items()}
        self.target = {k: np.asarray(v, dtype=float) for k, v in RECORDED['target_pose'].items()}
        self.object = copy.deepcopy(RECORDED['object_pose'])
        self.task = SimpleNamespace(target_poses={'part_1_assembled': copy.deepcopy(TARGET_OBJECT)})
        self.key = ('test', 'franka_left', 'insert_09')
        self.gates = []
        original = self.adapter._cartesian_command_servo_target_pose
        def observe(**kwargs):
            self.gates.append(copy.deepcopy(kwargs['target_pose']))
            return original(**kwargs)
        self.adapter._cartesian_command_servo_target_pose = observe

    def call(self):
        command = self.adapter._target_object_servo_pose(
            phase_key=self.key, task=self.task, robot_name='franka_left',
            spec=self.spec, tracked_robots={},
            tracked_objects={self.spec['object']: self.object},
            current_pose=self.current, target_pose=self.target)
        self.adapter._remember_cartesian_command_position(phase_key=self.key, command_target_pose=command)
        self.adapter._remember_cartesian_command_orientation(phase_key=self.key, command_target_pose=command)
        return command

    def enable(self):
        self.spec[KEY] = {'gain': 0.5, 'max_offset_m': 0.001}

    def lateral_error(self):
        return float(np.linalg.norm(np.asarray(TARGET_OBJECT['position'])[:2] - np.asarray(self.object['position'])[:2]))

    def advance_rigid_lag(self, command):
        # Fixed measured orientation retains the original residual. The payload
        # translates rigidly with the TCP; only position follows a first-order lag.
        shift = 0.25 * (np.asarray(command['position']) - self.current['position'])
        self.current['position'] += shift
        self.object['position'] = (np.asarray(self.object['position']) + shift).tolist()

    def test_original_57722_reproduces_recorded_command_and_deadlock(self):
        command = self.call()
        np.testing.assert_array_equal(command['position'], RECORDED['recorded_command_pose']['position'])
        np.testing.assert_array_equal(command['orientation'], RECORDED['recorded_command_pose']['orientation'])
        np.testing.assert_allclose(self.gates[-1]['position'][:2], self.target['position'][:2], atol=0., rtol=0.)
        for _ in range(200):
            self.advance_rigid_lag(self.call())
        self.assertGreater(self.lateral_error(), 0.0005)
        self.assertTrue(self.adapter._insertion_lateral_alignment_active[self.key])

    def test_recorded_rigid_bar_with_lag_converges_and_exits_alignment(self):
        self.enable()
        target_x = TARGET_OBJECT['position'][0]
        initial_error = self.lateral_error()
        errors = []
        signed_x_errors = []
        for _ in range(200):
            self.advance_rigid_lag(self.call())
            errors.append(self.lateral_error())
            signed_x_errors.append(self.object['position'][0] - target_x)
            if not self.adapter._insertion_lateral_alignment_active[self.key]:
                break
        self.assertLess(errors[-1], initial_error)
        self.assertLessEqual(errors[-1], 0.0005)
        self.assertFalse(self.adapter._insertion_lateral_alignment_active[self.key])
        self.assertLess(max([0.] + signed_x_errors), 0.0001)
        self.assertLess(len(errors), 200)

    def test_positive_error_corrects_positive_x_preserves_depth_and_orientation(self):
        off = self.call(); base = copy.deepcopy(self.gates[-1])
        self.setUp(); self.enable(); on = self.call(); gate = self.gates[-1]
        self.assertGreater(gate['position'][0], base['position'][0])
        self.assertEqual(gate['position'][2], base['position'][2])
        np.testing.assert_array_equal(gate['orientation'], base['orientation'])
        np.testing.assert_array_equal(on['orientation'], off['orientation'])
        # Projection is onto an arbitrary convergence plane, not a z-only hack.
        self.setUp(); self.enable(); self.spec['target_object_convergence_axis'] = [0., -1., 0.]
        base_y = self.target['position'][1] + self.object['position'][1] - TARGET_OBJECT['position'][1]
        self.call(); self.assertAlmostEqual(self.gates[-1]['position'][1], base_y, places=14)

    def test_three_mm_error_clamps_gate_to_one_mm_without_runaway(self):
        self.enable()
        self.object['position'][0] = TARGET_OBJECT['position'][0] - .003
        self.object['position'][1] = TARGET_OBJECT['position'][1]
        tcp_offsets = []
        command_offsets = []
        for _ in range(1000):
            self.advance_rigid_lag(self.call())
            offset = self.gates[-1]['position'][:2] - self.target['position'][:2]
            self.assertAlmostEqual(np.linalg.norm(offset), .001, places=12)
            tcp_offsets.append(float(np.linalg.norm(self.current['position'][:2] - self.target['position'][:2])))
            command_offsets.append(float(np.linalg.norm(np.asarray(self.adapter._cartesian_command_positions[self.key])[:2] - self.target['position'][:2])))
        # The original command accumulator may lead the 1mm gate. Preserve it;
        # bound the transient by the unchanged 1.5mm TCP acceptance envelope.
        self.assertLess(max(tcp_offsets), .0015)
        self.assertLess(max(command_offsets), .0015)
        self.assertAlmostEqual(tcp_offsets[-1], .001, places=10)
        self.assertTrue(self.adapter._insertion_lateral_alignment_active[self.key])

    def test_flag_absent_parts_3_and_2_preserve_original_golden(self):
        for obj in ['fabrica_beam_3', 'fabrica_beam_2']:
            with self.subTest(obj=obj):
                self.setUp(); self.spec['object'] = obj
                command = self.call()
                np.testing.assert_array_equal(command['position'], RECORDED['recorded_command_pose']['position'])
                np.testing.assert_array_equal(command['orientation'], RECORDED['recorded_command_pose']['orientation'])

    def test_flag_absent_compliant_joint_preserves_original_golden(self):
        self.object['attachment']['mode'] = 'compliant_joint'
        command = self.call()
        np.testing.assert_array_equal(command['position'], [0.8294890863059967, -0.09473989991150683, 1.2442766277852924])
        np.testing.assert_array_equal(command['orientation'], RECORDED['current_pose']['orientation'])

    def test_compiler_changes_only_twenty_bar_insert_keys(self):
        import json, os
        from pathlib import Path
        candidate = json.loads(Path(os.environ['BEAM_COMPILED_WORKER_CONFIG']).read_text())
        baseline = json.loads(Path(os.environ['BEAM_BASELINE_WORKER_CONFIG']).read_text())
        expected = copy.deepcopy(baseline)
        names = []
        for phase in expected['phase_specs']:
            if phase['name'].startswith(('assemble_02_part_1_insert_', 'assemble_03_part_0_insert_')):
                phase['local_skill'][KEY] = {'gain':.5, 'max_offset_m':.001}
                names.append(phase['name'])
        self.assertEqual(set(names), {prefix + f'_insert_{i:02d}' for prefix in ['assemble_02_part_1', 'assemble_03_part_0'] for i in range(10)})
        expected['recipe_fingerprint'] = candidate['recipe_fingerprint']
        self.assertEqual(candidate, expected)

    def test_invalid_configs_and_wrong_scope_raise(self):
        invalid = [None, False, 'bad', {}, {'gain':.5}, {'gain':.5,'max_offset_m':.001,'extra':1}]
        for field in ['gain', 'max_offset_m']:
            for value in [True, '0.5', b'0.5', complex(1., 0.), float('nan'), float('inf'), 10**1000, 0., -.1]:
                item={'gain':.5,'max_offset_m':.001};item[field]=value;invalid.append(item)
        invalid += [{'gain':1.00001,'max_offset_m':.001}, {'gain':.5,'max_offset_m':.00100001}]
        for value in invalid:
            with self.subTest(value=value):
                self.setUp();self.spec[KEY]=value
                with self.assertRaises(ValueError):self.call()
        for field,value in [('object','fabrica_beam_2'),('requires_held_object',False)]:
            self.setUp();self.enable();self.spec[field]=value
            with self.assertRaises(ValueError):self.call()
        for mode in ['compliant_joint','fixed_joint',None]:
            self.setUp();self.enable();self.object['attachment']['mode']=mode
            with self.assertRaises(ValueError):self.call()


if __name__ == '__main__':
    unittest.main()
